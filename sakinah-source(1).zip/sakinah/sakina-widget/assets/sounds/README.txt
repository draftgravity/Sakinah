Sons de Sakinah
===============

Ce dossier contient les sons OPTIONNELS de l'application.

Adhan (appel à la prière)
-------------------------
Déposez ici un fichier nommé exactement :

    adhan.mp3

Il sera joué à l'heure de chaque prière (si l'option est activée dans
les Paramètres > Notifications). Vous pouvez télécharger un adhan libre
de droits depuis des sites comme archive.org (recherche : "adhan mp3").

Si aucun fichier n'est présent, Sakinah joue un bip discret
(configurable dans les paramètres) — rien à installer donc.

Bruit blanc / pluie
-------------------
Aucun fichier nécessaire : ces ambiances sont SYNTHÉTISÉES localement
par l'application (génération de bruit blanc et brownien en WAV).
