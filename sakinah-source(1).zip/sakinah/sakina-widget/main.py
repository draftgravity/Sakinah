"""
Sakinah — widget discret de prières et de focus pour Windows.

Point d'entrée de l'application. Responsabilités :
  * sensibilisation DPI (Windows) pour des coordonnées fiables en 4K ;
  * mise en place de la journalisation (sakinah.log) ;
  * création de l'application Qt + icône + thème sombre ;
  * garantie d'instance unique (QLocalServer) ;
  * démarrage du contrôleur principal (``app.controller.SakinahApp``).

Lancement :
    python main.py
"""

import sys

from PyQt6.QtWidgets import QApplication

from app.constants import APP_ID, APP_NAME, APP_VERSION
from app.controller import SakinahApp
from app.theme import apply_theme, build_app_icon
from app.utils.logger import setup_logging
from app.utils.single_instance import SingleInstanceGuard


def _enable_dpi_awareness() -> None:
    """Demande à Windows un rendu net en haute résolution.

    Doit être appelé AVANT la création du ``QApplication`` afin que
    ``win32gui`` renvoie des coordonnées « physiques » cohérentes avec
    la géométrie utilisée par Qt (détection plein écran, position du
    widget, etc.). Silencieusement ignoré hors Windows.
    """
    if sys.platform != "win32":
        return
    try:
        import ctypes

        ctypes.windll.shcore.SetProcessDpiAwareness(2)  # PER_MONITOR_DPI_AWARE
    except Exception:  # pragma: no cover - anciennes versions de Windows
        pass


def main() -> int:
    _enable_dpi_awareness()
    setup_logging()

    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setApplicationVersion(APP_VERSION)
    app.setOrganizationName(APP_NAME)
    # L'application vit dans la zone de notification : fermer la fenêtre
    # principale ne doit PAS quitter le processus.
    app.setQuitOnLastWindowClosed(False)
    app.setWindowIcon(build_app_icon())
    apply_theme(app)

    # --- Instance unique --------------------------------------------------
    guard = SingleInstanceGuard(APP_ID)
    if not guard.is_primary:
        # Une instance tourne déjà : on lui demande de montrer sa fenêtre
        # principale puis on quitte immédiatement.
        guard.notify_primary()
        return 0

    controller = SakinahApp(app)
    guard.show_requested.connect(controller.open_main_window)

    app.aboutToQuit.connect(controller.shutdown)
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
