# Sakinah — Widget de prières & de focus pour Windows

> **سكينة** (*sakīnah*, « tranquillité ») : un petit carré noir discret, toujours
> au premier plan de votre écran, qui veille sur vos horaires de prière et vous
> aide à rester concentré.

![Python 3.10+](https://img.shields.io/badge/Python-3.10%2B-10B981)
![PyQt6](https://img.shields.io/badge/UI-PyQt6-0A0A0B)
![Plateforme](https://img.shields.io/badge/Plateforme-Windows-10B981)
![Licence](https://img.shields.io/badge/Licence-MIT-10B981)

---

## Fonctionnalités

### Le widget overlay (le carré noir)
- Petit carré noir (36 px par défaut, configurable 24 → 56) aux coins arrondis,
  **positionné en haut à droite** de l'écran, **glissable** à la souris.
- **Toujours au premier plan**, absent de la barre des tâches et d'Alt+Tab,
  il ne vole jamais le focus des autres applications.
- **Mode discret** (option) : le carré devient *click-through* — il ne peut
  littéralement jamais bloquer un clic.
- **Détection du plein écran** : dès qu'un jeu (Valorant…) ou une vidéo passe
  en plein écran, le carré se masque automatiquement, et revient à la sortie.
- **Ctrl + Alt + H** (lettre configurable) : masque/affiche le widget depuis
  n'importe quelle application. Clic gauche **ou** droit : ouvre la fenêtre.
- **Instance unique** : un second lancement affiche simplement la fenêtre.

### Onglet Prières (Mawaqit)
- Horaires réels de **votre mosquée** via mawaqit.net (recherche par nom,
  ville ou code postal — ou slug direct).
- Fajr, Chourouk, Dhuhr, Asr, Maghrib, Isha : la **prochaine prière est
  surlignée** avec un **compte à rebours dynamique** rafraîchi chaque seconde.
- **Rappel 15 minutes avant** chaque prière (délai configurable).
- **Notification à l'heure exacte** : adhan (`assets/sounds/adhan.mp3`,
  fourni par vous) ou bip discret généré par l'application.
- **Bonus** : un encadré « Dhikr du moment » tire au hasard un dhikr / une
  duaa (texte arabe + translittération + traduction française) avec sa source.
- **Mode hors-ligne** : les derniers horaires sont mis en cache dans
  `config.json` et réaffichés si mawaqit.net est injoignable.

### Onglet Mode Focus (Pomodoro)
- Un bouton : **« C'est parti ! »** → tout l'écran **s'assombrit immédiatement**
  (voile noir à 85 % sur tous les écrans).
- **Grand minuteur épuré** au centre avec anneau de progression, décompte de
  **25 minutes** (15 / 45 / 50 possibles).
- **Échap** (n'importe où dans Windows) **ou la croix** → arrêt instantané,
  l'écran redevient normal.
- À la fin : **carillon de fin** et retour à l'écran normal.
- **Bonus** : compteur de **sessions réussies aujourd'hui**, ambiance sonore
  **bruit blanc** ou **pluie** (synthétisées localement, aucun fichier requis).

### Système & ergonomie
- **Icône dans la zone de notification** (tray) avec menu complet.
- **Lancement automatique avec Windows** (option dans les paramètres).
- **`config.json`** : mosquée, préférences de son, position du widget…
- Journal `sakinah.log` pour diagnostiquer facilement un problème.

---

## Installation

### Prérequis
- Windows 10 ou 11
- Python **3.10** ou plus récent ([python.org](https://www.python.org/downloads/)
  → cochez *« Add Python to PATH »*)

### Démarrage rapide
```bat
:: 1. Ouvrez un terminal dans le dossier du projet, puis :
python -m pip install -r requirements.txt

:: 2. Lancez Sakinah :
python main.py
```

Le carré noir apparaît en haut à droite de l'écran. Cliquez dessus pour
ouvrir la fenêtre, et choisissez votre mosquée dans **Paramètres → Mosquée**.

### Options recommandées
| Étape | Action |
|---|---|
| Adhan | Déposez `adhan.mp3` dans `assets/sounds/` |
| Démarrage auto | Paramètres → Système → « Lancer avec Windows » |
| Raccourci | Ctrl + Alt + H (lettre modifiable dans les paramètres) |

---

## Structure du projet

```
sakina-widget/
├── main.py                      # Point d'entrée (DPI, Qt, instance unique)
├── config.json                  # Préférences (mosquée, sons, widget…)
├── requirements.txt             # PyQt6, requests, pynput, pywin32
├── assets/sounds/               # adhan.mp3 optionnel + explications
├── data/dhikrs.json             # 12 dhikrs/duaas (arabe + français + source)
└── app/
    ├── constants.py             # Constantes (couleurs, prières, URLs…)
    ├── config.py                # ConfigManager (deep-merge, sauvegarde atomique)
    ├── theme.py                 # Thème sombre QSS + icône générée par code
    ├── controller.py            # Chef d'orchestre (câblage de tous les signaux)
    ├── overlay_widget.py        # Le carré noir (drag, click-through, topmost)
    ├── main_window.py           # Pop-up 2 onglets (flyout sous le carré)
    ├── tray_icon.py             # Zone de notification + toasts Windows
    ├── services/
    │   ├── mawaqit.py           # Client API Mawaqit (recherche + confData)
    │   └── prayer_service.py    # Ticker 1 s : prochaine prière, rappels
    ├── focus/
    │   └── focus_overlay.py     # Voile 85 % multi-écrans + anneau + minuteur
    ├── ui/
    │   ├── prayers_tab.py       # Horaires, bannière countdown, dhikr
    │   ├── focus_tab.py         # « C'est parti ! », ambiance, compteur
    │   └── settings_dialog.py   # Paramètres (5 onglets)
    └── utils/
        ├── win32_helpers.py     # Plein écran, click-through, topmost
        ├── hotkeys.py           # Ctrl+Alt+H global + Échap (pynput)
        ├── audio.py             # Adhan/bips/carillon/bruit blanc/pluie
        ├── autostart.py         # Clé de registre Run (HKCU)
        ├── single_instance.py   # Verrou QLocalServer
        └── logger.py            # Journalisation rotative
```

## Comment ça marche (techniquement)

- **Horaires** : la recherche utilise l'API publique
  `mawaqit.net/api/2.0/mosque/search?word=…` ; les horaires quotidiens sont
  extraits du JSON `confData` embarqué dans la page publique de la mosquée
  (`mawaqit.net/fr/<slug>`), qui contient aussi le calendrier annuel — utilisé
  pour connaître le Fajr de demain après Isha. Les requêtes s'exécutent dans
  des threads dédiés : l'interface ne gèle jamais.
- **Plein écran** : toutes les 1,5 s, `win32gui` compare la géométrie de la
  fenêtre au premier plan à celle de son écran (plein écran exclusif *et*
  sans bordures sont détectés ; le bureau et nos propres fenêtres sont exclus).
- **Topmost** : le carré ré-affirme sa position `HWND_TOPMOST` toutes les 5 s.
- **Sons** : bips `winsound`, carillon et bruits blanc/pluie **synthétisés**
  en WAV par le module standard `wave` — zéro fichier à télécharger.
- **Focus** : une fenêtre frameless translucide par écran (voile à 85 %),
  minuteur ancré sur une échéance (`end - now`) pour rester exact même si
  l'ordinateur ralentit, Échap global via pynput.

## Dépannage

| Problème | Solution |
|---|---|
| Le carré disparaît pendant un jeu | C'est voulu (plein écran). Ctrl+Alt+H pour l'afficher, ou désactivez « Masquer en plein écran » dans les paramètres. |
| Pas d'adhan | Déposez `assets/sounds/adhan.mp3` (nom exact) et activez l'option dans les paramètres. |
| Horaires vides | Vérifiez le slug dans Paramètres → Mosquée (testez sur mawaqit.net), puis « Actualiser ». |
| Le carré bloque un clic | Activez le « Mode discret (click-through) » dans Paramètres → Widget. |
| Où sont mes réglages ? | Tout est dans `config.json`, à côté de `main.py`. |

## Feuille de route (idées v2)

- Date hégirienne dans l'onglet Prières
- Iqama (délais affichés à côté des horaires)
- Pauses courtes / longues Pomodoro avec cycle complet
- Statistiques hebdomadaires de focus (graphique)
- Compilation en `.exe` autonome (PyInstaller)

## Crédits & licence

- Horaires de prière : [mawaqit.net](https://mawaqit.net) — merci à leur
  équipe pour leur travail bénévole.
- Interface : [PyQt6](https://www.riverbankcomputing.com/software/pyqt/)
- Code publié sous licence MIT.
