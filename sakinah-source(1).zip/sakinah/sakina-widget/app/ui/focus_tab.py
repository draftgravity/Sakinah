"""
Onglet « Mode Focus » (Pomodoro 25 minutes).

* gros bouton circulaire « C'est parti ! » (ou minuteur pendant la session) ;
* durée configurable (15 / 25 / 45 / 50 min — 25 par défaut) ;
* ambiance sonore optionnelle : aucune / bruit blanc / pluie + volume ;
* compteur de sessions réussies aujourd'hui (points + total) ;
* rappels ergonomiques : « Échap pour arrêter à tout moment »,
  « l'écran s'assombrit à 85 % pendant la session ».

Le lancement réel (voile plein écran, minuteur, son de fin) est piloté par
le contrôleur via le signal ``start_requested``.
"""

from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtWidgets import (
    QComboBox,
    QFrame,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QSlider,
    QVBoxLayout,
    QWidget,
)

from app.constants import FOCUS_DEFAULT_MINUTES, FOCUS_SOUND_KINDS, FOCUS_SOUND_LABELS
from app.focus.focus_overlay import format_clock
from app.utils.logger import get_logger

logger = get_logger("focus-tab")


class FocusTab(QWidget):
    """Onglet complet « Mode Focus »."""

    start_requested = pyqtSignal(int, str, float)   # (durée s, son, volume)

    def __init__(self, config, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.config = config
        self._running = False

        root = QVBoxLayout(self)
        root.setContentsMargins(14, 16, 14, 14)
        root.setSpacing(14)

        # --- Titre ---------------------------------------------------------
        title = QLabel("Mode Focus — Pomodoro")
        title.setProperty("heading", True)
        root.addWidget(title)

        subtitle = QLabel(
            "L'écran s'assombrit, le minuteur démarre. Une session = 25 minutes "
            "de concentration profonde."
        )
        subtitle.setProperty("small", True)
        subtitle.setWordWrap(True)
        root.addWidget(subtitle)

        root.addStretch(1)

        # --- Bouton principal circulaire -------------------------------------
        button_row = QHBoxLayout()
        button_row.addStretch(1)
        self.start_button = QPushButton("C'est parti !")
        self.start_button.setObjectName("PrimaryButton")
        size = 168
        self.start_button.setFixedSize(size, size)
        self.start_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.start_button.setStyleSheet(
            f"""
            QPushButton#PrimaryButton {{
                border-radius: {size // 2}px;
                font-size: 17px; font-weight: 800;
            }}
            """
        )
        self.start_button.clicked.connect(self._on_start)
        button_row.addWidget(self.start_button)
        button_row.addStretch(1)
        root.addLayout(button_row)

        root.addStretch(1)

        # --- Réglages : durée / ambiance / volume -----------------------------
        settings = QFrame()
        settings.setObjectName("Card")
        settings_layout = QVBoxLayout(settings)
        settings_layout.setContentsMargins(14, 12, 14, 12)
        settings_layout.setSpacing(10)

        duration_row = QHBoxLayout()
        duration_label = QLabel("Durée de la session")
        duration_row.addWidget(duration_label)
        duration_row.addStretch(1)
        self.duration_combo = QComboBox()
        for minutes in (15, 25, 45, 50):
            self.duration_combo.addItem(f"{minutes} minutes", minutes)
        default_minutes = int(config.get("focus.duration_minutes", FOCUS_DEFAULT_MINUTES))
        index = self.duration_combo.findData(default_minutes)
        self.duration_combo.setCurrentIndex(max(0, index))
        duration_row.addWidget(self.duration_combo)
        settings_layout.addLayout(duration_row)

        sound_row = QHBoxLayout()
        sound_label = QLabel("Ambiance sonore")
        sound_row.addWidget(sound_label)
        sound_row.addStretch(1)
        self.sound_combo = QComboBox()
        for kind in FOCUS_SOUND_KINDS:
            self.sound_combo.addItem(FOCUS_SOUND_LABELS[kind], kind)
        current_sound = config.get("focus.sound", "none")
        if current_sound in FOCUS_SOUND_KINDS:
            self.sound_combo.setCurrentIndex(FOCUS_SOUND_KINDS.index(current_sound))
        sound_row.addWidget(self.sound_combo)
        settings_layout.addLayout(sound_row)

        volume_row = QHBoxLayout()
        volume_label = QLabel("Volume de l'ambiance")
        volume_row.addWidget(volume_label)
        volume_row.addStretch(1)
        self.volume_slider = QSlider(Qt.Orientation.Horizontal)
        self.volume_slider.setRange(0, 100)
        self.volume_slider.setValue(int(float(config.get("focus.volume", 0.6)) * 100))
        self.volume_slider.setMaximumWidth(140)
        volume_row.addWidget(self.volume_slider)
        settings_layout.addLayout(volume_row)

        root.addWidget(settings)

        # --- Compteur du jour -------------------------------------------------
        counter = QFrame()
        counter.setObjectName("Card")
        counter_layout = QHBoxLayout(counter)
        counter_layout.setContentsMargins(14, 10, 14, 10)

        counter_label = QLabel("Sessions réussies aujourd'hui")
        counter_layout.addWidget(counter_label)
        counter_layout.addStretch(1)

        self.dots_label = QLabel()
        self.dots_label.setStyleSheet("color: #34D399; letter-spacing: 3px;")
        counter_layout.addWidget(self.dots_label)

        self.count_label = QLabel("0")
        self.count_label.setStyleSheet(
            "font-size: 20px; font-weight: 800; color: #34D399;"
        )
        counter_layout.addWidget(self.count_label)
        root.addWidget(counter)

        # --- Aide -------------------------------------------------------------
        hint = QLabel(
            "Échap (ou la croix) arrête la session à tout moment. "
            "À la fin : carillon de fin et retour à l'écran normal."
        )
        hint.setProperty("small", True)
        hint.setWordWrap(True)
        root.addWidget(hint)

    # ------------------------------------------------------------------ API
    def _on_start(self) -> None:
        if self._running:
            return
        minutes = self.duration_combo.currentData() or FOCUS_DEFAULT_MINUTES
        kind = self.sound_combo.currentData() or "none"
        volume = self.volume_slider.value() / 100.0
        # Mémorise les préférences pour la prochaine fois (sauvegarde
        # immédiate : rien n'est perdu en cas de crash ou d'extinction).
        self.config.set("focus.duration_minutes", minutes, autosave=True)
        self.config.set("focus.sound", kind, autosave=True)
        self.config.set("focus.volume", volume, autosave=True)
        self.start_requested.emit(int(minutes * 60), kind, volume)

    def set_running(self, running: bool) -> None:
        """État du bouton pendant / hors session."""
        self._running = running
        self.start_button.setEnabled(not running)
        if running:
            self.start_button.setText("En cours…")
        else:
            self.start_button.setText("C'est parti !")

    def update_remaining(self, seconds: int) -> None:
        """Affiche le décompte sur le bouton pendant la session."""
        if self._running:
            self.start_button.setText(format_clock(seconds))

    def update_sessions(self, count: int) -> None:
        """Rafraîchit le compteur du jour (points ● + total)."""
        self.count_label.setText(str(count))
        self.dots_label.setText("●" * min(count, 8) + ("…" if count > 8 else ""))
