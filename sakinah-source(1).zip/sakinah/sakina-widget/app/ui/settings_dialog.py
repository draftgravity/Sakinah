"""
Boîte de dialogue « Paramètres ».

Cinq onglets :
  * Mosquée : recherche Mawaqit par mot-clé + saisie directe du slug ;
  * Notifications : activation, délai du rappel, adhan / bip, test sonore ;
  * Widget : taille, mode discret (click-through), masquage plein écran,
    réinitialisation de la position ;
  * Focus : durée et ambiance par défaut ;
  * Système : démarrage automatique avec Windows, lettre du raccourci
    global (Ctrl + Alt + <lettre>), à propos.

La recherche Mawaqit s'exécute dans un thread pour ne jamais figer la
fenêtre ; les résultats s'affichent dans une liste cliquable.
"""

import threading

from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QPushButton,
    QSlider,
    QSpinBox,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from app.config import ConfigManager
from app.constants import (
    APP_NAME,
    APP_VERSION,
    DEFAULT_HOTKEY_LETTER,
    FOCUS_SOUND_KINDS,
    FOCUS_SOUND_LABELS,
    WIDGET_MAX_SIZE,
    WIDGET_MIN_SIZE,
)
from app.services import mawaqit
from app.utils import autostart as autostart_util
from app.utils.logger import get_logger

logger = get_logger("settings")


class SettingsDialog(QDialog):
    """Paramètres de Sakinah — émet ``settings_saved`` après « Enregistrer »."""

    settings_saved = pyqtSignal()
    test_sound_requested = pyqtSignal()
    # (jeton anti-inversion, résultats) + message d'erreur éventuel.
    # Signal obligatoire : le worker tourne dans un thread Python sans
    # boucle d'événements Qt, un QTimer.singleShot y serait ignoré (C1).
    search_done = pyqtSignal(object, str)

    def __init__(self, config: ConfigManager, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.config = config
        self.selected_slug: str | None = None
        self.selected_name: str | None = None
        self.mosque_changed = False
        self._reset_widget_position = False
        self._search_token = 0
        self.search_done.connect(self._fill_results)

        self.setWindowTitle(f"{APP_NAME} — Paramètres")
        self.setModal(True)
        self.resize(520, 600)

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 12)
        root.setSpacing(12)

        self.tabs = QTabWidget()
        self.tabs.addTab(self._build_mosque_tab(), "Mosquée")
        self.tabs.addTab(self._build_notifications_tab(), "Notifications")
        self.tabs.addTab(self._build_widget_tab(), "Widget")
        self.tabs.addTab(self._build_focus_tab(), "Focus")
        self.tabs.addTab(self._build_system_tab(), "Système")
        root.addWidget(self.tabs, 1)

        buttons = QHBoxLayout()
        buttons.addStretch(1)
        cancel = QPushButton("Annuler")
        cancel.clicked.connect(self.reject)
        buttons.addWidget(cancel)
        save = QPushButton("Enregistrer")
        save.setObjectName("PrimaryButton")
        save.clicked.connect(self._on_save)
        buttons.addWidget(save)
        root.addLayout(buttons)

    # ------------------------------------------------------------ onglets
    def _build_mosque_tab(self) -> QWidget:
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setSpacing(10)

        current = QLabel(
            f"Mosquée actuelle : {self.config.get('mosque.name', '—')}\n"
            f"Slug Mawaqit : {self.config.get('mosque.slug', '—')}"
        )
        current.setProperty("small", True)
        layout.addWidget(current)

        # --- Recherche par mot-clé ------------------------------------------
        search_label = QLabel("Rechercher une mosquée (nom, ville, code postal) :")
        layout.addWidget(search_label)

        search_row = QHBoxLayout()
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("ex. Versailles, 75011, essalam…")
        self.search_input.returnPressed.connect(self._search)
        search_row.addWidget(self.search_input, 1)

        search_btn = QPushButton("Rechercher")
        search_btn.clicked.connect(self._search)
        search_row.addWidget(search_btn)
        layout.addLayout(search_row)

        self.results_list = QListWidget()
        self.results_list.itemClicked.connect(self._on_result_clicked)
        layout.addWidget(self.results_list, 1)

        self.selection_label = QLabel("Aucune sélection — la mosquée actuelle est conservée.")
        self.selection_label.setProperty("small", True)
        self.selection_label.setWordWrap(True)
        layout.addWidget(self.selection_label)

        # --- Saisie directe du slug -------------------------------------------
        slug_label = QLabel("Ou coller directement un slug Mawaqit :")
        layout.addWidget(slug_label)
        slug_row = QHBoxLayout()
        self.slug_input = QLineEdit()
        self.slug_input.setPlaceholderText("ex. grande-mosquee-de-paris")
        self.slug_input.textChanged.connect(self._on_slug_changed)
        slug_row.addWidget(self.slug_input, 1)
        layout.addLayout(slug_row)

        hint = QLabel(
            "Le slug est la fin de l'URL de la page mawaqit.net de votre mosquée :\n"
            "https://mawaqit.net/fr/<b>grande-mosquee-de-paris</b>"
        )
        hint.setProperty("small", True)
        layout.addWidget(hint)
        return tab

    def _build_notifications_tab(self) -> QWidget:
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setSpacing(12)

        self.chk_notifications = QCheckBox("Activer les notifications de prières")
        self.chk_notifications.setChecked(self.config.get("notifications.enabled", True))
        layout.addWidget(self.chk_notifications)

        delay_row = QHBoxLayout()
        delay_row.addWidget(QLabel("Rappel avant chaque prière :"))
        delay_row.addStretch(1)
        self.spin_minutes = QSpinBox()
        self.spin_minutes.setRange(1, 60)
        self.spin_minutes.setSuffix(" min")
        self.spin_minutes.setValue(int(self.config.get("notifications.minutes_before", 15)))
        delay_row.addWidget(self.spin_minutes)
        layout.addLayout(delay_row)

        self.chk_adhan = QCheckBox("Jouer l'adhan à l'heure de la prière (assets/sounds/adhan.mp3)")
        self.chk_adhan.setChecked(self.config.get("notifications.adhan_enabled", True))
        layout.addWidget(self.chk_adhan)

        self.chk_beep = QCheckBox("Bip discret si aucun fichier adhan n'est présent")
        self.chk_beep.setChecked(self.config.get("notifications.beep_fallback", True))
        layout.addWidget(self.chk_beep)

        # Volume dédié aux sons de prière (indépendant de l'ambiance focus — M2).
        volume_row = QHBoxLayout()
        volume_row.addWidget(QLabel("Volume de l'adhan / des bips :"))
        volume_row.addStretch(1)
        self.adhan_volume = QSlider(Qt.Orientation.Horizontal)
        self.adhan_volume.setRange(0, 100)
        self.adhan_volume.setMaximumWidth(140)
        self.adhan_volume.setValue(
            int(float(self.config.get("notifications.volume", 1.0)) * 100)
        )
        volume_row.addWidget(self.adhan_volume)
        layout.addLayout(volume_row)

        test_row = QHBoxLayout()
        test_row.addStretch(1)
        test_btn = QPushButton("Tester le son")
        test_btn.clicked.connect(self._test_sound_requested)
        test_row.addWidget(test_btn)
        layout.addLayout(test_row)

        layout.addStretch(1)
        return tab

    def _build_widget_tab(self) -> QWidget:
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setSpacing(12)

        size_row = QHBoxLayout()
        size_row.addWidget(QLabel("Taille du carré :"))
        size_row.addStretch(1)
        self.spin_size = QSpinBox()
        self.spin_size.setRange(WIDGET_MIN_SIZE, WIDGET_MAX_SIZE)
        self.spin_size.setSuffix(" px")
        self.spin_size.setValue(int(self.config.get("widget.size", 36)))
        size_row.addWidget(self.spin_size)
        layout.addLayout(size_row)

        self.chk_click_through = QCheckBox(
            "Mode discret : le carré ne bloque jamais les clics (click-through)\n"
            "— dans ce mode, seul le raccourci Ctrl+Alt+H ouvre l'application."
        )
        self.chk_click_through.setChecked(self.config.get("widget.click_through", False))
        layout.addWidget(self.chk_click_through)

        self.chk_fullscreen = QCheckBox(
            "Masquer automatiquement le carré quand une application\n"
            "est en plein écran (jeux, vidéos…)"
        )
        self.chk_fullscreen.setChecked(self.config.get("widget.hide_on_fullscreen", True))
        layout.addWidget(self.chk_fullscreen)

        reset_row = QHBoxLayout()
        reset_row.addStretch(1)
        reset_btn = QPushButton("Réinitialiser la position (haut-droite)")
        reset_btn.clicked.connect(self._reset_position_requested)
        reset_row.addWidget(reset_btn)
        layout.addLayout(reset_row)

        layout.addStretch(1)
        return tab

    def _build_focus_tab(self) -> QWidget:
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setSpacing(12)

        duration_row = QHBoxLayout()
        duration_row.addWidget(QLabel("Durée par défaut :"))
        duration_row.addStretch(1)
        self.focus_duration = QComboBox()
        for minutes in (15, 25, 45, 50):
            self.focus_duration.addItem(f"{minutes} minutes", minutes)
        index = self.focus_duration.findData(
            int(self.config.get("focus.duration_minutes", 25))
        )
        self.focus_duration.setCurrentIndex(max(0, index))
        duration_row.addWidget(self.focus_duration)
        layout.addLayout(duration_row)

        sound_row = QHBoxLayout()
        sound_row.addWidget(QLabel("Ambiance sonore par défaut :"))
        sound_row.addStretch(1)
        self.focus_sound = QComboBox()
        for kind in FOCUS_SOUND_KINDS:
            self.focus_sound.addItem(FOCUS_SOUND_LABELS[kind], kind)
        current = self.config.get("focus.sound", "none")
        if current in FOCUS_SOUND_KINDS:
            self.focus_sound.setCurrentIndex(FOCUS_SOUND_KINDS.index(current))
        sound_row.addWidget(self.focus_sound)
        layout.addLayout(sound_row)

        note = QLabel(
            "Les sons d'ambiance (bruit blanc, pluie) sont générés localement, "
            "aucun fichier à télécharger."
        )
        note.setProperty("small", True)
        note.setWordWrap(True)
        layout.addWidget(note)

        layout.addStretch(1)
        return tab

    def _build_system_tab(self) -> QWidget:
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setSpacing(12)

        self.chk_autostart = QCheckBox("Lancer Sakinah automatiquement avec Windows")
        self.chk_autostart.setChecked(self.config.get("general.autostart", False))
        layout.addWidget(self.chk_autostart)

        hotkey_row = QHBoxLayout()
        hotkey_row.addWidget(QLabel("Raccourci global d'affichage :"))
        hotkey_row.addStretch(1)
        hotkey_fixed = QLabel("Ctrl + Alt +")
        hotkey_row.addWidget(hotkey_fixed)
        self.hotkey_letter = QLineEdit()
        self.hotkey_letter.setMaxLength(1)
        self.hotkey_letter.setFixedWidth(44)
        self.hotkey_letter.setAlignment(Qt.AlignmentFlag.AlignCenter)
        letter = self.config.get("general.hotkey_letter", DEFAULT_HOTKEY_LETTER)
        self.hotkey_letter.setText((letter or DEFAULT_HOTKEY_LETTER)[:1])
        hotkey_row.addWidget(self.hotkey_letter)
        layout.addLayout(hotkey_row)

        about = QLabel(
            f"<b>{APP_NAME}</b> v{APP_VERSION} — widget de prières & de focus.\n"
            "Horaires : mawaqit.net · Interface : PyQt6 · Sons générés localement."
        )
        about.setProperty("small", True)
        about.setWordWrap(True)
        layout.addWidget(about)

        layout.addStretch(1)
        return tab

    # ------------------------------------------------------------ actions
    def _search(self) -> None:
        """Lance la recherche Mawaqit dans un thread (UI jamais bloquée)."""
        word = self.search_input.text().strip()
        if len(word) < 2:
            return
        self._search_token += 1
        token = self._search_token     # jeton anti-inversion des réponses
        self.results_list.clear()
        loading = QListWidgetItem(f"Recherche de « {word} »…")
        loading.setFlags(Qt.ItemFlag.NoItemFlags)
        self.results_list.addItem(loading)

        def worker() -> None:
            try:
                results = mawaqit.search_mosques(word)
                self.search_done.emit((token, results), "")
            except Exception as exc:
                logger.warning("Recherche échouée : %s", exc)
                # NB : capturer le message AVANT l'émission — Python supprime
                # `exc` à la sortie du bloc except.
                self.search_done.emit((token, None), str(exc))

        threading.Thread(target=worker, name="mawaqit-search", daemon=True).start()

    def _fill_results(self, payload, error: str = "") -> None:
        """Reçoit (jeton, résultats) — ignore les réponses obsolètes."""
        token, results = payload
        if token != self._search_token:
            return          # une recherche plus récente est déjà arrivée
        self.results_list.clear()
        if error:
            item = QListWidgetItem(f"Erreur : {error}")
            item.setFlags(Qt.ItemFlag.NoItemFlags)
            self.results_list.addItem(item)
            return
        if not results:
            item = QListWidgetItem("Aucune mosquée trouvée pour cette recherche.")
            item.setFlags(Qt.ItemFlag.NoItemFlags)
            self.results_list.addItem(item)
            return
        for mosque in results:
            display = f"{mosque.name}\n{mosque.localisation}"
            item = QListWidgetItem(display)
            item.setData(Qt.ItemDataRole.UserRole, (mosque.slug, mosque.name))
            self.results_list.addItem(item)

    def _on_result_clicked(self, item: QListWidgetItem) -> None:
        payload = item.data(Qt.ItemDataRole.UserRole)
        if not payload:
            return
        self.selected_slug, self.selected_name = payload
        self.slug_input.setText(payload[0])
        self.selection_label.setText(
            f"Sélection : {payload[1]} ({payload[0]})"
        )

    def _on_slug_changed(self, text: str) -> None:
        text = text.strip()
        if text and text != self.selected_slug:
            self.selected_slug = text
            self.selected_name = text
            self.selection_label.setText(f"Sélection (slug direct) : {text}")

    def _test_sound_requested(self) -> None:
        """Le contrôleur (branché sur ``test_sound_requested``) joue le son."""
        self.test_sound_requested.emit()

    def _reset_position_requested(self) -> None:
        self._reset_widget_position = True

    # ------------------------------------------------------------ save
    def _on_save(self) -> None:
        """Enregistre tous les réglages dans config.json puis ferme."""
        if self.selected_slug:
            self.config.set("mosque.slug", self.selected_slug)
            self.config.set("mosque.name", self.selected_name or self.selected_slug)
            self.mosque_changed = True
        self.config.set("notifications.enabled", self.chk_notifications.isChecked())
        self.config.set("notifications.minutes_before", self.spin_minutes.value())
        self.config.set("notifications.adhan_enabled", self.chk_adhan.isChecked())
        self.config.set("notifications.beep_fallback", self.chk_beep.isChecked())
        self.config.set("notifications.volume", self.adhan_volume.value() / 100.0)

        self.config.set("widget.size", self.spin_size.value())
        self.config.set("widget.click_through", self.chk_click_through.isChecked())
        self.config.set("widget.hide_on_fullscreen", self.chk_fullscreen.isChecked())
        if getattr(self, "_reset_widget_position", False):
            self.config.set("widget.position", None)

        self.config.set(
            "focus.duration_minutes", self.focus_duration.currentData() or 25
        )
        self.config.set("focus.sound", self.focus_sound.currentData() or "none")

        autostart = self.chk_autostart.isChecked()
        self.config.set("general.autostart", autostart)
        autostart_util.set_autostart(autostart)

        letter = self.hotkey_letter.text().strip().lower()
        self.config.set("general.hotkey_letter", letter or DEFAULT_HOTKEY_LETTER)

        self.config.save()
        self.settings_saved.emit()
        self.accept()
