"""Composants d'interface : onglets (prières, focus) et boîte Paramètres."""
