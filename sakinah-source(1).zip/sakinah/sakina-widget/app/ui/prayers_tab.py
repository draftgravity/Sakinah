"""
Onglet « Prières » : horaires Mawaqit du jour.

Contenu :
  * carte mosquée : nom, adresse, date du jour (FR), Jumu'a le vendredi,
    boutons « actualiser » et « changer de mosquée » ;
  * bannière « prochaine prière » avec compte à rebours dynamique ;
  * les 6 horaires (Chourouk grisé — ce n'est pas une prière) avec
    surbrillance de la prochaine ;
  * encadré bonus : dhikr / duaa aléatoire tiré de data/dhikrs.json,
    avec bouton « un autre ».
"""

import json
import random

from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from app.constants import (
    DHIKRS_PATH,
    PRAYERS,
    PRAYER_ARABIC,
    PRAYER_LABELS,
)
from app.services.mawaqit import MosqueData
from app.theme import arabic_font
from app.utils.logger import get_logger

logger = get_logger("prayers-tab")


class PrayerRow(QFrame):
    """Une ligne d'horaire : nom FR + nom arabe + heure à droite."""

    def __init__(self, key: str, is_sunrise: bool, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.key = key
        self.setObjectName("PrayerRow")

        layout = QHBoxLayout(self)
        layout.setContentsMargins(12, 9, 12, 9)

        name = QLabel(PRAYER_LABELS[key])
        if is_sunrise:
            name.setStyleSheet("color: #A1A1AA;")
        layout.addWidget(name)

        arabic = QLabel(PRAYER_ARABIC[key])
        arabic.setLayoutDirection(Qt.LayoutDirection.RightToLeft)
        arabic.setFont(arabic_font(11))
        arabic.setStyleSheet("color: #52525B;")
        layout.addWidget(arabic)

        layout.addStretch(1)

        self.time_label = QLabel("--:--")
        self.time_label.setStyleSheet(
            "font-size: 15px; font-weight: 700; letter-spacing: 1px;"
            + ("color: #A1A1AA;" if is_sunrise else "")
        )
        layout.addWidget(self.time_label)

    def set_time(self, value) -> None:
        self.time_label.setText(value.strftime("%H:%M") if value else "--:--")

    def set_next(self, is_next: bool) -> None:
        """Active/désactive la surbrillance « prochaine prière »."""
        self.setObjectName("PrayerRowNext" if is_next else "PrayerRow")
        # Force Qt à ré-appliquer le QSS du nouvel objectName :
        self.style().unpolish(self)
        self.style().polish(self)


class DhikrCard(QFrame):
    """Encadré bonus : dhikr ou duaa aléatoire + bouton « un autre »."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("Card")
        self._dhikrs: list[dict] = []
        try:
            self._dhikrs = json.loads(DHIKRS_PATH.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            logger.warning("dhikrs.json illisible : %s", exc)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(14, 12, 14, 14)
        outer.setSpacing(8)

        header = QHBoxLayout()
        title = QLabel("DHIKR DU MOMENT")
        title.setProperty("small", True)
        title.setStyleSheet("color: #34D399; letter-spacing: 2px; font-weight: 700;")
        header.addWidget(title)
        header.addStretch(1)

        shuffle_btn = QPushButton("Un autre")
        shuffle_btn.setObjectName("GhostButton")
        shuffle_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        shuffle_btn.clicked.connect(self.roll)
        header.addWidget(shuffle_btn)
        outer.addLayout(header)

        self.arabic_label = QLabel()
        self.arabic_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.arabic_label.setFont(arabic_font(19))
        self.arabic_label.setWordWrap(True)
        self.arabic_label.setLayoutDirection(Qt.LayoutDirection.RightToLeft)
        outer.addWidget(self.arabic_label)

        self.translit_label = QLabel()
        self.translit_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.translit_label.setStyleSheet("font-style: italic; color: #A1A1AA;")
        self.translit_label.setWordWrap(True)
        outer.addWidget(self.translit_label)

        self.french_label = QLabel()
        self.french_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.french_label.setWordWrap(True)
        outer.addWidget(self.french_label)

        self.note_label = QLabel()
        self.note_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.note_label.setProperty("small", True)
        self.note_label.setWordWrap(True)
        outer.addWidget(self.note_label)

        self.roll()

    def roll(self, force_new: bool = False) -> None:
        """Tire un dhikr au hasard — différent du précédent si possible."""
        if not self._dhikrs:
            self.arabic_label.setText("—")
            return
        previous = self.arabic_label.text()
        pick = random.choice(self._dhikrs)
        # Évite de retomber sur le même dhikr que celui affiché.
        for _ in range(6):
            if not force_new or pick.get("arabic", "") != previous:
                break
            pick = random.choice(self._dhikrs)
        self.arabic_label.setText(pick.get("arabic", ""))
        self.translit_label.setText(pick.get("transliteration", ""))
        self.french_label.setText(pick.get("french", ""))
        note = pick.get("note", "")
        source = pick.get("source", "")
        self.note_label.setText(" ".join(filter(None, [note, f"— {source}" if source else ""])))


class PrayersTab(QWidget):
    """Onglet complet « Prières »."""

    refresh_requested = pyqtSignal()
    change_mosque_requested = pyqtSignal()

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.rows: dict[str, PrayerRow] = {}
        self._data: MosqueData | None = None
        self._next_key: str | None = None

        root = QVBoxLayout(self)
        root.setContentsMargins(14, 12, 14, 14)
        root.setSpacing(10)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        content = QWidget()
        content.setStyleSheet("background: transparent;")
        self.layout_content = QVBoxLayout(content)
        self.layout_content.setContentsMargins(0, 0, 4, 0)
        self.layout_content.setSpacing(10)
        scroll.setWidget(content)
        root.addWidget(scroll, 1)

        # --- Carte mosquée -------------------------------------------------
        mosque_card = QFrame()
        mosque_card.setObjectName("Card")
        mosque_layout = QVBoxLayout(mosque_card)
        mosque_layout.setContentsMargins(14, 12, 14, 12)
        mosque_layout.setSpacing(2)

        top_row = QHBoxLayout()
        self.mosque_name = QLabel("Chargement des horaires…")
        self.mosque_name.setProperty("heading", True)
        top_row.addWidget(self.mosque_name, 1)
        refresh_btn = QPushButton("Actualiser")
        refresh_btn.setObjectName("GhostButton")
        refresh_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        refresh_btn.clicked.connect(self.refresh_requested.emit)
        top_row.addWidget(refresh_btn)
        change_btn = QPushButton("Changer")
        change_btn.setObjectName("GhostButton")
        change_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        change_btn.clicked.connect(self.change_mosque_requested.emit)
        top_row.addWidget(change_btn)
        mosque_layout.addLayout(top_row)

        self.mosque_location = QLabel()
        self.mosque_location.setProperty("small", True)
        mosque_layout.addWidget(self.mosque_location)

        self.date_label = QLabel()
        self.date_label.setProperty("small", True)
        self.date_label.setStyleSheet("color: #34D399;")
        mosque_layout.addWidget(self.date_label)

        self.layout_content.addWidget(mosque_card)

        # --- Bannière prochaine prière ---------------------------------------
        banner = QFrame()
        banner.setObjectName("NextBanner")
        banner_layout = QVBoxLayout(banner)
        banner_layout.setContentsMargins(14, 12, 14, 12)
        banner_layout.setSpacing(1)

        banner_title = QLabel("PROCHAINE PRIÈRE")
        banner_title.setProperty("small", True)
        banner_title.setStyleSheet("color: #6EE7B7; letter-spacing: 2px; font-weight: 700;")
        banner_layout.addWidget(banner_title)

        self.banner_main = QLabel("—")
        self.banner_main.setStyleSheet("font-size: 19px; font-weight: 800;")
        banner_layout.addWidget(self.banner_main)

        self.banner_countdown = QLabel()
        self.banner_countdown.setStyleSheet("color: #A7F3D0; font-size: 14px;")
        banner_layout.addWidget(self.banner_countdown)

        self.layout_content.addWidget(banner)

        # --- Lignes d'horaires ------------------------------------------------
        for key, _, _, is_real_prayer in PRAYERS:
            row = PrayerRow(key, is_sunrise=not is_real_prayer)
            self.rows[key] = row
            self.layout_content.addWidget(row)

        # --- Dhikr bonus -------------------------------------------------------
        self.dhikr_card = DhikrCard()
        self.layout_content.addWidget(self.dhikr_card)

        # --- Pied : source + état hors-ligne ------------------------------------
        self.status_label = QLabel("Horaires fournis par mawaqit.net")
        self.status_label.setProperty("small", True)
        self.status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.layout_content.addWidget(self.status_label)

        self.layout_content.addStretch(1)

    # ------------------------------------------------------------- dhikr
    def new_dhikr(self) -> None:
        """Nouveau tirage à chaque ouverture de la fenêtre (bonus)."""
        self.dhikr_card.roll(force_new=True)

    # ------------------------------------------------------------- mise à jour
    def update_times(self, data: MosqueData | None) -> None:
        """Remplit les lignes avec une nouvelle ``MosqueData``."""
        self._data = data
        if data is None:
            self.mosque_name.setText("Horaires indisponibles")
            return

        self.mosque_name.setText(data.name)
        self.mosque_location.setText("")
        # Date du jour en français (+ Jumu'a le vendredi si connue).
        from PyQt6.QtCore import QLocale  # noqa: PLC0415
        from datetime import date  # noqa: PLC0415

        locale = QLocale(QLocale.Language.French)
        today = date.today()
        date_text = locale.toString(today, "dddd d MMMM yyyy").capitalize()
        if today.weekday() == 4 and data.jumua:      # vendredi
            date_text += f"  ·  Jumu'a à {data.jumua}"
        self.date_label.setText(date_text)

        for key, row in self.rows.items():
            row.set_time(data.times.get(key))
        # Réinitialise un éventuel état d'erreur précédent (couleur ambre).
        self.status_label.setStyleSheet("")
        self.status_label.setText("Horaires fournis par mawaqit.net")

    def set_offline(self, message: str) -> None:
        """Affiche un état « hors-ligne » clair (données impossibles à joindre)."""
        self.mosque_name.setText("Connexion à mawaqit.net impossible")
        self.status_label.setText(message)
        self.status_label.setStyleSheet("color: #F59E0B;")

    def update_countdown(self, info: dict) -> None:
        """Met à jour bannière + surbrillance (appelé chaque seconde)."""
        if not info.get("has_data"):
            self.banner_main.setText("En attente des horaires…")
            self.banner_countdown.setText("")
            return

        next_key = info.get("next_key")
        if next_key != self._next_key:
            for key, row in self.rows.items():
                row.set_next(key == next_key)
            self._next_key = next_key

        if next_key is None:
            self.banner_main.setText("Aucune donnée")
            self.banner_countdown.setText("")
            return

        suffix = " (demain)" if info.get("is_tomorrow") else ""
        self.banner_main.setText(
            f"{info['next_label']} · {info['next_time']}{suffix}"
        )
        self.banner_countdown.setText(info.get("remaining_str", ""))
