"""
Contrôleur principal de Sakinah.

C'est le « chef d'orchestre » : il instancie et relie tous les modules —

    overlay  ──open──▶  main_window (pop-up sous le carré)
    tray     ──menu───▶  fenêtre / widget / focus / paramètres / quitter
    hotkeys  ──ctrl+alt+H──▶ toggle widget    ──Échap──▶ stop focus
    service  ──horaires + countdown + rappels──▶ UI / notifications
    focus    ──session (voile plein écran, minuteur, ambiance)──▶ stats

…et gère les états transverses :
    * masquage automatique quand une application plein écran est détectée ;
    * sauvegarde de la configuration à la fermeture ;
    * notifications Windows (toasts) pour les rappels de prières.
"""

from PyQt6.QtCore import QObject, QTimer
from PyQt6.QtWidgets import QApplication

from app.config import ConfigManager
from app.constants import (
    APP_NAME,
    APP_VERSION,
    FOCUS_DEFAULT_MINUTES,
    PRAYER_LABELS,
)
from app.focus.focus_overlay import FocusSession
from app.main_window import MainWindow
from app.overlay_widget import OverlayWidget
from app.services.prayer_service import PrayerService
from app.theme import build_app_icon
from app.tray_icon import TrayIcon
from app.ui.settings_dialog import SettingsDialog
from app.utils.audio import AudioManager
from app.utils.hotkeys import HotkeyManager
from app.utils.logger import get_logger
from app.utils import win32_helpers

logger = get_logger("controller")

FULLSCREEN_CHECK_MS = 1500


class SakinahApp(QObject):
    """Assemble l'application et gère les interactions entre modules."""

    def __init__(self, app: QApplication) -> None:
        super().__init__()
        self.app = app
        self.config = ConfigManager()

        # --- Modules -----------------------------------------------------
        self.audio = AudioManager(self.config, self)
        self.tray = TrayIcon(build_app_icon(), self)
        self.overlay = OverlayWidget(self.config)
        self.main_window = MainWindow(self.config)
        self.service = PrayerService(self.config, self)
        self.hotkeys = HotkeyManager(self.config.get("general.hotkey_letter", "h"))

        # --- État ---------------------------------------------------------
        self._widget_hidden_by_user = False     # masqué via raccourci/menu
        self._widget_suppressed_by_fs = False   # masqué par détection plein écran
        self.focus_session: FocusSession | None = None
        self._settings_dialog: SettingsDialog | None = None

        # Reprise automatique après un échec réseau (backoff 60 s → 5 min).
        self._retry_timer = QTimer(self)
        self._retry_timer.setSingleShot(True)
        self._retry_timer.timeout.connect(self._retry_fetch)
        self._retry_count = 0

        # --- Câblage des signaux ----------------------------------------------
        self._wire_signals()

        # --- Départ -----------------------------------------------------------
        self.overlay.apply_config()
        self.overlay.show()
        self.main_window.focus_tab.update_sessions(self.config.focus_sessions_today())
        self.service.start()
        self.hotkeys.start()
        self._refresh_tray_labels()

        # Surveille les applications plein écran (jeux, films…).
        self._fs_timer = QTimer(self)
        self._fs_timer.setInterval(FULLSCREEN_CHECK_MS)
        self._fs_timer.timeout.connect(self._watch_fullscreen)
        self._fs_timer.start()

        logger.info(
            "%s v%s prêt (mosquée : %s)",
            APP_NAME, APP_VERSION, self.config.get("mosque.slug"),
        )

    # ------------------------------------------------------------------ câblage
    def _wire_signals(self) -> None:
        # Carré noir → fenêtre principale / sauvegarde de position.
        self.overlay.open_requested.connect(self._toggle_main_window)
        self.overlay.position_changed.connect(
            lambda x, y: self.config.set("widget.position", [x, y], autosave=True)
        )

        # Tray.
        self.tray.show_main_requested.connect(self.open_main_window)
        self.tray.toggle_widget_requested.connect(self.toggle_widget)
        self.tray.focus_requested.connect(
            lambda: self.start_focus(
                int(self.config.get("focus.duration_minutes", FOCUS_DEFAULT_MINUTES)) * 60,
                self.config.get("focus.sound", "none"),
                float(self.config.get("focus.volume", 0.6)),
            )
        )
        self.tray.settings_requested.connect(self.open_settings)
        self.tray.quit_requested.connect(self.quit)

        # Raccourcis globaux (pynput → signaux Qt).
        self.hotkeys.signals.toggle_requested.connect(self.toggle_widget)
        self.hotkeys.signals.escape_requested.connect(self._cancel_focus)

        # Service de prières.
        self.service.times_ready.connect(self._on_times_ready)
        self.service.fetch_failed.connect(self._on_fetch_failed)
        self.service.countdown_changed.connect(self._on_countdown)
        self.service.reminder.connect(self._on_reminder)

        # Onglets.
        self.main_window.prayers_tab.refresh_requested.connect(self.service.refresh_async)
        self.main_window.prayers_tab.change_mosque_requested.connect(self.open_settings)
        self.main_window.focus_tab.start_requested.connect(
            lambda seconds, kind, volume: self.start_focus(seconds, kind, volume)
        )
        self.main_window.settings_requested.connect(self.open_settings)

    # --------------------------------------------------------------- fenêtre
    def open_main_window(self) -> None:
        """Ouvre la pop-up principale sous le carré noir."""
        if self.main_window.isVisible():
            self.main_window.raise_()
            self.main_window.activateWindow()
            return
        # Nouveau dhikr à chaque ouverture (bonus du cahier des charges).
        self.main_window.prayers_tab.new_dhikr()
        self.overlay.raise_()
        self.main_window.popup_below(
            self.overlay.x() + self.overlay.width() // 2,
            self.overlay.y() + self.overlay.height(),
        )

    def _toggle_main_window(self) -> None:
        """Clic sur le carré : ouvre la fenêtre (ou la referme si déjà ouverte)."""
        if self.main_window.isVisible():
            self.main_window.hide()
        else:
            self.open_main_window()

    # ---------------------------------------------------------------- widget
    def toggle_widget(self) -> None:
        """Ctrl+Alt+H ou menu tray : masque/affiche le carré noir."""
        if self.overlay.isVisible():
            self.overlay.hide()
            self._widget_hidden_by_user = True
            self.main_window.hide()
            logger.info("Widget masqué (manuel)")
        else:
            self._widget_hidden_by_user = False
            self.overlay.show()
            logger.info("Widget affiché (manuel)")
        self.tray.set_widget_checked(self.overlay.isVisible())

    def _watch_fullscreen(self) -> None:
        """Masque automatiquement le widget pendant les applications plein écran."""
        if not self.config.get("widget.hide_on_fullscreen", True):
            return
        fullscreen = win32_helpers.is_foreground_fullscreen()
        if fullscreen and not self._widget_suppressed_by_fs:
            self._widget_suppressed_by_fs = True
            self.overlay.hide()
            self.main_window.hide()
            logger.info("Plein écran détecté → widget masqué")
        elif not fullscreen and self._widget_suppressed_by_fs:
            self._widget_suppressed_by_fs = False
            # Ne ré-affiche pas si l'utilisateur l'avait masqué lui-même.
            if not self._widget_hidden_by_user:
                self.overlay.show()
                logger.info("Fin du plein écran → widget restauré")
            self.tray.set_widget_checked(self.overlay.isVisible())

    # ----------------------------------------------------------------- focus
    def start_focus(self, duration_s: int, sound_kind: str, volume: float) -> None:
        """Démarre une session Focus (une seule à la fois)."""
        if self.focus_session is not None:
            return
        self.main_window.hide()      # la pop-up n'a plus de sens sous le voile
        self.focus_session = FocusSession(
            duration_s, sound_kind, volume, self.audio, self
        )
        self.focus_session.tick.connect(
            self.main_window.focus_tab.update_remaining
        )
        self.focus_session.finished.connect(self._on_focus_finished)
        self.main_window.focus_tab.set_running(True)
        self.hotkeys.set_escape_enabled(True)      # Échap global actif
        self.focus_session.start()

    def _cancel_focus(self) -> None:
        """Échap global → arrêt instantané de la session en cours."""
        if self.focus_session is not None:
            self.focus_session.cancel()

    def _on_focus_finished(self, completed: bool) -> None:
        """Fin de session (réussie ou annulée) : nettoyage + éventuel décompte."""
        self.hotkeys.set_escape_enabled(False)
        self.main_window.focus_tab.set_running(False)
        self.focus_session = None
        if completed:
            total = self.config.add_focus_session()
            self.config.save()
            self.main_window.focus_tab.update_sessions(total)
            self.tray.notify(
                "Session terminée",
                f"Bravo ! {total} session(s) de focus réussie(s) aujourd'hui.",
            )

    # ---------------------------------------------------------------- prières
    def _on_times_ready(self, data) -> None:
        """Horaires frais (ou cache) → mise à jour de toute l'interface."""
        self._retry_timer.stop()      # le réseau est revenu : stoppe le backoff
        self._retry_count = 0
        self.service.data = data
        self.main_window.set_mosque_name(data.name)
        self.main_window.prayers_tab.update_times(data)
        if data.from_cache:
            self.main_window.prayers_tab.set_offline(
                "Hors ligne — horaires du dernier lancement réussi."
            )
        # Mémorise le joli nom renvoyé par Mawaqit.
        if not data.from_cache and data.name != self.config.get("mosque.name"):
            self.config.set("mosque.name", data.name)
            self.config.save()

    def _on_fetch_failed(self, message: str) -> None:
        logger.warning("fetch_failed : %s", message)
        self.main_window.prayers_tab.set_offline(
            "Impossible de joindre mawaqit.net — vérifiez la connexion "
            "ou le slug de la mosquée."
        )
        self.tray.notify(
            "Horaires indisponibles",
            "Connexion à mawaqit.net impossible. Nouvelle tentative automatique.",
        )
        # Reprise automatique : 1 min, puis 2, 5, 10… jusqu'à 15 min max.
        if not self._retry_timer.isActive():
            delays = (60, 120, 300, 600, 900)
            delay = delays[min(self._retry_count, len(delays) - 1)]
            self._retry_count += 1
            self._retry_timer.start(delay * 1000)
            logger.info("Nouvelle tentative dans %d s", delay)

    def _retry_fetch(self) -> None:
        self.service.refresh_async()

    def _on_countdown(self, info: dict) -> None:
        """Chaque seconde : bannière, footer, tooltip tray, point du carré."""
        self.main_window.prayers_tab.update_countdown(info)
        if info.get("has_data") and info.get("next_key"):
            summary = (
                f"{info['next_label']} {info['next_time']} — {info['remaining_str']}"
            )
            self.main_window.set_footer_countdown(summary)
            self.tray.set_tooltip(f"{APP_NAME} — Prochaine : {summary}")
            # Point d'état du carré : ambre si < 15 min, sinon émeraude.
            remaining = info.get("remaining_s") or 0
            minutes_before = int(self.config.get("notifications.minutes_before", 15))
            self.overlay.set_indicator("soon" if remaining <= minutes_before * 60 else "ok")
        else:
            self.main_window.set_footer_countdown("—")
            self.tray.set_tooltip(APP_NAME)
            self.overlay.set_indicator("idle")

    def _on_reminder(self, kind: str, key: str) -> None:
        """Rappel J-15 ou « à l'heure » → toast + adhan/bip."""
        label = PRAYER_LABELS.get(key, key)
        data = self.service.data
        time_str = ""
        if data is not None and data.times.get(key) is not None:
            time_str = data.times[key].strftime("%H:%M")

        if kind == "before":
            minutes = int(self.config.get("notifications.minutes_before", 15))
            self.tray.notify(
                f"{label} à {time_str}",
                f"La prière de {label} commence dans {minutes} minutes — "
                "prépare-toi.",
            )
        else:  # "at"
            self.tray.notify(
                f"C'est l'heure de {label}",
                f"La prière de {label} commence maintenant ({time_str}).",
            )
            if self.config.get("notifications.adhan_enabled", True):
                self.audio.play_adhan()
            elif self.config.get("notifications.beep_fallback", True):
                self.audio.play_beeps()

    # -------------------------------------------------------------- réglages
    def open_settings(self) -> None:
        """Ouvre la boîte Paramètres (une seule instance à la fois)."""
        if self._settings_dialog is not None:
            self._settings_dialog.raise_()
            return
        dialog = SettingsDialog(self.config)
        self._settings_dialog = dialog
        dialog.test_sound_requested.connect(self._test_sound)

        def on_saved() -> None:
            self._apply_settings(dialog)

        dialog.settings_saved.connect(on_saved)
        dialog.finished.connect(lambda _: self._settings_dialog_cleanup())
        dialog.show()

    def _settings_dialog_cleanup(self) -> None:
        self._settings_dialog = None

    def _test_sound(self) -> None:
        """Bouton « Tester le son » des paramètres."""
        if self.config.get("notifications.adhan_enabled", True):
            self.audio.play_adhan()
        else:
            self.audio.play_beeps()

    def _apply_settings(self, dialog: SettingsDialog) -> None:
        """Applique les nouveaux réglages à chaud."""
        # Raccourci global.
        self.hotkeys.set_letter(self.config.get("general.hotkey_letter", "h"))
        # Widget (taille, click-through).
        self.overlay.apply_config()
        if getattr(dialog, "_reset_widget_position", False):
            self.overlay.reset_position()
        # Libellés dynamiques (durée focus configurable → menu tray à jour).
        self._refresh_tray_labels()
        # Mosquée changée → recharge les horaires.
        if getattr(dialog, "mosque_changed", False):
            self.service.mosque_changed()

    def _refresh_tray_labels(self) -> None:
        """Met à jour le libellé du menu tray avec la durée configurée."""
        minutes = int(self.config.get("focus.duration_minutes", FOCUS_DEFAULT_MINUTES))
        self.tray.set_focus_minutes(minutes)

    # -------------------------------------------------------------- arrêt
    def shutdown(self) -> None:
        """Nettoyage propre à la fermeture (aboutToQuit)."""
        logger.info("Arrêt de Sakinah…")
        if self.focus_session is not None:
            self.focus_session.cancel()
        self.hotkeys.stop()
        self.tray.hide()
        self.config.save()

    def quit(self) -> None:
        self.shutdown()
        self.app.quit()
