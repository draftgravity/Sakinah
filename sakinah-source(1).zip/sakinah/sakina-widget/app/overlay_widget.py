"""
Le widget overlay : le petit carré noir de Sakinah.

Comportement :
  * fenêtre sans bordure, toujours au premier plan, absente de la barre
    des tâches et d'Alt+Tab (Qt.Tool) ;
  * n'active jamais une autre fenêtre quand il apparaît
    (WA_ShowWithoutActivating) → il ne « vole » jamais le focus ;
  * coins arrondis + léger liseré, dessinés à la main (paintEvent) ;
  * point d'état central : émeraude = OK, ambre = prière imminente
    (< 15 min), gris = horaires non chargés ;
  * clic gauche OU droit → ouvre la fenêtre principale (signal) ;
  * glisser-déposer pour le déplacer ; la position est mémorisée ;
  * mode « discret » (click-through) : le carré devient transparent aux
    clics → il ne peut jamais gêner l'utilisateur (voir win32_helpers) ;
  * le topmost est ré-affirmé périodiquement (certaines applications
    essaient de passer au-dessus).
"""

from PyQt6.QtCore import QPointF, QRectF, Qt, QTimer, pyqtSignal
from PyQt6.QtGui import QColor, QPen, QPainter
from PyQt6.QtWidgets import QApplication, QWidget

from app.config import ConfigManager
from app.constants import (
    COLOR_ACCENT_LIGHT,
    COLOR_AMBER,
    COLOR_MUTED,
    WIDGET_DEFAULT_SIZE,
    WIDGET_MAX_SIZE,
    WIDGET_MIN_SIZE,
    WIDGET_SCREEN_MARGIN,
)
from app.utils import win32_helpers
from app.utils.logger import get_logger

logger = get_logger("overlay")

# Distance (px) en dessous de laquelle un appui+relâchement est un clic
# (et non un déplacement) :
DRAG_THRESHOLD_PX = 6


class OverlayWidget(QWidget):
    """Le carré noir discret, ancré en haut à droite de l'écran."""

    open_requested = pyqtSignal()          # clic gauche ou droit
    position_changed = pyqtSignal(int, int)  # fin de déplacement

    def __init__(self, config: ConfigManager, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.config = config

        self._hovered = False
        self._indicator = QColor(COLOR_MUTED)      # point d'état central
        self._click_through = False

        # --- Fenêtre frameless, topmost, hors barre des tâches -----------
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.Tool
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating, True)
        self.setContextMenuPolicy(Qt.ContextMenuPolicy.NoContextMenu)

        self._apply_size()
        self._place_initial()

        # Astuce : tooltip discret pour guider l'utilisateur.
        self.setToolTip("Sakinah — cliquez pour ouvrir · Ctrl+Alt+H pour masquer")

        # Ré-affirme le topmost toutes les 5 s (certaines applications
        # tentent régulièrement de passer au-dessus de lui).
        self._topmost_timer = QTimer(self)
        self._topmost_timer.setInterval(5000)
        self._topmost_timer.timeout.connect(lambda: win32_helpers.pin_topmost(self))
        self._topmost_timer.start()

    # ------------------------------------------------------------ géométrie
    def _apply_size(self) -> None:
        size = int(self.config.get("widget.size", WIDGET_DEFAULT_SIZE))
        size = max(WIDGET_MIN_SIZE, min(WIDGET_MAX_SIZE, size))
        self.setFixedSize(size, size)

    def _place_initial(self) -> None:
        """Place le carré : position mémorisée, sinon haut-droite de l'écran."""
        position = self.config.get("widget.position")
        if isinstance(position, (list, tuple)) and len(position) == 2:
            try:
                x, y = int(position[0]), int(position[1])
                # Refuse une position hors de tout écran (écran débranché
                # depuis la dernière session) — sinon le carré serait invisible.
                from PyQt6.QtCore import QPoint  # noqa: PLC0415
                from PyQt6.QtGui import QGuiApplication  # noqa: PLC0415

                if QGuiApplication.screenAt(QPoint(x, y)) is not None:
                    self.move(x, y)
                    return
                logger.warning("Position mémorisée hors écran → réinitialisation")
            except (TypeError, ValueError):
                pass
        screen = self.screen() or QApplication.primaryScreen()
        if screen is not None:
            area = screen.availableGeometry()
            self.move(
                area.right() - self.width() - WIDGET_SCREEN_MARGIN,
                area.top() + WIDGET_SCREEN_MARGIN,
            )

    # -------------------------------------------------------------- état
    def set_indicator(self, state: str) -> None:
        """Couleur du point d'état : 'ok' | 'soon' | 'idle'."""
        color = {
            "ok": QColor(COLOR_ACCENT_LIGHT),
            "soon": QColor(COLOR_AMBER),
            "idle": QColor(COLOR_MUTED),
        }.get(state)
        if color is not None and color != self._indicator:
            self._indicator = color
            self.update()

    def set_click_through(self, enabled: bool) -> None:
        """Active le mode discret : les clics traversent le carré."""
        self._click_through = enabled
        if enabled:
            win32_helpers.set_click_through(self, True)
            self.setToolTip(
                "Sakinah (mode discret) — Ctrl+Alt+H pour reprendre le contrôle"
            )
        else:
            win32_helpers.set_click_through(self, False)
            self.setToolTip(
                "Sakinah — cliquez pour ouvrir · Ctrl+Alt+H pour masquer"
            )

    def apply_config(self) -> None:
        """Réapplique taille + mode discret après changement des paramètres."""
        old_size = self.size()
        self._apply_size()
        self.set_click_through(bool(self.config.get("widget.click_through", False)))
        if self.size() != old_size:
            # Recale pour que le carré reste « collé » au coin haut-droit.
            self.move(self.x() + (old_size.width() - self.width()),
                      self.y() + (old_size.height() - self.height()))

    def reset_position(self) -> None:
        self.config.set("widget.position", None)
        self._place_initial()

    # ----------------------------------------------------------- dessin
    def paintEvent(self, _event) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        rect = QRectF(self.rect()).adjusted(1.0, 1.0, -1.0, -1.0)
        radius = rect.width() * 0.28

        # Corps noir, léger liseré au survol :
        painter.setPen(QPen(QColor(255, 255, 255, 38 if self._hovered else 20), 1))
        painter.setBrush(QColor("#0A0A0B"))
        painter.drawRoundedRect(rect, radius, radius)

        # Point d'état central (battement de l'application) :
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(self._indicator)
        diameter = max(3.0, rect.width() * 0.12)
        center = rect.center()
        painter.drawEllipse(
            QPointF(center.x(), center.y()), diameter / 2, diameter / 2
        )

    # ---------------------------------------------------- interactions
    def enterEvent(self, _event) -> None:
        self._hovered = True
        self.update()

    def leaveEvent(self, _event) -> None:
        self._hovered = False
        self.update()

    def mousePressEvent(self, event) -> None:
        """Démarre un éventuel glisser ET retient le point de départ."""
        if event.button() in (
            Qt.MouseButton.LeftButton,
            Qt.MouseButton.RightButton,
        ):
            self._drag_start_global = event.globalPosition().toPoint()
            self._drag_start_origin = self.pos()
            self._drag_moved = False

    def mouseMoveEvent(self, event) -> None:
        """Déplace le carré si l'utilisateur maintient le clic gauche."""
        if (
            event.buttons() & Qt.MouseButton.LeftButton
            and hasattr(self, "_drag_start_global")
        ):
            delta = event.globalPosition().toPoint() - self._drag_start_global
            if delta.manhattanLength() > DRAG_THRESHOLD_PX:
                self._drag_moved = True
            # Cale le déplacement à l'intérieur de la zone virtuelle
            # (union de tous les écrans) pour ne pas perdre le carré.
            virtual = QApplication.primaryScreen().virtualGeometry()
            new_x = self._drag_start_origin.x() + delta.x()
            new_y = self._drag_start_origin.y() + delta.y()
            self.move(
                max(virtual.left(), min(new_x, virtual.right() - self.width())),
                max(virtual.top(), min(new_y, virtual.bottom() - self.height())),
            )

    def mouseReleaseEvent(self, event) -> None:
        """Clic (gauche ou droit) sans déplacement → ouvrir la fenêtre."""
        if event.button() in (
            Qt.MouseButton.LeftButton,
            Qt.MouseButton.RightButton,
        ):
            if not getattr(self, "_drag_moved", False):
                self.open_requested.emit()
            else:
                # Mémorise la nouvelle position du widget.
                self.position_changed.emit(self.x(), self.y())
        self._drag_moved = False

    # ---------------------------------------------------------- affichage
    def showEvent(self, event) -> None:
        super().showEvent(event)
        # Ré-applique le click-through après chaque réaffichage
        # (le style de fenêtre est réinitialisé par certains gestionnaires).
        if self._click_through:
            win32_helpers.set_click_through(self, True)
        win32_helpers.pin_topmost(self)
