"""
Constantes globales de Sakinah.

Centralise : chemins, palette de couleurs, définition des prières,
URLs de l'API Mawaqit et identifiants de l'application.
"""

from pathlib import Path

# --- Identité de l'application ------------------------------------------
APP_NAME = "Sakinah"
APP_VERSION = "1.0.0"
APP_ID = "sakinah-widget"          # nom du canal d'instance unique (QLocalServer)

# --- Chemins -------------------------------------------------------------
BASE_DIR = Path(__file__).resolve().parent.parent   # racine du projet
CONFIG_PATH = BASE_DIR / "config.json"
LOG_PATH = BASE_DIR / "sakinah.log"
DATA_DIR = BASE_DIR / "data"
DHIKRS_PATH = DATA_DIR / "dhikrs.json"
SOUNDS_DIR = BASE_DIR / "assets" / "sounds"
ADHAN_FILE = SOUNDS_DIR / "adhan.mp3"               # optionnel (fourni par l'utilisateur)

# --- Palette (thème sombre zinc + émeraude) ------------------------------
COLOR_BG = "#0C0C0E"
COLOR_SURFACE = "#141417"
COLOR_SURFACE_2 = "#1B1B20"
COLOR_BORDER = "#26262B"
COLOR_TEXT = "#FAFAFA"
COLOR_MUTED = "#A1A1AA"
COLOR_ACCENT = "#10B981"       # émeraude
COLOR_ACCENT_LIGHT = "#34D399"
COLOR_AMBER = "#F59E0B"        # utilisé quand la prochaine prière est imminente
COLOR_DANGER = "#F87171"

# --- Prières ---------------------------------------------------------------
# (clé interne, libellé FR, nom arabe, est-une-prière-avec-rappel)
# NB : Chourouk (= lever du soleil) est affiché mais ne déclenche ni adhan
# ni rappel — ce n'est pas une prière.
PRAYERS: list[tuple[str, str, str, bool]] = [
    ("fajr", "Fajr", "الفجر", True),
    ("shourouk", "Chourouk", "الشروق", False),
    ("dhuhr", "Dhuhr", "الظهر", True),
    ("asr", "Asr", "العصر", True),
    ("maghrib", "Maghrib", "المغرب", True),
    ("isha", "Isha", "العشاء", True),
]
PRAYER_LABELS = {key: label for key, label, _, _ in PRAYERS}
PRAYER_ARABIC = {key: arabic for key, _, arabic, _ in PRAYERS}
# Prières qui déclenchent un rappel / une notification :
REMINDABLE_PRAYERS = [key for key, _, _, real in PRAYERS if real]

# --- Raccourci global ------------------------------------------------------
# Modificateurs fixes (Ctrl + Alt) + lettre configurable via config.json
HOTKEY_MODIFIERS = ("ctrl", "alt")
DEFAULT_HOTKEY_LETTER = "h"

# --- Focus (Pomodoro) --------------------------------------------------------
FOCUS_DEFAULT_MINUTES = 25
FOCUS_DIM_OPACITY = 0.85          # opacité du voile noir pendant la session
FOCUS_SOUND_KINDS = ("none", "white", "rain")
FOCUS_SOUND_LABELS = {
    "none": "Aucun (silence)",
    "white": "Bruit blanc",
    "rain": "Pluie",
}

# --- Mawaqit -----------------------------------------------------------------
MAWAQIT_SEARCH_URL = "https://mawaqit.net/api/2.0/mosque/search"
MAWAQIT_MOSQUE_URL = "https://mawaqit.net/fr/{slug}"
MAWAQIT_HEADERS = {
    "User-Agent": "SakinahWidget/1.0 (+desktop; mawaqit.net)",
    "Accept": "application/json",
}
# Regex d'extraction du JSON `confData` embarqué dans la page de la mosquée.
CONF_DATA_RE = r"(?:var|let)\s+confData\s*=\s*(.*?);\s*\n"

# --- Widget overlay ------------------------------------------------------------
WIDGET_DEFAULT_SIZE = 36          # px (configurable de 24 à 56)
WIDGET_MIN_SIZE = 24
WIDGET_MAX_SIZE = 56
WIDGET_SCREEN_MARGIN = 12         # marge par rapport au coin haut-droit
