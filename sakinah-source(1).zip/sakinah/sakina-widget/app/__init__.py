"""Sakinah — widget discret de prières et de focus pour Windows."""
