"""
Lancement automatique de Sakinah avec Windows.

Utilise la clé de registre standard (aucun droit administrateur requis) ::
    HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run

Fonctionne que l'application soit lancée via ``python main.py`` ou
compilée en .exe (PyInstaller) — la commande construite s'adapte.
"""

import sys
from pathlib import Path

from app.utils.logger import get_logger

logger = get_logger("autostart")

_RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"
_VALUE_NAME = "SakinahWidget"


def _launch_command() -> str:
    """Commande à enregistrer pour démarrer Sakinah au boot."""
    if getattr(sys, "frozen", False):
        # Application compilée (PyInstaller) : l'exe se lance directement.
        return f'"{sys.executable}"'
    # Mode script : python "chemin/vers/main.py"
    main_script = Path(sys.argv[0]).resolve()
    return f'"{sys.executable}" "{main_script}"'


def set_autostart(enabled: bool) -> bool:
    """Active ou désactive le démarrage automatique. Renvoie le succès."""
    if sys.platform != "win32":
        logger.info("Autostart ignoré (pas Windows)")
        return False
    try:
        import winreg  # noqa: PLC0415

        with winreg.OpenKey(
            winreg.HKEY_CURRENT_USER, _RUN_KEY, 0, winreg.KEY_SET_VALUE
        ) as key:
            if enabled:
                winreg.SetValueEx(key, _VALUE_NAME, 0, winreg.REG_SZ, _launch_command())
                logger.info("Autostart ACTIVÉ : %s", _launch_command())
            else:
                try:
                    winreg.DeleteValue(key, _VALUE_NAME)
                    logger.info("Autostart désactivé")
                except FileNotFoundError:
                    pass
        return True
    except OSError as exc:
        logger.error("Autostart impossible : %s", exc)
        return False


def is_autostart_enabled() -> bool:
    """Vérifie si l'autostart est actuellement enregistré."""
    if sys.platform != "win32":
        return False
    try:
        import winreg  # noqa: PLC0415

        with winreg.OpenKey(
            winreg.HKEY_CURRENT_USER, _RUN_KEY, 0, winreg.KEY_READ
        ) as key:
            winreg.QueryValueEx(key, _VALUE_NAME)
            return True
    except OSError:
        return False
