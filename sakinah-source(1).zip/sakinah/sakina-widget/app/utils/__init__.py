"""Utilitaires système : win32, raccourcis globaux, audio, autostart…"""
