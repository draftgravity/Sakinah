"""
Moteur audio de Sakinah — 100 % sans fichier à télécharger :

* Adhan : si l'utilisateur dépose ``assets/sounds/adhan.mp3``, il est joué
  via QMediaPlayer (QtMultimedia). Sinon → bip discret (winsound) si activé.
* Bips de rappel : petites séries de notes via ``winsound.Beep`` (thread
  séparé pour ne jamais geler l'interface).
* Carillon de fin de session focus : accord Do-Mi-Sol-Do synthétisé en WAV
  (module standard ``wave``), joué via QSoundEffect.
* Bruit blanc / pluie d'ambiance : WAV générés à la volée (bruit blanc pur
  et bruit brownien filtré ≈ pluie), lus en boucle pendant la session.

Toutes les méthodes sont non bloquantes et tolérantes (pas de son ≠ crash).
"""

import array
import math
import random
import sys
import tempfile
import threading
import time
import wave
from pathlib import Path

from PyQt6.QtCore import QObject, QUrl

from app.constants import ADHAN_FILE, FOCUS_SOUND_KINDS
from app.utils.logger import get_logger

logger = get_logger("audio")

# QtMultimedia est optionnel (théoriquement inclus dans le wheel PyQt6) :
try:
    from PyQt6.QtMultimedia import QAudioOutput, QMediaPlayer, QSoundEffect

    MULTIMEDIA_OK = True
except ImportError:  # pragma: no cover
    MULTIMEDIA_OK = False
    logger.warning("QtMultimedia indisponible — adhan MP3 désactivé")

if sys.platform == "win32":
    import winsound
else:  # développement hors Windows : stub silencieux
    winsound = None

SAMPLE_RATE = 22050          # Hz — suffisant pour du bruit, fichiers légers
_CACHE_DIR = Path(tempfile.gettempdir()) / "sakinah-sounds"


# ---------------------------------------------------------------------------
# Synthèse WAV (module standard, aucune dépendance)
# ---------------------------------------------------------------------------
def _write_wav(path: Path, samples: list[float], rate: int = SAMPLE_RATE) -> None:
    """Écrit une liste de samples [-1, 1] dans un WAV 16 bits mono.

    Écriture atomique (.tmp puis remplacement) : un crash pendant la
    génération ne laissera jamais un fichier corrompu en cache.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".wav.tmp")
    with wave.open(str(tmp), "wb") as handle:
        handle.setnchannels(1)
        handle.setsampwidth(2)
        handle.setframerate(rate)
        frames = array.array(
            "h",
            (max(-32768, min(32767, int(s * 32767))) for s in samples),
        )
        handle.writeframes(frames.tobytes())
    tmp.replace(path)


def _fade(samples: list[float], fade_s: float = 0.05, rate: int = SAMPLE_RATE) -> None:
    """Applique un fondu entrant/sortant (évite les « clics » en boucle)."""
    n = int(fade_s * rate)
    if n * 2 >= len(samples):
        return
    for i in range(n):
        factor = i / n
        samples[i] *= factor
        samples[-1 - i] *= factor


def _synth_white(seconds: float = 8.0) -> list[float]:
    """Bruit blanc pur (souffle régulier)."""
    return [random.uniform(-1.0, 1.0) * 0.35 for _ in range(int(seconds * SAMPLE_RATE))]


def _synth_rain(seconds: float = 8.0) -> list[float]:
    """Bruit brownien (intégration de bruit blanc) — proche d'une pluie."""
    samples: list[float] = []
    last = 0.0
    for _ in range(int(seconds * SAMPLE_RATE)):
        white = random.uniform(-1.0, 1.0)
        last = (last + 0.02 * white) / 1.02
        samples.append(last * 3.5)
    # limitation douce
    return [max(-0.95, min(0.95, s)) for s in samples]


def _synth_chime() -> list[float]:
    """Carillon de fin de focus : arpège Do5-Mi5-Sol5-Do6, décroissance douce."""
    notes = (523.25, 659.25, 783.99, 1046.50)
    note_s, overlap_s = 1.1, 0.18
    total_s = note_s + overlap_s * (len(notes) - 1)
    total = int(total_s * SAMPLE_RATE)
    out = [0.0] * total
    for index, freq in enumerate(notes):
        start = int(index * overlap_s * SAMPLE_RATE)
        length = int(note_s * SAMPLE_RATE)
        for i in range(length):
            envelope = math.exp(-3.2 * i / length)
            out[start + i] += 0.28 * envelope * math.sin(
                2 * math.pi * freq * i / SAMPLE_RATE
            )
    return [max(-0.95, min(0.95, s)) for s in out]


def _cached_wav(name: str, synth) -> Path:
    """Génère (une seule fois) un WAV de synthèse dans le cache temporaire."""
    path = _CACHE_DIR / name
    if not path.exists():
        samples = synth()
        _fade(samples)
        _write_wav(path, samples)
        logger.info("WAV de synthèse généré : %s", path.name)
    return path


# ---------------------------------------------------------------------------
# Bip discret via winsound (exécuté dans un thread pour ne pas geler la GUI)
# ---------------------------------------------------------------------------
_BEEP_PATTERN_ADHAN = [(660, 350), (880, 350), (660, 500)]   # appel doux
_BEEP_PATTERN_SIMPLE = [(880, 160), (880, 160)]              # bip double


def _beep_worker(pattern: list[tuple[int, int]]) -> None:
    if winsound is None:
        return
    try:
        for freq, duration in pattern:
            winsound.Beep(freq, duration)
            time.sleep(0.08)
    except Exception as exc:  # pilote audio capricieux…
        logger.debug("Beep échoué : %s", exc)


class AudioManager(QObject):
    """Regroupe toutes les lectures sonores de l'application."""

    def __init__(self, config, parent: QObject | None = None) -> None:
        super().__init__(parent)
        self.config = config
        # Références gardées vivantes sinon Qt détruit les lecteurs :
        self._noise_effect = None
        self._chime_effect = None
        self._adhan_player = None
        self._adhan_output = None

    # ------------------------------------------------------------- adhan
    def play_adhan(self) -> None:
        """Joue l'adhan (MP3 utilisateur) sinon un bip d'appel discret."""
        if MULTIMEDIA_OK and ADHAN_FILE.exists():
            try:
                # Stoppe une éventuelle lecture précédente.
                if self._adhan_player is not None:
                    self._adhan_player.stop()
                self._adhan_player = QMediaPlayer(self)
                self._adhan_output = QAudioOutput(self)
                # Volume DÉDIÉ aux sons de prière (indépendant de l'ambiance
                # du Mode Focus — cf. config.json → notifications.volume).
                self._adhan_output.setVolume(
                    float(self.config.get("notifications.volume", 1.0))
                )
                self._adhan_player.setAudioOutput(self._adhan_output)
                self._adhan_player.setSource(QUrl.fromLocalFile(str(ADHAN_FILE)))
                self._adhan_player.play()
                logger.info("Adhan joué (%s)", ADHAN_FILE.name)
                return
            except Exception as exc:
                logger.warning("Lecture adhan impossible : %s", exc)
        if self.config.get("notifications.beep_fallback", True):
            self.play_beeps(_BEEP_PATTERN_ADHAN)

    def play_beeps(self, pattern: list[tuple[int, int]] | None = None) -> None:
        """Bip discret (non bloquant) — repli de l'adhan et rappels."""
        threading.Thread(
            target=_beep_worker,
            args=(pattern or _BEEP_PATTERN_SIMPLE,),
            name="beep",
            daemon=True,
        ).start()

    # ---------------------------------------------------------- carillon
    def play_chime(self) -> None:
        """Carillon de fin de session focus."""
        if not MULTIMEDIA_OK:
            self.play_beeps([(1046, 200), (784, 200), (523, 300)])
            return
        try:
            path = _cached_wav("chime.wav", _synth_chime)
            if self._chime_effect is not None:
                self._chime_effect.stop()
            self._chime_effect = QSoundEffect(self)
            self._chime_effect.setSource(QUrl.fromLocalFile(str(path)))
            self._chime_effect.setVolume(
                min(1.0, float(self.config.get("focus.volume", 0.6)) + 0.15)
            )
            self._chime_effect.setLoopCount(1)
            self._chime_effect.play()
        except Exception as exc:
            logger.warning("Carillon impossible : %s", exc)

    # ------------------------------------------------------- bruit d'ambiance
    def start_noise(self, kind: str, volume: float = 0.6) -> None:
        """Démarre une ambiance en boucle (white | rain). Stoppe l'ancienne."""
        self.stop_noise()
        if kind not in FOCUS_SOUND_KINDS or kind == "none":
            return
        if not MULTIMEDIA_OK:
            logger.warning("QtMultimedia absent — ambiance indisponible")
            return
        try:
            synth = _synth_white if kind == "white" else _synth_rain
            path = _cached_wav(f"{kind}.wav", synth)
            self._noise_effect = QSoundEffect(self)
            self._noise_effect.setSource(QUrl.fromLocalFile(str(path)))
            self._noise_effect.setVolume(max(0.0, min(1.0, volume)))
            self._noise_effect.setLoopCount(QSoundEffect.Loop.Infinite)
            self._noise_effect.play()
            logger.info("Ambiance « %s » démarrée", kind)
        except Exception as exc:
            logger.warning("Ambiance impossible : %s", exc)
            self._noise_effect = None

    def set_noise_volume(self, volume: float) -> None:
        if self._noise_effect is not None:
            self._noise_effect.setVolume(max(0.0, min(1.0, volume)))

    def stop_noise(self) -> None:
        if self._noise_effect is not None:
            self._noise_effect.stop()
            self._noise_effect = None
