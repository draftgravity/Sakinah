"""
Passerelle vers les API Win32 (pywin32) :

* détection d'une application plein écran (jeu en plein écran exclusif ou
  sans bordures, vidéo…) → pour masquer automatiquement le widget ;
* mode « click-through » : le carré noir devient invisible à la souris
  (WS_EX_TRANSPARENT) et ne bloque donc jamais les clics ;
* maintien du mode « toujours au premier plan » (topmost).

Tout est dégradé gracieusement : hors Windows (développement sous Linux
ou macOS) les fonctions ne font rien et renvoient False/None.
"""

import ctypes
import os
import sys

from app.utils.logger import get_logger

logger = get_logger("win32")

IS_WINDOWS = sys.platform == "win32"

# Constantes Win32 (évite d'importer win32con partout) :
GWL_EXSTYLE = -20
WS_EX_LAYERED = 0x0008_0000
WS_EX_TRANSPARENT = 0x0000_0020      # la fenêtre ignore les clics souris
WS_EX_NOACTIVATE = 0x0800_0000       # la fenêtre ne prend jamais le focus
HWND_TOPMOST = -1
SWP_NOSIZE = 0x0001
SWP_NOMOVE = 0x0002
SWP_NOACTIVATE = 0x0010
SWP_SHOWWINDOW = 0x0040

# Fenêtres du shell Windows à ignorer dans la détection plein écran :
_SHELL_CLASSES = {"Progman", "WorkerW", "Shell_TrayWnd", "Shell_SecondaryTrayWnd"}


def _imports():
    """Importe pynput-style : renvoie (win32gui, win32con) ou (None, None)."""
    if not IS_WINDOWS:
        return None, None
    try:
        import win32con  # noqa: PLC0415
        import win32gui  # noqa: PLC0415

        return win32gui, win32con
    except ImportError:
        logger.warning("pywin32 indisponible — fonctions Win32 désactivées")
        return None, None


def is_foreground_fullscreen() -> bool:
    """Vrai si la fenêtre au premier plan couvre tout un écran.

    Détecte :
      * le plein écran exclusif des jeux (Valorant…) ;
      * le mode « sans bordures » (fenêtre exactement à la taille de l'écran).
    Ignore le bureau, la barre des tâches et nos propres fenêtres.
    """
    win32gui, win32con = _imports()
    if win32gui is None:
        return False

    try:
        hwnd = win32gui.GetForegroundWindow()
        if not hwnd:
            return False

        # Ne pas se déclencher sur nos propres fenêtres (ex. le mode focus
        # de Sakinah couvre volontairement tout l'écran).
        pid = ctypes.c_ulong()
        ctypes.windll.user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if pid.value == os.getpid():
            return False

        if win32gui.GetClassName(hwnd) in _SHELL_CLASSES:
            return False
        if not win32gui.GetWindowText(hwnd):
            return False

        monitor = win32gui.MonitorFromWindow(
            hwnd, win32con.MONITOR_DEFAULTTONEAREST
        )
        info = win32gui.GetMonitorInfo(monitor)
        return win32gui.GetWindowRect(hwnd) == info["Monitor"]
    except Exception as exc:  # fenêtre en cours de destruction, etc.
        logger.debug("Détection plein écran : %s", exc)
        return False


def set_click_through(widget, enabled: bool) -> bool:
    """Active/désactive le mode « laisse passer les clics » d'un QWidget."""
    win32gui, _ = _imports()
    if win32gui is None:
        return False
    try:
        hwnd = int(widget.winId())
        style = win32gui.GetWindowLong(hwnd, GWL_EXSTYLE)
        if enabled:
            style |= WS_EX_LAYERED | WS_EX_TRANSPARENT | WS_EX_NOACTIVATE
        else:
            style &= ~(WS_EX_TRANSPARENT | WS_EX_NOACTIVATE)
        win32gui.SetWindowLong(hwnd, GWL_EXSTYLE, style)
        return True
    except Exception as exc:
        logger.warning("Click-through impossible : %s", exc)
        return False


def pin_topmost(widget) -> bool:
    """Replace la fenêtre au sommet de la pile Z (sans la focaliser)."""
    win32gui, _ = _imports()
    if win32gui is None:
        return False
    try:
        hwnd = int(widget.winId())
        win32gui.SetWindowPos(
            hwnd, HWND_TOPMOST, 0, 0, 0, 0,
            SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE | SWP_SHOWWINDOW,
        )
        return True
    except Exception as exc:
        logger.debug("Topmost impossible : %s", exc)
        return False
