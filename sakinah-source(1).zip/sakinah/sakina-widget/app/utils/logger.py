"""
Journalisation légère de Sakinah.

Écrit dans ``sakinah.log`` à côté du script (rotation : 2 sauvegardes de
200 Ko max) et reflète les messages INFO+ dans la console. En cas de
problème (fichier verrouillé, dossier en lecture seule…), la configuration
est ignorée silencieusement : la journalisation ne doit JAMAIS faire
planter l'application.
"""

import logging
from logging.handlers import RotatingFileHandler

from app.constants import LOG_PATH

_FORMAT = "%(asctime)s  %(levelname)-7s  %(name)-22s  %(message)s"


def setup_logging(level: int = logging.INFO) -> None:
    root = logging.getLogger("sakinah")
    if root.handlers:        # déjà configuré (relance à chaud)
        return
    root.setLevel(level)
    formatter = logging.Formatter(_FORMAT, datefmt="%Y-%m-%d %H:%M:%S")

    # --- Fichier rotatif ---------------------------------------------------
    try:
        file_handler = RotatingFileHandler(
            LOG_PATH, maxBytes=200_000, backupCount=2, encoding="utf-8"
        )
        file_handler.setFormatter(formatter)
        root.addHandler(file_handler)
    except OSError:
        pass  # disque en lecture seule, dossier protégé… on continue sans fichier

    # --- Console (utile pendant le développement) ---------------------------
    console = logging.StreamHandler()
    console.setFormatter(formatter)
    root.addHandler(console)

    root.info("=== Sakinah démarré ===")


def get_logger(name: str) -> logging.Logger:
    """Renvoie un logger enfant « sakinah.<name> »."""
    return logging.getLogger(f"sakinah.{name}")
