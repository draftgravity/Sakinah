"""
Garantie d'instance unique pour Sakinah.

Mécanisme standard Qt (QLocalServer / QLocalSocket) :

* au démarrage, on tente de se CONNECTER au serveur local « sakinah-widget » ;
  si la connexion réussit → une instance tourne déjà : on lui envoie
  « show » pour qu'elle affiche sa fenêtre, puis on quitte ;
* sinon → on devient le serveur (instance primaire) et on écoute les
  demandes des futures instances secondaires.
"""

from PyQt6.QtCore import QObject, pyqtSignal
from PyQt6.QtNetwork import QLocalServer, QLocalSocket

from app.utils.logger import get_logger

logger = get_logger("single-instance")


class SingleInstanceGuard(QObject):
    """Verrou d'instance unique + canal « montre-toi » entre instances."""

    show_requested = pyqtSignal()   # émis quand une 2e instance démarre

    def __init__(self, name: str, parent: QObject | None = None) -> None:
        super().__init__(parent)
        self.name = name
        self.is_primary = False
        self._server: QLocalServer | None = None

        # Nettoie un éventuel serveur fantôme d'un crash précédent.
        QLocalServer.removeServer(name)

        # Déjà lancé ? On tente une connexion au serveur existant.
        probe = QLocalSocket()
        probe.connectToServer(name)
        if probe.waitForConnected(300):
            probe.disconnectFromServer()
            logger.info("Instance existante détectée → demande d'affichage")
            return

        # Aucune instance → on devient le serveur primaire.
        self._server = QLocalServer(self)
        if self._server.listen(name):
            self.is_primary = True
            self._server.newConnection.connect(self._on_new_connection)
            logger.info("Instance primaire (serveur « %s »)", name)
        else:
            # Cas extrême (verrou système) : on continue en mode dégradé.
            logger.error("Écoute impossible : %s", self._server.errorString())

    # ------------------------------------------------------------------ API
    def notify_primary(self) -> None:
        """Demande à l'instance primaire d'afficher la fenêtre principale."""
        socket = QLocalSocket()
        socket.connectToServer(self.name)
        if socket.waitForConnected(300):
            socket.write(b"show\n")
            socket.flush()
            socket.waitForBytesWritten(300)
            socket.disconnectFromServer()

    def release(self) -> None:
        if self._server is not None:
            self._server.close()
            self._server = None

    # -------------------------------------------------------- réception
    def _on_new_connection(self) -> None:
        client = self._server.nextPendingConnection()
        if client is None:
            return
        def _read() -> None:
            if bytes(client.readAll()).strip() == b"show":
                self.show_requested.emit()
            client.disconnectFromServer()
        client.readyRead.connect(_read)
