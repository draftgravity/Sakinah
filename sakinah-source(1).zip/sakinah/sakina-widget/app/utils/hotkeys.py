"""
Raccourcis clavier globaux via pynput.

* Combo principal : **Ctrl + Alt + H** (lettre configurable) → masque /
  affiche le widget overlay, dans N'IMPORTE QUELLE application.
* Échap global : réservé au mode Focus — stoppe instantanément la session
  même si la fenêtre de focus n'a plus le focus clavier.

pynput tourne dans son propre thread : les callbacks sont donc convertis
en signaux Qt (émission thread-safe, livraison automatique dans le thread
GUI via connexion « queued »).

L'import de pynput est protégé : hors Windows (développement sous Linux
sans serveur X, pynput absent), le module se désactive proprement et
l'application démarre quand même — seuls les raccourcis globaux manquent.
"""

from app.constants import DEFAULT_HOTKEY_LETTER, HOTKEY_MODIFIERS
from app.utils.logger import get_logger

logger = get_logger("hotkeys")

try:
    from pynput import keyboard

    PYNPUT_OK = True
except Exception:  # ImportError, backend X11/Wayland indisponible…
    keyboard = None
    PYNPUT_OK = False
    logger.warning("pynput indisponible — raccourcis globaux désactivés")

if PYNPUT_OK:
    _KEY = keyboard.Key
else:  # stub minimal pour que _normalize reste définissable
    class _KeyStub:  # noqa: D401
        ctrl = ctrl_l = ctrl_r = alt = alt_l = alt_r = None
        cmd = cmd_l = cmd_r = esc = None

    _KEY = _KeyStub()


def _normalize(key) -> object:
    """Ramène une touche pynput à une forme stable ('ctrl', 'alt', 'h'…)."""
    # Modificateurs gauche/droit → forme canonique
    if key in (_KEY.ctrl, _KEY.ctrl_l, _KEY.ctrl_r):
        return "ctrl"
    if key in (_KEY.alt, _KEY.alt_l, _KEY.alt_r):
        return "alt"
    if key in (_KEY.cmd, _KEY.cmd_l, _KEY.cmd_r):
        return "cmd"

    # Lettres : pynput peut fournir soit `char`, soit un code virtuel.
    char = getattr(key, "char", None)
    if isinstance(char, str) and char:
        return char.lower()
    vk = getattr(key, "vk", None)
    if isinstance(vk, int) and 0x41 <= vk <= 0x5A:      # A…Z
        return chr(vk).lower()
    return key


class HotkeyManager:
    """Écoute globale du clavier et émet des signaux Qt propres."""

    def __init__(self, letter: str = DEFAULT_HOTKEY_LETTER) -> None:
        from PyQt6.QtCore import QObject, pyqtSignal  # noqa: PLC0415

        # Classe interne : les signaux doivent vivre dans un QObject.
        class _Bridge(QObject):
            toggle_requested = pyqtSignal()
            escape_requested = pyqtSignal()

        self.signals = _Bridge()
        self._letter = (letter or DEFAULT_HOTKEY_LETTER).lower()[:1]
        self._pressed: set = set()
        self._combo_armed = True    # évite les répétitions auto du clavier
        self._escape_enabled = False
        if PYNPUT_OK:
            self._listener = keyboard.Listener(
                on_press=self._on_press, on_release=self._on_release
            )
        else:
            self._listener = None

    # ------------------------------------------------------------------ API
    def set_letter(self, letter: str) -> None:
        self._letter = (letter or DEFAULT_HOTKEY_LETTER).lower()[:1]

    def set_escape_enabled(self, enabled: bool) -> None:
        """Active l'écoute d'Échap (pendant une session focus uniquement)."""
        self._escape_enabled = enabled

    def start(self) -> None:
        if not PYNPUT_OK:
            return
        self._listener.start()
        logger.info("Raccourci global actif : Ctrl+Alt+%s (maj.)",
                    self._letter.upper())

    def stop(self) -> None:
        if not PYNPUT_OK:
            return
        try:
            self._listener.stop()
        except Exception:
            pass

    # ----------------------------------------------------------- callbacks
    def _on_press(self, key) -> None:
        normalized = _normalize(key)

        # --- Échap (mode focus) : priorité absolue ------------------------
        if key is _KEY.esc and self._escape_enabled:
            self.signals.escape_requested.emit()
            return

        # --- Combo Ctrl + Alt + <lettre> -----------------------------------
        self._pressed.add(normalized)
        combo = set(HOTKEY_MODIFIERS) | {self._letter}
        if self._combo_armed and combo.issubset(self._pressed):
            self._combo_armed = False       # une seule fois par appui
            self.signals.toggle_requested.emit()

    def _on_release(self, key) -> None:
        normalized = _normalize(key)
        self._pressed.discard(normalized)
        # Réarme le combo dès qu'une touche du combo est relâchée.
        if normalized in HOTKEY_MODIFIERS or normalized == self._letter:
            self._combo_armed = True
