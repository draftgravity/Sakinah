"""Services métier : client Mawaqit et planificateur de prières."""
