"""
Service de suivi des prières.

Responsabilités :
  * récupérer les horaires Mawaqit dans un thread dédié (jamais dans le
    thread GUI) avec cache hors-ligne dans config.json ;
  * recalculer chaque seconde la « prochaine prière » et son compte à
    rebours (gère le passage de minuit et le Fajr de demain) ;
  * déclencher les rappels : notification N minutes avant, puis à l'heure
    exacte (adhan ou bip — la lecture est pilotée par le contrôleur).

Signaux émis (tous dans le thread GUI) :
  * ``times_ready(object)``      → ``MosqueData`` fraîchement chargée ;
  * ``fetch_failed(str)``        → message d'erreur lisible ;
  * ``countdown_changed(dict)``  → état complet du compte à rebours ;
  * ``reminder(str, str)``       → (type "before"|"at", clé de la prière).
"""

import threading
from datetime import date, datetime, timedelta

from PyQt6.QtCore import QObject, QTimer, pyqtSignal

from app.config import ConfigManager
from app.constants import PRAYER_LABELS, REMINDABLE_PRAYERS
from app.services import mawaqit
from app.utils.logger import get_logger

logger = get_logger("prayers")

REMINDER_BEFORE = "before"   # N minutes avant la prière
REMINDER_AT = "at"           # à l'heure exacte


def format_remaining(seconds: float) -> str:
    """Formate un nombre de secondes en durée lisible en français."""
    total = max(0, int(seconds))
    hours, rest = divmod(total, 3600)
    minutes, secs = divmod(rest, 60)
    if hours > 0:
        return f"dans {hours} h {minutes:02d} min"
    if minutes > 0:
        return f"dans {minutes} min {secs:02d} s"
    return f"dans {secs} s"


class PrayerService(QObject):
    times_ready = pyqtSignal(object)        # MosqueData
    fetch_failed = pyqtSignal(str)
    countdown_changed = pyqtSignal(dict)
    reminder = pyqtSignal(str, str)         # (kind, prayer_key)

    def __init__(self, config: ConfigManager, parent: QObject | None = None) -> None:
        super().__init__(parent)
        self.config = config
        self.data: mawaqit.MosqueData | None = None

        self._today: date = date.today()
        self._previous_now: datetime = datetime.now()
        self._fired: set[tuple[str, str]] = set()   # (kind, clé) déjà émis
        self._fetch_lock = threading.Lock()
        self._fetching = False

        self._ticker = QTimer(self)
        self._ticker.setInterval(1000)
        self._ticker.timeout.connect(self._on_tick)

    # ------------------------------------------------------------------ API
    def start(self) -> None:
        """Démarre le service : récupère les horaires puis lance le ticker."""
        self.refresh_async(use_cache=True)
        self._ticker.start()

    def refresh_async(self, use_cache: bool = False) -> None:
        """Lance la récupération des horaires dans un thread séparé."""
        slug = self.config.get("mosque.slug") or ""
        if not slug:
            self.fetch_failed.emit(
                "Aucune mosquée configurée — ouvrez les paramètres."
            )
            return

        if use_cache and self.data is not None:
            return  # données déjà en mémoire : rien à faire

        with self._fetch_lock:
            if self._fetching:
                return
            self._fetching = True

        def worker() -> None:
            try:
                fetched = mawaqit.fetch_mosque_data(slug)
                self.data = fetched            # dispo immédiatement pour le ticker
                self._save_cache(fetched)
                # Émettre depuis ce thread est sûr : Qt achemine
                # automatiquement le signal vers le thread GUI (queued).
                self.times_ready.emit(fetched)
            except Exception as exc:  # réseau, slug invalide, parsing…
                logger.warning("Échec de récupération Mawaqit : %s", exc)
                cached = self._load_cache(slug)
                if cached is not None:
                    logger.info("Repli sur le cache hors-ligne (%s)", cached.name)
                    self.times_ready.emit(cached)
                else:
                    self.fetch_failed.emit(str(exc))
            finally:
                with self._fetch_lock:
                    self._fetching = False

        threading.Thread(target=worker, name="mawaqit-fetch", daemon=True).start()

    def mosque_changed(self) -> None:
        """Appelé quand l'utilisateur change de mosquée : reset + fetch."""
        self.data = None
        self._fired.clear()
        self.refresh_async()

    # ------------------------------------------------------------ CACHE
    def _save_cache(self, data: mawaqit.MosqueData) -> None:
        """Stocke les horaires du jour en format sérialisable (JSON)."""
        def fmt(value):
            return value.strftime("%H:%M") if value else None

        self.config.cache_mosque({
            "slug": data.slug,
            "name": data.name,
            "timezone": data.timezone,
            "jumua": data.jumua,
            "times": {key: fmt(value) for key, value in data.times.items()},
            "tomorrow_fajr": fmt(data.tomorrow_fajr),
        })
        self.config.save()

    def _load_cache(self, slug: str) -> mawaqit.MosqueData | None:
        """Reconstruit des MosqueData depuis le cache (ou None si absent)."""
        raw = self.config.get("cache.mosque_data")
        if not isinstance(raw, dict) or raw.get("slug") != slug:
            return None
        times_raw = raw.get("times", {})
        times = {
            key: mawaqit.parse_time(times_raw.get(key))
            for key in mawaqit.TIME_KEYS
        }
        return mawaqit.MosqueData(
            slug=slug,
            name=raw.get("name") or slug,
            timezone=raw.get("timezone"),
            jumua=raw.get("jumua"),
            times=times,
            tomorrow_fajr=mawaqit.parse_time(raw.get("tomorrow_fajr")),
            from_cache=True,
        )

    # ------------------------------------------------------------ TICK 1 s
    def _on_tick(self) -> None:
        now = datetime.now()
        prev = self._previous_now
        self._previous_now = now

        # Passage de minuit → nouveau jour : on recharge les horaires.
        if now.date() != self._today:
            logger.info("Nouveau jour (%s) → rechargement", now.date())
            self._today = now.date()
            self._fired.clear()
            self.refresh_async()

        info = self._compute_next(now)
        self.countdown_changed.emit(info)

        # Rappels (uniquement pour les vraies prières, pas Chourouk).
        if self.data is not None and self.config.get("notifications.enabled", True):
            self._maybe_fire_reminders(prev, now)

    # -------------------------------------------------------- CALCULS
    def _compute_next(self, now: datetime) -> dict:
        """Détermine la prochaine prière et son compte à rebours."""
        if self.data is None:
            return {
                "has_data": False,
                "next_key": None, "next_label": None,
                "next_time": None, "next_datetime": None,
                "remaining_s": None, "remaining_str": None,
                "is_tomorrow": False,
            }

        today = now.date()
        best_key, best_dt = None, None

        for key in REMINDABLE_PRAYERS:            # fajr…isha (sans chourouk)
            value = self.data.times.get(key)
            if value is None:
                continue
            candidate = datetime.combine(today, value)
            if candidate > now and (best_dt is None or candidate < best_dt):
                best_key, best_dt = key, candidate

        is_tomorrow = False
        if best_dt is None:
            # Toutes les prières du jour sont passées → Fajr de demain.
            is_tomorrow = True
            best_key = "fajr"
            fajr = self.data.tomorrow_fajr or self.data.times.get("fajr")
            if fajr is not None:
                best_dt = datetime.combine(today + timedelta(days=1), fajr)

        if best_dt is None:
            return {"has_data": True, "next_key": None, "next_label": None,
                    "next_time": None, "next_datetime": None,
                    "remaining_s": None, "remaining_str": None,
                    "is_tomorrow": False}

        remaining = (best_dt - now).total_seconds()
        return {
            "has_data": True,
            "next_key": best_key,
            "next_label": PRAYER_LABELS.get(best_key, best_key),
            "next_time": best_dt.strftime("%H:%M"),
            "next_datetime": best_dt,
            "remaining_s": remaining,
            "remaining_str": format_remaining(remaining),
            "is_tomorrow": is_tomorrow,
        }

    def _maybe_fire_reminders(self, prev: datetime, now: datetime) -> None:
        """Notifie quand on franchit les seuils (T-N min, puis T)."""
        minutes_before = int(self.config.get("notifications.minutes_before", 15))
        for key in REMINDABLE_PRAYERS:
            value = self.data.times.get(key)
            if value is None:
                continue
            target = datetime.combine(now.date(), value)

            before_threshold = target - timedelta(minutes=minutes_before)
            if (key, REMINDER_BEFORE) not in self._fired and prev < before_threshold <= now:
                self._fired.add((key, REMINDER_BEFORE))
                self.reminder.emit(REMINDER_BEFORE, key)
                logger.info("Rappel « avant » déclenché pour %s", key)

            if (key, REMINDER_AT) not in self._fired and prev < target <= now:
                self._fired.add((key, REMINDER_AT))
                self.reminder.emit(REMINDER_AT, key)
                logger.info("Rappel « à l'heure » déclenché pour %s", key)
