"""
Client de l'API Mawaqit (non officielle, publique).

Deux sources de données complémentaires :

1. Recherche de mosquées ::
       GET https://mawaqit.net/api/2.0/mosque/search?word=<mot>
   → liste JSON : name, slug, localisation, times (6 horaires du jour :
     [Fajr, Chourouk, Dhuhr, Asr, Maghrib, Isha]), iqama, jumua…

2. Page publique de la mosquée ::
       GET https://mawaqit.net/fr/<slug>
   → HTML contenant ``var confData = {...};`` avec, entre autres :
     * ``times``      : 5 horaires du jour (SANS Chourouk)
     * ``shuruq``     : lever du soleil
     * ``calendar``   : 12 mois (index 0 = janvier) × jours → 6 horaires
                        (utile pour le Fajr de demain et le mode hors-ligne)
     * ``jumua``      : heure de la prière du vendredi
     * ``timezone``   : fuseau de la mosquée

Toutes les fonctions renvoient des structures typées et tolérantes
(champs manquants → None, formats « HH:MM » ou « H:MM » acceptés).
"""

import json
import re
from dataclasses import dataclass, field
from datetime import date, datetime, time

import requests

from app.constants import (
    MAWAQIT_HEADERS,
    MAWAQIT_MOSQUE_URL,
    MAWAQIT_SEARCH_URL,
)
from app.utils.logger import get_logger

logger = get_logger("mawaqit")

# Clés internes des horaires (l'ordre suit la journée) :
TIME_KEYS = ["fajr", "shourouk", "dhuhr", "asr", "maghrib", "isha"]


# ---------------------------------------------------------------------------
# Modèles de données
# ---------------------------------------------------------------------------
@dataclass
class MosqueSummary:
    """Résultat de recherche : une mosquée et ses horaires du jour."""
    slug: str
    name: str
    localisation: str = ""
    jumua: str | None = None
    times: dict[str, time | None] = field(default_factory=dict)


@dataclass
class MosqueData:
    """Données complètes d'une mosquée (page confData)."""
    slug: str
    name: str
    timezone: str | None = None
    jumua: str | None = None
    jumua2: str | None = None
    times: dict[str, time | None] = field(default_factory=dict)
    tomorrow_fajr: time | None = None          # premier horaire de demain
    calendar: list | None = None               # calendrier annuel brut
    fetched_at: datetime = field(default_factory=datetime.now)
    from_cache: bool = False                   # True = servi depuis config.json


# ---------------------------------------------------------------------------
# Outils de parsing
# ---------------------------------------------------------------------------
def parse_time(value) -> time | None:
    """Convertit « 20:15 » / « 5:06 » en ``datetime.time`` (tolérant)."""
    if value is None:
        return None
    if isinstance(value, time):
        return value
    text = str(value).strip()
    if not text:
        return None
    for fmt in ("%H:%M", "%H:%M:%S"):
        try:
            return datetime.strptime(text, fmt).time()
        except ValueError:
            continue
    return None


def _times_from_list(values) -> dict[str, time | None]:
    """Construit le dictionnaire des 6 horaires depuis une liste.

    Accepte :
      * 6 éléments → [Fajr, Chourouk, Dhuhr, Asr, Maghrib, Isha] (recherche)
      * 5 éléments → [Fajr, Dhuhr, Asr, Maghrib, Isha] (confData ``times``)
    """
    result = {key: None for key in TIME_KEYS}
    if not isinstance(values, (list, tuple)):
        return result
    items = [parse_time(v) for v in values]
    if len(items) >= 6:                     # format « recherche » (6 valeurs)
        for key, value in zip(TIME_KEYS, items[:6]):
            result[key] = value
    elif len(items) == 5:                   # format « confData » (sans Chourouk)
        for key, value in zip(
            ["fajr", "dhuhr", "asr", "maghrib", "isha"], items
        ):
            result[key] = value
    return result


def calendar_time(calendar, day: date, index: int = 0) -> time | None:
    """Extrait un horaire précis du calendrier annuel Mawaqit.

    ``calendar`` : liste de 12 mois ; ``calendar[m-1]`` est un dict dont les
    clés sont les jours (« 1 » … « 31 ») et les valeurs 6 horaires.
    ``index`` : 0 = Fajr, 1 = Chourouk, 2 = Dhuhr, 3 = Asr, 4 = Maghrib, 5 = Isha.
    """
    if not isinstance(calendar, list):
        return None
    if day.month - 1 >= len(calendar):    # calendrier plus court que prévu
        return None
    month = calendar[day.month - 1]
    if not isinstance(month, dict):
        return None
    day_values = month.get(str(day.day)) or month.get(day.day)
    if isinstance(day_values, (list, tuple)) and len(day_values) > index:
        return parse_time(day_values[index])
    return None


def pretty_name(raw: str | None) -> str:
    """« GRANDE MOSQUÉE DE PARIS » → « Grande Mosquée De Paris ».

    L'API Mawaqit renvoie parfois des noms tout en majuscules ; on applique
    une capitalisation douce uniquement dans ce cas.
    """
    if not raw or not raw.isupper():
        return raw or ""
    return " ".join(word.capitalize() for word in raw.split())


# ---------------------------------------------------------------------------
# Appels réseau
# ---------------------------------------------------------------------------
def search_mosques(word: str, timeout: float = 10.0) -> list[MosqueSummary]:
    """Recherche des mosquées par mot-clé (nom, ville, code postal…)."""
    word = (word or "").strip()
    if len(word) < 2:
        return []
    response = requests.get(
        MAWAQIT_SEARCH_URL,
        params={"word": word},
        headers=MAWAQIT_HEADERS,
        timeout=timeout,
    )
    response.raise_for_status()
    data = response.json()
    if not isinstance(data, list):
        return []

    results: list[MosqueSummary] = []
    for item in data:
        slug = item.get("slug")
        if not slug:
            continue
        results.append(
            MosqueSummary(
                slug=slug,
                name=item.get("name") or item.get("label") or slug,
                localisation=item.get("localisation") or "",
                jumua=item.get("jumua"),
                times=_times_from_list(item.get("times")),
            )
        )
    logger.info("Recherche « %s » : %d mosquée(s)", word, len(results))
    return results


def fetch_mosque_data(slug: str, timeout: float = 12.0) -> MosqueData:
    """Récupère et analyse la page publique de la mosquée (confData)."""
    url = MAWAQIT_MOSQUE_URL.format(slug=slug)
    response = requests.get(url, headers=MAWAQIT_HEADERS, timeout=timeout)
    response.raise_for_status()

    # Localise le début du JSON puis décode au plus près (raw_decode) :
    # plus robuste qu'une regex non-avide si un « ;\n » apparaissait dans
    # une valeur du JSON.
    match = re.search(r"(?:var|let)\s+confData\s*=\s*", response.text)
    if not match:
        raise ValueError(
            "Impossible de trouver les horaires sur la page de la mosquée "
            f"« {slug} » (slug invalide ou page modifiée)."
        )
    conf, _ = json.JSONDecoder().raw_decode(response.text[match.end():])
    if not isinstance(conf, dict):
        raise ValueError(f"Données inattendues sur la page de « {slug} ».")

    # Horaires du jour : ``times`` (5 valeurs) + ``shuruq`` séparé.
    times = _times_from_list(conf.get("times"))
    times["shourouk"] = parse_time(conf.get("shuruq"))

    # Fajr de demain via le calendrier annuel (repli : Fajr du jour).
    from datetime import timedelta  # import local pour lisibilité

    tomorrow = date.today() + timedelta(days=1)
    tomorrow_fajr = calendar_time(conf.get("calendar"), tomorrow, index=0)
    if tomorrow_fajr is None:
        tomorrow_fajr = times.get("fajr")

    data = MosqueData(
        slug=slug,
        name=pretty_name(conf.get("name") or conf.get("label")) or slug,
        timezone=conf.get("timezone"),
        jumua=conf.get("jumua"),
        jumua2=conf.get("jumua2"),
        times=times,
        tomorrow_fajr=tomorrow_fajr,
        calendar=conf.get("calendar"),
    )
    logger.info("Horaires récupérés pour « %s » (%s)", data.name, slug)
    return data
