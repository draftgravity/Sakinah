"""
Icône Sakinah dans la zone de notification (system tray).

* menu complet : fenêtre, widget, focus, paramètres, quitter ;
* clic simple sur l'icône → fenêtre principale ;
* notifications Windows natives (toasts) via ``showMessage`` — utilisées
  pour les rappels de prières et la fin des sessions focus.
"""

from PyQt6.QtCore import QObject, pyqtSignal
from PyQt6.QtGui import QAction, QIcon
from PyQt6.QtWidgets import QMenu, QSystemTrayIcon

from app.constants import APP_NAME
from app.utils.logger import get_logger

logger = get_logger("tray")


class TrayIcon(QObject):
    """Enveloppe QSystemTrayIcon avec signaux applicatifs propres."""

    show_main_requested = pyqtSignal()
    toggle_widget_requested = pyqtSignal()
    focus_requested = pyqtSignal()
    settings_requested = pyqtSignal()
    quit_requested = pyqtSignal()

    def __init__(self, icon: QIcon, parent: QObject | None = None) -> None:
        super().__init__(parent)
        self.tray = QSystemTrayIcon(icon, self)
        self.tray.setToolTip(APP_NAME)

        menu = QMenu()
        menu.setStyleSheet("QMenu::item { padding: 6px 24px 6px 14px; }")

        action_show = QAction("Afficher Sakinah", menu)
        action_show.triggered.connect(self.show_main_requested.emit)
        menu.addAction(action_show)

        self.action_widget = QAction("Widget visible", menu)
        self.action_widget.setCheckable(True)
        self.action_widget.setChecked(True)
        self.action_widget.toggled.connect(lambda _: self.toggle_widget_requested.emit())
        menu.addAction(self.action_widget)

        action_focus = QAction("Lancer une session Focus (25 min)", menu)
        action_focus.triggered.connect(self.focus_requested.emit)
        menu.addAction(action_focus)
        self.action_focus = action_focus

        action_settings = QAction("Paramètres…", menu)
        action_settings.triggered.connect(self.settings_requested.emit)
        menu.addAction(action_settings)

        menu.addSeparator()

        action_quit = QAction("Quitter", menu)
        action_quit.triggered.connect(self.quit_requested.emit)
        menu.addAction(action_quit)

        self.tray.setContextMenu(menu)
        # Clic simple → fenêtre ; double-clic idem (confort).
        self.tray.activated.connect(self._on_activated)
        self.tray.show()
        logger.info("Icône tray affichée")

    # ------------------------------------------------------------------ API
    def notify(self, title: str, message: str, seconds: int = 6) -> None:
        """Notification Windows native (toast)."""
        self.tray.showMessage(
            title,
            message,
            QSystemTrayIcon.MessageIcon.Information,
            seconds * 1000,
        )

    def set_widget_checked(self, visible: bool) -> None:
        """Met à jour la coche « Widget visible » SANS re-émettre le signal."""
        self.action_widget.blockSignals(True)
        self.action_widget.setChecked(visible)
        self.action_widget.blockSignals(False)

    def set_focus_minutes(self, minutes: int) -> None:
        """Met à jour le libellé Focus du menu avec la durée configurée."""
        self.action_focus.setText(f"Lancer une session Focus ({minutes} min)")

    def set_tooltip(self, text: str) -> None:
        self.tray.setToolTip(text)

    def hide(self) -> None:
        self.tray.hide()

    # -------------------------------------------------------- interactions
    def _on_activated(self, reason) -> None:
        if reason in (
            QSystemTrayIcon.ActivationReason.Trigger,
            QSystemTrayIcon.ActivationReason.DoubleClick,
        ):
            self.show_main_requested.emit()
