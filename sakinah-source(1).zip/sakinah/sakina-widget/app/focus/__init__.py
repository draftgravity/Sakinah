"""Module « Mode Focus » : voile plein écran + minuteur Pomodoro."""
