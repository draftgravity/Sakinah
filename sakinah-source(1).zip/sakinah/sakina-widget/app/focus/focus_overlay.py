"""
Session « Mode Focus » (Pomodoro).

Au lancement :
  * un voile noir semi-transparent (85 %) recouvre IMMÉDIATEMENT tous les
    écrans (une fenêtre frameless topmost par écran) ;
  * sur l'écran principal : grand minuteur épuré + anneau de progression
    au centre, croix de fermeture en haut à droite ;
  * Échap (n'importe où dans Windows, via le listener global pynput) ou
    la croix → arrêt instantané, le voile disparaît ;
  * à la fin des N minutes : carillon, le voile se retire, et le
    contrôleur incrémente le compteur de sessions réussies.

L'ambiance sonore (bruit blanc / pluie) est gérée par AudioManager.
"""

from datetime import datetime, timedelta

from PyQt6.QtCore import QObject, QRectF, Qt, QTimer, pyqtSignal
from PyQt6.QtGui import QColor, QConicalGradient, QFont, QPainter, QPen
from PyQt6.QtWidgets import (
    QApplication,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from app.constants import COLOR_ACCENT_LIGHT, COLOR_AMBER, FOCUS_DIM_OPACITY
from app.utils.audio import AudioManager
from app.utils.logger import get_logger

logger = get_logger("focus")


def format_clock(seconds: int) -> str:
    """1500 → « 25:00 » — utilisé par le grand minuteur et l'onglet Focus."""
    minutes, secs = divmod(max(0, int(seconds)), 60)
    return f"{minutes:02d}:{secs:02d}"


# ---------------------------------------------------------------------------
# Anneau de progression (dessiné à la main, dégradé émeraude → ambre)
# ---------------------------------------------------------------------------
class ProgressRing(QWidget):
    """Anneau circulaire avec un dégradé conique émeraude → ambre."""

    def __init__(self, diameter: int = 340, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setFixedSize(diameter, diameter)
        self._ratio = 1.0          # 1.0 = début, 0.0 = terminé

    def set_ratio(self, ratio: float) -> None:
        self._ratio = max(0.0, min(1.0, ratio))
        self.update()

    def paintEvent(self, _event) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        # Piste de fond.
        pen = QPen(QColor("#232329"), 10)
        pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        painter.setPen(pen)
        rect = QRectF(self.rect()).adjusted(8, 8, -8, -8)
        painter.drawArc(rect, 0, 360 * 16)

        if self._ratio <= 0.001:
            return

        # Dégradé conique (sens horaire depuis le haut).
        gradient = QConicalGradient(rect.center(), 90)
        gradient.setColorAt(0.0, QColor(COLOR_ACCENT_LIGHT))
        gradient.setColorAt(1.0, QColor(COLOR_AMBER))
        pen = QPen(gradient, 10)
        pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        painter.setPen(pen)
        span = int(-self._ratio * 360 * 16)     # sens horaire
        painter.drawArc(rect, 90 * 16, span)


# ---------------------------------------------------------------------------
# Fenêtres plein écran
# ---------------------------------------------------------------------------
class DimWindow(QWidget):
    """Voile noir translucide couvrant un écran."""

    def __init__(self, screen) -> None:
        super().__init__(None)
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.Tool
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating, True)
        self.setScreen(screen)
        self.setGeometry(screen.geometry())

    def paintEvent(self, _event) -> None:
        painter = QPainter(self)
        alpha = int(FOCUS_DIM_OPACITY * 255)
        painter.fillRect(self.rect(), QColor(0, 0, 0, alpha))


class FocusWindow(DimWindow):
    """Écran principal du mode focus : voile + minuteur + anneau + croix."""

    def __init__(self, screen, session: "FocusSession") -> None:
        super().__init__(screen)
        self.session = session
        # Cette fenêtre DOIT prendre le focus clavier (pour Échap local).
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating, False)
        self.setCursor(Qt.CursorShape.BlankCursor)

        root = QVBoxLayout(self)
        root.setContentsMargins(24, 24, 24, 24)
        root.setSpacing(6)

        # Croix d'arrêt en haut à droite (accessible à la souris).
        close_row = QVBoxLayout()
        close_row.setDirection(QVBoxLayout.Direction.TopToBottom)
        close = QPushButton("×")
        close.setObjectName("CloseButton")
        close.setFixedSize(56, 56)
        close.setCursor(Qt.CursorShape.PointingHandCursor)
        close.setStyleSheet("font-size: 26px;")
        close.clicked.connect(session.cancel)
        inner = QHBoxLayout()
        inner.addStretch(1)
        inner.addWidget(close)
        close_row.addLayout(inner)
        root.addLayout(close_row)

        root.addStretch(1)

        title = QLabel("MODE FOCUS")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet(
            "color: #6EE7B7; font-size: 16px; font-weight: 800; letter-spacing: 8px;"
        )
        root.addWidget(title)

        # Anneau + minuteur superposés.
        ring_holder = QVBoxLayout()
        ring_holder.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.ring = ProgressRing(360)
        ring_holder.addWidget(self.ring)
        root.addLayout(ring_holder)

        self.time_label = QLabel(format_clock(session.duration_s))
        self.time_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        font = QFont("Segoe UI Variable Display", 64)
        font.setBold(True)
        font.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, 2)
        self.time_label.setFont(font)
        self.time_label.setStyleSheet("color: #FAFAFA;")
        root.addWidget(self.time_label, 0, Qt.AlignmentFlag.AlignHCenter)

        self.status_label = QLabel("Reste concentré — tout le reste peut attendre.")
        self.status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.status_label.setStyleSheet("color: #A1A1AA; font-size: 14px;")
        root.addWidget(self.status_label)

        root.addStretch(1)

        hint = QLabel("Échap ou × pour arrêter")
        hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
        hint.setStyleSheet("color: #52525B; font-size: 12px; letter-spacing: 1px;")
        root.addWidget(hint)

    def update_display(self, remaining_s: int) -> None:
        """Met à jour le grand minuteur + l'anneau (appelé à chaque tick)."""
        self.time_label.setText(format_clock(remaining_s))
        if self.session.duration_s > 0:
            self.ring.set_ratio(remaining_s / self.session.duration_s)

    def paintEvent(self, event) -> None:
        super().paintEvent(event)   # le voile noir d'abord…

    def keyPressEvent(self, event) -> None:
        if event.key() == Qt.Key.Key_Escape:
            self.session.cancel()
        else:
            super().keyPressEvent(event)


# ---------------------------------------------------------------------------
# Session complète (multi-écrans)
# ---------------------------------------------------------------------------
class FocusSession(QObject):
    """Orchestre une session Pomodoro sur tous les écrans."""

    finished = pyqtSignal(bool)        # True = menée à son terme
    tick = pyqtSignal(int)             # secondes restantes

    def __init__(
        self,
        duration_s: int,
        sound_kind: str,
        volume: float,
        audio: AudioManager,
        parent: QObject | None = None,
    ) -> None:
        super().__init__(parent)
        self.duration_s = max(1, int(duration_s))
        self.audio = audio
        self.sound_kind = sound_kind
        self.volume = volume

        self._windows: list[DimWindow] = []
        self._main: FocusWindow | None = None
        self._timer = QTimer(self)
        self._timer.setInterval(200)
        self._timer.timeout.connect(self._on_tick)
        self._ended_at: datetime | None = None
        self._done = False

    # ------------------------------------------------------------------ API
    def start(self) -> None:
        logger.info(
            "Session focus : %d s, ambiance « %s »", self.duration_s, self.sound_kind
        )
        self._ended_at = datetime.now() + timedelta(seconds=self.duration_s)

        screens = QApplication.screens() or [QApplication.primaryScreen()]
        for index, screen in enumerate(screens):
            if index == 0:
                window: DimWindow = FocusWindow(screen, self)
                self._main = window
            else:
                window = DimWindow(screen)
            window.show()
            self._windows.append(window)

        if self._main is not None:
            self._main.show()
            self._main.raise_()
            self._main.activateWindow()     # pour Échap au clavier

        if self.sound_kind != "none":
            self.audio.start_noise(self.sound_kind, self.volume)
        self._timer.start()

    def cancel(self) -> None:
        """Arrêt volontaire (Échap / croix) — la session ne compte pas."""
        if self._done:
            return
        self._done = True          # garantit un seul signal finished
        logger.info("Session focus annulée par l'utilisateur")
        self._cleanup()
        self.finished.emit(False)

    # ------------------------------------------------------------- interne
    def _on_tick(self) -> None:
        if self._ended_at is None:
            return
        remaining = max(0, int((self._ended_at - datetime.now()).total_seconds()))
        # Alimente le grand minuteur plein écran + l'anneau de progression.
        if self._main is not None:
            self._main.update_display(remaining)
        self.tick.emit(remaining)

        if remaining <= 0:
            self._complete()

    def _complete(self) -> None:
        logger.info("Session focus terminée avec succès")
        self._done = True
        self.audio.play_chime()
        self._cleanup()
        self.finished.emit(True)

    def _cleanup(self) -> None:
        self._timer.stop()
        self.audio.stop_noise()
        for window in self._windows:
            window.close()
            window.deleteLater()
        self._windows.clear()
        self._main = None
