"""
Thème visuel de Sakinah : feuille de style QSS sombre (zinc + émeraude),
polices, icône applicative générée par code (aucun fichier image requis).
"""

from PyQt6.QtCore import QPointF, Qt
from PyQt6.QtGui import QColor, QFont, QIcon, QPainter, QPixmap
from PyQt6.QtWidgets import QApplication

from app.constants import (
    COLOR_ACCENT_LIGHT,
)

# ---------------------------------------------------------------------------
# Feuille de style globale (appliquée à toute l'application)
# ---------------------------------------------------------------------------
QSS = """
* { outline: none; }

QWidget {
    background-color: #0C0C0E;
    color: #FAFAFA;
    font-family: "Segoe UI Variable Text", "Segoe UI", "Inter", sans-serif;
    font-size: 13px;
}

QLabel { background: transparent; }
QLabel[small="true"]  { font-size: 11px; color: #A1A1AA; }
QLabel[heading="true"] { font-size: 15px; font-weight: 700; }

/* ---------- Boutons ---------- */
QPushButton {
    background-color: #1B1B20;
    color: #FAFAFA;
    border: 1px solid #2E2E35;
    border-radius: 8px;
    padding: 8px 14px;
    font-weight: 600;
}
QPushButton:hover  { background-color: #232329; border-color: #3F3F46; }
QPushButton:pressed{ background-color: #2A2A31; }
QPushButton:disabled { color: #52525B; background-color: #141417; border-color: #26262B; }

QPushButton#PrimaryButton {
    background-color: #10B981;
    color: #05261C;
    border: none;
    font-weight: 700;
}
QPushButton#PrimaryButton:hover  { background-color: #34D399; }
QPushButton#PrimaryButton:pressed{ background-color: #059669; color: #E7FFF5; }
QPushButton#PrimaryButton:disabled { background-color: #134E3B; color: #3F6B5C; }

QPushButton#GhostButton {
    background: transparent; border: none; color: #A1A1AA; padding: 6px;
}
QPushButton#GhostButton:hover { color: #FAFAFA; background-color: rgba(255,255,255,0.06); }

QPushButton#CloseButton {
    background: transparent; border: none; color: #A1A1AA;
    font-size: 16px; padding: 4px 10px;
}
QPushButton#CloseButton:hover { color: #F87171; background-color: rgba(248,113,113,0.12); }

/* ---------- Champs ---------- */
QLineEdit, QComboBox, QSpinBox {
    background-color: #16161A;
    border: 1px solid #26262B;
    border-radius: 8px;
    padding: 7px 10px;
    color: #FAFAFA;
    selection-background-color: #10B981;
}
QLineEdit:focus, QComboBox:focus, QSpinBox:focus { border-color: #10B981; }
QLineEdit:disabled { color: #52525B; }

QComboBox::drop-down { border: none; width: 24px; }
QComboBox QAbstractItemView {
    background-color: #16161A;
    border: 1px solid #2E2E35;
    selection-background-color: rgba(16,185,129,0.22);
    selection-color: #FAFAFA;
    outline: none;
}

QSpinBox::up-button, QSpinBox::down-button {
    background: #1B1B20; border: none; width: 18px;
}
QSpinBox::up-button:hover, QSpinBox::down-button:hover { background: #2E2E35; }

/* ---------- Listes ---------- */
QListWidget {
    background-color: #16161A;
    border: 1px solid #26262B;
    border-radius: 8px;
    padding: 4px;
}
QListWidget::item { padding: 8px; border-radius: 6px; color: #E4E4E7; }
QListWidget::item:hover { background-color: #1B1B20; }
QListWidget::item:selected { background-color: rgba(16,185,129,0.18); color: #FAFAFA; }

/* ---------- Onglets ---------- */
QTabWidget::pane { border: none; }
QTabBar::tab {
    background: transparent; color: #A1A1AA;
    padding: 9px 16px; margin-right: 4px;
    border-radius: 8px; font-weight: 600;
}
QTabBar::tab:hover { color: #E4E4E7; }
QTabBar::tab:selected { color: #34D399; background-color: rgba(16,185,129,0.10); }

/* ---------- Cases à cocher / sliders ---------- */
QCheckBox { spacing: 8px; color: #E4E4E7; background: transparent; }
QCheckBox::indicator {
    width: 16px; height: 16px; border-radius: 5px;
    border: 1px solid #3F3F46; background: #16161A;
}
QCheckBox::indicator:hover { border-color: #10B981; }
QCheckBox::indicator:checked { background-color: #10B981; border-color: #10B981; }

QSlider::groove:horizontal { height: 5px; background: #26262B; border-radius: 2px; }
QSlider::sub-page:horizontal { background: #10B981; border-radius: 2px; }
QSlider::handle:horizontal {
    width: 14px; height: 14px; margin: -5px 0;
    border-radius: 7px; background: #E4E4E7;
}
QSlider::handle:horizontal:hover { background: #34D399; }

/* ---------- Cadres / cartes ---------- */
QFrame#Card {
    background-color: #141417;
    border: 1px solid #26262B;
    border-radius: 12px;
}
QFrame#NextBanner {
    background-color: qlineargradient(x1:0, y1:0, x2:1, y2:1,
        stop:0 #0B2B21, stop:1 #10402F);
    border: 1px solid #17553F;
    border-radius: 12px;
}
QFrame#PrayerRow {
    background: transparent;
    border: none;
    border-bottom: 1px solid #1D1D22;
}
QFrame#PrayerRowNext {
    background-color: rgba(16,185,129,0.10);
    border: 1px solid rgba(16,185,129,0.45);
    border-radius: 10px;
}

/* ---------- Scroll / infobulle ---------- */
QScrollArea { background: transparent; border: none; }
QScrollBar:vertical { background: transparent; width: 8px; margin: 2px; }
QScrollBar::handle:vertical { background: #2E2E35; border-radius: 4px; min-height: 30px; }
QScrollBar::handle:vertical:hover { background: #3F3F46; }
QScrollBar::add-line, QScrollBar::sub-line { height: 0; width: 0; }
QScrollBar::add-page, QScrollBar::sub-page { background: transparent; }

QToolTip {
    background-color: #1D1D22; color: #E4E4E7;
    border: 1px solid #2E2E35; border-radius: 6px;
    padding: 6px 8px; font-size: 12px;
}

QGroupBox {
    border: 1px solid #26262B; border-radius: 10px;
    margin-top: 14px; padding: 14px 12px 12px 12px;
    font-weight: 600; color: #A1A1AA; background: transparent;
}
QGroupBox::title { subcontrol-origin: margin; left: 12px; padding: 0 6px; }
"""


def apply_theme(app: QApplication) -> None:
    """Applique la police de base et la feuille de style à l'application."""
    font = QFont("Segoe UI Variable Text", 10)
    font.setStyleStrategy(QFont.StyleStrategy.PreferAntialias)
    app.setFont(font)
    app.setStyleSheet(QSS)


def arabic_font(point_size: int = 18, bold: bool = False) -> QFont:
    """Renvoie une police adaptée à l'affichage de l'arabe (avec replis)."""
    font = QFont()
    # setFamilies permet une liste de repli : la première police installée
    # sur le système de l'utilisateur sera utilisée.
    font.setFamilies(["Amiri", "Scheherazade New", "Traditional Arabic", "Arial"])
    font.setPointSize(point_size)
    font.setBold(bold)
    return font


def build_app_icon(size: int = 256) -> QIcon:
    """Génère l'icône de l'application (carré noir arrondi + croissant).

    Dessinée entièrement par code → aucun fichier .ico à distribuer.
    Utilisée pour : tray icon, fenêtres, barre des tâches.
    """
    pixmap = QPixmap(size, size)
    pixmap.fill(Qt.GlobalColor.transparent)

    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    painter.setPen(Qt.PenStyle.NoPen)

    # Carré noir arrondi (identité visuelle du widget)
    painter.setBrush(QColor("#0B0B0C"))
    painter.drawRoundedRect(4, 4, size - 8, size - 8, size * 0.22, size * 0.22)

    # Croissant de lune émeraude = grand cercle moins cercle décalé
    cx, cy, radius = size * 0.50, size * 0.50, size * 0.20
    painter.setBrush(QColor(COLOR_ACCENT_LIGHT))
    painter.drawEllipse(QPointF(cx, cy), radius, radius)
    painter.setBrush(QColor("#0B0B0C"))
    painter.drawEllipse(QPointF(cx + radius * 0.42, cy - radius * 0.22),
                        radius * 0.88, radius * 0.88)

    # Petit point « étoile » à côté du croissant
    painter.setBrush(QColor(COLOR_ACCENT_LIGHT))
    painter.drawEllipse(QPointF(cx - radius * 0.85, cy + radius * 0.65),
                        radius * 0.14, radius * 0.14)
    painter.end()

    return QIcon(pixmap)
