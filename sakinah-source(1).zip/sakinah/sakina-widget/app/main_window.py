"""
Fenêtre principale de Sakinah (pop-up sous le carré noir).

* frameless + coins arrondis + liseré, taille fixe (420 × 640) ;
* apparaît SOUS le widget overlay (ancre passée par le contrôleur) et se
  recale automatiquement dans l'écran ;
* comportement « flyout » : se referme quand l'utilisateur clique
  ailleurs (après un délai de 250 ms pour laisser passer les allers-
  retours avec le carré) ;
* en-tête : nom de la mosquée + bouton Paramètres + bouton Fermer ;
* deux onglets : Prières (Mawaqit) et Mode Focus ;
* pied de page : prochaine prière en un coup d'œil + version.
"""

from PyQt6.QtCore import QTimer, Qt, pyqtSignal
from PyQt6.QtGui import QGuiApplication
from PyQt6.QtWidgets import (
    QApplication,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from app.config import ConfigManager
from app.constants import APP_VERSION
from app.ui.focus_tab import FocusTab
from app.ui.prayers_tab import PrayersTab
from app.utils.logger import get_logger

logger = get_logger("main-window")

POPUP_WIDTH = 430
POPUP_HEIGHT = 660


class MainWindow(QWidget):
    """Pop-up principale à deux onglets."""

    settings_requested = pyqtSignal()

    def __init__(self, config: ConfigManager, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.config = config
        self.setObjectName("MainPopup")

        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.Tool
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setFixedSize(POPUP_WIDTH, POPUP_HEIGHT)

        # Filet décoratif : la fenêtre est translucide, on dessine le fond
        # dans paintEvent pour obtenir les coins arrondis.
        self.setStyleSheet(
            "#MainPopup { background-color: #101013; "
            "border: 1px solid #26262B; border-radius: 16px; }"
        )

        root = QVBoxLayout(self)
        root.setContentsMargins(18, 14, 18, 14)
        root.setSpacing(10)

        # --- En-tête --------------------------------------------------------
        header = QHBoxLayout()
        header.setSpacing(8)

        title = QLabel("Sakinah")
        title.setStyleSheet(
            "font-size: 15px; font-weight: 800; letter-spacing: 1px;"
        )
        header.addWidget(title)

        self.mosque_chip = QLabel("")
        self.mosque_chip.setProperty("small", True)
        self.mosque_chip.setStyleSheet(
            "color: #A1A1AA; background: rgba(255,255,255,0.05); "
            "border-radius: 9px; padding: 2px 10px;"
        )
        header.addWidget(self.mosque_chip, 1)

        settings_btn = QPushButton("Paramètres")
        settings_btn.setObjectName("GhostButton")
        settings_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        settings_btn.clicked.connect(self.settings_requested.emit)
        header.addWidget(settings_btn)

        close_btn = QPushButton("×")
        close_btn.setObjectName("CloseButton")
        close_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        close_btn.clicked.connect(self._close_by_user)
        header.addWidget(close_btn)
        root.addLayout(header)

        # --- Onglets ----------------------------------------------------------
        self.tabs = QTabWidget()
        self.prayers_tab = PrayersTab()
        self.focus_tab = FocusTab(config)
        self.tabs.addTab(self.prayers_tab, "Prières")
        self.tabs.addTab(self.focus_tab, "Mode Focus")
        root.addWidget(self.tabs, 1)

        # --- Pied de page -----------------------------------------------------
        footer = QHBoxLayout()
        self.footer_countdown = QLabel("Prochaine prière : —")
        self.footer_countdown.setStyleSheet("color: #34D399; font-size: 12px;")
        footer.addWidget(self.footer_countdown)
        footer.addStretch(1)
        version = QLabel(f"v{APP_VERSION} · PyQt6")
        version.setProperty("small", True)
        footer.addWidget(version)
        root.addLayout(footer)

        # --- Fermeture automatique (flyout) -------------------------------------
        self._hide_timer = QTimer(self)
        self._hide_timer.setSingleShot(True)
        self._hide_timer.setInterval(250)
        self._hide_timer.timeout.connect(self._maybe_hide)
        self._ignore_next_deactivate = False

    # ------------------------------------------------------------- ouverture
    def popup_below(self, anchor_global_x: int, anchor_global_y: int) -> None:
        """Ouvre la fenêtre juste sous le carré, en restant dans l'écran.

        Utilise l'écran qui contient réellement le carré (et non l'écran
        primaire) — indispensable en configuration multi-écrans.
        """
        from PyQt6.QtCore import QPoint  # noqa: PLC0415

        screen = (
            QGuiApplication.screenAt(QPoint(anchor_global_x, anchor_global_y))
            or self.screen()
            or QApplication.primaryScreen()
        )
        if screen is None:
            self.show()
            return
        area = screen.availableGeometry()

        x = anchor_global_x + 8 - POPUP_WIDTH + 40   # aligné à droite du carré
        y = anchor_global_y + 12                      # juste en dessous

        # Cale la fenêtre dans la zone de travail (barre des tâches incluse).
        x = max(area.left(), min(x, area.right() - POPUP_WIDTH))
        y = max(area.top(), min(y, area.bottom() - POPUP_HEIGHT))

        self.move(x, y)
        self._ignore_next_deactivate = False
        self.show()
        self.raise_()
        self.activateWindow()

    # ---------------------------------------------------- flyout (auto-hide)
    def _close_by_user(self) -> None:
        self._ignore_next_deactivate = True
        self.hide()

    def _maybe_hide(self) -> None:
        if not self.isActiveWindow():
            self.hide()

    def changeEvent(self, event) -> None:
        # Perte de focus → fermeture différée (laisse le temps aux clics
        # sur le carré de rebasculer la fenêtre).
        if event.type() == event.Type.WindowDeactivate:
            if not self._ignore_next_deactivate:
                self._hide_timer.start()
        elif event.type() == event.Type.WindowActivate:
            self._hide_timer.stop()
        super().changeEvent(event)

    def keyPressEvent(self, event) -> None:
        if event.key() == Qt.Key.Key_Escape:
            self.hide()
        else:
            super().keyPressEvent(event)

    # ------------------------------------------------------------- contenu
    def set_mosque_name(self, name: str) -> None:
        text = name if len(name) <= 34 else name[:32] + "…"
        self.mosque_chip.setText(text)

    def set_footer_countdown(self, text: str) -> None:
        self.footer_countdown.setText(f"Prochaine prière : {text}")
