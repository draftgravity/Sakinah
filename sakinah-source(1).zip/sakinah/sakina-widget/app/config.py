"""
Gestion de la configuration (config.json).

* Valeurs par défaut robustes : toute clé manquante est recréée (deep merge),
  le fichier peut donc être édité / partiellement corrompu sans crash.
* Accès par chemin pointé : ``cfg.get("notifications.minutes_before")``.
* Sauvegarde atomique (écriture d'un .tmp puis remplacement) pour éviter
  toute corruption si l'ordinateur s'éteint au mauvais moment.
"""

import copy
import json
import logging
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any

from app.constants import CONFIG_PATH

logger = logging.getLogger("sakinah.config")

# ---------------------------------------------------------------------------
# Valeurs par défaut : structure complète de config.json
# ---------------------------------------------------------------------------
DEFAULTS: dict[str, Any] = {
    "mosque": {
        "slug": "grande-mosquee-de-paris",
        "name": "Grande Mosquée de Paris",
    },
    "notifications": {
        "enabled": True,
        "minutes_before": 15,       # rappel N minutes avant chaque prière
        "adhan_enabled": True,      # joue assets/sounds/adhan.mp3 à l'heure
        "beep_fallback": True,      # bip discret si pas d'adhan disponible
        "volume": 1.0,              # volume adhan/bips (indépendant du focus)
    },
    "focus": {
        "duration_minutes": 25,     # durée d'une session Pomodoro
        "sound": "none",            # none | white | rain (ambiance session)
        "volume": 0.6,              # volume de l'ambiance (0.0 → 1.0)
        "stats": {},                # {"YYYY-MM-DD": nb_sessions_réussies}
    },
    "widget": {
        "size": 36,                 # taille du carré en px (24 → 56)
        "position": None,           # [x, y] ou null → position auto (haut-droite)
        "click_through": False,     # mode discret : laisse passer les clics
        "hide_on_fullscreen": True, # masque le carré si une app plein écran
    },
    "general": {
        "autostart": False,         # lancement automatique avec Windows
        "hotkey_letter": "h",       # Ctrl + Alt + <lettre> pour masquer/afficher
    },
    "cache": {
        "mosque_data": None,        # dernier confData brut (mode hors-ligne)
        "fetched_at": None,
    },
}


def _deep_merge(base: dict, override: dict) -> dict:
    """Fusionne récursivement ``override`` dans ``base`` (base conservée)."""
    result = copy.deepcopy(base)
    for key, value in (override or {}).items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


# Champs numériques à valider au chargement : (chemin, minimum, maximum,
# défaut) — une valeur invalide (« abc », hors bornes…) est silencieusement
# remplacée par le défaut au lieu de faire planter l'application dans un
# slot QTimer (une exception dans un slot arrête le processus sous PyQt6).
_INT_BOUNDS: list[tuple[str, int, int, int]] = [
    ("notifications.minutes_before", 1, 60, 15),
    ("widget.size", 24, 56, 36),
    ("focus.duration_minutes", 1, 180, 25),
]
_FLOAT_BOUNDS: list[tuple[str, float, float, float]] = [
    ("focus.volume", 0.0, 1.0, 0.6),
    ("notifications.volume", 0.0, 1.0, 1.0),
]


class ConfigManager:
    """Petit gestionnaire de configuration avec accès par chemin pointé."""

    def __init__(self, path: Path = CONFIG_PATH) -> None:
        self.path = Path(path)
        self.data: dict = copy.deepcopy(DEFAULTS)
        self._load()

    # --- Chargement / sauvegarde -------------------------------------------
    def _load(self) -> None:
        """Charge config.json en fusionnant sur les valeurs par défaut."""
        if not self.path.exists():
            logger.info("config.json absent → valeurs par défaut créées")
            self.save()
            return
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
            if isinstance(raw, dict):
                self.data = _deep_merge(DEFAULTS, raw)
            else:
                logger.warning("config.json invalide → valeurs par défaut")
        except (json.JSONDecodeError, OSError) as exc:
            logger.warning("Impossible de lire config.json (%s) → défauts", exc)
        self._sanitize()

    def _sanitize(self) -> None:
        """Coerce les champs numériques critiques (config éditée à la main)."""
        for dotted, lo, hi, default in _INT_BOUNDS:
            try:
                value = int(self.get(dotted, default))
            except (TypeError, ValueError):
                value = default
            self.set(dotted, max(lo, min(hi, value)))
        for dotted, lo, hi, default in _FLOAT_BOUNDS:
            try:
                value = float(self.get(dotted, default))
            except (TypeError, ValueError):
                value = default
            self.set(dotted, max(lo, min(hi, value)))
        # Le dictionnaire de statistiques doit rester un dictionnaire.
        stats = self.data["focus"].get("stats")
        if not isinstance(stats, dict):
            self.data["focus"]["stats"] = {}

    def save(self) -> None:
        """Écrit la configuration sur disque de façon atomique."""
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_suffix(".json.tmp")
            tmp.write_text(
                json.dumps(self.data, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
            tmp.replace(self.path)
        except OSError as exc:
            logger.error("Sauvegarde de config.json impossible : %s", exc)

    # --- Accès par chemin pointé ---------------------------------------------
    def get(self, dotted: str, default: Any = None) -> Any:
        node: Any = self.data
        for part in dotted.split("."):
            if not isinstance(node, dict) or part not in node:
                return default
            node = node[part]
        return node

    def set(self, dotted: str, value: Any, autosave: bool = False) -> None:
        node = self.data
        parts = dotted.split(".")
        for part in parts[:-1]:
            node = node.setdefault(part, {})
            if not isinstance(node, dict):  # structure incohérente → répare
                logger.warning("config.json : chemin « %s » incohérent — ignoré", dotted)
                return
        node[parts[-1]] = value
        if autosave:
            self.save()

    # --- Statistiques Focus (compteur quotidien de sessions réussies) --------
    def add_focus_session(self) -> int:
        """Incrémente le compteur du jour et renvoie le nouveau total."""
        today = date.today().isoformat()
        stats: dict = self.data["focus"].setdefault("stats", {})
        stats[today] = int(stats.get(today, 0)) + 1
        self._prune_focus_stats()
        return stats[today]

    def focus_sessions_today(self) -> int:
        stats = self.get("focus.stats", {}) or {}
        return int(stats.get(date.today().isoformat(), 0))

    def _prune_focus_stats(self, keep_days: int = 30) -> None:
        """Ne conserve que les ``keep_days`` derniers jours de statistiques."""
        stats: dict = self.data["focus"].setdefault("stats", {})
        limit = (date.today() - timedelta(days=keep_days)).isoformat()
        for key in [k for k in stats if k < limit]:
            stats.pop(key, None)

    # --- Cache hors-ligne ------------------------------------------------------
    def cache_mosque(self, raw_conf: dict | None) -> None:
        self.set("cache.mosque_data", raw_conf)
        self.set("cache.fetched_at", datetime.now().isoformat(timespec="seconds"))
