# 🚀 Guide de déploiement — mettre Sakinah en ligne

> **Objectif** : votre site sur Internet, gratuit, en ~30 minutes.
> GitHub héberge le code · Vercel fait tourner le site · Neon héberge la
> base de données. Tout est gratuit pour un projet de cette taille.

```
   [ GitHub ]  ──déploiement auto──▶  [ Vercel : le site ]  ──▶  [ Neon : les comptes ]
    le code                           sakinah.vercel.app          la base PostgreSQL
```

**Sommaire**
1. [Le point crucial : quoi mettre sur GitHub](#1-le-point-crucial--quoi-mettre-sur-github)
2. [Étape A — Télécharger le paquet source](#2-étape-a--télécharger-le-paquet-source)
3. [Étape B — Créer le dépôt GitHub (public)](#3-étape-b--créer-le-dépôt-github-public)
4. [Étape C — Créer la base gratuite (Neon)](#4-étape-c--créer-la-base-gratuite-neon)
5. [Étape D — Déployer sur Vercel](#5-étape-d--déployer-sur-vercel)
6. [Étape E — Créer VOTRE compte gérant](#6-étape-e--créer-votre-compte-gérant)
7. [Mettre le site à jour plus tard](#7-mettre-le-site-à-jour-plus-tard)
8. [Optionnel — apparaître sur Google](#8-optionnel--apparaître-sur-google)
9. [Le ZIP du widget — ce que font les visiteurs](#9-le-zip-du-widget--ce-que-font-les-visiteurs)
10. [Sécurité : mots de passe et secrets](#10-sécurité--mots-de-passe-et-secrets)
11. [Questions fréquentes](#11-questions-fréquentes)

---

## 1. Le point crucial : quoi mettre sur GitHub

❌ **PAS le fichier `.tar`** — le bouton « Download » en haut à droite de
l'atelier de développement télécharge une archive de TOUT l'atelier
(outils internes, journaux, bases de test…). Elle n'est pas faite pour
GitHub.

✅ **Le paquet source** — depuis votre site, connecté en gérant :

> **Avatar (en haut à droite) → Espace gérant → onglet « Versions » →
> « Télécharger le paquet source (.zip) »**

Il contient exactement ce qui doit être public :

| Inclus                                   | Jamais inclus                        |
| ---------------------------------------- | ------------------------------------ |
| `src/` (le site Next.js complet)         | `.env` (mots de passe, URLs secrètes)|
| `sakina-widget/` (l'application Windows) | bases de données                     |
| `prisma/` (schéma de la base)            | journaux internes, captures de QA    |
| `README.md`, ce guide, `LICENSE` (MIT)   | `node_modules`                       |
| `.env.example` (modèle sans secret)      | comptes ou données de vos membres    |

> 🔒 Vérification rapide : ouvrez le zip décompressé — vous ne devez
> trouver **aucun fichier `.env`** et **aucun dossier `db/`**. C'est le
> cas par construction.

---

## 2. Étape A — Télécharger le paquet source

1. Ouvrez votre site et connectez-vous avec votre compte gérant ;
2. Cliquez sur votre avatar → **Espace gérant** ;
3. Onglet **« Versions »** (en haut du panneau) ;
4. Descendez jusqu'à **« Mettre le site en ligne — GitHub + Vercel »** ;
5. Cliquez sur **« Télécharger le paquet source (.zip) »** ;
6. **Décompressez** l'archive : vous obtenez un dossier `sakinah/`.

C'est CE dossier-là qui part sur GitHub — rien d'autre.

---

## 3. Étape B — Créer le dépôt GitHub (public)

### Pourquoi *public* ?

- Le projet est **open source** (licence MIT) : c'est le but, et cela
  inspire confiance — chacun peut lire le code, apprendre, le réutiliser
  en vous citant ;
- Personne ne peut **modifier** votre dépôt : seules vos propres
  validations (« commits ») y entrent ; les autres ne peuvent que
  *proposer* des changements que vous acceptez ou refusez ;
- Tout est gratuit. (Un dépôt *privé* fonctionne aussi avec Vercel, mais
  le projet ne serait pas open source.)

### Pas à pas avec GitHub Desktop (le plus simple)

1. **Créez votre compte** sur [github.com](https://github.com) (Sign up) ;
2. Installez **GitHub Desktop** : [desktop.github.com](https://desktop.github.com)
   → connectez-vous avec votre compte GitHub ;
3. Dans GitHub Desktop : **File → New repository…**
   - **Name** : `sakinah`
   - **Local path** : un nouveau dossier, ex. `Documents/GitHub/sakinah`
   - Laissez les autres cases cochées → **Create repository** ;
4. **Copiez le CONTENU du dossier `sakinah/` décompressé** (étape A) dans
   ce nouveau dossier — tout sauf rien, dossier par dossier si besoin ;
5. GitHub Desktop affiche alors toutes les lignes dans l'onglet
   **Changes** : écrivez un résumé (ex. `Première version de Sakinah`)
   → bouton **Commit to main** ;
6. Cliquez sur **Publish repository** :
   - ⚠️ **DÉCOUCHEZ « Keep this code private »** (pour un dépôt public) ;
   - **Publish**.

✅ Votre code est en ligne : `https://github.com/VOTRE-PSEUDO/sakinah`

> 💡 *Alternative en ligne de commande* (si vous êtes à l'aise) :
> ```bash
> cd sakinah
> git init && git add -A && git commit -m "Première version"
> git branch -M main
> git remote add origin https://github.com/VOTRE-PSEUDO/sakinah.git
> git push -u origin main
> ```

> ⚠️ *L'interface web de github.com (glisser-déposer) est limitée à
> 100 fichiers par lot — le projet en compte plus de 200. Utilisez GitHub
> Desktop.*

---

## 4. Étape C — Créer la base gratuite (Neon)

**Neon** fournit du PostgreSQL gratuit (0,5 Go — largement assez pour
des milliers de comptes). *Alternative équivalente : Supabase.*

1. Allez sur [neon.com](https://neon.com) → **Sign up** →
   « Continue with GitHub » ;
2. Sur le tableau de bord : **Create project** ;
   - Name : `sakinah`
   - Region : **Paris** (ou la plus proche de vos visiteurs)
   - **Create** ;
3. La page du projet affiche une **Connection string** qui commence par
   `postgresql://` → cliquez sur l'icône **copier** :

   ```
   postgresql://neondb_owner:xxxxxxxx@ep-sakinah-xxxx.eu-central-1.aws.neon.tech/neondb?sslmode=require
   ```

4. **Gardez cette chaîne précieusement** (elle sert à l'étape suivante)
   et ne la partagez jamais — elle contient le mot de passe de la base.

---

## 5. Étape D — Déployer sur Vercel

1. Allez sur [vercel.com](https://vercel.com) → **Continue with GitHub**
   (autorisez l'accès à vos dépôts) ;
2. **Add New… → Project** ;
3. Repérez le dépôt `sakinah` → **Import** ;
4. Configuration :
   - **Framework Preset** : Next.js (détecté automatiquement — ne touchez
     à rien : le script `vercel-build` du projet crée les tables puis
     compile) ;
   - Ouvrez **Environment Variables** et ajoutez :

     | Name          | Value                                      |
     | ------------- | ------------------------------------------ |
     | `DATABASE_URL`| *(la chaîne postgresql:// de l'étape C)*   |

5. Cliquez sur **Deploy** et attendez 1 à 2 minutes ;

✅ Votre site est en ligne : **`https://sakinah-votre-pseudo.vercel.app`**
(l'URL exacte s'affiche, et vous pourrez y ajouter un vrai nom de domaine
plus tard depuis les réglages du projet).

> 🔄 À partir de maintenant, **chaque mise à jour poussée sur GitHub est
> redéployée automatiquement** — vous n'aurez plus jamais à toucher
> Vercel.

---

## 6. Étape E — Créer VOTRE compte gérant

Sur le site en ligne (pas en local) :

1. Cliquez sur **Se connecter** → onglet **Créer un compte** ;
2. Choisissez votre nom d'utilisateur, e-mail et mot de passe ;

> ⭐ **Sur un site tout neuf, le PREMIER compte créé devient
> automatiquement le compte GÉRANT.** C'est vous : vous seul voyez
> l'espace d'administration, la bascule des versions et le paquet source.

3. Vérifiez : votre avatar → **Espace gérant** doit s'ouvrir ;
4. Les visiteurs qui créent un compte ensuite sont de simples membres
   (version prières).

---

## 7. Mettre le site à jour plus tard

1. Modifiez les fichiers concernés (dans votre dossier
   `Documents/GitHub/sakinah`) ;
2. GitHub Desktop : résumé des changements → **Commit to main** →
   **Push origin** ;
3. Vercel redéploie tout seul en ~1 minute. C'est fini.

---

## 8. Optionnel — apparaître sur Google

### a) Préparer Vercel

Dans Vercel → votre projet → **Settings → Environment Variables**,
ajoutez :

| Name                                 | Value                                    |
| ------------------------------------ | ---------------------------------------- |
| `NEXT_PUBLIC_SITE_URL`               | `https://sakinah-votre-pseudo.vercel.app`|
| `NEXT_PUBLIC_GOOGLE_SITE_VERIFICATION` | *(le code de Google, voir b))*         |

… puis **Deployments → ⋯ → Redeploy**.

### b) Google Search Console

1. [search.google.com/search-console](https://search.google.com/search-console)
   → connectez-vous avec un compte Google ;
2. **Add a property → URL prefix** → collez l'adresse de votre site →
   Continue ;
3. Méthode de vérification : **HTML tag**. Google affiche
   `<meta name="google-site-verification" content="XXXXXXXX" />` →
   copiez **uniquement le `XXXXXXXX`** dans la variable Vercel
   `NEXT_PUBLIC_GOOGLE_SITE_VERIFICATION` (étape a), puis redeployez ;
4. Retournez dans Search Console → **Verify** ;
5. Menu **Sitemaps** → entrez `sitemap.xml` → Submit ;
6. (Accélération) **URL Inspection** → collez votre URL → **Request
   indexing**. Google passe généralement sous 24 à 48 h.

---

## 9. Le ZIP du widget — ce que font les visiteurs

Le bouton **« Télécharger (.zip) »** du site fournit l'application
Windows (`sakinah-widget.zip`). Après décompression, le dossier contient
`README.md`, `main.py`, `config.json`, `requirements.txt`, `.gitignore`,
`app/`, `data/`, `assets/`. **Deux commandes** suffisent :

```bat
:: 1. installer les dépendances (PyQt6…) — une seule fois
python -m pip install -r requirements.txt

:: 2. lancer Sakinah
python main.py
```

→ **Le carré noir apparaît en haut à droite de l'écran.** Un clic
dessus ouvre la pop-up (horaires, calendrier, Qibla, Tasbih). La mosquée
se choisit dans **Paramètres → Mosquée** (nom de ville ou code postal).

Prérequis : Windows 10/11 + Python 3.10+ ([python.org](https://www.python.org/downloads/),
en cochant *« Add Python to PATH »*).

---

## 10. Sécurité : mots de passe et secrets

- **Mots de passe des comptes : jamais lisibles.** Ils sont hachés
  (scrypt) avant d'atteindre la base — même en ouvrant la base
  directement, on ne voit que
  `s1$8f3a…` (irréversible). L'API ne les renvoie jamais non plus.
- **`.env` et bases : jamais sur GitHub.** Le `.gitignore` du projet les
  exclut ; le paquet source ne les contient pas.
- **La chaîne Neon** (`DATABASE_URL`) reste dans Vercel (chiffré) — ne la
  collez jamais dans un fichier du dépôt.
- Si un secret fuite un jour : changez le mot de passe concerné, et dans
  Neon → projet → **Reset password** (une nouvelle URL est générée à
  reporter dans Vercel).

---

## 11. Questions fréquentes

**GitHub public ou privé ?**
Public pour un projet open source (c'est le cas — licence MIT) : les
visiteurs peuvent lire le code et le réutiliser en vous créditant ;
personne ne peut le modifier sans votre accord. Privé si vous voulez
garder le code pour vous — Vercel fonctionne pareil dans les deux cas.

**Ce que les gens voient sur GitHub ?**
Le code (site + application Windows), le README, la licence. Pas de
mots de passe, pas de données de membres, pas de base.

**Pourquoi Vercel relance-t-il un déploiement tout seul ?**
Il surveille votre dépôt GitHub : chaque « push » reconstruit le site.

**La base Neon est-elle vraiment gratuite ?**
Oui — 0,5 Go et des limites de connexions largement suffisantes pour
une communauté. Aucune carte bancaire demandée.

**Puis-je utiliser mon propre nom de domaine ?**
Oui : Vercel → Settings → Domains → ajoutez-le et suivez les
instructions (le plan gratuit l'autorise).

**Comment tester le site en local ?**
`cp .env.example .env` (avec votre URL Neon ou une base locale) puis
`bun run setup && bun run dev` — détails dans le
[README](README.md).
