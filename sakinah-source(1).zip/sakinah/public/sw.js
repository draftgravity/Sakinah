/**
 * Service worker Sakinah — volontairement MINIMAL et prudent :
 *
 *  * precache  : /offline.html (page autonome, sans dépendance /_next/),
 *               le manifeste et les icônes ;
 *  * navigation: network-first avec repli /offline.html (la vitrine reste
 *               honnête : en dev, les chunks /_next/ ne sont PAS cachés) ;
 *  * API horaires (/api/prayers, /api/prayers/calendar, /api/mosques/search)
 *               en GET : network-first + copie en cache → en cas de coupure
 *               réseau pendant une visite, la démo continue de fonctionner ;
 *  * TOUT le reste (chunks /_next/, HMR, POST…) : pas d'interception.
 *
 * ⚠️ Ne jamais cacher /_next/ ici : en développement les URLs des chunks
 * changent à chaque recompilation — cacher la page entière casserait le HMR.
 */

const VERSION = "v1";
const STATIC_CACHE = `sakinah-static-${VERSION}`;
const API_CACHE = `sakinah-api-${VERSION}`;

const PRECACHE_URLS = [
  "/offline.html",
  "/manifest.webmanifest",
  "/icons/icon-48.png",
  "/icons/icon-192.png",
  "/icons/icon-512.png",
  "/icons/maskable-192.png",
  "/icons/maskable-512.png",
];

/** Préfixes d'API dont la réponse peut être repliée en cache. */
const CACHED_API_PREFIXES = [
  "/api/prayers",
  "/api/mosques/search",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches
      .open(STATIC_CACHE)
      .then((cache) => cache.addAll(PRECACHE_URLS))
      .then(() => self.skipWaiting()),
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(
          keys
            .filter(
              (key) =>
                key.startsWith("sakinah-static-") ||
                key.startsWith("sakinah-api-"),
            )
            .filter((key) => key !== STATIC_CACHE && key !== API_CACHE)
            .map((key) => caches.delete(key)),
        ),
      )
      .then(() => self.clients.claim()),
  );
});

/** Réponse en cache la plus fraîche pour une URL d'API (null si absente). */
async function cachedApiResponse(request) {
  const cache = await caches.open(API_CACHE);
  const cached = await cache.match(request);
  if (!cached) return null;
  // Les réponses d'API portent leur date : au-delà de 6 h, on ne sert plus
  // un cache silencieux (le localStorage côté client prend alors le relais
  // avec ses propres gardes « même jour »).
  const fetchedAt = Date.parse(cached.headers.get("sw-fetched-at") || "");
  if (Number.isFinite(fetchedAt) && Date.now() - fetchedAt > 6 * 3600_000) {
    return null;
  }
  return cached;
}

self.addEventListener("fetch", (event) => {
  const { request } = event;
  if (request.method !== "GET") return;

  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  // 1) Navigations (documents HTML) : réseau d'abord, page hors-ligne sinon.
  if (request.mode === "navigate") {
    event.respondWith(
      fetch(request).catch(async () => {
        const cache = await caches.open(STATIC_CACHE);
        return (await cache.match("/offline.html")) || Response.error();
      }),
    );
    return;
  }

  // 2) API horaires/recherche : network-first + copie fraîche en cache.
  if (CACHED_API_PREFIXES.some((prefix) => url.pathname.startsWith(prefix))) {
    event.respondWith(
      (async () => {
        try {
          const response = await fetch(request);
          if (response.ok) {
            const cache = await caches.open(API_CACHE);
            // clone + horodatage via en-tête interne (non transmis au client).
            const copy = response.clone();
            const headers = new Headers(copy.headers);
            headers.set("sw-fetched-at", new Date().toISOString());
            const body = await copy.arrayBuffer();
            cache.put(request, new Response(body, { headers }));
          }
          return response;
        } catch {
          return (
            (await cachedApiResponse(request)) || Response.error()
          );
        }
      })(),
    );
  }
  // Tout le reste : pas d'interception (chunks /_next/, HMR, POST…).
});
