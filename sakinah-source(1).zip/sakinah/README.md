# 🕌 Sakinah — Widget de prières pour Windows

**Sakinah** est un compagnon de prière discret : un petit carré noir qui
reste au coin de votre écran et vous murmure l'heure de la prochaine
prière. Ce dépôt contient :

- **`sakina-widget/`** — l'application Windows (Python · PyQt6), figée en
  v1.0.0 : horaires Mawaqit, calendrier mensuel, boussole Qibla, mode
  concentration (Pomodoro), compteur de dhikr, notifications natives ;
- **la vitrine web** (ce site, Next.js 16) — une démo interactive du
  widget **dans le navigateur** (aucune installation), le téléchargement
  de l'application, un espace comptes avec statistiques synchronisées en
  ligne et une console d'administration pour le gérant.

## ✨ Fonctionnalités de la démo web

- **Horaires de prière en direct** (API Mawaqit) — prochaine prière,
  compte à rebours à la seconde, iqamas, Jumu'a, Ramadan ;
- **Pop-up widget** répliquée de l'application Windows : calendrier
  mensuel dépliable, boussole Qibla, rappels navigateur ;
- **Compteur de Tasbih** synchronisé : séries de régularité, graphique
  7 jours, export CSV ;
- **Comptes en ligne** : identifiant ou e-mail + mot de passe (scrypt),
  statistiques suivies sur tous vos appareils, fusion sans double
  comptage ;
- **Espace gérant** : gestion des comptes, statistiques par membre,
  journal d'activité ;
- **Mode concentration** (réservé au gérant) : minuteur Pomodoro
  immersif de 25 min avec pause.

## 🛠️ Stack technique

| Couche            | Choix                                                        |
| ----------------- | ------------------------------------------------------------ |
| Framework         | Next.js 16 (App Router, TypeScript strict)                   |
| Interface         | Tailwind CSS 4 · shadcn/ui · Framer Motion                   |
| Base de données   | PostgreSQL (Prisma ORM) — Neon/Supabase en production        |
| Horaires          | API publique Mawaqit (`mawaqit.net`)                         |
| Application       | Python 3 · PyQt6 (dossier `sakina-widget/`)                  |

## 🚀 Installation rapide

```bash
cp .env.example .env      # collez votre URL PostgreSQL
bun run setup             # dépendances + tables (+ gérant si SEED_MANAGER_* défini)
bun run dev               # → http://localhost:3000
```

*(sans bun : `npm install`, `npx prisma db push`, `npm run dev`)*

💡 Pas besoin de seed : sur une base vide, **le premier compte créé via
« Créer un compte » devient automatiquement le compte gérant**.

👉 **Guide complet** (GitHub, Vercel, base gratuite, Google Search
Console, installation ZIP) : **[GUIDE-DEPLOIEMENT.md](GUIDE-DEPLOIEMENT.md)**

## 📁 Structure du dépôt

```
src/              Vitrine + démo web (Next.js)
sakina-widget/    Application Windows (Python · PyQt6)
prisma/           Schéma de la base + seed
scripts/          Démarrage PostgreSQL local / serveur de dev
public/           Assets, manifest PWA, icônes
mini-services/    Services annexes (websocket)
examples/         Exemples techniques
```

## 🕌 Sources des horaires

Les horaires proviennent de l'API publique de
[Mawaqit](https://mawaqit.net) pour des milliers de mosquées dans le
monde. Le calcul de la prochaine prière, le calendrier hégirien
(umalqura) et le cap vers la Qibla sont effectués localement.

## 📄 Licence

MIT — voir [LICENSE](LICENSE).
