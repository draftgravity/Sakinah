/**
 * Rappels de prière dans le navigateur — le pendant web des notifications
 * Windows de l'application (app/services/prayer_service.py) :
 *  * notification 15 minutes avant chaque prière ;
 *  * notification à l'heure exacte (avec carillon discret optionnel) ;
 *  * dédupliqués par prière et par jour, comme `_fired` côté Python.
 *
 * Fonctionne tant que l'onglet est ouvert (Notification API sans service
 * worker) — la persistance de l'activation se fait via localStorage.
 */

"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useDemoStore } from "@/lib/demo-store";
import { computeNextPrayer, PRAYER_LABELS, zoneClock } from "@/lib/prayer-utils";

const STORAGE_KEY = "sakinah-notifications";
const MINUTES_BEFORE = 15;

type NotifPref = "enabled" | "disabled";

function readPref(): NotifPref {
  try {
    return window.localStorage.getItem(STORAGE_KEY) === "enabled"
      ? "enabled"
      : "disabled";
  } catch {
    return "disabled";
  }
}

/** Petit carillon discret (2 notes) — context audio créé sur le geste. */
function playReminderChime() {
  try {
    const Ctx =
      window.AudioContext ??
      (window as unknown as { webkitAudioContext?: typeof AudioContext })
        .webkitAudioContext;
    if (!Ctx) return;
    const ctx = new Ctx();
    const notes = [
      { freq: 660, at: 0 },
      { freq: 880, at: 0.22 },
    ];
    for (const { freq, at } of notes) {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(0.0001, ctx.currentTime + at);
      gain.gain.exponentialRampToValueAtTime(0.12, ctx.currentTime + at + 0.03);
      gain.gain.exponentialRampToValueAtTime(
        0.0001,
        ctx.currentTime + at + 0.5,
      );
      osc.connect(gain).connect(ctx.destination);
      osc.start(ctx.currentTime + at);
      osc.stop(ctx.currentTime + at + 0.55);
    }
    setTimeout(() => void ctx.close(), 1200);
  } catch {
    /* audio indisponible : la notification suffit */
  }
}

export function usePrayerNotifications() {
  // Initialisation paresseuse : ce hook n'est monté que côté client (la
  // pop-up de la démo n'apparaît qu'après montage) — window est garanti.
  const [supported] = useState(
    () => typeof window !== "undefined" && "Notification" in window,
  );
  const [permission, setPermission] =
    useState<NotificationPermission | "unsupported">(() =>
      typeof window !== "undefined" && "Notification" in window
        ? Notification.permission
        : "unsupported",
    );
  const [enabled, setEnabled] = useState(
    () =>
      typeof window !== "undefined" &&
      "Notification" in window &&
      Notification.permission === "granted" &&
      readPref() === "enabled",
  );
  /** clé → déjà notifiée (dédup « avant » / « à l'heure » par prière) */
  const firedRef = useRef<Set<string>>(new Set());
  /** prière « suivante » au dernier tick — pour détecter le passage à l'heure */
  const lastNextRef = useRef<{
    slug: string;
    key: string;
    isTomorrow: boolean;
  } | null>(null);

  const enable = useCallback(async () => {
    if (!("Notification" in window)) return;
    let perm = Notification.permission;
    if (perm === "default") {
      perm = await Notification.requestPermission();
    }
    setPermission(perm);
    if (perm === "granted") {
      try {
        window.localStorage.setItem(STORAGE_KEY, "enabled");
      } catch {
        /* ignore */
      }
      setEnabled(true);
      firedRef.current.clear();
      new Notification("Rappels activés", {
        body: "Vous serez averti 15 minutes avant chaque prière et à l'heure exacte — tant que cette page reste ouverte.",
        icon: "/icon.svg",
      });
    }
  }, []);

  const disable = useCallback(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, "disabled");
    } catch {
      /* ignore */
    }
    setEnabled(false);
  }, []);

  // --- boucle de vérification (1 s) ---------------------------------------
  useEffect(() => {
    if (!enabled) return;

    const check = () => {
      const state = useDemoStore.getState();
      const { prayers, prayersStatus } = state;
      // Pas de rappel sur des horaires d'exemple ni sur un cache périmé :
      // une notification basée sur de mauvaises heures serait trompeuse.
      if (
        !prayers ||
        prayersStatus === "sample" ||
        prayersStatus === "cache"
      )
        return;

      const next = computeNextPrayer(
        prayers.times,
        prayers.tomorrowFajr,
        prayers.timezone,
      );
      if (!next) return;

      // Clé du jour à l'horloge de la mosquée (déduplication fiable).
      const clock = zoneClock(prayers.timezone);
      const dayKey = clock
        ? `${clock.year}-${String(clock.month).padStart(2, "0")}-${String(
            clock.day,
          ).padStart(2, "0")}`
        : new Date().toISOString().slice(0, 10);
      const remaining = next.remainingSec;
      const timeStr = next.time;

      // Passage à l'heure exacte : la prière « suivante » a changé depuis le
      // dernier tick → la précédente vient de commencer.
      const prev = lastNextRef.current;
      const sameMosque = prev !== null && prev.slug === prayers.slug;
      if (
        sameMosque &&
        prev &&
        (prev.key !== next.key || prev.isTomorrow !== next.isTomorrow)
      ) {
        const label = PRAYER_LABELS[prev.key] ?? prev.key;
        const atKey = `${dayKey}:${prev.key}:at`;
        if (!firedRef.current.has(atKey)) {
          firedRef.current.add(atKey);
          new Notification(`C'est l'heure de ${label}`, {
            body: `La prière de ${label} commence maintenant.`,
            icon: "/icon.svg",
            tag: atKey,
          });
          playReminderChime();
        }
      }
      lastNextRef.current = {
        slug: prayers.slug,
        key: next.key,
        isTomorrow: next.isTomorrow,
      };

      // Rappel T-15 min : fenêtre [0 ; 15 min] avant la prière.
      const label = PRAYER_LABELS[next.key] ?? next.label;
      const beforeKey = `${dayKey}:${next.key}${next.isTomorrow ? "+1" : ""}:before`;
      if (
        remaining <= MINUTES_BEFORE * 60 &&
        remaining > 0 &&
        !firedRef.current.has(beforeKey)
      ) {
        firedRef.current.add(beforeKey);
        new Notification(`${label} à ${timeStr}`, {
          body: `La prière de ${label} commence dans ${MINUTES_BEFORE} minutes — prépare-toi.`,
          icon: "/icon.svg",
          tag: beforeKey,
        });
      }

      // Purge si la mémoire des clés dérive.
      if (firedRef.current.size > 64) firedRef.current.clear();
    };

    check();
    const id = setInterval(check, 1000);
    return () => clearInterval(id);
  }, [enabled]);

  return { enabled, supported, permission, enable, disable };
}
