/**
 * useDayChange — détecte le passage de minuit (changement de jour civil à
 * la date LOCALE du visiteur) et déclenche un rappel.
 *
 * Pourquoi : la démo peut rester ouverte des heures (voire toute la nuit).
 * Sans lui, les horaires affichés à 00h01 seraient ceux d'hier, le compteur
 * de sessions Focus et les totaux de Tasbih « aujourd'hui » ne seraient
 * jamais remis à zéro, et le surlignage « aujourd'hui » du calendrier
 * mensuel resterait figé sur hier.
 *
 * Stratégie :
 *  * une vérification légère toutes les 30 s (comparaison de la clé
 *    « YYYY-MM-DD » locale — aucun re-rendu tant que le jour ne change pas) ;
 *  * une vérification immédiate au retour d'onglet (« visibilitychange ») :
 *    l'onglet a très bien pu dormir plusieurs heures en arrière-plan, où
 *    les minuteurs du navigateur sont fortement throttlés ;
 *  * le rappel est stable (référence) : le hook ne se réabonne pas à
 *    chaque re-rendu.
 */

"use client";

import { useEffect, useRef } from "react";

/** Clé du jour local « YYYY-MM-DD » (même convention que le store). */
export function localDayKey(date: Date = new Date()): string {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(
    date.getDate(),
  ).padStart(2, "0")}`;
}

/** Intervalle de vérification : 30 s suffisent (± 30 s autour de minuit). */
const CHECK_INTERVAL_MS = 30_000;

/**
 * Appelle `onDayChange` exactement une fois par changement de jour civil
 * local pendant que le composant est monté.
 */
export function useDayChange(onDayChange: () => void) {
  const callbackRef = useRef(onDayChange);

  // « Latest ref » : garde la dernière version du rappel sans se réabonner
  // (affectation en effet, pas pendant le rendu).
  useEffect(() => {
    callbackRef.current = onDayChange;
  }, [onDayChange]);

  useEffect(() => {
    let lastKey = localDayKey();

    const check = () => {
      const key = localDayKey();
      if (key !== lastKey) {
        lastKey = key;
        callbackRef.current();
      }
    };

    const interval = window.setInterval(check, CHECK_INTERVAL_MS);
    const onVisibility = () => {
      if (document.visibilityState === "visible") check();
    };
    document.addEventListener("visibilitychange", onVisibility);

    return () => {
      window.clearInterval(interval);
      document.removeEventListener("visibilitychange", onVisibility);
    };
  }, []);
}
