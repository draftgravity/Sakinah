/**
 * Hook Web Audio pour la démo — pendant navigateur de app/utils/audio.py :
 *  * bruit blanc / pluie (bruit brownien) générés dans un AudioBuffer et
 *    lus en boucle avec fondu de bord (aucun fichier à télécharger) ;
 *  * carillon de fin de session (arpège Do-Mi-Sol-Do synthétisé) ;
 *  * tout est créé paresseusement (le navigateur exige un geste
 *    utilisateur avant de démarrer l'AudioContext).
 */

"use client";

import { useCallback, useEffect, useRef } from "react";

export type WebAudioAPI = ReturnType<typeof useWebAudio>;

export function useWebAudio() {
  const ctxRef = useRef<AudioContext | null>(null);
  const noiseRef = useRef<{ source: AudioBufferSourceNode; gain: GainNode } | null>(null);

  const ensureCtx = useCallback((): AudioContext | null => {
    if (typeof window === "undefined") return null;
    if (!ctxRef.current) {
      const Ctor =
        window.AudioContext ??
        (window as unknown as { webkitAudioContext?: typeof AudioContext })
          .webkitAudioContext;
      if (!Ctor) return null;
      ctxRef.current = new Ctor();
    }
    if (ctxRef.current.state === "suspended") {
      void ctxRef.current.resume();
    }
    return ctxRef.current;
  }, []);

  const stopNoise = useCallback(() => {
    const nodes = noiseRef.current;
    const ctx = ctxRef.current;
    if (!nodes || !ctx) return;
    noiseRef.current = null;
    try {
      // Court fondu pour éviter un « clic » à l'arrêt.
      nodes.gain.gain.cancelScheduledValues(ctx.currentTime);
      nodes.gain.gain.setValueAtTime(nodes.gain.gain.value, ctx.currentTime);
      nodes.gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.25);
      nodes.source.stop(ctx.currentTime + 0.3);
    } catch {
      /* déjà arrêté */
    }
  }, []);

  const startNoise = useCallback(
    (kind: "white" | "rain", volume: number) => {
      const ctx = ensureCtx();
      if (!ctx) return;
      stopNoise();

      const seconds = 4;
      const buffer = ctx.createBuffer(1, Math.floor(ctx.sampleRate * seconds), ctx.sampleRate);
      const data = buffer.getChannelData(0);

      if (kind === "white") {
        for (let i = 0; i < data.length; i++) {
          data[i] = (Math.random() * 2 - 1) * 0.32;
        }
      } else {
        // Bruit brownien ≈ pluie (intégration d'un bruit blanc).
        let last = 0;
        for (let i = 0; i < data.length; i++) {
          const white = Math.random() * 2 - 1;
          last = (last + 0.02 * white) / 1.02;
          data[i] = Math.max(-0.95, Math.min(0.95, last * 3.5));
        }
      }

      // Fondu entrant/sortant pour une boucle inaudible.
      const fade = Math.floor(ctx.sampleRate * 0.05);
      for (let i = 0; i < fade; i++) {
        data[i] *= i / fade;
        data[data.length - 1 - i] *= i / fade;
      }

      const source = ctx.createBufferSource();
      source.buffer = buffer;
      source.loop = true;
      const gain = ctx.createGain();
      gain.gain.value = volume;
      source.connect(gain).connect(ctx.destination);
      source.start();
      noiseRef.current = { source, gain };
    },
    [ensureCtx, stopNoise],
  );

  const setVolume = useCallback((volume: number) => {
    if (noiseRef.current) {
      noiseRef.current.gain.gain.value = Math.max(0, Math.min(1, volume));
    }
  }, []);

  /** Carillon de fin de session : Do5-Mi5-Sol5-Do6, décroissance douce. */
  const playChime = useCallback(
    (volume = 0.7) => {
      const ctx = ensureCtx();
      if (!ctx) return;
      const notes = [523.25, 659.25, 783.99, 1046.5];
      notes.forEach((frequency, index) => {
        const oscillator = ctx.createOscillator();
        const gain = ctx.createGain();
        const start = ctx.currentTime + index * 0.18;
        oscillator.type = "sine";
        oscillator.frequency.value = frequency;
        gain.gain.setValueAtTime(0.0001, start);
        gain.gain.exponentialRampToValueAtTime(0.28 * volume, start + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, start + 1.1);
        oscillator.connect(gain).connect(ctx.destination);
        oscillator.start(start);
        oscillator.stop(start + 1.2);
      });
    },
    [ensureCtx],
  );

  // Nettoyage au démontage du composant hôte.
  useEffect(
    () => () => {
      stopNoise();
      void ctxRef.current?.close().catch(() => undefined);
    },
    [stopNoise],
  );

  return { startNoise, stopNoise, playChime, setVolume, ensureCtx };
}
