/**
 * usePwaInstall — accès partagé à l'invitation d'installation PWA.
 *
 * L'événement `beforeinstallprompt` ne sont émis qu'UNE fois par page :
 * un hook local monté trop tard (ex. dialogue ouvert après le chargement)
 * le raterait. Le deferred prompt est donc capturé au NIVEAU MODULE (dès
 * l'import, côté client) et partagé à tous les consommateurs.
 *
 * `promptInstall()` renvoie "accepted", "dismissed" ou "unavailable"
 * (Firefox/iOS ou application déjà installée).
 */

"use client";

import { useEffect, useState } from "react";

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

type PromptState = {
  deferred: BeforeInstallPromptEvent | null;
  installed: boolean;
};

const state: PromptState = {
  deferred: null,
  installed: false,
};
const listeners = new Set<() => void>();

function notify() {
  listeners.forEach((listener) => listener());
}

if (typeof window !== "undefined") {
  const standalone =
    window.matchMedia?.("(display-mode: standalone)").matches ||
    (navigator as unknown as { standalone?: boolean }).standalone === true;
  if (standalone) state.installed = true;

  window.addEventListener("beforeinstallprompt", (event) => {
    event.preventDefault();
    state.deferred = event as BeforeInstallPromptEvent;
    state.installed = false;
    notify();
  });
  window.addEventListener("appinstalled", () => {
    state.installed = true;
    state.deferred = null;
    notify();
  });
}

export function usePwaInstall() {
  const [, setTick] = useState(0);

  useEffect(() => {
    const listener = () => setTick((tick) => tick + 1);
    listeners.add(listener);
    return () => {
      listeners.delete(listener);
    };
  }, []);

  const promptInstall = async (): Promise<
    "accepted" | "dismissed" | "unavailable"
  > => {
    const event = state.deferred;
    if (!event || state.installed) return "unavailable";
    state.deferred = null;
    try {
      await event.prompt();
      const choice = await event.userChoice;
      return choice.outcome;
    } catch {
      return "dismissed";
    }
  };

  return {
    /** true si le navigateur peut afficher son invitation native. */
    canInstall: state.deferred !== null && !state.installed,
    /** true si la web-app tourne déjà installée (standalone). */
    installed: state.installed,
    promptInstall,
  };
}
