/**
 * BackToTop — bouton flottant « remonter » discret :
 *  * apparaît en fondu après ~une écran et demie de défilement ;
 *  * défilement fluide (respecté par prefers-reduced-motion) ;
 *  * placé en bas à droite, SOUS le carré de la démo (z-40) et
 *    au-dessus du pied de page.
 */

"use client";

import { useEffect, useRef, useState } from "react";
import { ArrowUp } from "lucide-react";

export function BackToTop() {
  const [visible, setVisible] = useState(false);
  const visibleRef = useRef(false);

  useEffect(() => {
    const THRESHOLD = 700; // ~ une écran et demie
    let raf = 0;
    const update = () => {
      const show = window.scrollY > THRESHOLD;
      if (show !== visibleRef.current) {
        visibleRef.current = show;
        setVisible(show);
      }
    };
    const onScroll = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(update);
    };
    update();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("scroll", onScroll);
    };
  }, []);

  const scrollTop = () => {
    const prefersReduced = window.matchMedia(
      "(prefers-reduced-motion: reduce)",
    ).matches;
    window.scrollTo({ top: 0, behavior: prefersReduced ? "auto" : "smooth" });
  };

  return (
    <button
      type="button"
      onClick={scrollTop}
      aria-label="Remonter en haut de page"
      aria-hidden={!visible}
      tabIndex={visible ? 0 : -1}
      className={`fixed bottom-5 right-5 z-40 grid size-11 place-items-center rounded-full border border-white/10 bg-zinc-900/90 text-zinc-300 shadow-lg shadow-black/40 backdrop-blur transition-all duration-300 hover:border-emerald-500/40 hover:text-emerald-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400/60 ${
        visible
          ? "translate-y-0 opacity-100"
          : "pointer-events-none translate-y-3 opacity-0"
      }`}
    >
      <ArrowUp className="size-4" aria-hidden />
    </button>
  );
}
