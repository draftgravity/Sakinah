/**
 * FaqSection — questions fréquentes (accordion shadcn).
 */

import { SectionHeading } from "./section-heading";
import { FadeIn } from "./fade-in";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const FAQ_ITEMS = [
  {
    question: "Le carré disparaît quand je lance un jeu — normal ?",
    answer:
      "Oui, c'est la détection plein écran : dès qu'une application (Valorant, Netflix, une présentation…) passe en plein écran, Sakinah se masque automatiquement et revient à la sortie. Pour le garder affiché, utilisez Ctrl+Alt+H ou désactivez l'option « Masquer en plein écran » dans Paramètres → Widget.",
  },
  {
    question: "Comment trouver ma mosquée ?",
    answer:
      "Ouvrez la pop-up, cliquez sur l'icône des paramètres, puis cherchez votre mosquée par nom, ville ou code postal. Vous pouvez aussi coller directement le « slug » : c'est la fin de l'URL de votre page mawaqit.net/fr/… — par exemple grande-mosquee-de-paris. Plus de 8 000 mosquées sont référencées.",
  },
  {
    question: "L'adhan ne se joue pas ?",
    answer:
      "Vérifiez qu'un fichier nommé exactement adhan.mp3 est présent dans assets/sounds/ (créez le dossier s'il n'existe pas). Sans fichier audio, Sakinah joue un bip discret généré localement — vérifiez aussi le volume dans Paramètres → Sons.",
  },
  {
    question: "Mes données sont-elles envoyées quelque part ?",
    answer:
      "Non. Sakinah lit uniquement les horaires publics de votre mosquée sur mawaqit.net et ne transmet rien : ni nom, ni position, ni statistiques. Tout (mosquée, préférences, position du widget, cache horaires) reste dans config.json sur votre machine.",
  },
  {
    question: "Le widget bloque un clic, que faire ?",
    answer:
      "Activez le « mode discret » (click-through) dans Paramètres → Widget : le carré devient alors totalement transparent aux clics — il ne peut littéralement plus gêner. Vous le contrôlez ensuite uniquement au clavier, via Ctrl+Alt+H et H.",
  },
  {
    question: "Ça marche sur Mac ou Linux ?",
    answer:
      "Sakinah est conçu pour Windows : la détection plein écran, le mode click-through et le démarrage automatique s'appuient sur win32gui, pynput et le registre Windows. Le cœur PyQt6 est portable, mais ces intégrations ne sont pas supportées sur Mac/Linux.",
  },
];

export function FaqSection() {
  return (
    <section
      id="faq"
      aria-labelledby="faq-title"
      className="scroll-mt-24 py-16 sm:py-20 lg:py-24"
    >
      <div className="mx-auto w-full max-w-3xl px-4 sm:px-6">
        <SectionHeading
          eyebrow="FAQ"
          title="Questions fréquentes"
          description="Tout ce qu'on nous demande le plus souvent sur le carré noir."
        />

        <FadeIn>
          <div className="overflow-hidden rounded-2xl border border-white/5 bg-zinc-900/60">
            <Accordion
              type="single"
              collapsible
              className="scrollbar-slim max-h-96 overflow-y-auto px-5 sm:px-6"
            >
              {FAQ_ITEMS.map((item, index) => (
                <AccordionItem
                  key={item.question}
                  value={`faq-${index}`}
                  className="group/faq relative border-white/5 transition-colors data-[state=open]:bg-emerald-500/[0.04]"
                >
                  {/* fin trait émeraude — visible sur la question ouverte */}
                  <span
                    aria-hidden="true"
                    className="absolute bottom-0 left-0 top-0 w-0.5 origin-top scale-y-0 bg-gradient-to-b from-emerald-400 to-emerald-600 transition-transform duration-300 group-data-[state=open]/faq:scale-y-100"
                  />
                  <AccordionTrigger className="py-5 text-sm font-semibold text-zinc-200 transition-colors hover:text-emerald-300 hover:no-underline data-[state=open]:text-emerald-300 sm:text-base">
                    {item.question}
                  </AccordionTrigger>
                  <AccordionContent className="border-l-2 border-emerald-500/20 pb-5 pl-4 text-sm leading-relaxed text-zinc-400">
                    {item.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </FadeIn>
      </div>
    </section>
  );
}
