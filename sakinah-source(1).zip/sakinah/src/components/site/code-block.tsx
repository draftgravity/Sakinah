/**
 * CodeBlock — bloc de code stylé (police mono, fond zinc-950) avec en-tête
 * (label + bouton copier). Utilisé par la section Installation.
 */

import { CopyButton } from "./copy-button";
import { cn } from "@/lib/utils";

interface CodeBlockProps {
  label?: string;
  code: string;
  className?: string;
}

export function CodeBlock({ label, code, className }: CodeBlockProps) {
  return (
    <div
      className={cn(
        "overflow-hidden rounded-xl border border-white/10 bg-zinc-950/80",
        className,
      )}
    >
      <div className="flex items-center justify-between gap-3 border-b border-white/5 bg-white/[0.03] px-4 py-2">
        <span className="truncate font-mono text-xs text-zinc-500">
          {label ?? "terminal"}
        </span>
        <CopyButton value={code} label={label ?? "la commande"} />
      </div>
      <pre className="scrollbar-slim overflow-x-auto p-4">
        <code className="font-mono text-[13px] leading-relaxed text-emerald-200/90">
          {code}
        </code>
      </pre>
    </div>
  );
}
