/**
 * FeaturesSection — 4 groupes thématiques de fonctionnalités.
 * Chaque groupe est un panneau avec 4 mini-cartes (icône + titre + texte).
 */

"use client";

import type { ComponentType } from "react";
import { motion } from "framer-motion";
import {
  BellRing,
  BookOpenText,
  CircleDot,
  FileJson,
  Flame,
  Gamepad2,
  GitCompareArrows,
  Hourglass,
  Keyboard,
  MapPin,
  Moon,
  MoonStar,
  Pin,
  Power,
  ScrollText,
  Settings2,
  Square,
  TrendingUp,
} from "lucide-react";
import { SectionHeading } from "./section-heading";
import { cn } from "@/lib/utils";

interface FeatureItem {
  icon: ComponentType<{ className?: string }>;
  title: string;
  text: string;
}

interface FeatureGroup {
  icon: ComponentType<{ className?: string }>;
  title: string;
  description: string;
  accent: "emerald" | "amber";
  items: FeatureItem[];
}

const GROUPS: FeatureGroup[] = [
  {
    icon: Square,
    title: "Le widget overlay",
    description: "Le carré noir, pensé pour se faire oublier.",
    accent: "emerald",
    items: [
      {
        icon: Square,
        title: "Carré noir discret",
        text: "36 px, coins arrondis, glissable à la souris, ancré au coin haut-droit de l'écran.",
      },
      {
        icon: Pin,
        title: "Toujours au premier plan",
        text: "Jamais intrusif : absent de la barre des tâches — mode click-through optionnel.",
      },
      {
        icon: Gamepad2,
        title: "Détection plein écran",
        text: "Masqué automatiquement pendant Valorant, un film ou une présentation.",
      },
      {
        icon: Keyboard,
        title: "Raccourci global",
        text: "Ctrl+Alt+H depuis n'importe quelle application ; clic gauche ou droit ouvre la pop-up.",
      },
    ],
  },
  {
    icon: MoonStar,
    title: "Prières — Mawaqit",
    description: "Les horaires de VOTRE mosquée, en direct.",
    accent: "emerald",
    items: [
      {
        icon: MapPin,
        title: "Votre mosquée",
        text: "Recherche par nom, ville, code postal ou slug mawaqit.net — parmi plus de 8 000 mosquées.",
      },
      {
        icon: Hourglass,
        title: "Compte à rebours live",
        text: "La prochaine prière est surlignée en émeraude, décompte rafraîchi chaque seconde.",
      },
      {
        icon: BellRing,
        title: "Rappels & adhan",
        text: "Rappel 15 min avant, notification à l'heure exacte : adhan (votre adhan.mp3) ou bip discret.",
      },
      {
        icon: BookOpenText,
        title: "Dhikr + hors-ligne",
        text: "Dhikr aléatoire avec traduction, et cache des derniers horaires si mawaqit.net est coupé.",
      },
    ],
  },
  {
    icon: Flame,
    title: "Tasbih & moments clés",
    description: "À essayer librement sur cette même page.",
    accent: "amber",
    items: [
      {
        icon: CircleDot,
        title: "Compteur de Tasbih",
        text: "SubhânAllâh ×33, Alhamdulillâh ×33, Allâhu Akbar ×34 ou mode libre — jour, cumul et export CSV.",
      },
      {
        icon: TrendingUp,
        title: "Série de régularité",
        text: "Une tape par jour suffit : série de jours consécutifs et mini-graphique des 7 derniers jours.",
      },
      {
        icon: Moon,
        title: "Compte à rebours du Ramadan",
        text: "Calendrier hégirien (umalqura) : « jour N » pendant le mois sacré, « dans X jours » sinon.",
      },
      {
        icon: GitCompareArrows,
        title: "Comparaison de mosquées",
        text: "Adhans du jour côte à côte, écarts en minutes — pour choisir où prier.",
      },
    ],
  },
  {
    icon: Settings2,
    title: "Système & ergonomie",
    description: "Un vrai citoyen de votre bureau Windows.",
    accent: "emerald",
    items: [
      {
        icon: BellRing,
        title: "Tray + toasts natifs",
        text: "Icône dans la zone de notification avec menu complet et notifications Windows.",
      },
      {
        icon: Power,
        title: "Démarrage automatique",
        text: "Lancement optionnel avec Windows (inscription registre, réversible d'un clic).",
      },
      {
        icon: FileJson,
        title: "config.json",
        text: "Mosquée, sons, position du widget… tout est persisté, lisible et éditable à la main.",
      },
      {
        icon: ScrollText,
        title: "Instance unique + journal",
        text: "Un seul Sakinah à la fois, et un fichier sakinah.log pour tout diagnostiquer.",
      },
    ],
  },
];

const ACCENTS = {
  emerald: {
    icon: "text-emerald-400",
    ring: "border-emerald-500/20",
    chip: "bg-emerald-500/10 text-emerald-300",
  },
  amber: {
    icon: "text-amber-400",
    ring: "border-amber-400/20",
    chip: "bg-amber-400/10 text-amber-300",
  },
} as const;

export function FeaturesSection() {
  return (
    <section
      id="fonctionnalites"
      aria-labelledby="features-title"
      className="scroll-mt-24 py-16 sm:py-20 lg:py-24"
    >
      <div className="mx-auto w-full max-w-6xl px-4 sm:px-6">
        <SectionHeading
          eyebrow="Fonctionnalités"
          title="Pensé pour disparaître, jusqu'à ce que vous en ayez besoin."
          description="Sakinah reste un carré de 36 pixels tant que vous ne le sollicitez pas — puis il devient l'assistant le plus discret de votre journée."
        />

        <div className="grid gap-6 lg:grid-cols-2">
          {GROUPS.map((group, groupIndex) => {
            const accent = ACCENTS[group.accent];
            return (
              <motion.section
                key={group.title}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{
                  duration: 0.55,
                  delay: (groupIndex % 2) * 0.1,
                  ease: [0.21, 0.47, 0.32, 0.98],
                }}
                aria-labelledby={`group-${groupIndex}`}
                className="group/panel rounded-2xl border border-white/5 bg-zinc-900/60 p-5 transition-colors duration-300 hover:border-white/10 hover:bg-zinc-900/80 sm:p-6"
              >
                {/* en-tête de groupe */}
                <div className="mb-4 flex items-center gap-3.5">
                  <span
                    className={cn(
                      "flex size-10 shrink-0 items-center justify-center rounded-xl border transition-all duration-300 group-hover/panel:scale-105",
                      accent.ring,
                      accent.chip,
                    )}
                  >
                    <group.icon className="size-5" aria-hidden="true" />
                  </span>
                  <div>
                    <h3
                      id={`group-${groupIndex}`}
                      className="text-base font-bold tracking-tight text-zinc-100 sm:text-lg"
                    >
                      {group.title}
                    </h3>
                    <p className="text-xs text-zinc-500 sm:text-sm">{group.description}</p>
                  </div>
                </div>
                {/* filet dégradé sous l'en-tête */}
                <div
                  aria-hidden="true"
                  className={cn(
                    "mb-5 h-px bg-gradient-to-r from-transparent via-transparent to-transparent",
                    group.accent === "amber"
                      ? "via-amber-400/25"
                      : "via-emerald-500/25",
                  )}
                />

                {/* mini-cartes */}
                <div className="grid gap-3 sm:grid-cols-2">
                  {group.items.map((item) => (
                    <div
                      key={item.title}
                      className="group relative overflow-hidden rounded-xl border border-white/5 bg-zinc-950/60 p-4 transition-all duration-200 hover:-translate-y-0.5 hover:border-white/10 hover:bg-zinc-900"
                    >
                      {/* liseré d'accent au survol */}
                      <span
                        aria-hidden="true"
                        className={cn(
                          "absolute inset-x-0 top-0 h-px scale-x-0 bg-gradient-to-r from-transparent via-current to-transparent opacity-70 transition-transform duration-300 group-hover:scale-x-100",
                          group.accent === "amber" ? "text-amber-400/60" : "text-emerald-400/60",
                        )}
                      />
                      <item.icon
                        className={cn(
                          "mb-2.5 size-4.5 transition-transform duration-300 group-hover:scale-110",
                          accent.icon,
                        )}
                        aria-hidden="true"
                      />
                      <h4 className="mb-1 text-sm font-semibold text-zinc-100">
                        {item.title}
                      </h4>
                      <p className="text-xs leading-relaxed text-zinc-400">{item.text}</p>
                    </div>
                  ))}
                </div>
              </motion.section>
            );
          })}
        </div>
      </div>
    </section>
  );
}
