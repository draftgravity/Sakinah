/**
 * StatsBand — bande de 4 statistiques clés sous le hero.
 *
 * Les chiffres « montent » (compteur animé) quand la bande entre dans le
 * viewport — formatage français (espace fine des milliers) respecté.
 */

"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { useInView } from "framer-motion";
import { FadeIn } from "./fade-in";

/* ------------------------------------------------------------------ */
/* Compteur animé                                                       */
/* ------------------------------------------------------------------ */

interface ParsedValue {
  prefix: string;
  target: number;
  suffix: string;
}

/** « +8 000 » → { prefix: "+", target: 8000, suffix: "" }, etc. */
function parseValue(raw: string): ParsedValue | null {
  const match = raw.match(/^([^\d]*)([\d\s\u202f\u00a0]+)(.*)$/);
  if (!match) return null;
  const target = Number(match[2].replace(/[\s\u202f\u00a0]/g, ""));
  if (!Number.isFinite(target)) return null;
  return { prefix: match[1], target, suffix: match[3] };
}

function AnimatedValue({ raw }: { raw: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "-40px" });
  // ⚠️ MÉMOÏSÉ : un objet recréé à chaque rendu relancerait l'effet (et
  // donc le compteur) à chaque setDisplay — boucle infinie de redémarrages.
  const parsed = useMemo(() => parseValue(raw), [raw]);
  const [display, setDisplay] = useState(parsed ? `${parsed.prefix}0${parsed.suffix}` : raw);

  useEffect(() => {
    if (!inView || !parsed) return;
    const duration = 1100;
    const start = performance.now();
    let raf = 0;
    const fmt = new Intl.NumberFormat("fr-FR");
    const tick = (now: number) => {
      const progress = Math.min(1, (now - start) / duration);
      // ease-out expo : rapide au départ, pose en douceur à l'arrivée.
      const eased = 1 - Math.pow(2, -10 * progress);
      const value = Math.round(parsed.target * (progress === 1 ? 1 : eased));
      setDisplay(`${parsed.prefix}${fmt.format(value)}${parsed.suffix}`);
      if (progress < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [inView, parsed]);

  if (!parsed) return <span>{raw}</span>;
  return (
    <span ref={ref} className="tabular-nums">
      {display}
    </span>
  );
}

/* ------------------------------------------------------------------ */

const STATS = [
  {
    value: "12",
    label: "mois de calendrier dépliables, vendredis repérés",
    accent: "text-amber-400",
  },
  {
    value: "6",
    label: "horaires affichés pour votre mosquée",
    accent: "text-emerald-400",
  },
  {
    value: "+8 000",
    label: "mosquées référencées par Mawaqit",
    accent: "text-emerald-400",
  },
  {
    value: "100 %",
    label: "local — aucune donnée envoyée",
    accent: "text-emerald-400",
  },
];

export function StatsBand() {
  return (
    <section aria-label="Chiffres clés" className="border-y border-white/5 bg-white/[0.015]">
      <div className="mx-auto grid w-full max-w-6xl grid-cols-2 gap-px px-4 sm:px-6 lg:grid-cols-4">
        {STATS.map((stat, index) => (
          <FadeIn key={stat.value} delay={index * 0.08} className="h-full">
            <div className="group relative flex h-full flex-col gap-1 px-2 py-6 transition-colors duration-300 sm:px-4 sm:py-8">
              {/* liseré supérieur animé au survol */}
              <span
                aria-hidden="true"
                className={`absolute inset-x-4 top-0 h-px scale-x-0 bg-gradient-to-r from-transparent to-transparent transition-transform duration-500 group-hover:scale-x-100 ${
                  stat.accent === "text-amber-400"
                    ? "via-amber-400/50"
                    : "via-emerald-400/50"
                }`}
              />
              <span
                className={`text-2xl font-extrabold tracking-tight transition-transform duration-300 group-hover:-translate-y-0.5 sm:text-3xl ${stat.accent}`}
              >
                <AnimatedValue raw={stat.value} />
              </span>
              <span className="text-xs leading-snug text-zinc-500 transition-colors group-hover:text-zinc-400 sm:text-sm">
                {stat.label}
              </span>
            </div>
          </FadeIn>
        ))}
      </div>
    </section>
  );
}
