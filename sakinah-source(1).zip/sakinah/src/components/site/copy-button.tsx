/**
 * CopyButton — petit bouton « Copier » avec retour visuel « Copié ! » pendant
 * 2 secondes. Accessible (aria-label) et tactile (≥ 44 px via size par défaut).
 */

"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Check, Copy } from "lucide-react";
import { Button } from "@/components/ui/button";

interface CopyButtonProps {
  value: string;
  label?: string;
  className?: string;
}

export function CopyButton({ value, label, className }: CopyButtonProps) {
  const [copied, setCopied] = useState(false);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, []);

  const onCopy = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(value);
    } catch {
      // Repli pour les contextes non sécurisés : sélection manuelle.
      const textarea = document.createElement("textarea");
      textarea.value = value;
      textarea.style.position = "fixed";
      textarea.style.opacity = "0";
      document.body.appendChild(textarea);
      textarea.select();
      try {
        document.execCommand("copy");
      } catch {
        /* silencieux */
      }
      document.body.removeChild(textarea);
    }
    setCopied(true);
    if (timerRef.current) clearTimeout(timerRef.current);
    timerRef.current = setTimeout(() => setCopied(false), 2000);
  }, [value]);

  return (
    <Button
      type="button"
      variant="ghost"
      size="sm"
      onClick={onCopy}
      aria-label={copied ? "Copié dans le presse-papiers" : `Copier ${label ?? "le texte"}`}
      className={
        copied
          ? "h-8 gap-1.5 border border-emerald-500/30 bg-emerald-500/10 text-emerald-300 hover:bg-emerald-500/15 hover:text-emerald-200"
          : "h-8 gap-1.5 text-zinc-400 hover:bg-white/5 hover:text-zinc-200"
      }
    >
      {copied ? (
        <>
          <Check className="size-3.5" aria-hidden="true" />
          <span className="text-xs">Copié !</span>
        </>
      ) : (
        <>
          <Copy className="size-3.5" aria-hidden="true" />
          <span className="text-xs">Copier</span>
        </>
      )}
    </Button>
  );
}
