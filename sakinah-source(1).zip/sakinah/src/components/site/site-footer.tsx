/**
 * SiteFooter — pied de page sticky (mt-auto dans le wrapper flex de la page).
 */

import { ExternalLink, MoonStar } from "lucide-react";

const SECTION_LINKS = [
  { href: "#fonctionnalites", label: "Fonctionnalités" },
  { href: "#demo", label: "Démo interactive" },
  { href: "#code", label: "Code source" },
  { href: "#installation", label: "Installation" },
  { href: "#versions", label: "Journal des versions" },
  { href: "#faq", label: "FAQ" },
];

const RESOURCE_LINKS = [
  { href: "https://mawaqit.net", label: "mawaqit.net", external: true },
  {
    href: "/api/files/content?path=README.md&download=1",
    label: "README du projet",
    external: false,
  },
  { href: "#code", label: "Explorer le code", external: false },
  { href: "/api/download", label: "Télécharger (.zip)", external: false },
];

export function SiteFooter() {
  return (
    <footer className="mt-auto border-t border-white/5 bg-zinc-950 pb-[env(safe-area-inset-bottom)]">
      <div className="mx-auto w-full max-w-6xl px-4 py-12 sm:px-6">
        <div className="grid gap-10 md:grid-cols-[1.6fr_1fr_1fr]">
          {/* marque */}
          <div className="max-w-sm">
            <div className="flex items-center gap-2.5">
              <span
                aria-hidden="true"
                className="flex size-9 items-center justify-center rounded-lg border border-white/10 bg-[#0a0a0b]"
              >
                <MoonStar className="size-4 text-emerald-400" />
              </span>
              <span className="text-lg font-extrabold tracking-tight text-zinc-100">
                Sakinah
              </span>
            </div>
            <p className="mt-3 text-sm leading-relaxed text-zinc-500">
              Widget de prières pour Windows. Un petit carré noir qui veille
              sur vos horaires Mawaqit — adhan, iqama, Jumu&apos;a, calendrier
              du mois.
            </p>
          </div>

          {/* sections */}
          <nav aria-label="Sections de la page">
            <h3 className="mb-3 text-xs font-semibold tracking-widest text-zinc-400 uppercase">
              Sections
            </h3>
            <ul className="space-y-2.5">
              {SECTION_LINKS.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    className="text-sm text-zinc-500 transition-colors hover:text-emerald-300"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          {/* ressources */}
          <nav aria-label="Ressources externes et téléchargements">
            <h3 className="mb-3 text-xs font-semibold tracking-widest text-zinc-400 uppercase">
              Ressources
            </h3>
            <ul className="space-y-2.5">
              {RESOURCE_LINKS.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    {...(link.external
                      ? { target: "_blank", rel: "noopener noreferrer" }
                      : {})}
                    className="inline-flex items-center gap-1.5 text-sm text-zinc-500 transition-colors hover:text-emerald-300"
                  >
                    {link.label}
                    {link.external ? (
                      <ExternalLink className="size-3" aria-hidden="true" />
                    ) : null}
                  </a>
                </li>
              ))}
            </ul>
          </nav>
        </div>

        {/* ligne du bas */}
        <div className="mt-10 flex flex-col gap-2 border-t border-white/5 pt-6 text-xs text-zinc-600 sm:flex-row sm:items-center sm:justify-between">
          <p>Horaires fournis par mawaqit.net · Interface PyQt6 · Démo web interactive</p>
          <p>Fait avec soin — licence MIT</p>
        </div>
      </div>
    </footer>
  );
}
