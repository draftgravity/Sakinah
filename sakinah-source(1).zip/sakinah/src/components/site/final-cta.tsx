/**
 * FinalCta — grande carte dégradée émeraude de fin de page.
 */

import { Download, MoonStar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { InstallButton } from "@/components/pwa/install-button";
import { FadeIn } from "./fade-in";

/** Motif géométrique islamique (étoile à 8 branches / khatam) en SVG. */
function KhatamPattern() {
  return (
    <svg
      aria-hidden="true"
      className="absolute inset-0 h-full w-full [mask-image:radial-gradient(ellipse_70%_80%_at_50%_45%,black_25%,transparent_78%)]"
    >
      <defs>
        <pattern id="khatam" width="56" height="56" patternUnits="userSpaceOnUse">
          <g fill="none" stroke="rgba(16,185,129,0.13)" strokeWidth="1">
            {/* étoile à 8 branches = deux carrés superposés (l'un pivoté à 45°) */}
            <rect x="17" y="17" width="22" height="22" rx="1.5" />
            <rect
              x="17"
              y="17"
              width="22"
              height="22"
              rx="1.5"
              transform="rotate(45 28 28)"
            />
          </g>
          {/* point discret aux coins de la tuile */}
          <circle cx="28" cy="28" r="1" fill="rgba(16,185,129,0.22)" />
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill="url(#khatam)" />
    </svg>
  );
}

export function FinalCta() {
  return (
    <section aria-labelledby="final-cta-title" className="pb-20 pt-4 sm:pb-24">
      <div className="mx-auto w-full max-w-6xl px-4 sm:px-6">
        <FadeIn>
          <div className="relative overflow-hidden rounded-3xl border border-emerald-500/20 bg-gradient-to-br from-emerald-500/[0.14] via-zinc-900 to-zinc-950 px-6 py-14 text-center sm:px-10 sm:py-16">
            {/* halo décoratif */}
            <div
              aria-hidden="true"
              className="absolute -top-24 left-1/2 h-48 w-[420px] -translate-x-1/2 rounded-full bg-emerald-500/20 blur-[100px]"
            />
            {/* motif géométrique (khatam) — identité visuelle discrète */}
            <KhatamPattern />
            <div
              aria-hidden="true"
              className="dot-grid-fade absolute inset-0 opacity-40"
            />

            <div className="relative flex flex-col items-center gap-6">
              <span
                aria-hidden="true"
                className="flex size-12 items-center justify-center rounded-2xl border border-emerald-400/25 bg-[#0a0a0b] shadow-[0_0_28px_rgba(16,185,129,0.3)]"
              >
                <MoonStar className="size-5 text-emerald-400" />
              </span>

              <h2
                id="final-cta-title"
                className="text-balance text-2xl font-extrabold tracking-tight text-zinc-100 sm:text-3xl lg:text-4xl"
              >
                Paix du cœur, prières à l&apos;heure.
              </h2>

              <p className="max-w-xl text-pretty text-sm leading-relaxed text-zinc-400 sm:text-base">
                Téléchargez Sakinah, déposez le carré noir sur votre écran, et
                laissez-le veiller — discrètement — sur ce qui compte vraiment.
              </p>

              <div className="flex flex-wrap items-center justify-center gap-3">
                <Button
                  asChild
                  size="lg"
                  className="h-12 border border-emerald-400/30 bg-emerald-500 px-8 text-base font-semibold text-zinc-950 shadow-[0_0_32px_rgba(16,185,129,0.35)] transition-transform hover:scale-[1.03] hover:bg-emerald-400"
                >
                  <a href="/api/download" aria-label="Télécharger l'archive ZIP de Sakinah">
                    <Download className="size-5" aria-hidden="true" />
                    Télécharger Sakinah (.zip)
                  </a>
                </Button>
                <InstallButton variant="cta" />
              </div>

              <p className="text-xs tracking-wide text-zinc-500">
                MIT · Python 3.10+ · PyQt6 · web-app installable
              </p>
            </div>
          </div>
        </FadeIn>
      </div>
    </section>
  );
}
