/**
 * ChangelogSection — « Journal des versions » : timeline verticale retraçant
 * la vie du projet — la v1.0.0 de l'application Windows, puis les jalons de
 * la démo web qui la réplique dans le navigateur.
 *
 * Pour rester lisible, seuls les 4 derniers jalons sont dépliés ; les
 * précédents se rangent dans une « archive » dépliable (bouton). Le jalon
 * le plus récent porte le point pulsant « en direct ».
 */

"use client";

import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  Archive,
  Brush,
  CalendarDays,
  ChevronDown,
  CloudOff,
  Database,
  GitCompareArrows,
  Globe2,
  Github,
  MonitorSmartphone,
  Moon,
  MoonStar,
  PartyPopper,
  Rocket,
  ShieldCheck,
  Sparkles,
  Wand2,
} from "lucide-react";
import { SectionHeading } from "./section-heading";
import { FadeIn } from "./fade-in";
import { cn } from "@/lib/utils";

interface Milestone {
  /** icône du point de la timeline */
  icon: typeof Rocket;
  /** badge de version ou jalon */
  badge: string;
  /** libellé temporel */
  date: string;
  title: string;
  items: string[];
  /** true = jalon le plus récent (point pulsant, « en direct ») */
  live?: boolean;
}

const MILESTONES: Milestone[] = [
  {
    icon: MoonStar,
    badge: "v1.0.0",
    date: "Septembre 2026 · application Windows",
    title: "Le carré noir arrive sur Windows",
    items: [
      "Widget 36 px toujours au premier plan, clic pénétrant en mode discret, masquage automatique en plein écran",
      "Horaires Mawaqit de plus de 8 000 mosquées françaises : adhan, iqama, Jumu'a, compte à rebours",
      "Notifications Windows 15 min avant chaque prière et à l'heure — adhan.mp3 ou bip discret",
      "Dhikr du moment : un rappel tiré au hasard parmi douze, en arabe et sa traduction française",
      "Tout est local : config.json lisible à la main, zéro télémétrie, open source MIT",
    ],
  },
  {
    icon: Rocket,
    badge: "Web · jalon 1",
    date: "La démo vivante",
    title: "Le carré noir s'invite dans le navigateur",
    items: [
      "Le vrai widget monte sur la page : horaires Mawaqit en direct, compte à rebours seconde par seconde",
      "Rappels navigateur (15 min avant + à l'heure) et boussole Qibla — cap et distance depuis la mosquée",
      "Mosquée persistée, raccourci H, dhikr du moment",
    ],
  },
  {
    icon: CalendarDays,
    badge: "Web · jalon 2",
    date: "Le calendrier",
    title: "Les 12 mois de l'année Mawaqit, dépliables",
    items: [
      "Calendrier mensuel adhan + iqama, vendredis repérés, bascule d'affichage",
      "Détail du jour au clic : dates grégorienne et hégirienne complètes",
    ],
  },
  {
    icon: GitCompareArrows,
    badge: "Web · jalon 3",
    date: "Explorer",
    title: "Comparer, chercher, mesurer",
    items: [
      "Comparaison de deux mosquées côte à côte, écarts signés en minutes",
      "Recherche « autour de moi » triée par distance réelle (haversine)",
      "Copie des horaires du jour en presse-papiers, prêts à partager",
    ],
  },
  {
    icon: Globe2,
    badge: "Web · jalon 4",
    date: "L'heure juste",
    title: "Toute l'horloge à l'heure de la mosquée",
    items: [
      "Compte à rebours, dates et calendrier suivent le fuseau de la mosquée — pas celui du visiteur",
      "Correctif serveur : les horaires servis sont ceux du bon jour civil, même après minuit",
    ],
  },
  {
    icon: CloudOff,
    badge: "Web · jalon 5",
    date: "Hors ligne",
    title: "La démo survit aux coupures réseau",
    items: [
      "Cache local des horaires du jour — et de la ligne de demain : exacts même après minuit sans réseau",
      "Calendrier mensuel servi depuis le cache, page hors-ligne dédiée",
    ],
  },
  {
    icon: MonitorSmartphone,
    badge: "Web · jalon 6",
    date: "Installable",
    title: "La vitrine devient une web-app",
    items: [
      "PWA : manifeste, service worker, icônes, installation en un clic (Chrome/Edge/Android)",
      "Export du mois au format calendrier .ics — Google Agenda, Outlook, Apple Calendrier",
      "Comparaison de mosquées mémorisée entre les visites",
    ],
  },
  {
    icon: PartyPopper,
    badge: "Web · jalon 7",
    date: "Exclusivités web",
    title: "Compteur de Tasbih, menu mobile, vibrations",
    items: [
      "Compteur de Tasbih : SubhânAllâh ×33, Alhamdulillâh ×33, Allâhu Akbar ×34 ou mode libre",
      "Menu de navigation mobile : les 6 sections enfin accessibles depuis un téléphone",
      "Vibration à chaque tape et totaux du jour conservés d'une visite à l'autre",
    ],
  },
  {
    icon: Sparkles,
    badge: "Web · jalon 8",
    date: "Fraîcheur & statistiques",
    title: "Minuit automatique, export CSV du dhikr",
    items: [
      "Passage de minuit détecté : horaires rechargés en silence, compteurs du jour remis à zéro — même après une nuit d'onglet ouvert",
      "Indicateur de fraîcheur « synchro il y a… » dans la pop-up : l'âge des données Mawaqit est visible en continu",
      "Statistiques de dhikr : totaux jour/cumul, répartition par formule, export CSV (Excel/LibreOffice) et réinitialisation confirmée",
    ],
  },
  {
    icon: Moon,
    badge: "Web · jalon 9",
    date: "Régularité & Ramadan",
    title: "Série de dhikr, graphique 7 jours, compte à rebours",
    items: [
      "Régularité du dhikr : série de jours consécutifs + mini-graphique des 7 derniers jours",
      "Compte à rebours du Ramadan au calendrier hégirien (umalqura) : « jour N » pendant le mois sacré, « dans X jours » sinon",
      "Export CSV enrichi de la série et de la semaine ; « Effacer » emporte aussi l'historique",
    ],
  },
  {
    icon: ShieldCheck,
    badge: "Web · jalon 10",
    date: "Comptes & espace gérant",
    title: "Connexion, données en ligne, deux versions",
    items: [
      "Comptes réels : identifiant OU e-mail + mot de passe (scrypt, session en cookie httpOnly) — les statistiques sont stockées en ligne, plus en local",
      "Version normale (anonyme ou membre) recentrée sur les informations de prière — le gérant accède à la version complète",
      "Espace gérant : comptes et rôles, statistiques par utilisateur, séries 7 jours, journal d'activité — fusion multi-appareils sans double comptage",
    ],
  },
  {
    icon: Brush,
    badge: "Web · jalon 11",
    date: "Vitrine épurée",
    title: "Une page centrée prière, pour tout le monde",
    items: [
      "La présentation s'articule désormais autour de la prière : horaires, calendrier mensuel, Qibla, Tasbih et Ramadan",
      "Nouveau panneau « Tasbih & moments clés » dans les fonctionnalités, badge Ramadan en direct dans l'accroche",
      "Chiffres clés, description et partage mis à jour — une vitrine propre pour la version classique",
    ],
  },
  {
    icon: Wand2,
    badge: "Web · v1.5.2",
    date: "Polissage & fluidité",
    title: "La vitrine gagne en confort",
    items: [
      "Session corrigée dans l'aperçu intégré : la connexion et l'espace d'administration fonctionnent désormais aussi dans un cadre externe",
      "Navigation fidèle : la section active suit précisément les clics et le défilement, même quand la page se réorganise",
      "Journal des versions resserré — les anciens jalons se replient dans une archive dépliable",
      "Dialogue de connexion repensé : onglets lisibles, défilement interne et identifiants d'exemple en un clic",
    ],
  },
  {
    icon: Database,
    badge: "Web · v1.6.0",
    date: "PostgreSQL & confidentiel",
    title: "Base en ligne professionnelle, pop-up étanche",
    items: [
      "Migration complète vers PostgreSQL : comptes, sessions et statistiques suivent le projet chez n'importe quel hébergeur (Neon, Supabase…)",
      "La pop-up du widget se comporte comme une vraie fenêtre : la molette y fait défiler SES horaires (jusqu'à la dernière prière), plus jamais la page derrière",
      "Aucun identifiant affiché sur la vitrine : le dialogue de connexion ne montre plus aucun compte de démonstration — restez discret sur vos accès",
    ],
  },
  {
    icon: Github,
    badge: "Web · v1.6.1",
    date: "Comptes réels & mise en ligne",
    title: "Une base 100 % réelle, prête pour GitHub",
    items: [
      "Plus aucun compte fictif : la base ne contient que des comptes créés par de vraies personnes — et sur un site tout neuf, le premier compte devient automatiquement le compte gérant",
      "Votre région à l'ouverture (France, Belgique, États-Unis, Maroc…) : les mosquées de votre région passent en premier dans la recherche — 17 régions disponibles",
      "Plein écran : le carré noir reste affiché ou se masque, au choix dans les paramètres — comme l'option de l'application Windows",
      "Mots de passe invisibles partout : hachés avant d'atteindre la base, jamais renvoyés par l'API, jamais publiés sur GitHub",
      "Le gérant télécharge un paquet source « prêt pour GitHub » (code, README, guide pas à pas, licence MIT — zéro secret) et le ZIP comme l'explorateur fonctionnent sur Vercel",
    ],
    live: true,
  },
];

/** Nombre de jalons récents affichés dépliés (les autres → archive). */
const RECENT_COUNT = 4;

export function ChangelogSection() {
  const [archiveOpen, setArchiveOpen] = useState(false);
  const archived = MILESTONES.slice(0, MILESTONES.length - RECENT_COUNT);
  const recent = MILESTONES.slice(-RECENT_COUNT);

  return (
    <section
      id="versions"
      aria-labelledby="versions-title"
      className="scroll-mt-24 border-t border-white/5 py-16 sm:py-20 lg:py-24"
    >
      <div className="mx-auto w-full max-w-3xl px-4 sm:px-6">
        <SectionHeading
          eyebrow="Journal des versions"
          title="D'un carré noir à une web-app"
          description="L'application Windows est figée en v1.0.0 — la démo web, elle, continue de grandir. Voici les dernières étapes ; les premières se replient dans l'archive."
        />

        <div className="relative">
          {/* fil vertical de la timeline */}
          <div
            aria-hidden="true"
            className="absolute bottom-3 left-[19px] top-3 w-px bg-gradient-to-b from-emerald-500/50 via-white/10 to-emerald-500/20"
          />

          <ol className="space-y-8">
            {/* ------- Jalons récents (dépliés) ------- */}
            {recent.map((milestone, index) => (
              <MilestoneRow
                key={milestone.badge}
                milestone={milestone}
                index={index}
              />
            ))}

            {/* ------- Archive dépliable ------- */}
            <li className="relative pl-14">
              <span
                aria-hidden="true"
                className="absolute left-0 top-0 grid size-10 place-items-center rounded-xl border border-white/10 bg-zinc-900/70"
              >
                <Archive className="size-4 text-zinc-400" />
              </span>
              <button
                type="button"
                onClick={() => setArchiveOpen((open) => !open)}
                aria-expanded={archiveOpen}
                className="flex w-full min-h-11 items-center gap-3 rounded-2xl border border-white/5 bg-zinc-900/40 px-4 py-3 text-left transition-colors hover:border-white/10 hover:bg-zinc-900/70"
              >
                <span className="flex-1">
                  <span className="block text-sm font-bold text-zinc-200">
                    Premiers jalons
                  </span>
                  <span className="block text-[11px] text-zinc-500">
                    {archived.length} entrées — de la v1.0.0 Windows aux
                    exclusivités web
                  </span>
                </span>
                <span className="flex items-center gap-1.5 text-[11px] font-semibold text-emerald-300">
                  {archiveOpen ? "Replier" : "Déplier"}
                  <ChevronDown
                    className={cn(
                      "size-4 transition-transform duration-300",
                      archiveOpen && "rotate-180",
                    )}
                    aria-hidden
                  />
                </span>
              </button>

              <AnimatePresence initial={false}>
                {archiveOpen && (
                  <motion.div
                    key="archive-content"
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.4, ease: [0.21, 0.47, 0.32, 0.98] }}
                    className="overflow-hidden"
                  >
                    <ol className="space-y-8 pt-8">
                      {archived.map((milestone, index) => (
                        <MilestoneRow
                          key={milestone.badge}
                          milestone={milestone}
                          index={index}
                        />
                      ))}
                    </ol>
                  </motion.div>
                )}
              </AnimatePresence>
            </li>
          </ol>

          {/* note finale — ce qui vient ensuite */}
          <FadeIn delay={0.1}>
            <p className="mt-8 pl-14 text-xs leading-relaxed text-zinc-600">
              Ensuite&nbsp;: traduction arabe/anglais de la vitrine,
              notifications hors onglet… — la feuille de route suit vos
              retours.
            </p>
          </FadeIn>
        </div>
      </div>
    </section>
  );
}

/** Une entrée de la timeline (icône + carte). */
function MilestoneRow({
  milestone,
  index,
}: {
  milestone: Milestone;
  index: number;
}) {
  return (
    <li className="relative pl-14">
      {/* point de la timeline */}
      <span
        aria-hidden="true"
        className={cn(
          "absolute left-0 top-0 grid size-10 place-items-center rounded-xl border",
          milestone.live
            ? "border-emerald-400/40 bg-emerald-500/15 shadow-[0_0_22px_rgba(16,185,129,0.28)]"
            : index === 0
              ? "border-white/15 bg-zinc-900"
              : "border-white/10 bg-zinc-900/70",
        )}
      >
        {milestone.live && (
          <span className="absolute inset-0 rounded-xl border border-emerald-400/40 motion-safe:animate-ping [animation-duration:2.4s]" />
        )}
        <milestone.icon
          className={cn(
            "size-4",
            milestone.live
              ? "text-emerald-300"
              : index === 0
                ? "text-zinc-300"
                : "text-zinc-400",
          )}
        />
      </span>

      <FadeIn delay={index * 0.05} y={16}>
        <div className="rounded-2xl border border-white/5 bg-zinc-900/50 p-4 transition-colors hover:border-white/10 sm:p-5">
          <div className="flex flex-wrap items-center gap-2">
            <span
              className={cn(
                "rounded-full border px-2 py-0.5 text-[10px] font-bold tracking-wide",
                milestone.live
                  ? "border-emerald-500/30 bg-emerald-500/10 text-emerald-300"
                  : "border-white/10 bg-zinc-800/60 text-zinc-300",
              )}
            >
              {milestone.badge}
            </span>
            <span className="text-[10px] font-medium uppercase tracking-wider text-zinc-500">
              {milestone.date}
            </span>
            {milestone.live && (
              <span className="ml-auto flex items-center gap-1.5 rounded-full bg-emerald-500/10 px-2 py-0.5 text-[10px] font-semibold text-emerald-300">
                <span className="relative flex size-1.5">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75 motion-reduce:animate-none" />
                  <span className="relative inline-flex size-1.5 rounded-full bg-emerald-400" />
                </span>
                en direct sur cette page
              </span>
            )}
          </div>

          <h3 className="mt-2 text-sm font-bold tracking-tight text-zinc-100 sm:text-base">
            {milestone.title}
          </h3>

          <ul className="mt-2.5 space-y-1.5">
            {milestone.items.map((item) => (
              <li
                key={item}
                className="flex items-start gap-2 text-xs leading-relaxed text-zinc-400 sm:text-[13px]"
              >
                <span
                  aria-hidden="true"
                  className="mt-[7px] size-1 shrink-0 rounded-full bg-emerald-500/50"
                />
                {item}
              </li>
            ))}
          </ul>
        </div>
      </FadeIn>
    </li>
  );
}
