/**
 * SiteHeader — en-tête sticky de la page vitrine.
 *
 * ⚠️ Le carré noir de la démo (fixed, z-70) occupe le coin haut-droit :
 * le conteneur interne réserve donc `lg:pr-[92px]` sur desktop. Sur mobile,
 * le carré se place automatiquement sous l'en-tête.
 *
 * Navigation : liens de section en desktop (scroll-spy) et, sous lg,
 * panneau latéral (Sheet, z-90 — au-dessus du carré noir) ouvert par le
 * bouton hamburger : les 6 sections + installation + téléchargement.
 *
 * Détail : un fin fil de progression (émeraude → ambre, comme l'anneau du
 * Mode Focus) suit le défilement en bas de l'en-tête — mise à jour directe
 * du DOM via ref (aucun re-render), lissée par requestAnimationFrame.
 */

"use client";

import { useEffect, useRef, useState } from "react";
import { Download, LogIn, LogOut, Menu, MoonStar } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { InstallButton } from "@/components/pwa/install-button";
import { AuthDialog } from "@/components/site/auth-dialog";
import { UserMenu } from "@/components/site/user-menu";
import { useAuthStore } from "@/lib/auth-store";

const NAV_LINKS = [
  { href: "#fonctionnalites", label: "Fonctionnalités" },
  { href: "#demo", label: "Démo" },
  { href: "#code", label: "Code" },
  { href: "#installation", label: "Installation" },
  { href: "#versions", label: "Versions" },
  { href: "#faq", label: "FAQ" },
];

export function SiteHeader() {
  const progressRef = useRef<HTMLDivElement>(null);

  /** Menu mobile (Sheet) — les liens de section n'existent qu'en desktop
   *  sans lui ; il se referme au choix d'une destination. */
  const [menuOpen, setMenuOpen] = useState(false);

  // Session : rétablie depuis le cookie httpOnly au premier montage.
  const user = useAuthStore((state) => state.user);
  const ready = useAuthStore((state) => state.ready);
  const initAuth = useAuthStore((state) => state.init);
  const setLoginOpen = useAuthStore((state) => state.setLoginOpen);
  const logout = useAuthStore((state) => state.logout);
  useEffect(() => {
    void initAuth();
  }, [initAuth]);

  // Scroll-spy : section active → lien éclairé (mise à jour seulement
  // quand l'active CHANGE — pas de re-render au fil du défilement).
  const [active, setActive] = useState<string | null>(null);

  useEffect(() => {
    let raf = 0;
    let current: string | null = null;
    // Ligne de lecture : un peu SOUS la position d'atterrissage des ancres
    // (scroll-mt-24 = 96 px) pour que la section cliquée soit active dès
    // l'arrivée, même si le défilement doux se termine à 1-2 px près.
    const ANCHOR_LINE = 112;
    const update = () => {
      let containing: string | null = null;
      let lastAbove: string | null = null;
      for (const link of NAV_LINKS) {
        const el = document.querySelector(link.href);
        if (!el) continue;
        const rect = el.getBoundingClientRect();
        if (rect.top - ANCHOR_LINE <= 0) {
          lastAbove = link.href;
          if (rect.bottom - ANCHOR_LINE > 0) containing = link.href;
        }
      }
      const found = containing ?? lastAbove;
      if (found !== current) {
        current = found;
        setActive(found);
      }
    };
    const onScroll = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(update);
    };
    update();
    window.addEventListener("scroll", onScroll, { passive: true });
    // Les sections changent de hauteur après coup (explorateur de code,
    // données Mawaqit, accordéons…) : on ré-évalue quand la page se
    // réorganise — pas seulement au défilement. Sans cela, le lien actif
    // « restait » sur l'ancienne section après un clic de navigation.
    const observer = new ResizeObserver(onScroll);
    observer.observe(document.documentElement);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("scroll", onScroll);
      observer.disconnect();
    };
  }, []);

  // Fil de progression du défilement (échelle horizontale 0 → 1).
  useEffect(() => {
    let raf = 0;
    const update = () => {
      const doc = document.documentElement;
      const max = doc.scrollHeight - doc.clientHeight;
      const ratio = max > 0 ? Math.min(1, doc.scrollTop / max) : 0;
      if (progressRef.current) {
        progressRef.current.style.transform = `scaleX(${ratio})`;
      }
    };
    const onScroll = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(update);
    };
    update();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll, { passive: true });
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
    };
  }, []);

  return (
    <header className="sticky top-0 z-50 border-b border-white/5 bg-zinc-950/80 backdrop-blur-xl">
      <div className="mx-auto flex h-16 w-full max-w-6xl items-center justify-between gap-3 px-4 sm:px-6 lg:pr-[92px]">
        {/* Logo */}
        <a
          href="#"
          className="flex min-h-11 items-center gap-2.5 rounded-lg outline-none focus-visible:ring-2 focus-visible:ring-emerald-400/60"
          aria-label="Sakinah — retour en haut de page"
        >
          <span
            aria-hidden="true"
            className="flex size-9 shrink-0 items-center justify-center rounded-lg border border-white/10 bg-[#0a0a0b] shadow-[0_0_18px_rgba(16,185,129,0.18)]"
          >
            <MoonStar className="size-4 text-emerald-400" />
          </span>
          <span className="text-lg font-extrabold tracking-tight text-zinc-100">
            Sakinah
          </span>
        </a>

        {/* Navigation (desktop) */}
        <nav aria-label="Navigation principale" className="hidden lg:flex">
          <ul className="flex items-center gap-1">
            {NAV_LINKS.map((link) => (
              <li key={link.href}>
                <a
                  href={link.href}
                  aria-current={active === link.href ? "true" : undefined}
                  onClick={() => setActive(link.href)}
                  className={`rounded-md px-3 py-2 text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400/60 ${
                    active === link.href
                      ? "bg-emerald-500/10 text-emerald-300"
                      : "text-zinc-400 hover:bg-white/5 hover:text-zinc-100"
                  }`}
                >
                  {link.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>

        {/* Actions */}
        <div className="flex items-center gap-2.5">
          <Badge
            variant="outline"
            className="hidden border-emerald-500/25 bg-emerald-500/10 text-emerald-300 sm:inline-flex"
          >
            v1.6.1
          </Badge>
          <InstallButton className="hidden sm:inline-flex" />

          {/* Compte : avatar si connecté, bouton Connexion sinon.
           * (ready évite le flash de bouton pendant la vérification.) */}
          {!ready ? (
            <span
              aria-hidden="true"
              className="size-11 shrink-0 animate-pulse rounded-full border border-white/5 bg-white/5"
            />
          ) : user ? (
            <UserMenu />
          ) : (
            <Button
              variant="outline"
              onClick={() => setLoginOpen(true)}
              aria-label="Se connecter à un compte Sakinah"
              className="h-11 shrink-0 gap-2 rounded-full border-white/10 bg-white/5 text-[13px] font-semibold text-zinc-300 hover:border-emerald-500/30 hover:bg-emerald-500/5 hover:text-emerald-300"
            >
              <LogIn className="size-4" aria-hidden />
              <span className="hidden sm:inline">Se connecter</span>
            </Button>
          )}

          <Button
            asChild
            className="h-11 border border-emerald-400/30 bg-emerald-500/90 font-semibold text-zinc-950 shadow-[0_0_24px_rgba(16,185,129,0.25)] hover:bg-emerald-400"
          >
            <a href="/api/download" aria-label="Télécharger l'archive ZIP du projet Sakinah">
              <Download className="size-4" aria-hidden="true" />
              <span className="hidden sm:inline">Télécharger (.zip)</span>
              <span className="sm:hidden">.zip</span>
            </a>
          </Button>

          {/* Menu mobile — les 6 sections n'y sont pas accessibles en
           *  dessous de lg sans lui : hamburger ouvrant un panneau. */}
          <Button
            variant="outline"
            size="icon"
            className="h-11 w-11 shrink-0 border-white/10 bg-white/5 text-zinc-300 hover:bg-white/10 hover:text-zinc-100 lg:hidden"
            onClick={() => setMenuOpen(true)}
            aria-label="Ouvrir le menu de navigation"
            aria-expanded={menuOpen}
          >
            <Menu className="size-5" aria-hidden="true" />
          </Button>
        </div>
      </div>

      {/* ------- Panneau de navigation mobile ------- */}
      <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
        <SheetContent
          side="right"
          className="flex w-[290px] flex-col border-l border-white/10 bg-zinc-950 p-0"
        >
          <SheetHeader className="border-b border-white/5 p-4">
            <SheetTitle className="flex items-center gap-2.5 text-left">
              <span
                aria-hidden="true"
                className="flex size-8 items-center justify-center rounded-lg border border-white/10 bg-[#0a0a0b]"
              >
                <MoonStar className="size-4 text-emerald-400" />
              </span>
              <span className="text-base font-extrabold tracking-tight text-zinc-100">
                Sakinah
              </span>
              <Badge
                variant="outline"
                className="ml-auto border-emerald-500/25 bg-emerald-500/10 text-emerald-300"
              >
                v1.6.1
              </Badge>
            </SheetTitle>
            <SheetDescription className="sr-only">
              Navigation dans les sections du site, compte et téléchargements.
            </SheetDescription>
          </SheetHeader>

          <nav
            aria-label="Navigation principale (mobile)"
            className="flex-1 overflow-y-auto p-3"
          >
            <ul className="space-y-1">
              {NAV_LINKS.map((link, index) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    onClick={() => setMenuOpen(false)}
                    aria-current={active === link.href ? "true" : undefined}
                    className={`flex min-h-11 items-center justify-between rounded-xl px-4 text-[15px] font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400/60 ${
                      active === link.href
                        ? "bg-emerald-500/10 text-emerald-300"
                        : "text-zinc-300 hover:bg-white/5 hover:text-zinc-100"
                    }`}
                  >
                    {link.label}
                    <span
                      aria-hidden="true"
                      className="text-xs tabular-nums text-zinc-600"
                    >
                      0{index + 1}
                    </span>
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          <div className="space-y-2.5 border-t border-white/5 p-4 pb-[max(1rem,env(safe-area-inset-bottom))]">
            {/* Compte (mobile) : connecté → carte du compte, sinon connexion */}
            {user ? (
              <div className="rounded-xl border border-white/10 bg-zinc-900/60 p-3">
                <p className="flex items-center justify-between gap-2">
                  <span className="min-w-0 truncate text-sm font-bold text-zinc-100">
                    {user.username}
                  </span>
                  <Badge
                    variant="outline"
                    className={
                      user.role === "MANAGER"
                        ? "border-amber-400/30 bg-amber-500/10 text-[10px] font-bold text-amber-300"
                        : "border-emerald-500/25 bg-emerald-500/10 text-[10px] font-bold text-emerald-300"
                    }
                  >
                    {user.role === "MANAGER" ? "Gérant" : "Membre"}
                  </Badge>
                </p>
                <p className="mt-0.5 truncate text-[11px] text-zinc-500">
                  {user.email}
                </p>
                <p className="mt-1.5 text-[10px] leading-relaxed text-zinc-600">
                  Données de dhikr synchronisées en ligne ✓
                </p>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={async () => {
                    const username = user.username;
                    setMenuOpen(false);
                    await logout();
                    toast(`À bientôt, ${username} 👋`);
                  }}
                  className="mt-2.5 h-9 w-full gap-2 rounded-full border-white/10 text-[12px] text-zinc-400 hover:border-red-500/30 hover:bg-red-500/5 hover:text-red-300"
                >
                  <LogOut className="size-3.5" aria-hidden />
                  Se déconnecter
                </Button>
              </div>
            ) : (
              <Button
                variant="outline"
                onClick={() => {
                  setMenuOpen(false);
                  setLoginOpen(true);
                }}
                className="h-11 w-full gap-2 rounded-full border-emerald-500/25 bg-emerald-500/5 text-[13px] font-semibold text-emerald-300 hover:bg-emerald-500/10 hover:text-emerald-200"
              >
                <LogIn className="size-4" aria-hidden />
                Se connecter / Créer un compte
              </Button>
            )}
            <InstallButton className="w-full" />
            <Button
              asChild
              className="h-11 w-full border border-emerald-400/30 bg-emerald-500/90 font-semibold text-zinc-950 shadow-[0_0_24px_rgba(16,185,129,0.25)] hover:bg-emerald-400"
            >
              <a href="/api/download" aria-label="Télécharger l'archive ZIP du projet Sakinah">
                <Download className="size-4" aria-hidden="true" />
                Télécharger (.zip)
              </a>
            </Button>
            <p className="pt-1 text-center text-[10px] leading-relaxed text-zinc-600">
              Widget de prières pour Windows
            </p>
          </div>
        </SheetContent>
      </Sheet>

      {/* Dialogue de connexion / inscription (unique pour toute la page) */}
      <AuthDialog />

      {/* Fin fil de progression du défilement */}
      <div
        ref={progressRef}
        aria-hidden="true"
        className="absolute bottom-0 left-0 h-[2px] w-full origin-left scale-x-0 bg-gradient-to-r from-emerald-600 via-emerald-400 to-amber-400/80"
      />
    </header>
  );
}
