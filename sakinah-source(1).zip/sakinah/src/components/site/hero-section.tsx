/**
 * HeroSection — accroche de la page + maquette CSS d'un bureau Windows
 * montrant le carré noir, la pop-up des prières (compte à rebours RÉEL via
 * le store de la démo + useNow) et un toast de rappel.
 *
 * Les valeurs « live » (compte à rebours, surlignage, horloge) ne sont
 * rendues qu'après montage côté client pour éviter tout écart d'hydratation.
 */

"use client";

import { useMemo, useSyncExternalStore } from "react";
import { motion } from "framer-motion";
import {
  BellRing,
  Code2,
  Download,
  FileCode2,
  Keyboard,
  Moon,
  MoonStar,
  ShieldCheck,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useDemoStore } from "@/lib/demo-store";
import { PRAYERS, computeNextPrayer, ramadanInfo, useNow } from "@/lib/prayer-utils";
import { SAMPLE_MOSQUE } from "@/lib/sample-data";
import { cn } from "@/lib/utils";

/** Formate des secondes en « h:mm:ss » ou « mm:ss ». */
function mmss(totalSec: number): string {
  const sec = Math.max(0, totalSec);
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  const mm = String(m).padStart(2, "0");
  const ss = String(s).padStart(2, "0");
  return h > 0 ? `${h}:${mm}:${ss}` : `${mm}:${ss}`;
}

const emptySubscribe = () => () => {};

/**
 * Détection d'hydratation sans setState dans un effet : snapshot serveur à
 * false, client à true — les valeurs « live » (décompte, horloge) ne sont
 * rendues qu'après hydratation pour éviter tout écart serveur/client.
 */
function useHydrated(): boolean {
  return useSyncExternalStore(
    emptySubscribe,
    () => true,
    () => false,
  );
}

function DesktopMockup() {
  const mounted = useHydrated();

  const prayers = useDemoStore((state) => state.prayers);
  const status = useDemoStore((state) => state.prayersStatus);
  const now = useNow(1000);

  // Données affichées : horaires réels si chargés, sinon jeu d'exemple
  // (identique serveur/client au premier rendu → hydratation stable).
  const data = prayers ?? SAMPLE_MOSQUE;
  const next = useMemo(
    () => computeNextPrayer(data.times, data.tomorrowFajr, data.timezone),
    [data],
  );
  // Badge flottant « Ramadan » : compte à rebours réel au calendrier hégirien
  // (mémoïsé par jour dans prayer-utils — recalcul invisible). Rendu après
  // hydratation, comme le décompte, pour un HTML serveur stable.
  const ramadan = mounted ? ramadanInfo(now, data.timezone) : null;
  const remainingSec =
    mounted && next
      ? Math.max(0, Math.round((next.datetime.getTime() - now.getTime()) / 1000))
      : null;

  return (
    <div className="relative mx-auto w-full max-w-md pb-7 lg:max-w-none">
      {/* halo émeraude derrière la maquette */}
      <div
        aria-hidden="true"
        className="absolute -inset-6 rounded-[32px] bg-emerald-500/10 blur-3xl"
      />

      {/* ------------------------------------------------ fenêtre stylisée */}
      <div className="relative overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-br from-zinc-900/90 via-zinc-950 to-black shadow-2xl shadow-black/60">
        {/* barre de titre factice */}
        <div className="flex items-center justify-between gap-3 border-b border-white/5 bg-white/[0.03] px-4 py-2.5">
          <div className="flex items-center gap-1.5" aria-hidden="true">
            <span className="size-2.5 rounded-full bg-zinc-700" />
            <span className="size-2.5 rounded-full bg-zinc-700" />
            <span className="size-2.5 rounded-full bg-zinc-700" />
          </div>
          <span className="truncate font-mono text-[11px] text-zinc-500">
            Sakinah — bureau Windows
          </span>
          <span className="w-10" aria-hidden="true" />
        </div>

        {/* scène du bureau */}
        <div className="dot-grid relative min-h-[310px] p-4 sm:min-h-[340px]">
          {/* le carré noir (réplique factice, la vraie démo est sur la page) */}
          <div
            aria-hidden="true"
            className="absolute right-3.5 top-3.5 flex size-9 items-center justify-center rounded-lg border border-white/10 bg-[#0a0a0b] shadow-lg shadow-black/60"
          >
            <MoonStar className="size-3.5 text-emerald-400" />
            <span className="absolute -bottom-0.5 -right-0.5 size-1.5 rounded-full bg-emerald-400" />
          </div>

          {/* mini pop-up « prières » */}
          <div className="absolute right-3.5 top-[60px] w-56 rounded-xl border border-white/10 bg-zinc-950/95 p-3 shadow-2xl shadow-black/50 sm:w-60">
            <div className="flex items-start justify-between gap-2 border-b border-white/5 pb-2">
              <div className="min-w-0">
                <p className="truncate text-[11px] font-semibold text-zinc-200">
                  {data.name}
                </p>
                <p className="text-[10px] text-zinc-500">
                  {mounted && status === "live" ? "Mawaqit · en direct" : "Mawaqit"}
                </p>
              </div>
              <span className="shrink-0 rounded-full bg-emerald-500/15 px-2 py-0.5 text-[9px] font-semibold text-emerald-300">
                direct
              </span>
            </div>

            <ul className="mt-2 space-y-0.5">
              {PRAYERS.map((prayer) => {
                const time = data.times[prayer.key] ?? "--:--";
                const isNext = mounted && next?.key === prayer.key;
                return (
                  <li
                    key={prayer.key}
                    className={cn(
                      "flex items-center justify-between gap-2 rounded-md px-1.5 py-1 text-[11px]",
                      isNext
                        ? "bg-emerald-500/10 font-semibold text-emerald-300"
                        : "text-zinc-400",
                    )}
                  >
                    <span className="flex min-w-0 items-center gap-1.5">
                      {isNext ? (
                        <span
                          className="size-1.5 shrink-0 animate-pulse rounded-full bg-emerald-400"
                          aria-hidden="true"
                        />
                      ) : null}
                      <span className="truncate">{prayer.label}</span>
                      <span className="shrink-0 text-zinc-600">{prayer.arabic}</span>
                    </span>
                    <span className="flex items-center gap-1.5">
                      <span className="font-mono">{time}</span>
                      {isNext && remainingSec !== null ? (
                        <span className="rounded bg-emerald-500/15 px-1.5 py-0.5 font-mono text-[9px] tabular-nums text-emerald-300">
                          {mmss(remainingSec)}
                        </span>
                      ) : null}
                    </span>
                  </li>
                );
              })}
            </ul>
          </div>

          {/* toast de rappel factice, légèrement animé */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: [0, -4, 0] }}
            transition={{
              opacity: { delay: 0.7, duration: 0.5 },
              y: { delay: 1.2, duration: 3.2, repeat: Infinity, ease: "easeInOut" },
            }}
            className="absolute bottom-3.5 right-3.5 flex items-center gap-2.5 rounded-xl border border-white/10 bg-zinc-900/95 px-3.5 py-2.5 shadow-xl shadow-black/50 backdrop-blur"
          >
            <span
              aria-hidden="true"
              className="flex size-7 items-center justify-center rounded-lg bg-emerald-500/15"
            >
              <BellRing className="size-3.5 text-emerald-400" />
            </span>
            <div className="leading-tight">
              <p className="text-[11px] font-medium text-zinc-200">
                {mounted && next
                  ? `${next.label} ${next.isTomorrow ? "demain " : ""}dans ${mmss(remainingSec ?? 0)}`
                  : "Maghrib dans 15 minutes"}
              </p>
              <p className="text-[10px] text-zinc-500">Rappel · Sakinah</p>
            </div>
          </motion.div>
        </div>

        {/* barre des tâches factice */}
        <div className="flex items-center justify-between border-t border-white/5 bg-white/[0.02] px-4 py-2">
          <div className="flex items-center gap-1.5" aria-hidden="true">
            <span className="size-5 rounded-md bg-white/5" />
            <span className="size-5 rounded-md bg-white/5" />
            <span className="size-5 rounded-md bg-emerald-500/20" />
          </div>
          <span className="font-mono text-[10px] tabular-nums text-zinc-500">
            {mounted
              ? now.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })
              : "21:04"}
          </span>
        </div>
      </div>

      {/* badge flottant : raccourci clavier */}
      <motion.div
        animate={{ y: [0, -5, 0] }}
        transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
        className="absolute -bottom-4 left-4 flex items-center gap-2 rounded-xl border border-white/10 bg-zinc-900/95 px-3.5 py-2 shadow-xl shadow-black/40 backdrop-blur sm:left-6"
      >
        <Keyboard className="size-4 text-emerald-400" aria-hidden="true" />
        <span className="flex items-center gap-1 font-mono text-[11px] text-zinc-300">
          <kbd className="rounded border border-white/10 bg-white/5 px-1.5 py-0.5">Ctrl</kbd>
          <span className="text-zinc-600">+</span>
          <kbd className="rounded border border-white/10 bg-white/5 px-1.5 py-0.5">Alt</kbd>
          <span className="text-zinc-600">+</span>
          <kbd className="rounded border border-emerald-400/20 bg-emerald-500/10 px-1.5 py-0.5 text-emerald-300">
            H
          </kbd>
        </span>
        <span className="hidden text-[10px] text-zinc-500 sm:inline">
          masquer / afficher
        </span>
      </motion.div>

      {/* badge flottant : compte à rebours du Ramadan (thème ambre) */}
      {ramadan && (
        <motion.div
          animate={{ y: [0, 4, 0] }}
          transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 0.6 }}
          className="absolute -top-4 right-6 flex items-center gap-2 rounded-full border border-amber-400/25 bg-zinc-900/95 px-3.5 py-1.5 shadow-xl shadow-black/40 backdrop-blur"
        >
          <Moon className="size-3.5 text-amber-400" aria-hidden="true" />
          <span className="font-mono text-[11px] font-medium text-amber-300">
            {ramadan.inProgress
              ? `Ramadan · jour ${ramadan.dayOfRamadan}`
              : `Ramadan · dans ${ramadan.daysLeft} jours`}
          </span>
        </motion.div>
      )}
    </div>
  );
}

export function HeroSection() {
  return (
    <section className="relative overflow-hidden" aria-labelledby="hero-title">
      <div className="mx-auto grid w-full max-w-6xl items-center gap-12 px-4 pb-16 pt-14 sm:px-6 sm:pt-20 lg:grid-cols-[1.05fr_0.95fr] lg:gap-10 lg:pb-24">
        {/* ---------------------------------------------------- colonne texte */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: [0.21, 0.47, 0.32, 0.98] }}
          className="flex flex-col items-start gap-6"
        >
          <span className="inline-flex items-center gap-2 rounded-full border border-emerald-500/20 bg-emerald-500/10 px-3.5 py-1.5 text-xs font-medium text-emerald-300">
            <span className="size-1.5 rounded-full bg-emerald-400" aria-hidden="true" />
            Application Windows · Open Source · PyQt6
          </span>

          <div className="space-y-3">
            <p className="text-sm font-semibold tracking-widest text-emerald-400 uppercase">
              Sakinah · سكينة — la tranquillité
            </p>
            <h1
              id="hero-title"
              className="text-balance text-3xl font-extrabold leading-tight tracking-tight text-zinc-100 sm:text-4xl lg:text-5xl"
            >
              Le carré noir qui veille sur vos{" "}
              <span className="text-emerald-400">prières</span> —{" "}
              <span className="text-amber-400">du Fajr à l&apos;Isha</span>.
            </h1>
          </div>

          <p className="max-w-xl text-pretty text-base leading-relaxed text-zinc-400 sm:text-lg">
            Un petit carré noir, discret, en haut à droite de votre écran. Un
            clic : les horaires de prière de{" "}
            <strong className="font-semibold text-zinc-200">votre mosquée</strong>{" "}
            (Mawaqit) avec compte à rebours en direct. Autour d&apos;eux :
            calendrier du mois, boussole Qibla et Jumu&apos;a — jusqu&apos;au
            compte à rebours du Ramadan.
          </p>

          <div className="flex w-full flex-col gap-3 sm:w-auto sm:flex-row sm:flex-wrap">
            <Button
              asChild
              size="lg"
              className="h-12 border border-emerald-400/30 bg-emerald-500 px-6 text-base font-semibold text-zinc-950 shadow-[0_0_28px_rgba(16,185,129,0.3)] transition-transform hover:scale-[1.02] hover:bg-emerald-400"
            >
              <a href="/api/download" aria-label="Télécharger le projet Sakinah au format ZIP">
                <Download className="size-4.5" aria-hidden="true" />
                Télécharger le projet
              </a>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="h-12 border-white/15 bg-transparent px-6 text-base font-medium text-zinc-200 hover:bg-white/5 hover:text-zinc-100"
            >
              <a href="#code" aria-label="Aller à la section Code source">
                <FileCode2 className="size-4.5" aria-hidden="true" />
                Explorer le code
              </a>
            </Button>
            <Button
              asChild
              size="lg"
              variant="ghost"
              className="h-12 px-4 text-base text-emerald-300 hover:bg-emerald-500/10 hover:text-emerald-200"
            >
              <a href="#demo" aria-label="Aller à la démonstration interactive">
                C'est parti
                <span aria-hidden="true">↓</span>
              </a>
            </Button>
          </div>

          {/* gages de confiance */}
          <ul className="flex flex-wrap items-center gap-x-5 gap-y-2 text-xs text-zinc-500">
            <li className="flex items-center gap-1.5">
              <Code2 className="size-3.5 text-emerald-400/80" aria-hidden="true" />
              Open source · licence MIT
            </li>
            <li className="flex items-center gap-1.5">
              <ShieldCheck className="size-3.5 text-emerald-400/80" aria-hidden="true" />
              Aucune donnée collectée
            </li>
            <li className="flex items-center gap-1.5">
              <MoonStar className="size-3.5 text-emerald-400/80" aria-hidden="true" />
              Windows 10 / 11 · Python 3.10+
            </li>
          </ul>
        </motion.div>

        {/* -------------------------------------------------- colonne maquette */}
        <motion.div
          initial={{ opacity: 0, y: 32, scale: 0.97 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.7, delay: 0.15, ease: [0.21, 0.47, 0.32, 0.98] }}
        >
          <DesktopMockup />
        </motion.div>
      </div>
    </section>
  );
}
