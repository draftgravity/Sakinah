/**
 * UserMenu — pastille du compte connecté dans l'en-tête.
 *
 * * avatar : initiale du nom d'utilisateur (anneau émeraude pour le
 *   gérant, zinc pour un membre) + badge de rôle dans le menu ;
 * * actions : « Espace gérant » (réservé au rôle MANAGER — ouvre le
 *   tableau de bord), bascule rapide « Version : complète / prières »
 *   (gérant, préférence en ligne) et « Se déconnecter » ;
 * * état « pas encore prêt » (session en cours de vérification) : la
 *   pastille ne s'affiche pas pour éviter un flash de bouton.
 */

"use client";

import { useState } from "react";
import { LogOut, LayoutDashboard, MoonStar, Timer } from "lucide-react";
import { toast } from "sonner";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { useAuthStore } from "@/lib/auth-store";
import { ManagerDashboard } from "@/components/site/manager-dashboard";
import { cn } from "@/lib/utils";

function initialsOf(username: string): string {
  const trimmed = username.trim();
  if (!trimmed) return "?";
  // initiale + 2ᵉ caractère si le nom est composé (ex. « Jean-Luc »)
  const parts = trimmed.split(/[\s_.-]+/).filter(Boolean);
  if (parts.length >= 2) {
    return (parts[0][0] + parts[1][0]).toUpperCase();
  }
  return trimmed.slice(0, 2).toUpperCase();
}

export function UserMenu() {
  const user = useAuthStore((state) => state.user);
  const ready = useAuthStore((state) => state.ready);
  const logout = useAuthStore((state) => state.logout);
  const setFocusEnabled = useAuthStore((state) => state.setFocusEnabled);
  const [dashboardOpen, setDashboardOpen] = useState(false);
  const [versionBusy, setVersionBusy] = useState(false);

  if (!ready || !user) return null;

  const isManager = user.role === "MANAGER";

  const handleLogout = async () => {
    const username = user.username;
    await logout();
    toast(`À bientôt, ${username} 👋`);
  };

  /** Bascule rapide de la version (gérant) — préférence en ligne. */
  const handleSwitchVersion = async () => {
    if (versionBusy) return;
    setVersionBusy(true);
    const next = !user.focusEnabled;
    const result = await setFocusEnabled(next);
    setVersionBusy(false);
    if (result.ok) {
      toast.success(
        next
          ? "Version complète — l'onglet Mode Focus est visible."
          : "Version prières — le Mode Focus est masqué.",
      );
    } else {
      toast.error(result.error ?? "Modification impossible.");
    }
  };

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger
          aria-label={`Compte de ${user.username}`}
          className={cn(
            "flex size-11 items-center justify-center rounded-full border text-[13px] font-extrabold uppercase tracking-wide outline-none transition-all focus-visible:ring-2 focus-visible:ring-emerald-400/60",
            isManager
              ? "border-emerald-400/50 bg-emerald-500/15 text-emerald-300 shadow-[0_0_16px_rgba(16,185,129,0.25)] hover:border-emerald-300/70"
              : "border-white/15 bg-white/5 text-zinc-300 hover:border-white/30 hover:text-zinc-100",
          )}
        >
          {initialsOf(user.username)}
        </DropdownMenuTrigger>
        <DropdownMenuContent
          align="end"
          sideOffset={8}
          className="w-64 rounded-xl border-white/10 bg-zinc-950/98 p-1.5 text-zinc-200 shadow-2xl shadow-black/60"
        >
          <DropdownMenuLabel className="rounded-lg px-2.5 py-2">
            <p className="truncate text-sm font-bold text-zinc-100">
              {user.username}
            </p>
            <p className="mt-0.5 truncate text-[11px] text-zinc-500">
              {user.email}
            </p>
            <Badge
              variant="outline"
              className={
                isManager
                  ? "mt-1.5 border-amber-400/30 bg-amber-500/10 text-[10px] font-bold text-amber-300"
                  : "mt-1.5 border-emerald-500/25 bg-emerald-500/10 text-[10px] font-bold text-emerald-300"
              }
            >
              {isManager ? "Gérant" : "Membre"}
            </Badge>
          </DropdownMenuLabel>
          <DropdownMenuSeparator className="bg-white/5" />
          {isManager && (
            <>
              <DropdownMenuItem
                onSelect={() => setDashboardOpen(true)}
                className="min-h-10 cursor-pointer gap-2.5 rounded-lg px-2.5 text-[13px] font-semibold text-amber-200 outline-none transition-colors focus:bg-amber-500/10 focus:text-amber-200 data-[highlighted]:bg-amber-500/10 data-[highlighted]:text-amber-200"
              >
                <LayoutDashboard className="size-4" aria-hidden />
                Espace gérant
              </DropdownMenuItem>
              <DropdownMenuItem
                onSelect={() => void handleSwitchVersion()}
                disabled={versionBusy}
                className="min-h-10 cursor-pointer gap-2.5 rounded-lg px-2.5 text-[13px] font-medium text-zinc-300 outline-none transition-colors focus:bg-white/5 focus:text-zinc-100 data-[highlighted]:bg-white/5 data-[highlighted]:text-zinc-100"
              >
                {user.focusEnabled ? (
                  <MoonStar className="size-4 text-emerald-400" aria-hidden />
                ) : (
                  <Timer className="size-4 text-rose-400" aria-hidden />
                )}
                <span className="flex-1">
                  Version :{" "}
                  <strong className="font-semibold">
                    {user.focusEnabled ? "complète" : "prières"}
                  </strong>
                </span>
                <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-600">
                  basculer
                </span>
              </DropdownMenuItem>
            </>
          )}
          <DropdownMenuItem
            onSelect={() => void handleLogout()}
            className="min-h-10 cursor-pointer gap-2.5 rounded-lg px-2.5 text-[13px] font-medium text-zinc-400 outline-none transition-colors focus:bg-red-500/10 focus:text-red-300 data-[highlighted]:bg-red-500/10 data-[highlighted]:text-red-300"
          >
            <LogOut className="size-4" aria-hidden />
            Se déconnecter
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      {/* Tableau de bord gérant (dialogue plein cadre) */}
      <ManagerDashboard open={dashboardOpen} onOpenChange={setDashboardOpen} />
    </>
  );
}
