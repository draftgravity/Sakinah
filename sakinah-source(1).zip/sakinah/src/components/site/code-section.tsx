/**
 * CodeSection — explorateur de code source de l'application Python.
 *
 *  * arborescence (gauche) construite depuis /api/files (dossiers pliables) ;
 *  * visionneuse (droite) alimentée par /api/files/content avec coloration
 *    syntaxique Prism (thème vscDarkPlus), copie et téléchargement ;
 *  * cartes « modules clés » cliquables qui sélectionnent le fichier.
 */

"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Prism as SyntaxHighlighter } from "react-syntax-highlighter";
import { vscDarkPlus } from "react-syntax-highlighter/dist/esm/styles/prism";
import {
  AlertCircle,
  ChevronRight,
  Download,
  FileCode2,
  FileJson,
  FileText,
  Folder,
  FolderOpen,
  RotateCcw,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { SectionHeading } from "./section-heading";
import { CopyButton } from "./copy-button";
import { cn } from "@/lib/utils";

/* ------------------------------------------------------------------ types */

interface ManifestFile {
  path: string;
  size: number;
  lines: number;
  language: "python" | "json" | "markdown" | "text";
}

interface Manifest {
  files: ManifestFile[];
  totalLines: number;
  totalFiles: number;
}

interface FileContent {
  path: string;
  content: string;
  language: string;
  lines: number;
}

interface TreeNode {
  name: string;
  path: string;
  type: "dir" | "file";
  children: TreeNode[];
  meta?: ManifestFile;
}

/* ------------------------------------------------------------- utilitaires */

function buildTree(files: ManifestFile[]): TreeNode[] {
  const root: TreeNode = { name: "", path: "", type: "dir", children: [] };
  for (const file of files) {
    const parts = file.path.split("/");
    let current = root;
    parts.forEach((part, index) => {
      const isLeaf = index === parts.length - 1;
      let child = current.children.find(
        (c) => c.name === part && c.type === (isLeaf ? "file" : "dir"),
      );
      if (!child) {
        child = {
          name: part,
          path: parts.slice(0, index + 1).join("/"),
          type: isLeaf ? "file" : "dir",
          children: [],
          meta: isLeaf ? file : undefined,
        };
        current.children.push(child);
      }
      current = child;
    });
  }

  const sortNodes = (nodes: TreeNode[]): TreeNode[] => {
    const sorted = [...nodes].sort((a, b) => {
      if (a.type !== b.type) return a.type === "dir" ? -1 : 1;
      return a.name.localeCompare(b.name, "en");
    });
    sorted.forEach((node) => {
      node.children = sortNodes(node.children);
    });
    return sorted;
  };

  return sortNodes(root.children);
}

function FileIcon({ node, className }: { node: TreeNode; className?: string }) {
  if (node.name.endsWith(".py")) return <FileCode2 className={className} aria-hidden="true" />;
  if (node.name.endsWith(".json")) return <FileJson className={className} aria-hidden="true" />;
  return <FileText className={className} aria-hidden="true" />;
}

/* -------------------------------------------------------------- arborescence */

function TreeFolder({
  node,
  depth,
  selected,
  onSelect,
}: {
  node: TreeNode;
  depth: number;
  selected: string | null;
  onSelect: (path: string) => void;
}) {
  const [open, setOpen] = useState(depth === 0);
  return (
    <Collapsible open={open} onOpenChange={setOpen}>
      <CollapsibleTrigger
        className={cn(
          "group flex min-h-11 w-full items-center gap-1.5 rounded-md px-2 text-left text-[13px] font-medium text-zinc-300 transition-colors hover:bg-white/5 hover:text-zinc-100",
          "outline-none focus-visible:ring-2 focus-visible:ring-emerald-400/60",
        )}
        aria-label={`${open ? "Replier" : "Déplier"} le dossier ${node.name}`}
      >
        <ChevronRight
          className="size-3.5 shrink-0 text-zinc-600 transition-transform duration-200 group-data-[state=open]:rotate-90"
          aria-hidden="true"
        />
        {open ? (
          <FolderOpen className="size-4 shrink-0 text-emerald-400/90" aria-hidden="true" />
        ) : (
          <Folder className="size-4 shrink-0 text-emerald-400/70" aria-hidden="true" />
        )}
        <span className="truncate">{node.name}</span>
        <span className="ml-auto shrink-0 text-[10px] text-zinc-600">
          {node.children.length}
        </span>
      </CollapsibleTrigger>
      <CollapsibleContent>
        <div className="ml-[13px] border-l border-white/5 pl-1.5">
          {node.children.map((child) =>
            child.type === "dir" ? (
              <TreeFolder
                key={child.path}
                node={child}
                depth={depth + 1}
                selected={selected}
                onSelect={onSelect}
              />
            ) : (
              <TreeFile
                key={child.path}
                node={child}
                selected={selected}
                onSelect={onSelect}
              />
            ),
          )}
        </div>
      </CollapsibleContent>
    </Collapsible>
  );
}

function TreeFile({
  node,
  selected,
  onSelect,
}: {
  node: TreeNode;
  selected: string | null;
  onSelect: (path: string) => void;
}) {
  const isSelected = selected === node.path;
  return (
    <button
      type="button"
      onClick={() => onSelect(node.path)}
      aria-current={isSelected ? "true" : undefined}
      className={cn(
        "flex min-h-11 w-full items-center gap-1.5 rounded-md px-2 text-left text-[13px] transition-colors outline-none focus-visible:ring-2 focus-visible:ring-emerald-400/60",
        isSelected
          ? "bg-emerald-500/10 font-medium text-emerald-300"
          : "text-zinc-400 hover:bg-white/5 hover:text-zinc-200",
      )}
    >
      <span className="w-3.5 shrink-0" aria-hidden="true" />
      <FileIcon node={node} className="size-4 shrink-0 text-zinc-500" />
      <span className="truncate">{node.name}</span>
      <span className="ml-auto shrink-0 font-mono text-[10px] text-zinc-600">
        {node.meta?.lines}
      </span>
    </button>
  );
}

/* ----------------------------------------------------------- modules clés */

const KEY_MODULES: Array<{
  path: string;
  role: string;
  desc: string;
}> = [
  {
    path: "app/controller.py",
    role: "Le chef d'orchestre",
    desc: "Relie widget, prières et tray : rien ne bouge dans l'application sans lui.",
  },
  {
    path: "app/overlay_widget.py",
    role: "Le carré noir",
    desc: "Le QWidget frameless : draggable, toujours au premier plan, click-through, détection plein écran.",
  },
  {
    path: "app/services/mawaqit.py",
    role: "Client API Mawaqit",
    desc: "Recherche de mosquée, parsing de confData et cache hors-ligne dans config.json.",
  },
  {
    path: "app/services/prayer_service.py",
    role: "Le rythme des prières",
    desc: "Prochaine prière, compte à rebours et rappels 15 min avant — recalculés chaque seconde, à l'heure de la mosquée.",
  },
];

/*
 * Fichiers du mode concentration (réservé au gérant) : absents de
 * l'arborescence présentée et des compteurs affichés. L'archive .zip
 * téléchargeable reste, elle, complète et intacte.
 */
const HIDDEN_PREFIXES = ["app/focus/", "app/ui/focus"];

/* ----------------------------------------------------------------- section */

export function CodeSection() {
  const [manifest, setManifest] = useState<Manifest | null>(null);
  const [manifestError, setManifestError] = useState<string | null>(null);
  const [selected, setSelected] = useState<string | null>(null);
  const [file, setFile] = useState<FileContent | null>(null);
  const [fileLoading, setFileLoading] = useState(false);
  const [fileError, setFileError] = useState<string | null>(null);
  const [retryNonce, setRetryNonce] = useState(0);
  const viewerRef = useRef<HTMLDivElement | null>(null);

  // --- chargement du manifeste + pré-sélection de app/controller.py ------
  const loadManifest = useCallback(async () => {
    setManifestError(null);
    try {
      const response = await fetch("/api/files");
      if (!response.ok) throw new Error(`Erreur ${response.status}`);
      const data = (await response.json()) as Manifest;
      setManifest(data);
      // Pré-sélection : le module « rythme des prières » (propre à la
      // présentation publique — les autres fichiers restent explorables).
      setSelected((current) => current ?? "app/services/prayer_service.py");
    } catch (error) {
      setManifestError(
        error instanceof Error ? error.message : "Échec du chargement de l'arborescence.",
      );
    }
  }, []);

  useEffect(() => {
    void loadManifest();
  }, [loadManifest]);

  // --- contenu du fichier sélectionné ------------------------------------
  useEffect(() => {
    if (!selected) return;
    let cancelled = false;
    setFileLoading(true);
    setFileError(null);
    fetch(`/api/files/content?path=${encodeURIComponent(selected)}`)
      .then(async (response) => {
        if (!response.ok) {
          const body = (await response.json().catch(() => null)) as { error?: string } | null;
          throw new Error(body?.error ?? `Erreur ${response.status}`);
        }
        return (await response.json()) as FileContent;
      })
      .then((data) => {
        if (!cancelled) setFile(data);
      })
      .catch((error: unknown) => {
        if (!cancelled) {
          setFile(null);
          setFileError(
            error instanceof Error ? error.message : "Impossible de lire ce fichier.",
          );
        }
      })
      .finally(() => {
        if (!cancelled) setFileLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [selected, retryNonce]);

  const tree = useMemo(
    () =>
      buildTree(
        (manifest?.files ?? []).filter(
          (file) => !HIDDEN_PREFIXES.some((prefix) => file.path.startsWith(prefix)),
        ),
      ),
    [manifest],
  );

  const selectFromCard = useCallback((path: string) => {
    setSelected(path);
    viewerRef.current?.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }, []);

  const statsLabel = manifest
    ? (() => {
        const visible = manifest.files.filter(
          (file) => !HIDDEN_PREFIXES.some((prefix) => file.path.startsWith(prefix)),
        );
        return `${visible.length} fichiers · ${visible
          .reduce((total, file) => total + file.lines, 0)
          .toLocaleString("fr-FR")} lignes · commentaires en français`;
      })()
    : "28 fichiers · ~3 700 lignes · commentaires en français";

  return (
    <section
      id="code"
      aria-labelledby="code-title"
      className="scroll-mt-24 py-16 sm:py-20 lg:py-24"
    >
      <div className="mx-auto w-full max-w-6xl px-4 sm:px-6">
        <SectionHeading
          eyebrow="Code source"
          title="Architecture du code"
          description="Une base Python claire et modulaire : PyQt6 pour l'interface, requests pour Mawaqit, win32gui pour l'intégration Windows. Parcourez le cœur du projet ci-dessous."
        />

        {/* bandeau stats + téléchargement */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.5 }}
          className="mb-6 flex flex-col gap-3 rounded-xl border border-white/5 bg-zinc-900/60 px-4 py-3.5 sm:flex-row sm:items-center sm:justify-between"
        >
          <p className="flex items-center gap-2 text-sm text-zinc-300">
            <FileCode2 className="size-4 shrink-0 text-emerald-400" aria-hidden="true" />
            <span>{statsLabel}</span>
          </p>
          <Button
            asChild
            size="sm"
            className="h-10 border border-emerald-400/30 bg-emerald-500 font-semibold text-zinc-950 hover:bg-emerald-400"
          >
            <a href="/api/download" aria-label="Télécharger tout le projet en archive ZIP">
              <Download className="size-4" aria-hidden="true" />
              Télécharger tout (.zip)
            </a>
          </Button>
        </motion.div>

        {/* explorateur : arbre + visionneuse */}
        <div className="grid gap-4 lg:grid-cols-[300px_1fr]">
          {/* ---------------------------------------------------- arborescence */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.5 }}
            className="overflow-hidden rounded-2xl border border-white/5 bg-zinc-900/60"
            aria-label="Arborescence des fichiers du projet"
          >
            <div className="border-b border-white/5 bg-white/[0.02] px-4 py-3">
              <h3 className="text-xs font-semibold tracking-wide text-zinc-400 uppercase">
                sakina-widget/
              </h3>
            </div>
            <div className="scrollbar-slim max-h-80 overflow-y-auto p-2 lg:max-h-[560px]">
              {manifestError ? (
                <div className="flex flex-col items-start gap-3 p-3">
                  <p className="flex items-center gap-2 text-sm text-red-300">
                    <AlertCircle className="size-4 shrink-0" aria-hidden="true" />
                    {manifestError}
                  </p>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => void loadManifest()}
                    className="border-white/15 bg-transparent text-zinc-300 hover:bg-white/5"
                  >
                    <RotateCcw className="size-3.5" aria-hidden="true" />
                    Réessayer
                  </Button>
                </div>
              ) : manifest ? (
                <div aria-label="Fichiers du projet sakina-widget">
                  {tree.map((node) =>
                    node.type === "dir" ? (
                      <TreeFolder
                        key={node.path}
                        node={node}
                        depth={0}
                        selected={selected}
                        onSelect={setSelected}
                      />
                    ) : (
                      <TreeFile
                        key={node.path}
                        node={node}
                        selected={selected}
                        onSelect={setSelected}
                      />
                    ),
                  )}
                </div>
              ) : (
                <div className="space-y-2 p-2" aria-label="Chargement de l'arborescence">
                  {Array.from({ length: 9 }).map((_, index) => (
                    <Skeleton key={index} className="h-8 w-full bg-white/5" />
                  ))}
                </div>
              )}
            </div>
          </motion.div>

          {/* ------------------------------------------------------ visionneuse */}
          <motion.div
            ref={viewerRef}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.5, delay: 0.08 }}
            className="flex min-h-[420px] flex-col overflow-hidden rounded-2xl border border-white/5 bg-zinc-900/60"
            aria-label="Visionneuse de code source"
          >
            {/* barre d'outils */}
            <div className="flex items-center justify-between gap-3 border-b border-white/5 bg-white/[0.02] px-4 py-2.5">
              <p className="flex min-w-0 items-center gap-2 font-mono text-xs text-zinc-300">
                <FileCode2 className="size-4 shrink-0 text-emerald-400" aria-hidden="true" />
                <span className="truncate">{selected ?? "—"}</span>
                {file ? (
                  <span className="hidden shrink-0 text-zinc-600 sm:inline">
                    · {file.lines} lignes
                  </span>
                ) : null}
              </p>
              <div className="flex shrink-0 items-center gap-1">
                {file ? <CopyButton value={file.content} label="le fichier" /> : null}
                {selected ? (
                  <Button
                    asChild
                    variant="ghost"
                    size="icon"
                    className="size-8 text-zinc-400 hover:bg-white/5 hover:text-zinc-200"
                  >
                    <a
                      href={`/api/files/content?path=${encodeURIComponent(selected)}&download=1`}
                      aria-label={`Télécharger le fichier ${selected}`}
                    >
                      <Download className="size-3.5" aria-hidden="true" />
                    </a>
                  </Button>
                ) : null}
              </div>
            </div>

            {/* contenu */}
            <div className="scrollbar-slim flex-1 overflow-auto">
              {fileLoading ? (
                <div className="space-y-3 p-5" aria-label="Chargement du fichier">
                  {Array.from({ length: 10 }).map((_, index) => (
                    <Skeleton
                      key={index}
                      className="h-4 bg-white/5"
                      style={{ width: `${88 - (index % 5) * 13}%` }}
                    />
                  ))}
                </div>
              ) : fileError ? (
                <div className="flex flex-col items-start gap-3 p-6">
                  <p className="flex items-center gap-2 text-sm text-red-300">
                    <AlertCircle className="size-4 shrink-0" aria-hidden="true" />
                    {fileError}
                  </p>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => setRetryNonce((nonce) => nonce + 1)}
                    className="border-white/15 bg-transparent text-zinc-300 hover:bg-white/5"
                  >
                    <RotateCcw className="size-3.5" aria-hidden="true" />
                    Réessayer
                  </Button>
                </div>
              ) : file ? (
                <SyntaxHighlighter
                  language={file.language}
                  style={vscDarkPlus}
                  showLineNumbers
                  wrapLongLines={false}
                  customStyle={{
                    background: "transparent",
                    fontSize: "12px",
                    margin: 0,
                    padding: "16px 12px",
                  }}
                  codeTagProps={{
                    style: { fontFamily: "var(--font-geist-mono), ui-monospace, monospace" },
                  }}
                >
                  {file.content}
                </SyntaxHighlighter>
              ) : (
                <div className="flex h-full items-center justify-center p-6">
                  <p className="text-sm text-zinc-600">
                    Sélectionnez un fichier dans l'arborescence.
                  </p>
                </div>
              )}
            </div>
          </motion.div>
        </div>

        {/* -------------------------------------------------- modules clés */}
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {KEY_MODULES.map((module, index) => (
            <motion.button
              key={module.path}
              type="button"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.5, delay: index * 0.07 }}
              onClick={() => selectFromCard(module.path)}
              className={cn(
                "group rounded-2xl border p-5 text-left transition-all duration-200 outline-none focus-visible:ring-2 focus-visible:ring-emerald-400/60",
                selected === module.path
                  ? "border-emerald-500/30 bg-emerald-500/[0.06]"
                  : "border-white/5 bg-zinc-900/60 hover:-translate-y-0.5 hover:border-emerald-500/20 hover:bg-zinc-900",
              )}
              aria-label={`Afficher ${module.path} dans la visionneuse`}
            >
              <p className="font-mono text-xs text-emerald-400">{module.path}</p>
              <h3 className="mt-2 text-sm font-bold tracking-tight text-zinc-100">
                {module.role}
              </h3>
              <p className="mt-1.5 text-xs leading-relaxed text-zinc-400">{module.desc}</p>
              <span className="mt-3 inline-flex items-center gap-1 text-xs font-medium text-zinc-500 transition-colors group-hover:text-emerald-300">
                Voir le fichier
                <ChevronRight className="size-3.5" aria-hidden="true" />
              </span>
            </motion.button>
          ))}
        </div>
      </div>
    </section>
  );
}
