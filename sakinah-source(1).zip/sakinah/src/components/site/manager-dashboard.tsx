/**
 * ManagerDashboard — l'espace gérant (dialogue plein cadre, z-50+).
 *
 * Réservé au rôle MANAGER (les routes /api/manager/* rejettent les
 * autres — ce composant n'est qu'une fenêtre sur ces données).
 *
 * * « Vue d'ensemble » : 4 KPI (utilisateurs, actifs du jour, dhikr du
 *   jour, focus) + séries des 7 derniers jours (barres émeraude/ambre)
 *   + activités récentes ;
 * * « Utilisateurs » : annuaire complet avec recherche, statistiques par
 *   compte, promotion/rétrogradation et suppression (confirmées) — le
 *   gérant ne peut pas toucher à son propre compte ;
 * * « Activité » : journal complet des 15 derniers événements.
 */

"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import {
  Activity,
  ArrowUpDown,
  CalendarDays,
  CloudCog,
  Download,
  Flame,
  Github,
  LayoutDashboard,
  LogIn,
  MonitorDown,
  MoonStar,
  MoreHorizontal,
  RefreshCw,
  Search,
  ShieldCheck,
  Sparkles,
  Timer,
  Trash2,
  UserCheck,
  UserPlus,
  Users,
} from "lucide-react";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useAuthStore } from "@/lib/auth-store";
import { usePwaInstall } from "@/hooks/use-pwa-install";
import { cn } from "@/lib/utils";

/* ------------------------------------------------------------------ */
/* Types des réponses API                                              */
/* ------------------------------------------------------------------ */

interface OverviewData {
  kpis: {
    users: number;
    newUsers7d: number;
    activeToday: number;
    dhikrToday: number;
    dhikrLifetime: number;
    focusSessions: number;
    focusMinutes: number;
  };
  dhikr7d: { date: string; count: number }[];
  focus7d: { date: string; sessions: number; minutes: number }[];
  activity: {
    id: string;
    type: string;
    detail: string;
    username: string | null;
    createdAt: string;
  }[];
  generatedAt: string;
}

interface UserRow {
  id: string;
  username: string;
  name: string | null;
  email: string;
  role: "USER" | "MANAGER";
  createdAt: string;
  lastLoginAt: string | null;
  dhikrToday: number;
  dhikrLifetime: number;
  focusSessions: number;
  focusMinutes: number;
}

/* ------------------------------------------------------------------ */
/* Petits formateurs                                                   */
/* ------------------------------------------------------------------ */

const dateFmt = new Intl.DateTimeFormat("fr-FR", {
  day: "numeric",
  month: "short",
  year: "numeric",
});
const timeFmt = new Intl.DateTimeFormat("fr-FR", {
  hour: "2-digit",
  minute: "2-digit",
});
const weekdayFmt = new Intl.DateTimeFormat("fr-FR", { weekday: "short" });

function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const minutes = Math.floor(diff / 60_000);
  if (minutes < 1) return "à l'instant";
  if (minutes < 60) return `il y a ${minutes} min`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `il y a ${hours} h`;
  const days = Math.floor(hours / 24);
  if (days === 1) return "hier";
  if (days < 7) return `il y a ${days} j`;
  return dateFmt.format(new Date(iso));
}

const ACTIVITY_ICONS: Record<
  string,
  { icon: React.ComponentType<{ className?: string }>; className: string }
> = {
  LOGIN: { icon: LogIn, className: "text-emerald-400 bg-emerald-500/10" },
  REGISTER: { icon: UserPlus, className: "text-emerald-400 bg-emerald-500/10" },
  FOCUS: { icon: Timer, className: "text-amber-400 bg-amber-500/10" },
  FOCUS_IMPORT: { icon: CloudCog, className: "text-zinc-400 bg-white/5" },
  ROLE: { icon: ShieldCheck, className: "text-amber-400 bg-amber-500/10" },
  DELETE: { icon: Trash2, className: "text-red-400 bg-red-500/10" },
};

function initialsOf(username: string): string {
  const parts = username.trim().split(/[\s_.-]+/).filter(Boolean);
  if (parts.length >= 2) return (parts[0][0] + parts[1][0]).toUpperCase();
  return username.trim().slice(0, 2).toUpperCase() || "?";
}

/* ------------------------------------------------------------------ */
/* Mini-graphique 7 jours (barres)                                     */
/* ------------------------------------------------------------------ */

function WeekBars({
  values,
  labels,
  hints,
  tone,
}: {
  values: number[];
  labels: string[];
  hints: string[];
  tone: "emerald" | "amber";
}) {
  const peak = Math.max(1, ...values);
  return (
    <div className="flex items-end gap-1.5" style={{ height: 84 }}>
      {values.map((value, index) => {
        const height = value === 0 ? 3 : Math.max(8, (value / peak) * 56);
        return (
          <div
            key={`${labels[index]}-${index}`}
            className="flex flex-1 flex-col items-center justify-end gap-1"
            title={hints[index]}
          >
            <span
              className={cn(
                "text-[9px] font-bold tabular-nums",
                value > 0
                  ? tone === "emerald"
                    ? "text-emerald-300"
                    : "text-amber-300"
                  : "text-zinc-700",
              )}
            >
              {value > 0 ? value : ""}
            </span>
            <div
              aria-hidden="true"
              style={{ height: `${height}px` }}
              className={cn(
                "w-full max-w-[22px] rounded-sm transition-all duration-500",
                value === 0
                  ? "bg-white/10"
                  : tone === "emerald"
                    ? "bg-gradient-to-t from-emerald-700/70 to-emerald-500/80"
                    : "bg-gradient-to-t from-amber-600/70 to-amber-400/80",
              )}
            />
            <span className="text-[9px] font-medium capitalize text-zinc-600">
              {labels[index]}
            </span>
          </div>
        );
      })}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Composant principal                                                 */
/* ------------------------------------------------------------------ */

export function ManagerDashboard({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const me = useAuthStore((state) => state.user);
  const setFocusEnabled = useAuthStore((state) => state.setFocusEnabled);
  const setLoginOpen = useAuthStore((state) => state.setLoginOpen);
  const [overview, setOverview] = useState<OverviewData | null>(null);
  const [users, setUsers] = useState<UserRow[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [sessionExpired, setSessionExpired] = useState(false);
  const [tab, setTab] = useState("overview");
  const [search, setSearch] = useState("");
  const [pendingDelete, setPendingDelete] = useState<UserRow | null>(null);
  const [busyUserId, setBusyUserId] = useState<string | null>(null);
  const [versionBusy, setVersionBusy] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    setSessionExpired(false);
    try {
      const [overviewResponse, usersResponse] = await Promise.all([
        fetch("/api/manager/overview", { cache: "no-store" }),
        fetch("/api/manager/users", { cache: "no-store" }),
      ]);
      if (
        overviewResponse.status === 401 ||
        usersResponse.status === 401
      ) {
        // Le cookie de session n'est plus valable (expiré ou refusé) :
        // message explicite + proposition de reconnexion plutôt qu'un
        // sec « Chargement impossible ».
        setSessionExpired(true);
        throw new Error(
          "Session expirée — reconnectez-vous pour accéder à l'espace gérant.",
        );
      }
      if (!overviewResponse.ok || !usersResponse.ok) {
        throw new Error(
          overviewResponse.status === 403 || usersResponse.status === 403
            ? "Accès réservé au gérant."
            : "Chargement impossible.",
        );
      }
      const [overviewData, usersData] = (await Promise.all([
        overviewResponse.json(),
        usersResponse.json(),
      ])) as [OverviewData, { users: UserRow[] }];
      setOverview(overviewData);
      setUsers(usersData.users);
    } catch (caught) {
      setError(
        caught instanceof Error ? caught.message : "Chargement impossible.",
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (open) void load();
  }, [open, load]);

  /* ---- actions utilisateurs ---- */

  const changeRole = async (user: UserRow) => {
    const role = user.role === "MANAGER" ? "USER" : "MANAGER";
    setBusyUserId(user.id);
    try {
      const response = await fetch(`/api/manager/users/${user.id}`, {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ role }),
      });
      const data = (await response.json().catch(() => ({}))) as {
        error?: string;
      };
      if (!response.ok) {
        toast.error(data.error ?? "Modification impossible.");
      } else {
        toast.success(
          role === "MANAGER"
            ? `${user.username} est maintenant gérant.`
            : `${user.username} redevient membre.`,
        );
        await load();
      }
    } catch {
      toast.error("Réseau indisponible.");
    } finally {
      setBusyUserId(null);
    }
  };

  const deleteUser = async () => {
    const user = pendingDelete;
    if (!user) return;
    setPendingDelete(null);
    setBusyUserId(user.id);
    try {
      const response = await fetch(`/api/manager/users/${user.id}`, {
        method: "DELETE",
      });
      const data = (await response.json().catch(() => ({}))) as {
        error?: string;
      };
      if (!response.ok) {
        toast.error(data.error ?? "Suppression impossible.");
      } else {
        toast.success(`Compte ${user.username} supprimé.`);
        await load();
      }
    } catch {
      toast.error("Réseau indisponible.");
    } finally {
      setBusyUserId(null);
    }
  };

  /* ---- versions (gérant) ---- */

  const pwa = usePwaInstall();

  /** Bascule la version du compte (en ligne) — sans installation. */
  const switchVersion = async (enabled: boolean) => {
    if (me?.focusEnabled === enabled || versionBusy) return;
    setVersionBusy(true);
    const result = await setFocusEnabled(enabled);
    setVersionBusy(false);
    if (result.ok) {
      toast.success(
        enabled
          ? "Version complète active — l'onglet Mode Focus est de retour."
          : "Version prières active — le Mode Focus est masqué.",
      );
    } else {
      toast.error(result.error ?? "Modification impossible.");
    }
  };

  /** Enregistre la version PUIS lance l'installation de la web-app :
   *  l'application installée s'ouvrira avec la version choisie. */
  const installVersion = async (enabled: boolean) => {
    if (versionBusy) return;
    setVersionBusy(true);
    const result = await setFocusEnabled(enabled);
    setVersionBusy(false);
    if (!result.ok) {
      toast.error(result.error ?? "Modification impossible.");
      return;
    }
    if (pwa.installed) {
      toast.success(
        "Version enregistrée — l'application installée est déjà à jour.",
      );
      return;
    }
    const outcome = await pwa.promptInstall();
    if (outcome === "accepted") {
      toast.success(
        enabled
          ? "Web-app installée — version complète (avec Mode Focus)."
          : "Web-app installée — version prières.",
      );
    } else if (outcome === "unavailable") {
      toast.info(
        "Votre navigateur n'affiche pas d'invitation : utilisez le menu ⋮ → « Installer l'application ». La version choisie est déjà enregistrée.",
        { duration: 7000 },
      );
    } else {
      toast.info(
        "Installation annulée — la version choisie est tout de même enregistrée sur votre compte.",
      );
    }
  };

  /* ---- données dérivées ---- */

  const filteredUsers = useMemo(() => {
    if (!users) return null;
    const query = search.trim().toLowerCase();
    if (!query) return users;
    return users.filter(
      (user) =>
        user.username.toLowerCase().includes(query) ||
        user.email.toLowerCase().includes(query) ||
        (user.name ?? "").toLowerCase().includes(query),
    );
  }, [users, search]);

  const dhikrChart = useMemo(
    () =>
      (overview?.dhikr7d ?? []).map((day) => ({
        value: day.count,
        label: weekdayFmt.format(new Date(`${day.date}T12:00:00`)).replace(".", ""),
        hint: `${day.date} — ${day.count} dhikr${day.count > 1 ? "s" : ""}`,
      })),
    [overview],
  );
  const focusChart = useMemo(
    () =>
      (overview?.focus7d ?? []).map((day) => ({
        value: day.minutes,
        label: weekdayFmt.format(new Date(`${day.date}T12:00:00`)).replace(".", ""),
        hint: `${day.date} — ${day.sessions} session${day.sessions > 1 ? "s" : ""} · ${day.minutes} min`,
      })),
    [overview],
  );

  const kpis = overview?.kpis;

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="flex max-h-[92vh] w-[calc(100vw-1rem)] flex-col gap-0 overflow-hidden rounded-2xl border-white/10 bg-zinc-950 p-0 sm:max-w-6xl">
          <div
            aria-hidden="true"
            className="h-1 w-full shrink-0 bg-gradient-to-r from-amber-500 via-emerald-400 to-amber-400/80"
          />

          {/* ------- En-tête ------- */}
          <DialogHeader className="shrink-0 border-b border-white/5 px-4 py-4 sm:px-6">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="min-w-0">
                <DialogTitle className="flex flex-wrap items-center gap-2 text-lg font-extrabold text-zinc-100">
                  <span
                    aria-hidden="true"
                    className="grid size-9 place-items-center rounded-lg border border-amber-400/30 bg-amber-500/10"
                  >
                    <LayoutDashboard className="size-4 text-amber-400" />
                  </span>
                  Espace gérant
                  <Badge
                    variant="outline"
                    className="border-amber-400/30 bg-amber-500/10 text-[10px] font-bold text-amber-300"
                  >
                    {me?.username}
                  </Badge>
                </DialogTitle>
                <DialogDescription className="mt-1 text-[12.5px] text-zinc-400">
                  Données en ligne de la base Sakinah — comptes, dhikr et
                  sessions de focus.
                  {overview && (
                    <span className="ml-1 text-zinc-600">
                      Dernière synchro à {timeFmt.format(new Date(overview.generatedAt))}
                      .
                    </span>
                  )}
                </DialogDescription>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => void load()}
                disabled={loading}
                className="h-9 shrink-0 gap-2 rounded-full border-white/10 bg-white/5 text-zinc-300 hover:bg-white/10 hover:text-zinc-100"
              >
                <RefreshCw
                  className={cn("size-3.5", loading && "animate-spin")}
                  aria-hidden
                />
                Actualiser
              </Button>
            </div>
          </DialogHeader>

          {/* ------- Corps ------- */}
          <div className="min-h-0 flex-1 overflow-y-auto px-4 py-4 sm:px-6">
            {error && (
              <div className="rounded-xl border border-red-500/20 bg-red-500/10 p-4 text-center">
                <p className="text-[13px] font-semibold text-red-300">{error}</p>
                <div className="mt-3 flex flex-wrap items-center justify-center gap-2">
                  {sessionExpired && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        onOpenChange(false);
                        setLoginOpen(true);
                      }}
                      className="h-9 gap-2 rounded-full border-amber-400/30 text-amber-200 hover:bg-amber-500/10"
                    >
                      <LogIn className="size-3.5" aria-hidden />
                      Se reconnecter
                    </Button>
                  )}
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => void load()}
                    className="h-9 rounded-full border-red-400/30 text-red-200 hover:bg-red-500/10"
                  >
                    Réessayer
                  </Button>
                </div>
              </div>
            )}

            {!error && loading && !overview && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
                  {Array.from({ length: 4 }).map((_, index) => (
                    <Skeleton key={index} className="h-24 rounded-xl bg-white/5" />
                  ))}
                </div>
                <Skeleton className="h-40 rounded-xl bg-white/5" />
                <Skeleton className="h-40 rounded-xl bg-white/5" />
              </div>
            )}

            {!error && overview && (
              <Tabs value={tab} onValueChange={setTab}>
                <TabsList className="grid h-11 w-full max-w-2xl grid-cols-2 rounded-xl border border-white/5 bg-zinc-900/60 p-1 sm:grid-cols-4">
                  <TabsTrigger
                    value="overview"
                    className="gap-1.5 rounded-lg text-[12.5px] font-semibold text-zinc-400 data-[state=active]:bg-emerald-500/10 data-[state=active]:text-emerald-300"
                  >
                    Vue d&apos;ensemble
                  </TabsTrigger>
                  <TabsTrigger
                    value="users"
                    className="gap-1.5 rounded-lg text-[12.5px] font-semibold text-zinc-400 data-[state=active]:bg-emerald-500/10 data-[state=active]:text-emerald-300"
                  >
                    Utilisateurs
                  </TabsTrigger>
                  <TabsTrigger
                    value="activity"
                    className="gap-1.5 rounded-lg text-[12.5px] font-semibold text-zinc-400 data-[state=active]:bg-emerald-500/10 data-[state=active]:text-emerald-300"
                  >
                    Activité
                  </TabsTrigger>
                  <TabsTrigger
                    value="versions"
                    className="gap-1.5 rounded-lg text-[12.5px] font-semibold text-zinc-400 data-[state=active]:bg-emerald-500/10 data-[state=active]:text-emerald-300"
                  >
                    Versions
                  </TabsTrigger>
                </TabsList>

                {/* ================= Vue d'ensemble ================= */}
                <TabsContent value="overview" className="mt-4">
                  <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
                    <KpiCard
                      icon={Users}
                      label="Utilisateurs"
                      value={kpis?.users ?? 0}
                      sub={
                        (kpis?.newUsers7d ?? 0) > 0
                          ? `+${kpis?.newUsers7d} cette semaine`
                          : "aucun nouveau cette semaine"
                      }
                      tone="emerald"
                    />
                    <KpiCard
                      icon={UserCheck}
                      label="Actifs aujourd'hui"
                      value={kpis?.activeToday ?? 0}
                      sub="dhikr ou focus aujourd'hui"
                      tone="emerald"
                    />
                    <KpiCard
                      icon={Sparkles}
                      label="Dhikr aujourd'hui"
                      value={kpis?.dhikrToday ?? 0}
                      sub={`cumul total : ${kpis?.dhikrLifetime ?? 0}`}
                      tone="emerald"
                    />
                    <KpiCard
                      icon={Timer}
                      label="Sessions focus"
                      value={kpis?.focusSessions ?? 0}
                      sub={`${kpis?.focusMinutes ?? 0} min au total`}
                      tone="amber"
                    />
                  </div>

                  <div className="mt-4 grid grid-cols-1 gap-4 lg:grid-cols-2">
                    <section className="rounded-xl border border-white/5 bg-zinc-900/50 p-4">
                      <header className="mb-3 flex items-center justify-between">
                        <h3 className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-[0.16em] text-emerald-400">
                          <Sparkles className="size-3.5" aria-hidden />
                          Dhikr — 7 derniers jours
                        </h3>
                        <span className="text-[10px] text-zinc-600">
                          {dhikrChart.reduce((sum, d) => sum + d.value, 0)} cette
                          semaine
                        </span>
                      </header>
                      <WeekBars
                        values={dhikrChart.map((d) => d.value)}
                        labels={dhikrChart.map((d) => d.label)}
                        hints={dhikrChart.map((d) => d.hint)}
                        tone="emerald"
                      />
                    </section>
                    <section className="rounded-xl border border-white/5 bg-zinc-900/50 p-4">
                      <header className="mb-3 flex items-center justify-between">
                        <h3 className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-[0.16em] text-amber-400">
                          <Flame className="size-3.5" aria-hidden />
                          Focus — 7 derniers jours
                        </h3>
                        <span className="text-[10px] text-zinc-600">
                          minutes par jour
                        </span>
                      </header>
                      <WeekBars
                        values={focusChart.map((d) => d.value)}
                        labels={focusChart.map((d) => d.label)}
                        hints={focusChart.map((d) => d.hint)}
                        tone="amber"
                      />
                    </section>
                  </div>

                  {/* Activités récentes (aperçu) */}
                  <section className="mt-4 rounded-xl border border-white/5 bg-zinc-900/50 p-4">
                    <header className="mb-2 flex items-center justify-between">
                      <h3 className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-[0.16em] text-zinc-400">
                        <Activity className="size-3.5" aria-hidden />
                        Activité récente
                      </h3>
                      <button
                        type="button"
                        onClick={() => setTab("activity")}
                        className="rounded-md text-[11px] font-semibold text-emerald-400 transition-colors hover:text-emerald-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400/60"
                      >
                        Tout voir →
                      </button>
                    </header>
                    <ActivityList items={overview.activity.slice(0, 5)} />
                  </section>
                </TabsContent>

                {/* ================= Utilisateurs ================= */}
                <TabsContent value="users" className="mt-4">
                  <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
                    <div className="relative min-w-0 flex-1 sm:max-w-xs">
                      <Search
                        className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-zinc-600"
                        aria-hidden
                      />
                      <Input
                        value={search}
                        onChange={(event) => setSearch(event.target.value)}
                        placeholder="Rechercher un compte…"
                        aria-label="Rechercher un utilisateur"
                        className="h-10 border-white/10 bg-zinc-900/60 pl-9 text-[13px] text-zinc-100 placeholder:text-zinc-600 focus-visible:ring-emerald-400/50"
                      />
                    </div>
                    <p className="flex items-center gap-1.5 text-[11px] text-zinc-600">
                      <ArrowUpDown className="size-3" aria-hidden />
                      gérants d&apos;abord, puis inscription
                    </p>
                  </div>

                  {!filteredUsers && (
                    <Skeleton className="h-64 rounded-xl bg-white/5" />
                  )}
                  {filteredUsers && filteredUsers.length === 0 && (
                    <p className="rounded-xl border border-white/5 bg-zinc-900/50 p-6 text-center text-[13px] text-zinc-500">
                      Aucun compte ne correspond à « {search} ».
                    </p>
                  )}

                  {filteredUsers && filteredUsers.length > 0 && (
                    <div className="overflow-x-auto rounded-xl border border-white/5 bg-zinc-900/50">
                      <Table className="min-w-[760px]">
                        <TableHeader>
                          <TableRow className="border-white/5 hover:bg-transparent">
                            <TableHead className="pl-4 text-[10.5px] font-bold uppercase tracking-wider text-zinc-500">
                              Utilisateur
                            </TableHead>
                            <TableHead className="text-[10.5px] font-bold uppercase tracking-wider text-zinc-500">
                              Rôle
                            </TableHead>
                            <TableHead className="text-[10.5px] font-bold uppercase tracking-wider text-zinc-500">
                              Inscription
                            </TableHead>
                            <TableHead className="text-[10.5px] font-bold uppercase tracking-wider text-zinc-500">
                              Dernière connexion
                            </TableHead>
                            <TableHead className="text-right text-[10.5px] font-bold uppercase tracking-wider text-zinc-500">
                              Dhikr (jour · cumul)
                            </TableHead>
                            <TableHead className="text-right text-[10.5px] font-bold uppercase tracking-wider text-zinc-500">
                              Focus
                            </TableHead>
                            <TableHead className="w-12 pr-3" aria-label="Actions" />
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {filteredUsers.map((user) => {
                            const self = user.id === me?.id;
                            const isManager = user.role === "MANAGER";
                            return (
                              <TableRow
                                key={user.id}
                                className={cn(
                                  "border-white/5",
                                  busyUserId === user.id && "opacity-50",
                                )}
                              >
                                <TableCell className="py-3 pl-4">
                                  <div className="flex items-center gap-2.5">
                                    <span
                                      aria-hidden="true"
                                      className={cn(
                                        "grid size-9 shrink-0 place-items-center rounded-full border text-[11px] font-extrabold uppercase",
                                        isManager
                                          ? "border-amber-400/40 bg-amber-500/10 text-amber-300"
                                          : "border-white/10 bg-white/5 text-zinc-400",
                                      )}
                                    >
                                      {initialsOf(user.username)}
                                    </span>
                                    <div className="min-w-0">
                                      <p className="flex items-center gap-1.5 truncate text-[13px] font-bold text-zinc-100">
                                        {user.username}
                                        {self && (
                                          <span className="text-[10px] font-medium text-emerald-400">
                                            (vous)
                                          </span>
                                        )}
                                      </p>
                                      <p className="truncate text-[11px] text-zinc-500">
                                        {user.email}
                                      </p>
                                    </div>
                                  </div>
                                </TableCell>
                                <TableCell>
                                  <Badge
                                    variant="outline"
                                    className={
                                      isManager
                                        ? "border-amber-400/30 bg-amber-500/10 text-[10px] font-bold text-amber-300"
                                        : "border-emerald-500/25 bg-emerald-500/10 text-[10px] font-bold text-emerald-300"
                                    }
                                  >
                                    {isManager ? "Gérant" : "Membre"}
                                  </Badge>
                                </TableCell>
                                <TableCell>
                                  <span className="flex items-center gap-1.5 text-[12px] text-zinc-400">
                                    <CalendarDays
                                      className="size-3.5 text-zinc-600"
                                      aria-hidden
                                    />
                                    {dateFmt.format(new Date(user.createdAt))}
                                  </span>
                                </TableCell>
                                <TableCell>
                                  <span className="text-[12px] text-zinc-400">
                                    {user.lastLoginAt
                                      ? timeAgo(user.lastLoginAt)
                                      : "jamais"}
                                  </span>
                                </TableCell>
                                <TableCell className="text-right font-mono text-[12px] tabular-nums text-zinc-300">
                                  <span className="text-emerald-300">
                                    {user.dhikrToday}
                                  </span>
                                  <span className="text-zinc-600"> · </span>
                                  {user.dhikrLifetime}
                                </TableCell>
                                <TableCell className="text-right text-[12px] text-zinc-300">
                                  <span className="font-mono tabular-nums text-amber-300">
                                    {user.focusSessions}
                                  </span>
                                  <span className="text-zinc-600">
                                    {" "}
                                    · {user.focusMinutes} min
                                  </span>
                                </TableCell>
                                <TableCell className="pr-2">
                                  <DropdownMenu>
                                    <DropdownMenuTrigger
                                      aria-label={`Actions pour ${user.username}`}
                                      disabled={self || busyUserId === user.id}
                                      className="grid size-9 place-items-center rounded-lg text-zinc-500 outline-none transition-colors hover:bg-white/5 hover:text-zinc-200 focus-visible:ring-2 focus-visible:ring-emerald-400/60 disabled:opacity-30 data-[state=open]:bg-white/5"
                                    >
                                      <MoreHorizontal
                                        className="size-4"
                                        aria-hidden
                                      />
                                    </DropdownMenuTrigger>
                                    <DropdownMenuContent
                                      align="end"
                                      sideOffset={6}
                                      className="w-52 rounded-xl border-white/10 bg-zinc-950/98 p-1.5 text-zinc-200"
                                    >
                                      <DropdownMenuItem
                                        onSelect={() => void changeRole(user)}
                                        className="min-h-9 cursor-pointer gap-2 rounded-lg px-2.5 text-[12.5px] font-medium outline-none data-[highlighted]:bg-emerald-500/10 data-[highlighted]:text-emerald-200"
                                      >
                                        <ShieldCheck
                                          className="size-4 text-emerald-400"
                                          aria-hidden
                                        />
                                        {isManager
                                          ? "Rétrograder en membre"
                                          : "Promouvoir gérant"}
                                      </DropdownMenuItem>
                                      <DropdownMenuSeparator className="bg-white/5" />
                                      <DropdownMenuItem
                                        onSelect={() => setPendingDelete(user)}
                                        className="min-h-9 cursor-pointer gap-2 rounded-lg px-2.5 text-[12.5px] font-medium text-red-300 outline-none data-[highlighted]:bg-red-500/10 data-[highlighted]:text-red-200"
                                      >
                                        <Trash2
                                          className="size-4 text-red-400"
                                          aria-hidden
                                        />
                                        Supprimer le compte
                                      </DropdownMenuItem>
                                    </DropdownMenuContent>
                                  </DropdownMenu>
                                </TableCell>
                              </TableRow>
                            );
                          })}
                        </TableBody>
                      </Table>
                    </div>
                  )}
                </TabsContent>

                {/* ================= Activité ================= */}
                <TabsContent value="activity" className="mt-4">
                  <section className="rounded-xl border border-white/5 bg-zinc-900/50 p-4">
                    <h3 className="mb-3 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-[0.16em] text-zinc-400">
                      <Activity className="size-3.5" aria-hidden />
                      Journal — 15 derniers événements
                    </h3>
                    {overview.activity.length === 0 ? (
                      <p className="py-6 text-center text-[13px] text-zinc-500">
                        Aucune activité pour l&apos;instant.
                      </p>
                    ) : (
                      <ActivityList items={overview.activity} />
                    )}
                  </section>
                </TabsContent>

                {/* ================= Versions ================= */}
                <TabsContent value="versions" className="mt-4">
                  <p className="max-w-2xl text-[13px] leading-relaxed text-zinc-400">
                    Votre compte gérant peut utiliser — et installer — les{" "}
                    <strong className="font-semibold text-zinc-200">
                      deux versions
                    </strong>{" "}
                    de la démo. La préférence est enregistrée{" "}
                    <strong className="font-semibold text-zinc-200">
                      en ligne
                    </strong>{" "}
                    : elle suit votre compte sur tous vos appareils et dans la
                    web-app installée.
                  </p>

                  <div className="mt-4 grid grid-cols-1 gap-4 lg:grid-cols-2">
                    {/* ---- Version complète ---- */}
                    <section
                      className={cn(
                        "relative flex flex-col rounded-xl border p-4 transition-colors sm:p-5",
                        me?.focusEnabled
                          ? "border-rose-400/30 bg-gradient-to-b from-rose-500/[0.07] to-transparent"
                          : "border-white/5 bg-zinc-900/50",
                      )}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <span
                          aria-hidden="true"
                          className="grid size-10 shrink-0 place-items-center rounded-lg border border-rose-400/25 bg-rose-500/10"
                        >
                          <Timer className="size-4.5 text-rose-400" aria-hidden />
                        </span>
                        {me?.focusEnabled ? (
                          <Badge
                            variant="outline"
                            className="shrink-0 border-rose-400/30 bg-rose-500/10 text-[10px] font-bold text-rose-300"
                          >
                            Version active
                          </Badge>
                        ) : null}
                      </div>
                      <h3 className="mt-3 text-[15px] font-bold text-zinc-100">
                        Version complète
                      </h3>
                      <p className="text-[11px] font-medium uppercase tracking-wider text-rose-300/80">
                        Avec le Mode Focus
                      </p>
                      <ul className="mt-3 flex-1 space-y-1.5 text-[12.5px] leading-relaxed text-zinc-400">
                        <li className="flex gap-2">
                          <span className="mt-[7px] size-1 shrink-0 rounded-full bg-rose-400/60" />
                          Onglet « Mode Focus — Pomodoro » dans la pop-up
                        </li>
                        <li className="flex gap-2">
                          <span className="mt-[7px] size-1 shrink-0 rounded-full bg-rose-400/60" />
                          Sessions 15 / 25 / 50 min, pause, ambiance sonore
                        </li>
                        <li className="flex gap-2">
                          <span className="mt-[7px] size-1 shrink-0 rounded-full bg-rose-400/60" />
                          Historique 7 jours et statistiques de concentration
                        </li>
                        <li className="flex gap-2">
                          <span className="mt-[7px] size-1 shrink-0 rounded-full bg-rose-400/60" />
                          Tout le contenu de la version prières, évidemment
                        </li>
                      </ul>
                      <div className="mt-4 flex flex-wrap gap-2">
                        <Button
                          size="sm"
                          disabled={me?.focusEnabled || versionBusy}
                          onClick={() => void switchVersion(true)}
                          className="h-9 rounded-full border border-rose-400/30 bg-rose-500/15 px-4 text-[12px] font-semibold text-rose-200 hover:bg-rose-500/25 disabled:opacity-50"
                        >
                          {me?.focusEnabled ? "Active" : "Utiliser cette version"}
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          disabled={versionBusy}
                          onClick={() => void installVersion(true)}
                          className="h-9 gap-2 rounded-full border-white/10 bg-white/5 px-4 text-[12px] font-semibold text-zinc-300 hover:bg-white/10 hover:text-zinc-100"
                        >
                          <MonitorDown className="size-3.5" aria-hidden />
                          {pwa.installed ? "Déjà installée" : "Installer"}
                        </Button>
                      </div>
                    </section>

                    {/* ---- Version prières ---- */}
                    <section
                      className={cn(
                        "relative flex flex-col rounded-xl border p-4 transition-colors sm:p-5",
                        !me?.focusEnabled
                          ? "border-emerald-400/30 bg-gradient-to-b from-emerald-500/[0.07] to-transparent"
                          : "border-white/5 bg-zinc-900/50",
                      )}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <span
                          aria-hidden="true"
                          className="grid size-10 shrink-0 place-items-center rounded-lg border border-emerald-400/25 bg-emerald-500/10"
                        >
                          <MoonStar className="size-4.5 text-emerald-400" aria-hidden />
                        </span>
                        {!me?.focusEnabled ? (
                          <Badge
                            variant="outline"
                            className="shrink-0 border-emerald-400/30 bg-emerald-500/10 text-[10px] font-bold text-emerald-300"
                          >
                            Version active
                          </Badge>
                        ) : null}
                      </div>
                      <h3 className="mt-3 text-[15px] font-bold text-zinc-100">
                        Version prières
                      </h3>
                      <p className="text-[11px] font-medium uppercase tracking-wider text-emerald-300/80">
                        Sans Mode Focus
                      </p>
                      <ul className="mt-3 flex-1 space-y-1.5 text-[12.5px] leading-relaxed text-zinc-400">
                        <li className="flex gap-2">
                          <span className="mt-[7px] size-1 shrink-0 rounded-full bg-emerald-400/60" />
                          Pop-up recentrée sur les informations de prière
                        </li>
                        <li className="flex gap-2">
                          <span className="mt-[7px] size-1 shrink-0 rounded-full bg-emerald-400/60" />
                          Horaires Mawaqit, calendrier, Qibla, Tasbih, Ramadan
                        </li>
                        <li className="flex gap-2">
                          <span className="mt-[7px] size-1 shrink-0 rounded-full bg-emerald-400/60" />
                          L&apos;onglet et les réglages du Mode Focus disparaissent
                        </li>
                        <li className="flex gap-2">
                          <span className="mt-[7px] size-1 shrink-0 rounded-full bg-emerald-400/60" />
                          C&apos;est la version que voient vos membres
                        </li>
                      </ul>
                      <div className="mt-4 flex flex-wrap gap-2">
                        <Button
                          size="sm"
                          disabled={!me?.focusEnabled || versionBusy}
                          onClick={() => void switchVersion(false)}
                          className="h-9 rounded-full border border-emerald-400/30 bg-emerald-500/15 px-4 text-[12px] font-semibold text-emerald-200 hover:bg-emerald-500/25 disabled:opacity-50"
                        >
                          {!me?.focusEnabled ? "Active" : "Utiliser cette version"}
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          disabled={versionBusy}
                          onClick={() => void installVersion(false)}
                          className="h-9 gap-2 rounded-full border-white/10 bg-white/5 px-4 text-[12px] font-semibold text-zinc-300 hover:bg-white/10 hover:text-zinc-100"
                        >
                          <MonitorDown className="size-3.5" aria-hidden />
                          {pwa.installed ? "Déjà installée" : "Installer"}
                        </Button>
                      </div>
                    </section>
                  </div>

                  <p className="mt-4 max-w-2xl text-[11.5px] leading-relaxed text-zinc-600">
                    Astuce : basculez en un clic depuis le menu de votre avatar
                    (en haut à droite) — « Version : complète / prières ».
                    L&apos;installation installe la même web-app ; c&apos;est la
                    version choisie ici qui s&apos;affiche à l&apos;ouverture.
                  </p>

                  {/* ---- Mettre le site en ligne (GitHub + Vercel) ---- */}
                  <section className="mt-5 rounded-xl border border-emerald-400/20 bg-gradient-to-b from-emerald-500/[0.06] to-transparent p-4 sm:p-5">
                    <div className="flex items-start gap-3">
                      <span
                        aria-hidden="true"
                        className="grid size-10 shrink-0 place-items-center rounded-lg border border-emerald-400/25 bg-emerald-500/10"
                      >
                        <Github className="size-4.5 text-emerald-400" aria-hidden />
                      </span>
                      <div className="min-w-0 flex-1">
                        <h3 className="text-[15px] font-bold text-zinc-100">
                          Mettre le site en ligne — GitHub + Vercel
                        </h3>
                        <p className="mt-1 text-[12.5px] leading-relaxed text-zinc-400">
                          Le paquet source ci-dessous contient exactement ce
                          qu&apos;il faut publier sur GitHub — code complet,
                          README, guide de déploiement pas à pas et licence
                          MIT. <strong className="font-semibold text-zinc-200">Aucun mot de passe ni donnée privée</strong> :
                          les fichiers .env et les bases restent chez vous.
                        </p>
                        <ol className="mt-3 space-y-1.5 text-[12.5px] leading-relaxed text-zinc-400">
                          <li className="flex gap-2">
                            <span className="mt-0.5 grid size-4.5 shrink-0 place-items-center rounded-full border border-emerald-400/30 bg-emerald-500/10 text-[10px] font-bold text-emerald-300">1</span>
                            Téléchargez le paquet source et décompressez-le
                          </li>
                          <li className="flex gap-2">
                            <span className="mt-0.5 grid size-4.5 shrink-0 place-items-center rounded-full border border-emerald-400/30 bg-emerald-500/10 text-[10px] font-bold text-emerald-300">2</span>
                            Créez un dépôt GitHub public et glissez-y le contenu du paquet
                          </li>
                          <li className="flex gap-2">
                            <span className="mt-0.5 grid size-4.5 shrink-0 place-items-center rounded-full border border-emerald-400/30 bg-emerald-500/10 text-[10px] font-bold text-emerald-300">3</span>
                            Créez une base PostgreSQL gratuite (Neon) et copiez son URL
                          </li>
                          <li className="flex gap-2">
                            <span className="mt-0.5 grid size-4.5 shrink-0 place-items-center rounded-full border border-emerald-400/30 bg-emerald-500/10 text-[10px] font-bold text-emerald-300">4</span>
                            Importez le dépôt dans Vercel avec la variable DATABASE_URL — le site est en ligne
                          </li>
                        </ol>
                        <p className="mt-3 text-[11.5px] leading-relaxed text-zinc-500">
                          Le détail de chaque étape (captures, noms exacts des
                          boutons, création du compte gérant) est dans le
                          fichier <code className="rounded bg-white/5 px-1 py-0.5 text-[11px] text-emerald-300">GUIDE-DEPLOIEMENT.md</code> inclus dans le paquet.
                        </p>
                        <div className="mt-4">
                          <Button
                            size="sm"
                            onClick={() =>
                              window.location.assign("/api/manager/source")
                            }
                            className="h-9 gap-2 rounded-full border border-emerald-400/30 bg-emerald-500/15 px-4 text-[12px] font-semibold text-emerald-200 hover:bg-emerald-500/25"
                          >
                            <Download className="size-3.5" aria-hidden />
                            Télécharger le paquet source (.zip)
                          </Button>
                        </div>
                      </div>
                    </div>
                  </section>
                </TabsContent>
              </Tabs>
            )}
          </div>

          {/* ------- Pied ------- */}
          <footer className="shrink-0 border-t border-white/5 px-4 py-2.5 sm:px-6">
            <p className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[10.5px] text-zinc-600">
              <span className="inline-flex items-center gap-1">
                <CloudCog className="size-3" aria-hidden />
                Base en ligne (PostgreSQL) —
              </span>
              <span className="tabular-nums">
                {users?.length ?? 0} comptes · {kpis?.focusSessions ?? 0} sessions
                de focus
              </span>
              <span className="text-zinc-700">
                · les suppressions sont définitives
              </span>
            </p>
          </footer>
        </DialogContent>
      </Dialog>

      {/* Confirmation de suppression */}
      <AlertDialog
        open={pendingDelete !== null}
        onOpenChange={(open) => !open && setPendingDelete(null)}
      >
        <AlertDialogContent className="max-w-[calc(100vw-2rem)] rounded-xl border-white/10 bg-zinc-950 sm:max-w-md">
          <AlertDialogHeader className="text-left">
            <AlertDialogTitle className="text-base font-bold text-zinc-100">
              Supprimer le compte {pendingDelete?.username} ?
            </AlertDialogTitle>
            <AlertDialogDescription className="text-[13px] leading-relaxed text-zinc-400">
              Ses données seront également supprimées : sessions de connexion,
              dhikr ({pendingDelete?.dhikrLifetime ?? 0} au cumul) et sessions
              de focus ({pendingDelete?.focusSessions ?? 0}). Cette action est
              immédiate et irréversible.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="gap-2">
            <AlertDialogCancel className="h-9 rounded-full border-white/10 bg-transparent px-4 text-zinc-300 hover:bg-white/5 hover:text-zinc-100">
              Annuler
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => void deleteUser()}
              className="h-9 rounded-full border border-red-500/40 bg-red-500/20 px-4 text-[13px] font-semibold text-red-200 transition-colors hover:bg-red-500/30 focus-visible:ring-2 focus-visible:ring-red-400/60"
            >
              Supprimer
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

/* ------------------------------------------------------------------ */
/* Sous-composants                                                     */
/* ------------------------------------------------------------------ */

function KpiCard({
  icon: Icon,
  label,
  value,
  sub,
  tone,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: number;
  sub: string;
  tone: "emerald" | "amber";
}) {
  return (
    <div className="rounded-xl border border-white/5 bg-zinc-900/50 p-3.5">
      <p
        className={cn(
          "flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-[0.14em]",
          tone === "emerald" ? "text-emerald-400" : "text-amber-400",
        )}
      >
        <Icon className="size-3.5" aria-hidden />
        {label}
      </p>
      <p className="mt-1.5 font-mono text-2xl font-extrabold tabular-nums leading-none text-zinc-100">
        {value.toLocaleString("fr-FR")}
      </p>
      <p className="mt-1.5 truncate text-[10.5px] text-zinc-600" title={sub}>
        {sub}
      </p>
    </div>
  );
}

function ActivityList({
  items,
}: {
  items: OverviewData["activity"];
}) {
  return (
    <ul className="divide-y divide-white/5">
      {items.map((item) => {
        const config = ACTIVITY_ICONS[item.type] ?? {
          icon: Activity,
          className: "text-zinc-400 bg-white/5",
        };
        const Icon = config.icon;
        return (
          <li key={item.id} className="flex items-center gap-3 py-2.5">
            <span
              aria-hidden="true"
              className={cn(
                "grid size-8 shrink-0 place-items-center rounded-lg",
                config.className,
              )}
            >
              <Icon className="size-3.5" />
            </span>
            <p className="min-w-0 flex-1 truncate text-[12.5px] text-zinc-300">
              {item.detail}
            </p>
            <span className="shrink-0 text-[10.5px] tabular-nums text-zinc-600">
              {timeAgo(item.createdAt)}
            </span>
          </li>
        );
      })}
    </ul>
  );
}
