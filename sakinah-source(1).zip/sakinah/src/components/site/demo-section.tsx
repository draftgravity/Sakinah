/**
 * DemoSection — guide de la démo interactive : le carré noir réel est déjà
 * monté en haut à droite de la page (via <SakinahDemo /> dans page.tsx).
 * Les boutons pilotent le store zustand partagé avec la démo.
 */

"use client";

import { motion } from "framer-motion";
import {
  ArrowUpRight,
  BellRing,
  CalendarArrowDown,
  CalendarClock,
  CalendarDays,
  Check,
  CloudOff,
  Compass,
  Copy,
  Flame,
  GitCompareArrows,
  Hourglass,
  Keyboard,
  LocateFixed,
  Moon,
  MoonStar,
  MousePointerClick,
  ShieldCheck,
  Sparkles,
  Square,
  Timer,
  Users,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { SectionHeading } from "./section-heading";
import { useDemoStore } from "@/lib/demo-store";
import { useAuthStore } from "@/lib/auth-store";

const PARITY_ITEMS = [
  {
    icon: MoonStar,
    label: "Mêmes horaires Mawaqit en direct",
    detail: "même mosquée, mêmes 6 horaires, même Jumu'a",
  },
  {
    icon: Hourglass,
    label: "Même compte à rebours",
    detail: "prochaine prière surlignée, décompte seconde par seconde",
  },
  {
    icon: BellRing,
    label: "Mêmes rappels avant chaque prière",
    detail: "notification 15 min avant + à l'heure, directement dans le navigateur",
  },
  {
    icon: Compass,
    label: "Boussole Qibla exacte",
    detail: "cap et distance depuis votre mosquée — ou depuis votre position (géolocalisation)",
  },
  {
    icon: CalendarDays,
    label: "Calendrier mensuel dépliable",
    detail: "les 12 mois, vendredis repérés — adhan, iqama ou les deux, détail du jour au clic",
  },
  {
    icon: MousePointerClick,
    label: "Détail de chaque jour",
    detail: "un clic sur une date : adhan + iqama, dates grégorienne et hégirienne",
  },
  {
    icon: LocateFixed,
    label: "Mosquées autour de vous",
    detail: "recherche triée par distance réelle, badges « à X km »",
  },
  {
    icon: Copy,
    label: "Copie des horaires",
    detail: "les horaires du jour en presse-papiers, prêts à partager",
  },
  {
    icon: Users,
    label: "Iqama de chaque prière",
    detail: "début de la prière en commun : du jour ET du calendrier annuel",
  },
  {
    icon: CalendarClock,
    label: "Compte à rebours Jumu'a",
    detail: "prochaine prière du vendredi, jour par jour",
  },
  {
    icon: Flame,
    label: "Régularité du dhikr",
    detail: "série de jours consécutifs et mini-graphique des 7 derniers jours",
  },
  {
    icon: Moon,
    label: "Compte à rebours du Ramadan",
    detail: "calendrier hégirien (umalqura) : « jour N » pendant le mois sacré, « dans X jours » sinon",
  },
  {
    icon: ShieldCheck,
    label: "Comptes & données en ligne",
    detail: "connexion identifiant ou e-mail — vos dhikr et statistiques suivent le compte, pas l'appareil",
  },
  {
    icon: Sparkles,
    label: "Mêmes dhikrs",
    detail: "les 12 dhikrs de data/dhikrs.json, tirés au hasard",
  },
  {
    icon: GitCompareArrows,
    label: "Comparaison de mosquées",
    detail: "adhans du jour côte à côte, écarts en minutes — mémorisée entre les visites",
  },
  {
    icon: CalendarArrowDown,
    label: "Export calendrier .ics",
    detail: "le mois complet importable dans Google Agenda, Outlook, Apple Calendrier",
  },
  {
    icon: CloudOff,
    label: "Reprise hors ligne",
    detail: "horaires et calendrier en cache local — exacts même après minuit sans réseau",
  },
];

export function DemoSection() {
  const openPopup = useDemoStore((s) => s.openPopup);
  const toggleWidget = useDemoStore((s) => s.toggleWidget);
  const startFocus = useDemoStore((s) => s.startFocus);
  // Le bouton de démo Focus n’est proposé qu’au compte GÉRANT en version
  // complète (préférence en ligne) : la présentation publique, elle, se
  // recentre sur les informations de prière — aucun bouton Focus n’y apparaît.
  const isManager = useAuthStore(
    (state) => state.user?.role === "MANAGER" && state.user.focusEnabled,
  );
  const widgetVisible = useDemoStore((s) => s.widgetVisible);
  const focusActive = useDemoStore((s) => s.focusActive);

  return (
    <section
      id="demo"
      aria-labelledby="demo-title"
      className="relative scroll-mt-24 border-y border-white/5 bg-gradient-to-b from-emerald-500/[0.04] to-transparent py-16 sm:py-20 lg:py-24"
    >
      <div className="mx-auto w-full max-w-6xl px-4 sm:px-6">
        <SectionHeading
          eyebrow="Démo interactive"
          title="Essayez-le. Il est déjà sur cette page."
          description="Le carré noir en haut à droite de votre écran n'est pas une image : c'est la démo réelle. Cliquez pour ouvrir la pop-up, glissez-le, changez de mosquée — les données Mawaqit sont en direct, et un compte (bouton « Se connecter ») garde vos statistiques en ligne."
        />

        <div className="grid items-start gap-6 lg:grid-cols-[1.1fr_0.9fr]">
          {/* -------------------------------------------------- panneau actions */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.55, ease: [0.21, 0.47, 0.32, 0.98] }}
            className="rounded-2xl border border-emerald-500/15 bg-zinc-900/60 p-5 sm:p-7"
          >
            {/* indice vers le coin haut-droit */}
            <div className="mb-6 flex items-start gap-4">
              <div
                aria-hidden="true"
                className="relative mt-1 h-20 w-28 shrink-0 overflow-hidden rounded-lg border border-white/10 bg-zinc-950/80 dot-grid"
              >
                <span className="absolute right-2 top-2 flex size-7 items-center justify-center rounded-md border border-white/10 bg-[#0a0a0b]">
                  <Square className="size-3 text-emerald-400" />
                </span>
                <motion.span
                  animate={{ opacity: [0.15, 0.5, 0.15] }}
                  transition={{ duration: 2.2, repeat: Infinity, ease: "easeInOut" }}
                  className="absolute right-0 top-0 size-14 rounded-bl-[28px] bg-emerald-400/20"
                />
              </div>
              <div>
                <p className="flex items-center gap-1.5 text-sm font-semibold text-zinc-100">
                  Regardez en haut à droite
                  <ArrowUpRight className="size-4 text-emerald-400" aria-hidden="true" />
                </p>
                <p className="mt-1 text-sm leading-relaxed text-zinc-400">
                  Le carré noir de Sakinah vit déjà sur cette page. Un clic
                  (gauche ou droit) ouvre la pop-up — l&apos;onglet{" "}
                  <span className="text-emerald-300">Prières</span> avec
                  rappels navigateur, boussole Qibla (mosquée ou votre
                  position), calendrier mensuel (adhan + iqama, détail du jour
                  au clic, export .ics), comparaison de mosquées, recherche
                  triée par distance autour de vous, compteur de Tasbih (avec
                  statistiques exportables en CSV et série de régularité),
                  compte à rebours du Ramadan — et l&apos;icône ⚙︎ ouvre les
                  paramètres. Créez un compte pour que vos dhikr et
                  statistiques vous suivent d&apos;un appareil à l&apos;autre.
                </p>
              </div>
            </div>

            {/* boutons d'action */}
            <div className="flex flex-col gap-3">
              <Button
                type="button"
                size="lg"
                onClick={() => openPopup("prayers")}
                className="h-12 w-full justify-start border border-emerald-400/25 bg-emerald-500/90 text-left font-semibold text-zinc-950 hover:bg-emerald-400 sm:w-auto sm:justify-center"
              >
                <MousePointerClick className="size-4.5" aria-hidden="true" />
                Ouvrir la pop-up
              </Button>

              <Button
                type="button"
                size="lg"
                variant="outline"
                onClick={() => toggleWidget()}
                className="h-12 w-full justify-start border-white/15 bg-transparent text-left font-medium text-zinc-200 hover:bg-white/5 hover:text-zinc-100 sm:w-auto sm:justify-center"
                aria-label={
                  widgetVisible
                    ? "Masquer le carré noir de la démonstration"
                    : "Afficher le carré noir de la démonstration"
                }
              >
                <Square className="size-4.5 text-emerald-400" aria-hidden="true" />
                {widgetVisible ? "Masquer le widget" : "Afficher le widget"}{" "}
                <kbd className="rounded border border-white/10 bg-white/5 px-1.5 py-0.5 font-mono text-[11px] text-zinc-400">
                  H
                </kbd>
              </Button>

              {isManager && (
                <Button
                  type="button"
                  size="lg"
                  variant="outline"
                  onClick={() => startFocus(25, "rain", 0.6)}
                  disabled={focusActive}
                  title="Lancer une session de démonstration de 25 secondes"
                  className="h-12 w-full justify-start border-amber-400/25 bg-amber-400/[0.06] text-left font-medium text-amber-200 hover:bg-amber-400/15 hover:text-amber-100 disabled:opacity-60 sm:w-auto sm:justify-center"
                >
                  <Timer className="size-4.5" aria-hidden="true" />
                  {focusActive
                    ? "Session en cours…"
                    : "Lancer un focus démo — 25 s"}
                </Button>
              )}
            </div>

            {/* rappels clavier */}
            <ul className="mt-6 flex flex-wrap gap-x-5 gap-y-2 text-xs text-zinc-500">
              <li className="flex items-center gap-1.5">
                <Keyboard className="size-3.5 text-zinc-400" aria-hidden="true" />
                Fonctionne au clavier : <span className="font-mono text-zinc-300">H</span>{" "}
                ou <span className="font-mono text-zinc-300">Ctrl+Alt+H</span>
              </li>
              <li className="flex items-center gap-1.5">
                <kbd className="rounded border border-white/10 bg-white/5 px-1.5 py-0.5 font-mono text-[10px] text-zinc-300">
                  Échap
                </kbd>
                ferme la pop-up
              </li>
            </ul>
          </motion.div>

          {/* -------------------------------------------------- carte parité */}
          <motion.aside
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.55, delay: 0.12, ease: [0.21, 0.47, 0.32, 0.98] }}
            aria-labelledby="parity-title"
            className="rounded-2xl border border-white/5 bg-zinc-900/60 p-5 sm:p-7"
          >
            <h3
              id="parity-title"
              className="flex flex-wrap items-center gap-2.5 text-base font-bold tracking-tight text-zinc-100"
            >
              Parité web / application
              <span className="rounded-full border border-emerald-500/30 bg-emerald-500/10 px-2 py-0.5 text-[11px] font-semibold text-emerald-300">
                {PARITY_ITEMS.length} points
              </span>
            </h3>
            <p className="mt-1 text-xs text-zinc-500 sm:text-sm">
              Cette page est une réplique fidèle de l'application Windows :
            </p>
            <ul className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-1 xl:grid-cols-2">
              {PARITY_ITEMS.map((item) => (
                <li key={item.label} className="flex items-start gap-3">
                  <span
                    aria-hidden="true"
                    className="mt-0.5 flex size-6 shrink-0 items-center justify-center rounded-md border border-emerald-500/20 bg-emerald-500/10"
                  >
                    <item.icon className="size-3.5 text-emerald-400" />
                  </span>
                  <div>
                    <p className="flex items-center gap-1.5 text-sm font-medium text-zinc-200">
                      <Check
                        className="size-3.5 shrink-0 text-emerald-400"
                        aria-hidden="true"
                      />
                      {item.label}
                    </p>
                    <p className="text-xs text-zinc-500">{item.detail}</p>
                  </div>
                </li>
              ))}
            </ul>
          </motion.aside>
        </div>
      </div>
    </section>
  );
}
