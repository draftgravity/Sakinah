/**
 * FadeIn — enveloppe d'animation framer-motion : apparition douce (fondu +
 * translation vers le haut) when the element entre dans le viewport.
 * Utilisé par toutes les sections de la page vitrine.
 */

"use client";

import { motion } from "framer-motion";
import type { ReactNode } from "react";

interface FadeInProps {
  children: ReactNode;
  /** délai en secondes (pour décaler les cartes d'une même grille) */
  delay?: number;
  className?: string;
  /** translation verticale initiale en px */
  y?: number;
}

export function FadeIn({ children, delay = 0, className, y = 24 }: FadeInProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.55, delay, ease: [0.21, 0.47, 0.32, 0.98] }}
      className={className}
    >
      {children}
    </motion.div>
  );
}
