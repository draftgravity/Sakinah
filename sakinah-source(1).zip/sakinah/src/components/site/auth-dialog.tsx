/**
 * AuthDialog — connexion / inscription (dialogue unique de la page).
 *
 * * Onglet « Se connecter » : UN champ « identifiant ou e-mail » + mot de
 *   passe (le serveur accepte les deux, insensible à la casse) ;
 * * Onglet « Créer un compte » : nom d'utilisateur, e-mail, nom affiché
 *   (facultatif), mot de passe — les comptes créés sont des MEMBRES
 *   (version prières) ; seul le gérant promeut ;
 * * erreurs du serveur affichées en rouge sous le formulaire, mot de
 *   passe masquable (œil), focus du premier champ à l'ouverture ;
 * * note « données synchronisées » : le rappel du bénéfice du compte.
 */

"use client";

import { useEffect, useRef, useState } from "react";
import {
  AtSign,
  Eye,
  EyeOff,
  Lock,
  LogIn,
  Mail,
  ShieldCheck,
  Sparkles,
  UserRound,
  UserRoundPlus,
} from "lucide-react";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { useAuthStore } from "@/lib/auth-store";
import { cn } from "@/lib/utils";

const inputClass =
  "h-11 border-white/10 bg-zinc-900/60 text-zinc-100 placeholder:text-zinc-600 focus-visible:ring-emerald-400/50";
const labelClass = "text-[11px] font-semibold text-zinc-400";

export function AuthDialog() {
  const open = useAuthStore((state) => state.loginOpen);
  const setOpen = useAuthStore((state) => state.setLoginOpen);

  // --- état partagé des formulaires ---
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState<"login" | "register" | null>(null);

  const firstInputRef = useRef<HTMLInputElement>(null);

  // À l'ouverture : focus du premier champ (action DOM pure).
  useEffect(() => {
    if (!open) return;
    const timer = setTimeout(() => firstInputRef.current?.focus(), 120);
    return () => clearTimeout(timer);
  }, [open]);

  const login = useAuthStore((state) => state.login);
  const register = useAuthStore((state) => state.register);

  const handleLogin = async (event: React.FormEvent) => {
    event.preventDefault();
    if (busy) return;
    setError(null);
    setBusy("login");
    const result = await login(identifier.trim(), password);
    setBusy(null);
    if (result.ok) {
      setOpen(false);
      const user = useAuthStore.getState().user;
      toast.success(`Bienvenue, ${user?.username ?? ""} 👋`, {
        description: "Vos données sont maintenant synchronisées en ligne.",
      });
    } else {
      setError(result.error ?? "Connexion impossible.");
    }
  };

  const handleRegister = async (event: React.FormEvent) => {
    event.preventDefault();
    if (busy) return;
    setError(null);
    setBusy("register");
    const result = await register({
      username: username.trim(),
      email: email.trim(),
      password,
      name: displayName.trim() || undefined,
    });
    setBusy(null);
    if (result.ok) {
      setOpen(false);
      const user = useAuthStore.getState().user;
      toast.success(`Compte créé — bienvenue, ${user?.username ?? ""} !`, {
        description:
          "Vos statistiques de dhikr seront désormais conservées en ligne.",
      });
    } else {
      setError(result.error ?? "Création impossible.");
    }
  };

  return (
    <Dialog
      open={open}
      onOpenChange={(next) => {
        if (next) setError(null); // nouvelle ouverture → repart propre
        setOpen(next);
      }}
    >
      <DialogContent className="max-h-[calc(100dvh-2rem)] max-w-[calc(100vw-2rem)] overflow-y-auto overscroll-contain rounded-2xl border-white/10 bg-zinc-950 p-0 sm:max-w-md">
        <div
          aria-hidden="true"
          className="h-1 w-full rounded-t-2xl bg-gradient-to-r from-emerald-600 via-emerald-400 to-amber-400/80"
        />
        <div className="p-5 pt-4 sm:p-6 sm:pt-5">
          <DialogHeader className="text-left">
            <DialogTitle className="flex items-center gap-2 text-lg font-extrabold text-zinc-100">
              <span
                aria-hidden="true"
                className="grid size-9 place-items-center rounded-lg border border-white/10 bg-[#0a0a0b] shadow-[0_0_18px_rgba(16,185,129,0.18)]"
              >
                <ShieldCheck className="size-4 text-emerald-400" />
              </span>
              Compte Sakinah
            </DialogTitle>
            <DialogDescription className="text-[13px] leading-relaxed text-zinc-400">
              Connectez-vous pour synchroniser vos données en ligne —
              vos dhikr et statistiques suivent votre compte, pas votre
              appareil.
            </DialogDescription>
          </DialogHeader>

          <Tabs defaultValue="login" className="mt-4">
            <TabsList className="grid h-11 w-full grid-cols-2 rounded-xl border border-white/5 bg-zinc-900/60 p-1">
              <TabsTrigger
                value="login"
                className="gap-1.5 rounded-lg text-[13px] font-semibold text-zinc-400 transition-colors hover:text-zinc-200 data-[state=active]:bg-emerald-500/10 data-[state=active]:text-emerald-300"
              >
                <LogIn className="size-3.5" aria-hidden />
                Se connecter
              </TabsTrigger>
              <TabsTrigger
                value="register"
                className="gap-1.5 rounded-lg text-[13px] font-semibold text-zinc-400 transition-colors hover:text-zinc-200 data-[state=active]:bg-emerald-500/10 data-[state=active]:text-emerald-300"
              >
                <UserRoundPlus className="size-3.5" aria-hidden />
                Créer un compte
              </TabsTrigger>
            </TabsList>

            {/* ------------------- Connexion ------------------- */}
            <TabsContent value="login" className="mt-4">
              <form onSubmit={handleLogin} className="space-y-3.5">
                <div className="space-y-1.5">
                  <Label htmlFor="auth-identifier" className={labelClass}>
                    Identifiant ou adresse e-mail
                  </Label>
                  <div className="relative">
                    <AtSign
                      className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-zinc-600"
                      aria-hidden
                    />
                    <Input
                      id="auth-identifier"
                      ref={firstInputRef}
                      value={identifier}
                      onChange={(event) => setIdentifier(event.target.value)}
                      placeholder="ex. mohamed_92"
                      autoComplete="username"
                      className={cn(inputClass, "pl-9")}
                      required
                    />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="auth-password" className={labelClass}>
                    Mot de passe
                  </Label>
                  <div className="relative">
                    <Lock
                      className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-zinc-600"
                      aria-hidden
                    />
                    <Input
                      id="auth-password"
                      type={showPassword ? "text" : "password"}
                      value={password}
                      onChange={(event) => setPassword(event.target.value)}
                      placeholder="••••••••"
                      autoComplete="current-password"
                      className={cn(inputClass, "pl-9 pr-11")}
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword((visible) => !visible)}
                      aria-label={
                        showPassword
                          ? "Masquer le mot de passe"
                          : "Afficher le mot de passe"
                      }
                      className="absolute right-2 top-1/2 grid size-8 -translate-y-1/2 place-items-center rounded-md text-zinc-500 transition-colors hover:bg-white/5 hover:text-zinc-300"
                    >
                      {showPassword ? (
                        <EyeOff className="size-4" aria-hidden />
                      ) : (
                        <Eye className="size-4" aria-hidden />
                      )}
                    </button>
                  </div>
                </div>

                {error && (
                  <p
                    role="alert"
                    className="rounded-lg border border-red-500/20 bg-red-500/10 px-3 py-2 text-[12px] font-medium text-red-300"
                  >
                    {error}
                  </p>
                )}

                <Button
                  type="submit"
                  disabled={busy !== null}
                  className="h-11 w-full rounded-xl border border-emerald-400/30 bg-emerald-500/90 text-[13px] font-bold text-zinc-950 shadow-[0_0_24px_rgba(16,185,129,0.25)] hover:bg-emerald-400 disabled:opacity-60"
                >
                  {busy === "login" ? "Connexion…" : "Se connecter"}
                </Button>

                <p className="flex items-start gap-1.5 text-[11px] leading-relaxed text-zinc-600">
                  <Sparkles
                    className="mt-0.5 size-3 shrink-0 text-emerald-500/70"
                    aria-hidden
                  />
                  Les membres voient la version prières ; le gérant accède aux
                  deux versions et à l&apos;espace d&apos;administration.
                </p>
              </form>
            </TabsContent>

            {/* ------------------- Inscription ------------------- */}
            <TabsContent value="register" className="mt-4">
              <form onSubmit={handleRegister} className="space-y-3.5">
                <div className="grid grid-cols-1 gap-3.5 sm:grid-cols-2">
                  <div className="space-y-1.5">
                    <Label htmlFor="auth-username" className={labelClass}>
                      Nom d&apos;utilisateur
                    </Label>
                    <div className="relative">
                      <UserRound
                        className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-zinc-600"
                        aria-hidden
                      />
                      <Input
                        id="auth-username"
                        value={username}
                        onChange={(event) => setUsername(event.target.value)}
                        placeholder="ex. mohamed_92"
                        autoComplete="username"
                        className={cn(inputClass, "pl-9")}
                        required
                      />
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="auth-email" className={labelClass}>
                      Adresse e-mail
                    </Label>
                    <div className="relative">
                      <Mail
                        className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-zinc-600"
                        aria-hidden
                      />
                      <Input
                        id="auth-email"
                        type="email"
                        value={email}
                        onChange={(event) => setEmail(event.target.value)}
                        placeholder="vous@exemple.fr"
                        autoComplete="email"
                        className={cn(inputClass, "pl-9")}
                        required
                      />
                    </div>
                  </div>
                </div>
                <div className="space-y-1.5">
                  <Label
                    htmlFor="auth-display-name"
                    className={cn(labelClass, "after:ml-1 after:text-zinc-600 after:content-['(facultatif)']")}
                  >
                    Nom affiché
                  </Label>
                  <Input
                    id="auth-display-name"
                    value={displayName}
                    onChange={(event) => setDisplayName(event.target.value)}
                    placeholder="ex. Mohamed K."
                    autoComplete="name"
                    className={inputClass}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="auth-new-password" className={labelClass}>
                    Mot de passe (8 caractères min.)
                  </Label>
                  <div className="relative">
                    <Lock
                      className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-zinc-600"
                      aria-hidden
                    />
                    <Input
                      id="auth-new-password"
                      type={showPassword ? "text" : "password"}
                      value={password}
                      onChange={(event) => setPassword(event.target.value)}
                      placeholder="••••••••"
                      autoComplete="new-password"
                      minLength={8}
                      className={cn(inputClass, "pl-9 pr-11")}
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword((visible) => !visible)}
                      aria-label={
                        showPassword
                          ? "Masquer le mot de passe"
                          : "Afficher le mot de passe"
                      }
                      className="absolute right-2 top-1/2 grid size-8 -translate-y-1/2 place-items-center rounded-md text-zinc-500 transition-colors hover:bg-white/5 hover:text-zinc-300"
                    >
                      {showPassword ? (
                        <EyeOff className="size-4" aria-hidden />
                      ) : (
                        <Eye className="size-4" aria-hidden />
                      )}
                    </button>
                  </div>
                </div>

                {error && (
                  <p
                    role="alert"
                    className="rounded-lg border border-red-500/20 bg-red-500/10 px-3 py-2 text-[12px] font-medium text-red-300"
                  >
                    {error}
                  </p>
                )}

                <Button
                  type="submit"
                  disabled={busy !== null}
                  className="h-11 w-full rounded-xl border border-emerald-400/30 bg-emerald-500/90 text-[13px] font-bold text-zinc-950 shadow-[0_0_24px_rgba(16,185,129,0.25)] hover:bg-emerald-400 disabled:opacity-60"
                >
                  {busy === "register" ? "Création…" : "Créer mon compte"}
                </Button>

                <p className="flex items-start gap-1.5 text-[11px] leading-relaxed text-zinc-600">
                  <ShieldCheck
                    className="mt-0.5 size-3 shrink-0 text-emerald-500/70"
                    aria-hidden
                  />
                  Mot de passe chiffré (scrypt), session en cookie sécurisé
                  httpOnly. Vos statistiques restent les vôtres.
                </p>
              </form>
            </TabsContent>
          </Tabs>
        </div>
      </DialogContent>
    </Dialog>
  );
}
