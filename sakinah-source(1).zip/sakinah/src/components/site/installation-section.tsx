/**
 * InstallationSection — « Prêt en trois commandes » : prérequis, pip install,
 * python main.py. Plus le contenu de requirements.txt et deux options
 * (adhan personnalisé, démarrage automatique).
 */

import { ExternalLink, Lightbulb, Music, Power, Terminal } from "lucide-react";
import { SectionHeading } from "./section-heading";
import { CodeBlock } from "./code-block";
import { FadeIn } from "./fade-in";

const REQUIREMENTS_TXT = `PyQt6>=6.6.0          # Interface graphique (widgets, fenêtres frameless)
requests>=2.31.0      # Appels HTTP vers mawaqit.net
pynput>=1.7.6         # Raccourci clavier global (Ctrl + Alt + H)
pywin32>=306          # win32gui : plein écran, click-through, topmost`;

interface Step {
  title: string;
  description: string;
  code?: { label: string; content: string };
}

const STEPS: Step[] = [
  {
    title: "Installez Python 3.10 ou plus",
    description:
      "Windows 10 ou 11 + Python 3.10+. Sur python.org, cochez « Add Python to PATH » pendant l'installation — c'est le seul piège.",
    code: { label: "vérifier", content: "python --version" },
  },
  {
    title: "Ouvrez un terminal dans le dossier dézippé",
    description:
      "Dézippez l'archive, placez-vous dans le dossier sakina-widget et installez les 4 dépendances.",
    code: {
      label: "cmd",
      content: "cd sakina-widget\npython -m pip install -r requirements.txt",
    },
  },
  {
    title: "Lancez Sakinah",
    description:
      "Le carré noir apparaît en haut à droite de l'écran. Cliquez dessus, puis choisissez votre mosquée dans Paramètres → Mosquée.",
    code: { label: "cmd", content: "python main.py" },
  },
];

const OPTIONS = [
  {
    icon: Music,
    title: "Adhan personnalisé",
    text: "Déposez votre appel à la prière dans assets/sounds/adhan.mp3 — sans fichier, Sakinah joue un bip discret généré localement.",
    code: "assets/sounds/adhan.mp3",
  },
  {
    icon: Power,
    title: "Démarrage automatique",
    text: "Cochez « Lancer avec Windows » dans Paramètres → Système : l'inscription au registre (HKCU) est réversible d'un clic.",
    code: "Paramètres → Système",
  },
];

export function InstallationSection() {
  return (
    <section
      id="installation"
      aria-labelledby="installation-title"
      className="scroll-mt-24 border-t border-white/5 bg-white/[0.015] py-16 sm:py-20 lg:py-24"
    >
      <div className="mx-auto w-full max-w-4xl px-4 sm:px-6">
        <SectionHeading
          eyebrow="Installation"
          title="Prêt en trois commandes"
          description="Pas d'installeur, pas de compte, pas de dépendance exotique : Python et c'est tout."
        />

        {/* ------------------------------------------------------- les 3 étapes */}
        <ol className="relative space-y-8">
          {STEPS.map((step, index) => (
            <FadeIn key={step.title} delay={index * 0.08}>
              <li className="relative flex gap-4 sm:gap-6">
                {/* numéro + ligne de connexion */}
                <div className="flex flex-col items-center" aria-hidden="true">
                  <span className="flex size-10 shrink-0 items-center justify-center rounded-xl border border-emerald-500/25 bg-emerald-500/10 text-sm font-extrabold text-emerald-300">
                    {index + 1}
                  </span>
                  {index < STEPS.length - 1 ? (
                    <span className="mt-2 w-px flex-1 bg-gradient-to-b from-emerald-500/25 to-white/5" />
                  ) : null}
                </div>

                <div className="min-w-0 flex-1 pb-2">
                  <h3 className="text-base font-bold tracking-tight text-zinc-100 sm:text-lg">
                    {step.title}
                  </h3>
                  <p className="mt-1.5 text-sm leading-relaxed text-zinc-400">
                    {step.description}
                  </p>

                  {index === 0 ? (
                    <p className="mt-3 inline-flex items-start gap-2 rounded-lg border border-amber-400/20 bg-amber-400/[0.06] px-3 py-2 text-xs leading-relaxed text-amber-200/90">
                      <Lightbulb className="mt-0.5 size-3.5 shrink-0 text-amber-400" aria-hidden="true" />
                      <span>
                        Astuce : téléchargez Python sur{" "}
                        <a
                          href="https://www.python.org/downloads/"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="font-medium text-amber-300 underline decoration-amber-400/40 underline-offset-2 hover:text-amber-200"
                        >
                          python.org
                          <ExternalLink className="ml-1 inline size-3" aria-hidden="true" />
                        </a>{" "}
                        et cochez « Add to PATH » au premier écran.
                      </span>
                    </p>
                  ) : null}

                  {step.code ? (
                    <CodeBlock
                      label={step.code.label}
                      code={step.code.content}
                      className="mt-3"
                    />
                  ) : null}
                </div>
              </li>
            </FadeIn>
          ))}
        </ol>

        {/* -------------------------------------------------- requirements.txt */}
        <FadeIn delay={0.1}>
          <div className="mt-10 rounded-2xl border border-white/5 bg-zinc-900/60 p-5 sm:p-6">
            <div className="mb-4 flex items-center gap-2.5">
              <Terminal className="size-4.5 text-emerald-400" aria-hidden="true" />
              <h3 className="text-sm font-bold tracking-tight text-zinc-100">
                Ce que pip installera — requirements.txt
              </h3>
            </div>
            <CodeBlock label="requirements.txt" code={REQUIREMENTS_TXT} />
          </div>
        </FadeIn>

        {/* -------------------------------------------------- options (2 cartes) */}
        <div className="mt-6 grid gap-4 sm:grid-cols-2">
          {OPTIONS.map((option, index) => (
            <FadeIn key={option.title} delay={index * 0.08} className="h-full">
              <div className="flex h-full flex-col rounded-2xl border border-white/5 bg-zinc-900/60 p-5 transition-colors hover:border-white/10">
                <option.icon className="mb-3 size-5 text-emerald-400" aria-hidden="true" />
                <h3 className="text-sm font-bold tracking-tight text-zinc-100">
                  {option.title}
                </h3>
                <p className="mt-1.5 flex-1 text-sm leading-relaxed text-zinc-400">
                  {option.text}
                </p>
                <code className="mt-4 inline-block self-start rounded-md border border-white/10 bg-zinc-950/80 px-2.5 py-1 font-mono text-xs text-emerald-200/90">
                  {option.code}
                </code>
              </div>
            </FadeIn>
          ))}
        </div>
      </div>
    </section>
  );
}
