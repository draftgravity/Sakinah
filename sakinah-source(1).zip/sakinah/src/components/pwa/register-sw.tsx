/**
 * Enregistrement du service worker Sakinah (PWA).
 *
 * Monté une seule fois dans la page : enregistre /sw.js quand le navigateur
 * le supporte. Le worker est volontairement minimal — voir public/sw.js
 * pour le détail de la stratégie de cache (page hors-ligne + repli API).
 */

"use client";

import { useEffect } from "react";

export function RegisterSw() {
  useEffect(() => {
    if (typeof window === "undefined" || !("serviceWorker" in navigator)) {
      return;
    }
    navigator.serviceWorker.register("/sw.js").catch(() => {
      /* enregistrement impossible (origine non sécurisée, mode privé…) —
         la vitrine fonctionne parfaitement sans service worker */
    });
  }, []);

  return null;
}
