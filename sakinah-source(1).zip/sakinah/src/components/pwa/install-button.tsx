/**
 * Bouton « Installer l'application » (PWA).
 *
 * Captive l'événement `beforeinstallprompt` (Chrome/Edge/Android) et ne
 * s'affiche QUE lorsqu'une installation native est réellement proposée —
 * jamais sur Firefox/iOS (pas d'événement) ni quand l'app est déjà
 * installée (display-mode: standalone).
 *
 * Deux habillages : « pill » discret (en-tête) et « cta » (carte finale).
 */

"use client";

import { useEffect, useState } from "react";
import { Check, MonitorDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

function isStandalone(): boolean {
  if (typeof window === "undefined") return false;
  return (
    window.matchMedia?.("(display-mode: standalone)").matches ||
    // iOS Safari < 17 ne remplit pas display-mode pour les web apps ajoutées
    (navigator as unknown as { standalone?: boolean }).standalone === true
  );
}

export function InstallButton({
  variant = "pill",
  className,
}: {
  variant?: "pill" | "cta";
  className?: string;
}) {
  const [promptEvent, setPromptEvent] =
    useState<BeforeInstallPromptEvent | null>(null);
  const [installed, setInstalled] = useState(false);

  useEffect(() => {
    if (isStandalone()) return;

    const onBeforeInstallPrompt = (event: Event) => {
      event.preventDefault();
      setPromptEvent(event as BeforeInstallPromptEvent);
    };
    const onInstalled = () => {
      setInstalled(true);
      setPromptEvent(null);
    };

    window.addEventListener("beforeinstallprompt", onBeforeInstallPrompt);
    window.addEventListener("appinstalled", onInstalled);
    return () => {
      window.removeEventListener("beforeinstallprompt", onBeforeInstallPrompt);
      window.removeEventListener("appinstalled", onInstalled);
    };
  }, []);

  // Aucune invitation disponible → bouton complètement absent (pas de
  // « faux » bouton qui ne ferait rien sur Firefox/iOS).
  if (!promptEvent || installed) return null;

  const install = async () => {
    const event = promptEvent;
    setPromptEvent(null);
    try {
      await event.prompt();
      const choice = await event.userChoice;
      if (choice.outcome === "accepted") setInstalled(true);
    } catch {
      /* invitation déjà consommée ou refusée */
    }
  };

  if (variant === "cta") {
    return (
      <Button
        type="button"
        size="lg"
        onClick={() => void install()}
        className={cn(
          "animate-in fade-in slide-in-from-bottom-1 fill-mode-both duration-300",
          "h-12 gap-2 border border-white/15 bg-white/[0.06] px-7 text-base font-semibold text-zinc-100 backdrop-blur transition-all hover:scale-[1.02] hover:border-emerald-400/40 hover:bg-emerald-500/10 hover:text-emerald-200",
          className,
        )}
      >
        {installed ? (
          <Check className="size-5" aria-hidden="true" />
        ) : (
          <MonitorDown className="size-5" aria-hidden="true" />
        )}
        {installed ? "Application installée" : "Installer la web-app"}
      </Button>
    );
  }

  return (
    <Button
      type="button"
      onClick={() => void install()}
      className={cn(
        "animate-in fade-in slide-in-from-top-1 fill-mode-both duration-300",
        "h-11 gap-1.5 border border-emerald-400/25 bg-emerald-500/10 font-semibold text-emerald-300 transition-colors hover:border-emerald-400/50 hover:bg-emerald-500/20 hover:text-emerald-200",
        className,
      )}
    >
      <MonitorDown className="size-4" aria-hidden="true" />
      <span className="hidden md:inline">Installer</span>
    </Button>
  );
}
