/**
 * Calendrier mensuel des prières de la démo — replique web de la vue
 * « calendrier » de mawaqit.net : pour chaque jour du mois, les 6 horaires
 * [Fajr, Chourouk, Dhuhr, Asr, Maghrib, Isha] extraits de `confData.calendar`
 * (calendrier annuel) via /api/prayers/calendar.
 *
 * Fonctionnalités :
 *  * panneau dépliable (bouton « Calendrier du mois ») ;
 *  * navigation entre les 12 mois de l'année Mawaqit (‹ ›) ;
 *  * jour courant surligné en émeraude, vendredis repérés (Jumu'a) ;
 *  * affichage au choix des ADHANS, des IQAMAS (prière en commun, heures
 *    finales) ou des deux — si la mosquée publie iqamaCalendar ;
 *  * SÉLECTEUR DE JOUR : un clic sur une ligne ouvre une carte de détail
 *    (date complète grégorienne + hégirienne, adhan et iqama de chaque
 *    prière) — navigable aussi au clavier via le bouton du numéro de jour ;
 *  * chargement paresseux au premier dépliage, rechargé si la mosquée change.
 */

"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import {
  CalendarDays,
  CalendarArrowDown,
  ChevronLeft,
  ChevronRight,
  Loader2,
  Moon,
  Users,
  X,
} from "lucide-react";
import { useDemoStore } from "@/lib/demo-store";
import { PRAYERS, zoneClock } from "@/lib/prayer-utils";
import { downloadMonthIcs } from "@/lib/ics";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const MONTH_NAMES = [
  "Janvier", "Février", "Mars", "Avril", "Mai", "Juin",
  "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre",
];

interface CalendarPayload {
  slug: string;
  name: string;
  timezone: string | null;
  /** calendar[mois 0-11][jour "1".."31"] = [Fajr, Chourouk, Dhuhr, Asr, Maghrib, Isha] */
  calendar: (Record<string, string[]> | null)[];
  /** iqamaCalendar[mois 0-11][jour "1".."31"] = [Fajr, Dhuhr, Asr, Maghrib, Isha] — heures finales */
  iqamaCalendar?: (Record<string, (string | null)[]> | null)[];
}

const SHORT_LABELS: Record<string, string> = {
  fajr: "Fajr",
  shourouk: "Chour.",
  dhuhr: "Dhuhr",
  asr: "Asr",
  maghrib: "Magh.",
  isha: "Isha",
};

/** Mode d'affichage du calendrier : adhans, iqamas, ou les deux superposés. */
type ViewMode = "adhan" | "iqama" | "both";

/* ---------- Cache local du calendrier (reprise hors ligne) ---------- */

const CAL_CACHE_PREFIX = "sakinah-cal-cache:";
const CAL_CACHE_MAX_AGE_MS = 3 * 86_400_000; // 3 jours

interface CalCacheEntry {
  at: number;
  data: CalendarPayload;
}

/** Lit le calendrier en cache pour ce slug (null si absent/périmé). */
function readCalCache(slug: string): CalendarPayload | null {
  try {
    const raw = window.localStorage.getItem(CAL_CACHE_PREFIX + slug);
    if (!raw) return null;
    const entry = JSON.parse(raw) as CalCacheEntry;
    if (
      !entry ||
      typeof entry.at !== "number" ||
      Date.now() - entry.at > CAL_CACHE_MAX_AGE_MS ||
      !entry.data ||
      !Array.isArray(entry.data.calendar)
    ) {
      return null;
    }
    return entry.data;
  } catch {
    return null;
  }
}

function writeCalCache(slug: string, data: CalendarPayload) {
  try {
    const entry: CalCacheEntry = { at: Date.now(), data };
    window.localStorage.setItem(
      CAL_CACHE_PREFIX + slug,
      JSON.stringify(entry),
    );
  } catch {
    /* quota localStorage — cache best effort */
  }
}

const VIEW_MODES: { key: ViewMode; label: string; title: string }[] = [
  { key: "adhan", label: "Adhan", title: "Heures de l'adhan" },
  { key: "iqama", label: "Iqama", title: "Heures de la prière en commun" },
  { key: "both", label: "Les deux", title: "Adhan et iqama superposés" },
];

/**
 * Index d'iqama pour chaque prière : iqamaCalendar ne contient que
 * [Fajr, Dhuhr, Asr, Maghrib, Isha] — Chourouk n'a pas d'iqama.
 */
const IQAMA_INDEXES: Record<string, number | null> = {
  fajr: 0,
  shourouk: null,
  dhuhr: 1,
  asr: 2,
  maghrib: 3,
  isha: 4,
};

/** Libellé du mois hégirien correspondant (ex. « rabia ath-thani 1448 »). */
function hijriMonthLabel(year: number, month: number): string {
  try {
    const fmt = new Intl.DateTimeFormat("fr-FR-u-ca-islamic-umalqura", {
      month: "long",
      year: "numeric",
    });
    const first = new Date(year, month, 1);
    const last = new Date(year, month + 1, 0);
    const firstLabel = fmt.format(first);
    const lastLabel = fmt.format(last);
    if (firstLabel === lastLabel) return firstLabel;
    // Le mois grégorien chevauche deux mois hégiriens.
    const firstMonth = firstLabel.split(" ").slice(0, -1).join(" ");
    const lastMonth = lastLabel.split(" ").slice(0, -1).join(" ");
    return `${firstMonth} → ${lastLabel}`;
  } catch {
    return "";
  }
}

/** Date complète en français : « lundi 21 septembre 2026 ». */
function fullFrenchDate(date: Date): string {
  try {
    return new Intl.DateTimeFormat("fr-FR", {
      weekday: "long",
      day: "numeric",
      month: "long",
      year: "numeric",
    }).format(date);
  } catch {
    return "";
  }
}

/** Date hégirienne complète : « 10 rabia ath-thani 1448 AH » (l'ère est déjà
 *  ajoutée par l'Intl français avec le calendrier islamique). */
function fullHijriDate(date: Date): string {
  try {
    return new Intl.DateTimeFormat("fr-FR-u-ca-islamic-umalqura", {
      day: "numeric",
      month: "long",
      year: "numeric",
    }).format(date);
  } catch {
    return "";
  }
}

export function MonthCalendar() {
  const slug = useDemoStore((state) => state.mosque.slug);
  const jumuaTime = useDemoStore((state) => state.prayers?.jumua ?? null);
  const [open, setOpen] = useState(false);
  const [data, setData] = useState<CalendarPayload | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [nonce, setNonce] = useState(0); // incrémente pour réessayer
  const [month, setMonth] = useState(() => new Date().getMonth());
  const [view, setView] = useState<ViewMode>("adhan");
  /** Jour sélectionné dans le tableau (null = aucun) — détail ci-dessous. */
  const [selectedDay, setSelectedDay] = useState<number | null>(null);
  /** Données affichées depuis le cache (réseau en échec). */
  const [fromCache, setFromCache] = useState(false);
  /** « .ics exporté » pendant 2,4 s après un export réussi. */
  const [exported, setExported] = useState(false);

  // Chargement au premier dépliage (et si la mosquée change / réessai).
  // Stratégie « stale-while-revalidate » : le cache local s'affiche
  // immédiatement s'il existe, puis la réponse réseau le remplace.
  useEffect(() => {
    if (!open) return;
    let cancelled = false;

    // 1) Affichage instantané depuis le cache (s'il est valide).
    const cached = readCalCache(slug);
    if (cached) {
      setData(cached);
      setError(null);
    }

    // 2) Revalidation réseau.
    setLoading(true);
    setError(null);
    setFromCache(false);

    const load = async () => {
      try {
        const response = await fetch(
          `/api/prayers/calendar?slug=${encodeURIComponent(slug)}`,
          { signal: AbortSignal.timeout(13000) },
        );
        if (!response.ok) throw new Error(`status ${response.status}`);
        const payload = (await response.json()) as CalendarPayload;
        if (!cancelled) {
          setData(payload);
          writeCalCache(slug, payload);
        }
      } catch {
        if (!cancelled) {
          if (cached) {
            // Hors ligne : on garde le calendrier du cache.
            setFromCache(true);
          } else {
            setError("Calendrier indisponible — réessayez dans un instant.");
          }
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    };

    void load();
    return () => {
      cancelled = true;
    };
  }, [open, slug, nonce]);

  const monthData = data?.calendar?.[month] ?? null;
  const iqamaData = data?.iqamaCalendar?.[month] ?? null;
  const hasIqama = (data?.iqamaCalendar?.length ?? 0) > 0;
  // « Aujourd'hui » à l'horloge de la mosquée dès que le fuseau est connu
  // (repli navigateur sinon) — les surlignages suivent le jour de la mosquée.
  const today = new Date();
  const clock = zoneClock(data?.timezone);
  const todayMonth = clock ? clock.month - 1 : today.getMonth();
  const todayDay = clock ? clock.day : today.getDate();
  const todayYear = clock ? clock.year : today.getFullYear();
  const isCurrentMonth = todayMonth === month;

  // À l'arrivée du calendrier, si le visiteur n'a pas encore navigué,
  // on se cale sur le mois courant de la mosquée (fuseau ≠ navigateur).
  const navigatedRef = useRef(false);
  useEffect(() => {
    if (data && !navigatedRef.current && clock && clock.month - 1 !== month) {
      setMonth(clock.month - 1);
    }
  }, [data]); // volontairement sans `clock`/`month` : calage one-shot à l'arrivée des données

  // Détail du jour sélectionné (masqué si le jour n'existe pas dans ce mois).
  const selectedValues =
    selectedDay !== null ? (monthData?.[String(selectedDay)] ?? null) : null;
  const selectedIqamas =
    selectedDay !== null ? (iqamaData?.[String(selectedDay)] ?? null) : null;
  const showDetail = selectedDay !== null && selectedValues !== null;
  const selectedDate =
    selectedDay !== null
      ? new Date(todayYear, month, selectedDay)
      : null;

  // Retour à l'affichage « adhan » si la nouvelle mosquée ne publie pas d'iqama.
  useEffect(() => {
    if (!hasIqama && view !== "adhan") setView("adhan");
  }, [hasIqama, view]);

  const days = useMemo(() => {
    if (!monthData) return [];
    return Object.keys(monthData)
      .map(Number)
      .filter((n) => Number.isInteger(n) && n >= 1 && n <= 31)
      .sort((a, b) => a - b);
  }, [monthData]);

  return (
    <section aria-label="Calendrier mensuel des prières">
      {/* ------- Bouton d'ouverture ------- */}
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        className={cn(
          "flex w-full items-center justify-between rounded-xl border px-3.5 py-2.5 text-left transition-colors",
          open
            ? "border-emerald-500/30 bg-emerald-500/5"
            : "border-white/5 bg-zinc-900/60 hover:border-white/10 hover:bg-zinc-900",
        )}
      >
        <span className="flex items-center gap-2">
          <CalendarDays className="h-4 w-4 text-emerald-400" aria-hidden />
          <span className="text-xs font-semibold text-zinc-200">
            Calendrier du mois
          </span>
          {data && !loading && (
            <span className="text-[10px] font-normal text-zinc-500">
              · {MONTH_NAMES[month].toLowerCase()}
              {hasIqama ? " · adhan + iqama" : ""}
            </span>
          )}
        </span>
        <span className="flex items-center gap-1.5">
          {loading && <Loader2 className="h-3.5 w-3.5 animate-spin text-zinc-500" aria-hidden />}
          <ChevronRight
            className={cn(
              "h-4 w-4 text-zinc-500 transition-transform",
              open && "rotate-90",
            )}
            aria-hidden
          />
        </span>
      </button>

      {/* ------- Panneau ------- */}
      {open && (
        <div className="mt-2 overflow-hidden rounded-xl border border-white/5 bg-zinc-950/70">
          {/* Barre de navigation du mois */}
          <div className="flex items-center justify-between gap-2 border-b border-white/5 px-3 py-2">
            <Button
              variant="ghost"
              size="sm"
              className="h-7 w-7 p-0 text-zinc-400 hover:text-zinc-100"
              onClick={() => {
                navigatedRef.current = true;
                setMonth((m) => (m + 11) % 12);
              }}
              aria-label="Mois précédent"
              disabled={month === 0}
            >
              <ChevronLeft className="h-4 w-4" aria-hidden />
            </Button>
            <div className="flex min-w-0 flex-col items-center">
              <p className="text-xs font-bold tracking-wide text-zinc-200">
                {MONTH_NAMES[month]}
                <span
                  className={
                    fromCache
                      ? "ml-2 text-[10px] font-normal text-amber-400/90"
                      : "ml-2 text-[10px] font-normal text-zinc-600"
                  }
                >
                  {fromCache
                    ? "hors ligne — calendrier en cache"
                    : "horaires mawaqit.net"}
                </span>
              </p>
              {(() => {
                const hijri = hijriMonthLabel(todayYear, month);
                return hijri ? (
                  <p className="mt-0.5 text-[10px] font-normal text-emerald-400/70">
                    {hijri}
                  </p>
                ) : null;
              })()}
            </div>
            <Button
              variant="ghost"
              size="sm"
              className="h-7 w-7 p-0 text-zinc-400 hover:text-zinc-100"
              onClick={() => {
                navigatedRef.current = true;
                setMonth((m) => (m + 1) % 12);
              }}
              aria-label="Mois suivant"
              disabled={month === 11}
            >
              <ChevronRight className="h-4 w-4" aria-hidden />
            </Button>
          </div>

          {/* ------- Export du mois au format calendrier (.ics) ------- */}
          {!loading && !error && days.length > 0 && (
            <div className="flex items-center justify-between gap-2 border-b border-white/5 px-3 py-1.5">
              <p className="min-w-0 text-[9px] leading-relaxed text-zinc-600">
                Importez ce mois dans Google Agenda, Outlook ou Apple
                Calendrier — horaires à l&apos;heure de la mosquée.
              </p>
              <button
                type="button"
                onClick={() => {
                  const ok = downloadMonthIcs({
                    mosqueName: data?.name ?? "Mosquée",
                    slug,
                    timezone: data?.timezone ?? null,
                    year: todayYear,
                    month,
                    monthData,
                    iqamaData,
                    jumua: jumuaTime,
                  });
                  if (ok) {
                    setExported(true);
                    setTimeout(() => setExported(false), 2400);
                  }
                }}
                className={cn(
                  "flex shrink-0 items-center gap-1.5 rounded-full border px-2.5 py-1 text-[10px] font-semibold transition-all",
                  exported
                    ? "border-emerald-500/50 bg-emerald-500/15 text-emerald-300"
                    : "border-white/10 bg-zinc-900 text-zinc-400 hover:border-emerald-500/40 hover:bg-emerald-500/5 hover:text-emerald-300",
                )}
                aria-label={`Exporter les horaires de ${MONTH_NAMES[month]} au format iCalendar`}
              >
                {exported ? (
                  <>
                    <svg
                      viewBox="0 0 24 24"
                      className="h-3 w-3"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="3"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      aria-hidden
                    >
                      <path d="M20 6 9 17l-5-5" />
                    </svg>
                    Exporté
                  </>
                ) : (
                  <>
                    <CalendarArrowDown className="h-3 w-3" aria-hidden />
                    .ics
                  </>
                )}
              </button>
            </div>
          )}

          {/* ------- Bascule adhan / iqama / les deux ------- */}
          {hasIqama && !loading && !error && (
            <div
              className="flex items-center justify-center gap-1.5 border-b border-white/5 px-3 py-2"
              role="radiogroup"
              aria-label="Type d'horaires affichées"
            >
              {VIEW_MODES.map((mode) => {
                const active = view === mode.key;
                return (
                  <button
                    key={mode.key}
                    type="button"
                    role="radio"
                    aria-checked={active}
                    title={mode.title}
                    onClick={() => setView(mode.key)}
                    className={cn(
                      "rounded-full border px-2.5 py-1 text-[10px] font-semibold transition-colors",
                      active
                        ? "border-emerald-500/60 bg-emerald-500/15 text-emerald-300"
                        : "border-white/10 bg-zinc-900 text-zinc-400 hover:border-white/20 hover:text-zinc-200",
                    )}
                  >
                    {mode.key === "iqama" && (
                      <Users
                        className="mr-1 inline h-2.5 w-2.5 align-[-1px]"
                        aria-hidden
                      />
                    )}
                    {mode.label}
                  </button>
                );
              })}
            </div>
          )}

          {/* ------- Carte de détail du jour sélectionné ------- */}
          {showDetail && selectedDate && (
            <div
              className="animate-in fade-in slide-in-from-top-1 border-b border-white/5 bg-gradient-to-b from-emerald-500/[0.07] to-transparent px-3.5 py-3"
              aria-live="polite"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <p className="text-xs font-bold capitalize text-zinc-100">
                    {fullFrenchDate(selectedDate)}
                    {isCurrentMonth && todayDay === selectedDay && (
                      <span className="ml-2 rounded bg-emerald-500/20 px-1.5 py-0.5 text-[8px] font-bold uppercase tracking-wider text-emerald-300">
                        aujourd&apos;hui
                      </span>
                    )}
                    {selectedDate.getDay() === 5 && (
                      <span className="ml-1.5 rounded bg-amber-500/15 px-1.5 py-0.5 text-[8px] font-bold uppercase tracking-wider text-amber-300">
                        jumu&apos;a
                      </span>
                    )}
                  </p>
                  {(() => {
                    const hijri = fullHijriDate(selectedDate);
                    return hijri ? (
                      <p className="mt-0.5 flex items-center gap-1 text-[10px] text-emerald-400/80">
                        <Moon className="h-2.5 w-2.5" aria-hidden />
                        {hijri}
                      </p>
                    ) : null;
                  })()}
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedDay(null)}
                  aria-label="Fermer le détail du jour"
                  className="grid h-5 w-5 shrink-0 place-items-center rounded-md text-zinc-500 transition-colors hover:bg-white/10 hover:text-zinc-200"
                >
                  <X className="h-3 w-3" aria-hidden />
                </button>
              </div>
              <ul className="mt-2 grid grid-cols-3 gap-1.5">
                {PRAYERS.map((prayer, index) => {
                  const adhan = selectedValues[index] ?? null;
                  const iqamaIndex = IQAMA_INDEXES[prayer.key];
                  const iqama =
                    iqamaIndex !== null
                      ? (selectedIqamas?.[iqamaIndex] ?? null)
                      : null;
                  return (
                    <li
                      key={prayer.key}
                      className={cn(
                        "rounded-lg border px-2 py-1.5",
                        prayer.real
                          ? "border-white/10 bg-zinc-900/60"
                          : "border-white/5 bg-zinc-900/30",
                      )}
                    >
                      <p
                        className={cn(
                          "flex items-baseline justify-between gap-1 text-[9px] font-semibold uppercase tracking-wide",
                          prayer.real ? "text-zinc-400" : "text-zinc-600",
                        )}
                      >
                        {prayer.label}
                        <span
                          className="font-normal normal-case tracking-normal text-zinc-500"
                          aria-hidden
                        >
                          {prayer.arabic}
                        </span>
                      </p>
                      <p className="mt-0.5 font-mono text-sm font-bold tabular-nums leading-none text-zinc-100">
                        {adhan ?? "—"}
                      </p>
                      {prayer.real && (
                        <p
                          className={cn(
                            "mt-0.5 font-mono text-[9px] tabular-nums leading-none",
                            iqama
                              ? "text-emerald-400"
                              : "text-zinc-600",
                          )}
                        >
                          {iqama ? `iqama ${iqama}` : "iqama —"}
                        </p>
                      )}
                      {!prayer.real && (
                        <p className="mt-0.5 text-[8px] leading-tight text-zinc-600">
                          lever du soleil
                        </p>
                      )}
                    </li>
                  );
                })}
              </ul>
            </div>
          )}

          {/* Contenu */}
          {loading ? (
            <div className="flex items-center justify-center gap-2 py-10 text-xs text-zinc-500">
              <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
              Chargement du calendrier…
            </div>
          ) : error ? (
            <div className="px-4 py-8 text-center">
              <p className="text-xs text-zinc-400">{error}</p>
              <Button
                variant="outline"
                size="sm"
                className="mt-3 h-7 border-white/10 bg-transparent text-[11px] text-zinc-300 hover:bg-white/5"
                onClick={() => setNonce((n) => n + 1)}
              >
                Réessayer
              </Button>
            </div>
          ) : days.length === 0 ? (
            <p className="px-4 py-8 text-center text-xs text-zinc-500">
              Aucun horaire publié pour ce mois.
            </p>
          ) : (
            <div className="max-h-72 overflow-y-auto overscroll-contain scrollbar-slim">
              <table className="w-full border-collapse text-[10px] tabular-nums">
                <caption className="sr-only">
                  Horaires de prière de {MONTH_NAMES[month]} — {view === "iqama" ? "iqamas (prière en commun)" : view === "both" ? "adhans et iqamas" : "adhans"}
                </caption>
                <thead className="sticky top-0 z-10 bg-zinc-950/95 backdrop-blur">
                  <tr className="text-zinc-500">
                    <th scope="col" className="px-2 py-1.5 text-left font-semibold">
                      Jour
                    </th>
                    {PRAYERS.map((prayer) => (
                      <th
                        key={prayer.key}
                        scope="col"
                        className={cn(
                          "px-1 py-1.5 text-right font-semibold",
                          !prayer.real && "text-zinc-600",
                        )}
                      >
                        {SHORT_LABELS[prayer.key]}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {days.map((day) => {
                    const values = monthData[String(day)] ?? [];
                    const iqamas = iqamaData?.[String(day)] ?? null;
                    const isToday = isCurrentMonth && todayDay === day;
                    // Vendredi = jour de la Jumu'a.
                    const dayDate = new Date(todayYear, month, day);
                    const isFriday = dayDate.getDay() === 5;
                    return (
                      <tr
                        key={day}
                        onClick={() =>
                          setSelectedDay((d) => (d === day ? null : day))
                        }
                        aria-selected={selectedDay === day}
                        className={cn(
                          "cursor-pointer border-t border-white/[0.04] transition-colors hover:bg-white/[0.05] focus-within:bg-white/[0.03]",
                          isToday && "bg-emerald-500/10",
                          !isToday && isFriday && "bg-amber-500/[0.04]",
                          selectedDay === day &&
                            "bg-emerald-500/[0.14] shadow-[inset_2px_0_0_0_#34d399]",
                        )}
                      >
                        <th
                          scope="row"
                          className={cn(
                            "px-2 py-1.5 text-left font-semibold",
                            isToday
                              ? "text-emerald-300"
                              : isFriday
                                ? "text-amber-300/90"
                                : "text-zinc-400",
                          )}
                        >
                          {/* Bouton réel : accès clavier à la sélection du jour. */}
                          <button
                            type="button"
                            onClick={(event) => {
                              event.stopPropagation();
                              setSelectedDay((d) => (d === day ? null : day));
                            }}
                            aria-expanded={selectedDay === day}
                            aria-label={`Détail du ${day} ${MONTH_NAMES[month].toLowerCase()}`}
                            className="rounded text-left focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-emerald-400/60"
                          >
                            {day}
                            {isToday && (
                              <span className="ml-1.5 rounded bg-emerald-500/20 px-1 text-[8px] font-bold uppercase tracking-wider text-emerald-300">
                                aujourd&apos;hui
                              </span>
                            )}
                            {isFriday && !isToday && (
                              <span className="ml-1.5 text-[8px] font-bold uppercase tracking-wider text-amber-400/70">
                                jumu&apos;a
                              </span>
                            )}
                          </button>
                        </th>
                        {PRAYERS.map((prayer, index) => {
                          const adhan = values[index] ?? null;
                          const iqamaIndex = IQAMA_INDEXES[prayer.key];
                          const iqama =
                            iqamaIndex !== null
                              ? (iqamas?.[iqamaIndex] ?? null)
                              : null;

                          // --- Mode iqama uniquement : heure de la prière en commun ---
                          if (view === "iqama") {
                            const shown = prayer.real ? (iqama ?? "—") : "—";
                            return (
                              <td
                                key={prayer.key}
                                title={
                                  prayer.real && iqama
                                    ? `Adhan ${adhan ?? "?"} · iqama ${iqama}`
                                    : undefined
                                }
                                className={cn(
                                  "px-1 py-1.5 text-right",
                                  isToday
                                    ? "font-bold text-emerald-200"
                                    : prayer.real && iqama
                                      ? "text-emerald-300/70"
                                      : "text-zinc-600",
                                )}
                              >
                                {shown}
                              </td>
                            );
                          }

                          // --- Modes « adhan » et « les deux » ---
                          return (
                            <td
                              key={prayer.key}
                              title={
                                view === "both" && prayer.real && iqama
                                  ? `Adhan ${adhan ?? "?"} · iqama ${iqama}`
                                  : undefined
                              }
                              className="px-1 py-1.5 text-right align-top leading-tight"
                            >
                              <span
                                className={cn(
                                  "block",
                                  isToday
                                    ? "font-bold text-emerald-200"
                                    : prayer.real
                                      ? "text-zinc-300"
                                      : "text-zinc-600",
                                )}
                              >
                                {adhan ?? "—"}
                              </span>
                              {view === "both" && prayer.real && iqama && (
                                <span
                                  className={cn(
                                    "block text-[9px] text-emerald-400/80",
                                    isToday && "font-semibold",
                                  )}
                                >
                                  {iqama}
                                </span>
                              )}
                            </td>
                          );
                        })}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
              {hasIqama && (
                <p className="border-t border-white/5 px-3 py-2 text-center text-[9px] leading-relaxed text-zinc-600">
                  <span className="text-emerald-400/70">Émeraude</span> = iqama
                  (début de la prière en commun) · basculez ci-dessus pour
                  l&apos;afficher seule · <span className="text-zinc-500">cliquez sur un jour pour son détail</span>
                </p>
              )}
              {!hasIqama && (
                <p className="border-t border-white/5 px-3 py-2 text-center text-[9px] text-zinc-600">
                  <span className="text-zinc-500">Cliquez sur un jour pour voir le détail complet des horaires</span>
                </p>
              )}
            </div>
          )}
        </div>
      )}
    </section>
  );
}
