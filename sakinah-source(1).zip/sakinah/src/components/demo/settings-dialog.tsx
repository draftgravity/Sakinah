/**
 * Boîte « Paramètres » de la démo — replica web de app/ui/settings_dialog.py.
 * Seule la partie réellement utile en ligne est interactive : la recherche
 * de mosquée Mawaqit (via /api/mosques/search) et les préférences
 * d'ambiance. Les autres options de l'application Windows y sont décrites
 * à titre informatif.
 *
 * Recherche « Autour de moi » : géolocalisation navigateur → tri des
 * résultats par distance orthodromique (haversine) + badge « à X km ».
 */

"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import {
  ExternalLink,
  Globe2,
  LocateFixed,
  Loader2,
  MapPin,
  Monitor,
  Search,
  Sparkles,
} from "lucide-react";
import { useDemoStore } from "@/lib/demo-store";
import { useAuthStore } from "@/lib/auth-store";
import { haversineKm } from "@/lib/qibla";
import { REGIONS } from "@/lib/regions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { cn } from "@/lib/utils";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

interface MosqueSearchItem {
  slug: string;
  name: string;
  localisation: string;
  latitude: number | null;
  longitude: number | null;
}

/** Position utilisateur pour le tri « autour de moi » (null = pertinence). */
interface UserPos {
  lat: number;
  lng: number;
}

type GeoState = "idle" | "locating" | "denied" | "unavailable";

/** « à 3,2 km » / « à 850 m » — séparateur décimal français. */
function formatNearbyDistance(km: number): string {
  if (km < 1) return `à ${Math.max(10, Math.round((km * 1000) / 10) * 10)} m`;
  if (km < 10) return `à ${km.toFixed(1).replace(".", ",")} km`;
  return `à ${Math.round(km)} km`;
}

export function SettingsDialog() {
  const open = useDemoStore((state) => state.settingsOpen);
  const setOpen = useDemoStore((state) => state.setSettingsOpen);
  const mosque = useDemoStore((state) => state.mosque);
  const setMosque = useDemoStore((state) => state.setMosque);
  const region = useDemoStore((state) => state.region);
  const setRegion = useDemoStore((state) => state.setRegion);
  const fullscreenHide = useDemoStore((state) => state.fullscreenHide);
  const setFullscreenHide = useDemoStore((state) => state.setFullscreenHide);
  const focusSound = useDemoStore((state) => state.focusSound);
  const setFocusSound = useDemoStore((state) => state.setFocusSound);
  const focusVolume = useDemoStore((state) => state.focusVolume);
  const setFocusVolume = useDemoStore((state) => state.setFocusVolume);
  // Les réglages d'ambiance ne concernent que le mode concentration,
  // réservé au gérant EN VERSION COMPLÈTE (préférence « focusEnabled »
  // conservée en ligne) : la section est masquée pour tous les autres.
  const isManager = useAuthStore(
    (state) => state.user?.role === "MANAGER" && state.user.focusEnabled,
  );

  const [query, setQuery] = useState("");
  const [results, setResults] = useState<MosqueSearchItem[] | null>(null);
  const [searching, setSearching] = useState(false);
  const [offline, setOffline] = useState(false);
  const [selected, setSelected] = useState<string | null>(null);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // --- Géolocalisation « autour de moi » ---------------------------------
  const [userPos, setUserPos] = useState<UserPos | null>(null);
  const [geoState, setGeoState] = useState<GeoState>("idle");

  const locateMe = () => {
    if (userPos) {
      // Second clic : retour à l'ordre de pertinence Mawaqit.
      setUserPos(null);
      setGeoState("idle");
      return;
    }
    if (!("geolocation" in navigator)) {
      setGeoState("unavailable");
      return;
    }
    setGeoState("locating");
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setUserPos({
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        });
        setGeoState("idle");
      },
      (error) => {
        setGeoState(
          error.code === error.PERMISSION_DENIED ? "denied" : "unavailable",
        );
      },
      { enableHighAccuracy: true, timeout: 10_000, maximumAge: 300_000 },
    );
  };

  // Résultats triés par distance quand une position est disponible ;
  // les mosquées sans coordonnées publiées passent en fin de liste.
  const displayResults = useMemo(() => {
    if (!results) return null;
    if (!userPos) return results;
    const withDistance = results.map((item) => ({
      item,
      distanceKm:
        item.latitude !== null && item.longitude !== null
          ? haversineKm(userPos.lat, userPos.lng, item.latitude, item.longitude)
          : null,
    }));
    withDistance.sort((a, b) => {
      if (a.distanceKm === null && b.distanceKm === null) return 0;
      if (a.distanceKm === null) return 1;
      if (b.distanceKm === null) return -1;
      return a.distanceKm - b.distanceKm;
    });
    return withDistance.map(({ item }) => item);
  }, [results, userPos]);

  /** Distance d'un résultat par rapport à la position (null si inconnue). */
  const distanceOf = (item: MosqueSearchItem): number | null => {
    if (!userPos || item.latitude === null || item.longitude === null) {
      return null;
    }
    return haversineKm(userPos.lat, userPos.lng, item.latitude, item.longitude);
  };

  // Recherche debouncée (400 ms) dès 2 caractères.
  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    const trimmed = query.trim();
    if (trimmed.length < 2) {
      setResults(null);
      setSearching(false);
      setOffline(false);
      return;
    }
    setSearching(true);
    debounceRef.current = setTimeout(async () => {
      try {
        const regionParam =
          region && region !== "all" ? `&region=${region}` : "";
        const response = await fetch(
          `/api/mosques/search?q=${encodeURIComponent(trimmed)}${regionParam}`,
          { signal: AbortSignal.timeout(10000) },
        );
        const data = await response.json();
        setResults(Array.isArray(data.mosques) ? data.mosques : []);
        setOffline(data.source === "offline");
      } catch {
        setResults([]);
        setOffline(true);
      } finally {
        setSearching(false);
      }
    }, 400);
    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
    };
  }, [query, region]);

  const pick = (item: MosqueSearchItem) => {
    setSelected(item.slug);
    setMosque({ slug: item.slug, name: item.name });
    setTimeout(() => {
      setOpen(false);
      setSelected(null);
      setQuery("");
      setResults(null);
    }, 350);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="max-h-[85vh] gap-0 overflow-hidden border-white/10 bg-zinc-950 p-0 sm:max-w-[460px]">
        <DialogHeader className="border-b border-white/5 px-5 py-4">
          <DialogTitle className="text-base">Paramètres</DialogTitle>
          <DialogDescription className="text-xs">
            Mosquée, notifications et ambiance — persistés localement
            (l&apos;équivalent web de <code className="text-[10px]">config.json</code>).
          </DialogDescription>
        </DialogHeader>

        {/* min-w-0 : dans la grille Radix (DialogContent), un item sans
            largeur minimale nulle ne peut pas rétrécir sous son contenu. */}
        <ScrollArea className="max-h-[62vh] min-w-0">
          <div className="space-y-5 px-5 py-4">
            {/* ------- Région de recherche ------- */}
            <section>
              <Label className="flex items-center gap-1.5 text-xs font-semibold text-zinc-300">
                <Globe2 className="h-3.5 w-3.5 text-emerald-400" aria-hidden />
                Région de recherche
              </Label>
              <p className="mt-1 text-[11px] leading-relaxed text-zinc-500">
                Les mosquées de votre région passent en premier dans les
                résultats — les autres restent disponibles, juste après.
              </p>
              <div
                role="radiogroup"
                aria-label="Région de recherche"
                className="mt-2 flex flex-wrap gap-1.5"
              >
                <button
                  type="button"
                  role="radio"
                  aria-checked={(region ?? "all") === "all"}
                  onClick={() => setRegion("all")}
                  className={`rounded-full border px-2.5 py-1 text-[11px] font-semibold transition-colors ${
                    (region ?? "all") === "all"
                      ? "border-emerald-500/60 bg-emerald-500/15 text-emerald-300"
                      : "border-white/10 bg-zinc-900/60 text-zinc-400 hover:border-white/25 hover:text-zinc-200"
                  }`}
                >
                  Toutes
                </button>
                {REGIONS.map((item) => (
                  <button
                    key={item.key}
                    type="button"
                    role="radio"
                    aria-checked={region === item.key}
                    onClick={() => setRegion(item.key)}
                    className={`flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-semibold transition-colors ${
                      region === item.key
                        ? "border-emerald-500/60 bg-emerald-500/15 text-emerald-300"
                        : "border-white/10 bg-zinc-900/60 text-zinc-400 hover:border-white/25 hover:text-zinc-200"
                    }`}
                  >
                    <span
                      className={`font-mono text-[9px] tracking-wide ${
                        region === item.key ? "text-emerald-400" : "text-zinc-600"
                      }`}
                    >
                      {item.key}
                    </span>
                    {item.label}
                  </button>
                ))}
              </div>
            </section>

            <Separator className="opacity-40" />

            {/* ------- Mosquée ------- */}
            <section>
              <Label className="text-xs font-semibold text-zinc-300">
                Mosquée actuelle
              </Label>
              <div className="mt-2 flex items-center justify-between rounded-lg border border-white/5 bg-zinc-900/60 px-3 py-2.5">
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold">{mosque.name}</p>
                  <p className="truncate font-mono text-[10px] text-zinc-500">
                    {mosque.slug}
                  </p>
                </div>
                <a
                  href={`https://mawaqit.net/fr/${mosque.slug}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="grid h-8 w-8 shrink-0 place-items-center rounded-lg text-zinc-500 transition-colors hover:bg-white/5 hover:text-zinc-200"
                  aria-label="Voir sur mawaqit.net"
                  title="Voir sur mawaqit.net"
                >
                  <ExternalLink className="h-4 w-4" />
                </a>
              </div>

              <Label
                htmlFor="mosque-search"
                className="mt-4 text-xs font-semibold text-zinc-300"
              >
                Rechercher une mosquée (nom, ville, code postal)
              </Label>
              <div className="relative mt-2">
                {searching ? (
                  <Loader2
                    className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 animate-spin text-emerald-400"
                    aria-hidden
                  />
                ) : (
                  <Search
                    className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-500"
                    aria-hidden
                  />
                )}
                <Input
                  id="mosque-search"
                  value={query}
                  onChange={(event) => setQuery(event.target.value)}
                  placeholder="ex. Versailles, 75011, essalam…"
                  className="border-white/10 bg-zinc-900/60 pl-9 pr-[6.6rem] text-sm placeholder:text-zinc-600"
                  autoComplete="off"
                />
                {/* Bouton « Autour de moi » : trie les résultats par distance */}
                <button
                  type="button"
                  onClick={locateMe}
                  aria-pressed={userPos !== null}
                  title={
                    userPos
                      ? "Position active — cliquer pour revenir à l'ordre de pertinence"
                      : "Trier les résultats par distance depuis ma position"
                  }
                  className={cn(
                    "absolute right-2 top-1/2 flex -translate-y-1/2 items-center gap-1 rounded-full border px-2 py-1 text-[10px] font-semibold transition-colors",
                    userPos
                      ? "border-emerald-500/60 bg-emerald-500/15 text-emerald-300"
                      : "border-white/10 bg-zinc-900 text-zinc-400 hover:border-white/25 hover:text-zinc-200",
                  )}
                >
                  {geoState === "locating" ? (
                    <>
                      <Loader2 className="h-2.5 w-2.5 animate-spin" aria-hidden />
                      Localisation…
                    </>
                  ) : (
                    <>
                      <LocateFixed
                        className={cn(
                          "h-2.5 w-2.5",
                          userPos && "animate-pulse",
                        )}
                        aria-hidden
                      />
                      Autour de moi
                    </>
                  )}
                </button>
              </div>

              {geoState !== "idle" && geoState !== "locating" && (
                <p className="mt-2 rounded-lg border border-amber-500/25 bg-amber-500/[0.07] px-2.5 py-1.5 text-[11px] leading-relaxed text-amber-200/80">
                  {geoState === "denied"
                    ? "Géolocalisation refusée — autorisez-la dans le navigateur pour trier par distance."
                    : "Géolocalisation indisponible sur cet appareil."}
                </p>
              )}

              {userPos && results !== null && results.length > 0 && (
                <p className="mt-2 text-[10px] text-zinc-500">
                  Triées par distance depuis votre position (les mosquées sans
                  coordonnées publiées sont en fin de liste).
                </p>
              )}

              {displayResults !== null && (
                <ul className="mt-2 space-y-1.5">
                  {displayResults.length === 0 && (
                    <li className="rounded-lg border border-white/5 bg-zinc-900/40 px-3 py-2.5 text-xs text-zinc-500">
                      {offline
                        ? "Recherche Mawaqit indisponible (hors ligne)."
                        : "Aucune mosquée trouvée pour cette recherche."}
                    </li>
                  )}
                  {displayResults.map((item) => {
                    const distance = distanceOf(item);
                    return (
                      <li key={item.slug}>
                        <button
                          type="button"
                          onClick={() => pick(item)}
                          className={`flex w-full items-center justify-between gap-2 rounded-lg border px-3 py-2.5 text-left transition-colors ${
                            selected === item.slug
                              ? "border-emerald-500/60 bg-emerald-500/15"
                              : "border-white/5 bg-zinc-900/40 hover:border-white/15 hover:bg-zinc-900/80"
                          }`}
                        >
                          <span className="min-w-0 flex-1">
                            <span className="block truncate text-[13px] font-semibold text-zinc-100">
                              {item.name}
                            </span>
                            <span className="mt-0.5 flex items-center gap-1 truncate text-[11px] text-zinc-500">
                              <MapPin className="h-3 w-3 shrink-0" aria-hidden />
                              {item.localisation || item.slug}
                            </span>
                          </span>
                          {distance !== null && (
                            <span className="shrink-0 rounded-full border border-emerald-500/40 bg-emerald-500/10 px-2 py-0.5 font-mono text-[10px] font-semibold tabular-nums text-emerald-300">
                              {formatNearbyDistance(distance)}
                            </span>
                          )}
                        </button>
                      </li>
                    );
                  })}
                </ul>
              )}
            </section>

            <Separator className="opacity-40" />

            {/* ------- Widget : plein écran ------- */}
            <section className="space-y-3">
              <Label className="flex items-center gap-1.5 text-xs font-semibold text-zinc-300">
                <Monitor className="h-3.5 w-3.5 text-emerald-400" aria-hidden />
                En plein écran
              </Label>
              <div className="flex items-center justify-between gap-3 rounded-lg border border-white/5 bg-zinc-900/60 px-3 py-2.5">
                <div>
                  <p className="text-[13px] font-medium text-zinc-200">
                    Le carré noir se masque
                  </p>
                  <p className="text-[11px] leading-relaxed text-zinc-500">
                    Quand la page passe en plein écran (vidéo, lecteur), le
                    carré se fait discret et revient à la sortie. Désactivé,
                    il reste affiché en permanence.
                  </p>
                </div>
                <Switch
                  checked={fullscreenHide}
                  onCheckedChange={setFullscreenHide}
                  aria-label="Masquer le carré noir en plein écran"
                />
              </div>
              <p className="text-[10.5px] leading-relaxed text-zinc-600">
                Même option que « Masquer en plein écran » de
                l&apos;application Windows (Paramètres → Widget) — pratique
                pendant un jeu ou un film.
              </p>
            </section>

            <Separator className="opacity-40" />

            {/* ------- Notifications (informatif web) ------- */}
            <section className="space-y-3">
              <Label className="text-xs font-semibold text-zinc-300">
                Notifications & sons
              </Label>
              <div className="flex items-center justify-between gap-3 rounded-lg border border-white/5 bg-zinc-900/60 px-3 py-2.5">
                <div>
                  <p className="text-[13px] font-medium text-zinc-200">
                    Rappel 15 min avant + adhan
                  </p>
                  <p className="text-[11px] leading-relaxed text-zinc-500">
                    Dans l&apos;application Windows : toasts natifs, adhan
                    (<code className="text-[10px]">adhan.mp3</code>) ou bip discret.
                  </p>
                </div>
                <Switch checked disabled aria-label="Activé dans l'application" />
              </div>
            </section>

            {isManager && (
              <>
                <Separator className="opacity-40" />

                {/* ------- Ambiance focus (gérant) ------- */}
                <section className="space-y-3">
                  <Label className="text-xs font-semibold text-zinc-300">
                    Ambiance par défaut du Mode Focus
                  </Label>
                  <div className="flex gap-1.5">
                    {(["none", "white", "rain"] as const).map((kind) => (
                      <Button
                        key={kind}
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => setFocusSound(kind)}
                        className={`h-8 flex-1 border-white/10 text-[11px] ${
                          focusSound === kind
                            ? "border-emerald-500/60 bg-emerald-500/15 text-emerald-300 hover:bg-emerald-500/20 hover:text-emerald-200"
                            : "bg-zinc-900/60 text-zinc-400 hover:bg-zinc-900 hover:text-zinc-200"
                        }`}
                      >
                        {kind === "none" ? "Aucun" : kind === "white" ? "Bruit blanc" : "Pluie"}
                      </Button>
                    ))}
                  </div>
                  {focusSound !== "none" && (
                    <div className="flex items-center gap-3 px-1">
                      <Slider
                        value={[Math.round(focusVolume * 100)]}
                        min={0}
                        max={100}
                        step={5}
                        onValueChange={([value]) => setFocusVolume(value / 100)}
                        aria-label="Volume de l'ambiance"
                      />
                      <span className="w-10 shrink-0 text-right font-mono text-[11px] tabular-nums text-zinc-500">
                        {Math.round(focusVolume * 100)}%
                      </span>
                    </div>
                  )}
                </section>
              </>
            )}

            <p className="flex items-start gap-2 rounded-lg border border-emerald-500/20 bg-emerald-500/5 px-3 py-2.5 text-[11px] leading-relaxed text-emerald-200/80">
              <Sparkles className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden />
              Astuce : dans l&apos;application, ces réglages vivent dans
              <code className="text-[10px] text-emerald-300">config.json</code>
              avec la position du widget, le raccourci et le démarrage
              automatique de Windows.
            </p>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
