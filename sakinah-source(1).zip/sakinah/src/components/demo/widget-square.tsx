/**
 * Le carré noir — replica web du widget overlay de l'application.
 *
 *  * ancré en haut à droite de la fenêtre (comme sous Windows) ;
 *  * déplaçable au doigt / à la souris (pointer events), position
 *    persistée dans le store ;
 *  * un clic (sans déplacement) ouvre la pop-up ;
 *  * point d'état central : émeraude (OK), ambre pulsant si la prochaine
 *    prière arrive dans moins de 15 minutes, gris si horaires absents.
 */

"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useDemoStore } from "@/lib/demo-store";
import { computeNextPrayer, useNow } from "@/lib/prayer-utils";

const SIZE = 40;
const MARGIN = 14;

export function WidgetSquare() {
  const visible = useDemoStore((state) => state.widgetVisible);
  const pos = useDemoStore((state) => state.widgetPos);
  const setWidgetPos = useDemoStore((state) => state.setWidgetPos);
  const openPopup = useDemoStore((state) => state.openPopup);
  const prayers = useDemoStore((state) => state.prayers);
  const fullscreenHide = useDemoStore((state) => state.fullscreenHide);

  const [mounted, setMounted] = useState(false);
  /** Un élément de la page (ou la page entière) est en plein écran. */
  const [pageFullscreen, setPageFullscreen] = useState(false);
  const dragRef = useRef<{
    pointerId: number;
    startX: number;
    startY: number;
    originX: number;
    originY: number;
    moved: boolean;
  } | null>(null);

  // Position par défaut : coin haut-droit (sous l'en-tête sur mobile).
  useEffect(() => {
    setMounted(true);
    if (!useDemoStore.getState().widgetPos) {
      const isMobile = window.innerWidth < 1024;
      setWidgetPos({
        x: window.innerWidth - SIZE - MARGIN,
        y: isMobile ? 84 : MARGIN + 4,
      });
    }
  }, [setWidgetPos]);

  // Recale le carré au montage ET au redimensionnement : il ne doit jamais
  // sortir de l'écran ni chevaucher l'en-tête sur mobile (même comportement
  // que le clamping de drag de l'application Windows).
  useEffect(() => {
    const clamp = () => {
      const pos = useDemoStore.getState().widgetPos;
      if (!pos) return;
      const vw = window.innerWidth;
      const vh = window.innerHeight;
      const minY = vw < 1024 ? 84 : 8;   // sous l'en-tête sur mobile
      const x = Math.min(Math.max(8, pos.x), vw - SIZE - 8);
      const y = Math.min(Math.max(minY, pos.y), vh - SIZE - 8);
      if (x !== pos.x || y !== pos.y) {
        setWidgetPos({ x, y });
      }
    };
    clamp();
    window.addEventListener("resize", clamp);
    return () => window.removeEventListener("resize", clamp);
  }, [setWidgetPos]);

  // « Masquer en plein écran » (option des paramètres) : quand un élément
  // passe en plein écran via l'API Fullscreen (vidéo, lecteur, page
  // entière), le carré se fait discret — il revient dès la sortie. C'est
  // l'équivalent web du masquage automatique devant un jeu de l'app Windows.
  useEffect(() => {
    const onChange = () => setPageFullscreen(document.fullscreenElement !== null);
    document.addEventListener("fullscreenchange", onChange);
    onChange();
    return () => document.removeEventListener("fullscreenchange", onChange);
  }, []);

  // Prochaine prière + décompte live (re-render chaque seconde).
  const now = useNow(1000);
  const next = useMemo(
    () =>
      prayers
        ? computeNextPrayer(prayers.times, prayers.tomorrowFajr, prayers.timezone)
        : null,
    [prayers],
  );
  const remainingSec = next
    ? Math.max(0, Math.round((next.datetime.getTime() - now.getTime()) / 1000))
    : null;

  const soon = next !== null && remainingSec !== null && remainingSec <= 15 * 60;
  const dotClass = !next
    ? "bg-zinc-600"
    : soon
      ? "bg-amber-400 animate-pulse"
      : "bg-emerald-400";

  // ---------------------------------------------------------------- drag
  const onPointerDown = (event: React.PointerEvent<HTMLButtonElement>) => {
    const current = useDemoStore.getState().widgetPos ?? { x: 0, y: 0 };
    dragRef.current = {
      pointerId: event.pointerId,
      startX: event.clientX,
      startY: event.clientY,
      originX: current.x,
      originY: current.y,
      moved: false,
    };
    event.currentTarget.setPointerCapture(event.pointerId);
  };

  const onPointerMove = (event: React.PointerEvent<HTMLButtonElement>) => {
    const drag = dragRef.current;
    if (!drag || drag.pointerId !== event.pointerId) return;
    const dx = event.clientX - drag.startX;
    const dy = event.clientY - drag.startY;
    if (Math.abs(dx) + Math.abs(dy) > 6) drag.moved = true;
    if (!drag.moved) return;
    const x = Math.min(
      Math.max(8, drag.originX + dx),
      window.innerWidth - SIZE - 8,
    );
    const y = Math.min(
      Math.max(8, drag.originY + dy),
      window.innerHeight - SIZE - 8,
    );
    setWidgetPos({ x, y });
  };

  const onPointerUp = (event: React.PointerEvent<HTMLButtonElement>) => {
    const drag = dragRef.current;
    dragRef.current = null;
    if (event.currentTarget.hasPointerCapture(event.pointerId)) {
      event.currentTarget.releasePointerCapture(event.pointerId);
    }
    if (drag && !drag.moved) {
      openPopup(); // simple clic (gauche… ou droit : mêmes actions)
    }
  };

  if (!mounted || !visible || !pos) return null;
  // Option « Masquer le carré en plein écran » active + page en plein écran.
  if (pageFullscreen && fullscreenHide) return null;

  return (
    <AnimatePresence>
      <motion.button
        key="sakinah-widget"
        type="button"
        aria-label="Sakinah — ouvrir le widget (H pour masquer)"
        title="Sakinah — cliquez pour ouvrir · glissez pour déplacer · H pour masquer"
        initial={{ opacity: 0, scale: 0.6 }}
        animate={{ opacity: 1, scale: 1 }}
        whileHover={{ scale: 1.08 }}
        whileTap={{ scale: 0.92 }}
        exit={{ opacity: 0, scale: 0.6 }}
        transition={{ type: "spring", stiffness: 400, damping: 26 }}
        className="fixed z-[70] grid h-10 w-10 cursor-pointer touch-none select-none place-items-center rounded-xl border border-white/10 bg-[#0a0a0b] shadow-lg shadow-black/50 outline-none transition-shadow duration-200 hover:border-white/25 hover:shadow-xl hover:shadow-emerald-500/10 focus-visible:ring-2 focus-visible:ring-emerald-400/70"
        style={{ left: pos.x, top: pos.y }}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onContextMenu={(event) => event.preventDefault()}
      >
        <span className={`h-[5px] w-[5px] rounded-full ${dotClass}`} />
      </motion.button>
    </AnimatePresence>
  );
}
