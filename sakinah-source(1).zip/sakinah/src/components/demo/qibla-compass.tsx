/**
 * Boussole Qibla de la démo — indique le cap vers la Kaaba :
 *  * par défaut, depuis la mosquée choisie (coordonnées /api/prayers) ;
 *  * sur demande, depuis VOTRE position (géolocalisation navigateur) pour
 *    un cap exact là où vous êtes — bouton « Utiliser ma position ».
 *
 * L'aiguille pivote en douceur (rotation par le plus court chemin) et le
 * marqueur Kaaba reste au centre. L'orientation magnétique en temps réel
 * dépend du capteur de l'appareil — l'application Windows affiche le même
 * cap depuis les coordonnées de votre mosquée.
 */

"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { Compass, LocateFixed, Loader2, MapPin, RotateCcw } from "lucide-react";
import {
  cardinalLabel,
  formatDistance,
  kaabaDistanceKm,
  qiblaBearing,
} from "@/lib/qibla";
import { cn } from "@/lib/utils";

interface QiblaCompassProps {
  latitude?: number | null;
  longitude?: number | null;
  mosqueName?: string | null;
}

/** Angle cible ajusté pour tourner par le plus court chemin (±180°). */
function shortestAngle(from: number, to: number): number {
  let delta = (to - from) % 360;
  if (delta > 180) delta -= 360;
  if (delta < -180) delta += 360;
  return from + delta;
}

type GeoStatus = "idle" | "requesting" | "granted" | "denied" | "error";

export function QiblaCompass({ latitude, longitude, mosqueName }: QiblaCompassProps) {
  // Position de l'utilisateur (mode « depuis ma position »).
  const [userPos, setUserPos] = useState<{ lat: number; lng: number; accuracy: number } | null>(null);
  const [geoStatus, setGeoStatus] = useState<GeoStatus>("idle");

  const hasMosqueCoords =
    typeof latitude === "number" &&
    typeof longitude === "number" &&
    Number.isFinite(latitude) &&
    Number.isFinite(longitude);
  const useUser = userPos !== null;

  // Coordonnées actives : position de l'utilisateur si demandée, sinon mosquée.
  const activeLat = useUser ? userPos.lat : hasMosqueCoords ? latitude : null;
  const activeLng = useUser ? userPos.lng : hasMosqueCoords ? longitude : null;

  const data = useMemo(() => {
    if (typeof activeLat !== "number" || typeof activeLng !== "number") {
      return null;
    }
    const bearing = qiblaBearing(activeLat, activeLng);
    return {
      bearing,
      cardinal: cardinalLabel(bearing),
      distance: kaabaDistanceKm(activeLat, activeLng),
    };
  }, [activeLat, activeLng]);

  // Rotation animée : l'angle affiché rejoint le cap par le plus court chemin.
  const targetBearing = data?.bearing ?? null;
  const [displayAngle, setDisplayAngle] = useState<number | null>(null);
  const angleRef = useRef<number>(0);
  useEffect(() => {
    if (targetBearing === null) return;
    const target = shortestAngle(angleRef.current, targetBearing);
    angleRef.current = target;
    setDisplayAngle(target);
  }, [targetBearing]);

  if (!data) return null;

  const { bearing, cardinal, distance } = data;

  /** Demande la position du navigateur (permission à la volée). */
  const requestPosition = () => {
    if (!("geolocation" in navigator)) {
      setGeoStatus("error");
      return;
    }
    setGeoStatus("requesting");
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setUserPos({
          lat: position.coords.latitude,
          lng: position.coords.longitude,
          accuracy: position.coords.accuracy,
        });
        setGeoStatus("granted");
      },
      (error) => {
        setGeoStatus(error.code === error.PERMISSION_DENIED ? "denied" : "error");
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 },
    );
  };

  const backToMosque = () => {
    setUserPos(null);
    setGeoStatus("idle");
  };

  const geoAvailable = typeof window !== "undefined" && "geolocation" in navigator;

  return (
    <section
      aria-label="Direction de la Qibla"
      className="rounded-xl border border-white/5 bg-zinc-900/60 p-3.5"
    >
      <div className="flex items-center justify-between">
        <p className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-[0.18em] text-emerald-400">
          <Compass className="h-3 w-3" aria-hidden />
          Qibla
        </p>
        <p className="flex items-center gap-1.5 text-[10px] text-zinc-600">
          {useUser && (
            <span className="relative flex h-1.5 w-1.5" aria-hidden>
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-60" />
              <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-emerald-400" />
            </span>
          )}
          {useUser ? "depuis votre position" : "depuis votre mosquée"}
        </p>
      </div>

      <div className="mt-2 flex items-center gap-3.5">
        {/* ------- Rose des vents SVG ------- */}
        <svg
          viewBox="0 0 120 120"
          className="h-[92px] w-[92px] shrink-0"
          role="img"
          aria-label={`Boussole : Qibla à ${Math.round(bearing)} degrés, direction ${cardinal}, depuis ${useUser ? "votre position" : mosqueName ?? "votre mosquée"}`}
        >
          <defs>
            <linearGradient id="qibla-ring" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#10b981" stopOpacity="0.35" />
              <stop offset="100%" stopColor="#059669" stopOpacity="0.08" />
            </linearGradient>
            <filter id="qibla-needle-glow" x="-40%" y="-40%" width="180%" height="180%">
              <feDropShadow dx="0" dy="0" stdDeviation="2.4" floodColor="#10b981" floodOpacity="0.55" />
            </filter>
          </defs>

          {/* Cadran */}
          <circle cx="60" cy="60" r="55" fill="url(#qibla-ring)" stroke="rgba(255,255,255,0.08)" strokeWidth="1" />
          <circle cx="60" cy="60" r="44" fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="1" />

          {/* Graduations tous les 30° */}
          {Array.from({ length: 12 }, (_, i) => {
            const angle = (i * 30 * Math.PI) / 180;
            const x1 = 60 + 48 * Math.sin(angle);
            const y1 = 60 - 48 * Math.cos(angle);
            const x2 = 60 + 54 * Math.sin(angle);
            const y2 = 60 - 54 * Math.cos(angle);
            return (
              <line
                key={i}
                x1={x1} y1={y1} x2={x2} y2={y2}
                stroke="rgba(255,255,255,0.18)"
                strokeWidth={i % 3 === 0 ? 2 : 1}
              />
            );
          })}

          {/* Points cardinaux français */}
          <text x="60" y="20" textAnchor="middle" fill="#a1a1aa" fontSize="10" fontWeight="700">N</text>
          <text x="103" y="63.5" textAnchor="middle" fill="#71717a" fontSize="9">E</text>
          <text x="60" y="107" textAnchor="middle" fill="#71717a" fontSize="9">S</text>
          <text x="17" y="63.5" textAnchor="middle" fill="#71717a" fontSize="9">O</text>

          {/* Aiguille vers la Qibla — rotation douce par le plus court chemin */}
          <g
            style={{
              transform: displayAngle === null ? `rotate(${bearing}deg)` : `rotate(${displayAngle}deg)`,
              transformOrigin: "60px 60px",
              transformBox: "view-box",
              transition: "transform 800ms cubic-bezier(0.3, 1.2, 0.5, 1)",
            }}
          >
            {/* Halo de l'aiguille */}
            <polygon
              points="60,18 56,60 60,54 64,60"
              fill="#10b981"
              stroke="rgba(16,185,129,0.5)"
              strokeWidth="0.5"
              filter="url(#qibla-needle-glow)"
            />
            {/* Contre-aiguille discrète */}
            <polygon points="60,96 58,60 62,60" fill="rgba(255,255,255,0.14)" />
          </g>

          {/* Kaaba au centre */}
          <rect x="54" y="54" width="12" height="12" rx="2" fill="#18181b" stroke="rgba(16,185,129,0.55)" strokeWidth="1.2" />
          <line x1="54.5" y1="58" x2="65.5" y2="58" stroke="#d4af37" strokeWidth="1.6" strokeLinecap="round" />

          {/* Moyeu */}
          <circle cx="60" cy="60" r="2.2" fill="#f4f4f5" />
        </svg>

        {/* ------- Chiffres ------- */}
        <div className="min-w-0 flex-1">
          <p className="text-2xl font-extrabold tracking-tight text-zinc-100">
            {Math.round(bearing)}°
            <span className="ml-1.5 text-sm font-semibold text-emerald-400">
              {cardinal}
            </span>
          </p>
          <p className="mt-1 truncate text-xs leading-relaxed text-zinc-400">
            Cap vers la Kaaba depuis{" "}
            <span className="text-zinc-300">
              {useUser ? "votre position" : (mosqueName ?? "votre mosquée")}
            </span>
          </p>
          <p className="mt-1.5 text-[11px] text-zinc-600">
            ≈ {formatDistance(distance)} à vol d&apos;oiseau
            {useUser && userPos && (
              <span className="text-zinc-600">
                {" "}· précision ±{Math.round(userPos.accuracy)} m
              </span>
            )}
          </p>

          {/* ------- Bascule mosquée / position ------- */}
          <div className="mt-2.5 flex flex-wrap gap-1.5">
            {!useUser ? (
              <button
                type="button"
                onClick={requestPosition}
                disabled={geoStatus === "requesting" || !geoAvailable}
                className={cn(
                  "flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[10px] font-semibold transition-colors",
                  geoStatus === "requesting" || !geoAvailable
                    ? "cursor-not-allowed border-white/5 text-zinc-600"
                    : "border-emerald-500/30 bg-emerald-500/5 text-emerald-300 hover:border-emerald-400/50 hover:bg-emerald-500/10",
                )}
                aria-label="Utiliser ma position pour un cap exact"
              >
                {geoStatus === "requesting" ? (
                  <Loader2 className="h-3 w-3 animate-spin" aria-hidden />
                ) : (
                  <LocateFixed className="h-3 w-3" aria-hidden />
                )}
                Utiliser ma position
              </button>
            ) : (
              <button
                type="button"
                onClick={backToMosque}
                className="flex items-center gap-1.5 rounded-full border border-white/10 bg-zinc-900 px-2.5 py-1 text-[10px] font-semibold text-zinc-300 transition-colors hover:border-white/20 hover:text-zinc-100"
                aria-label="Revenir au cap calculé depuis la mosquée"
              >
                <RotateCcw className="h-3 w-3" aria-hidden />
                Revenir à la mosquée
              </button>
            )}
          </div>

          {/* ------- États de la géolocalisation ------- */}
          {geoStatus === "denied" && (
            <p className="mt-2 flex items-start gap-1.5 text-[10px] leading-relaxed text-amber-400/90">
              <MapPin className="mt-0.5 h-3 w-3 shrink-0" aria-hidden />
              Géolocalisation refusée — le cap reste calculé depuis votre
              mosquée.
            </p>
          )}
          {geoStatus === "error" && (
            <p className="mt-2 flex items-start gap-1.5 text-[10px] leading-relaxed text-amber-400/90">
              <MapPin className="mt-0.5 h-3 w-3 shrink-0" aria-hidden />
              Position indisponible — le cap reste calculé depuis votre
              mosquée.
            </p>
          )}
        </div>
      </div>
    </section>
  );
}
