/**
 * Onglet « Prières » de la démo — replica web de app/ui/prayers_tab.py :
 *  * carte mosquée (nom, slug, date FR + hégirienne, Jumu'a le vendredi) ;
 *  * bannière « prochaine prière » avec compte à rebours à la seconde ;
 *  * les 6 horaires du jour + iqama (prière en commun) en sous-libellé,
 *    Chourouk grisé (ce n'est pas une prière), prochaine surlignée ;
 *  * bouton « copier les horaires du jour » (presse-papiers) ;
 *  * rappels navigateur (15 min avant + à l'heure, Notification API) ;
 *  * boussole Qibla (cap + distance depuis les coordonnées de la mosquée) ;
 *  * calendrier mensuel dépliable (calendrier annuel Mawaqit) ;
 *  * encadré bonus « Dhikr du moment » (aléatoire, bouton « Un autre ») ;
 *  * badge « hors-ligne » + repli sur les données d'exemple.
 */

"use client";

import { useMemo, useState } from "react";
import {
  BadgeCheck,
  CalendarClock,
  Check,
  CloudOff,
  Copy,
  Globe2,
  Loader2,
  MapPin,
  Moon,
  MoonStar,
  RefreshCw,
  Share2,
  Shuffle,
} from "lucide-react";
import { useDemoStore } from "@/lib/demo-store";
import {
  ONBOARDING_REGION_KEYS,
  regionByKey,
} from "@/lib/regions";
import {
  PRAYERS,
  computeNextPrayer,
  formatRemaining,
  hijriToday,
  normalizeTime,
  ramadanInfo,
  timeToSeconds,
  zoneClock,
  useNow,
} from "@/lib/prayer-utils";
import { DHIKRS } from "@/lib/sample-data";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import { NotificationsToggle } from "@/components/demo/notifications-toggle";
import { QiblaCompass } from "@/components/demo/qibla-compass";
import { MonthCalendar } from "@/components/demo/month-calendar";
import { CompareCard } from "@/components/demo/compare-card";
import { TasbihCounter } from "@/components/demo/tasbih-counter";

/** Date du jour en français (à l'horloge de la mosquée si connue). */
function frenchToday(timezone?: string | null): string {
  try {
    const text = new Intl.DateTimeFormat("fr-FR", {
      weekday: "long",
      day: "numeric",
      month: "long",
      year: "numeric",
      ...(timezone ? { timeZone: timezone } : {}),
    }).format(new Date());
    return text.charAt(0).toUpperCase() + text.slice(1);
  } catch {
    return "";
  }
}

/** Prochaine Jumu'a : « aujourd'hui », « demain » ou « dans N jours » + heure (à l'horloge de la mosquée). */
function nextJumua(
  jumua: string | null | undefined,
  timezone?: string | null,
): string | null {
  const jumuaSec = timeToSeconds(jumua);
  if (jumuaSec === null) return null;
  const clock = zoneClock(timezone);
  const localNow = clock ? null : new Date();
  const weekday = clock ? clock.weekday : localNow!.getDay();
  const nowSec = clock
    ? clock.sec
    : localNow!.getHours() * 3600 +
      localNow!.getMinutes() * 60 +
      localNow!.getSeconds();
  let days = (5 - weekday + 7) % 7; // 0 si aujourd'hui vendredi
  if (days === 0 && jumuaSec <= nowSec) days = 7; // déjà passée
  const time = normalizeTime(jumua!);
  if (days === 0) return `aujourd'hui à ${time}`;
  if (days === 1) return `demain à ${time}`;
  return `dans ${days} jours · à ${time}`;
}

/** « il y a 2 h 05 », « il y a 12 min »… */
function formatElapsed(seconds: number): string {
  const total = Math.max(0, Math.floor(seconds));
  const hours = Math.floor(total / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  if (hours > 0) return `il y a ${hours} h ${String(minutes).padStart(2, "0")}`;
  if (minutes > 0) return `il y a ${minutes} min`;
  return `il y a ${total} s`;
}

export function PrayersTabDemo() {
  const prayers = useDemoStore((state) => state.prayers);
  const status = useDemoStore((state) => state.prayersStatus);
  const mosque = useDemoStore((state) => state.mosque);
  const refreshPrayers = useDemoStore((state) => state.refreshPrayers);
  const setSettingsOpen = useDemoStore((state) => state.setSettingsOpen);
  const region = useDemoStore((state) => state.region);
  const setRegion = useDemoStore((state) => state.setRegion);

  const [dhikrIndex, setDhikrIndex] = useState(() =>
    Math.floor(Math.random() * DHIKRS.length),
  );
  const [copyState, setCopyState] = useState<"idle" | "done" | "failed">("idle");
  const [shareState, setShareState] = useState<"idle" | "done" | "failed">(
    "idle",
  );
  /** Web Share API disponible ? (progressive enhancement — sinon copie) */
  const [canShare] = useState(
    () => typeof navigator !== "undefined" && typeof navigator.share === "function",
  );

  const now = useNow(1000);
  const next = useMemo(
    () =>
      prayers
        ? computeNextPrayer(prayers.times, prayers.tomorrowFajr, prayers.timezone)
        : null,
    [prayers],
  );
  const remaining = next
    ? Math.max(0, (next.datetime.getTime() - now.getTime()) / 1000)
    : null;

  // Horloge du jour : fuseau de la mosquée si connu, sinon navigateur.
  const clock = zoneClock(prayers?.timezone, now);
  const nowSec = clock
    ? clock.sec
    : now.getHours() * 3600 + now.getMinutes() * 60 + now.getSeconds();

  // Prière précédente (ancre du fil de progression) — dernière du jour
  // déjà passée, sinon minuit. Recalculé à chaque seconde : 6 comparaisons.
  const prev = (() => {
    if (!prayers) return null;
    let best: { label: string; time: string; sec: number } | null = null;
    for (const prayer of PRAYERS) {
      const sec = timeToSeconds(prayers.times?.[prayer.key]);
      if (sec === null || sec > nowSec) continue;
      if (!best || sec >= best.sec) {
        best = {
          label: prayer.label,
          time: normalizeTime(prayers.times?.[prayer.key] ?? ""),
          sec,
        };
      }
    }
    if (best) return best;
    return { label: "minuit", time: "00:00", sec: 0 };
  })();

  // Fraction écoulée entre la prière précédente et la prochaine
  // (en secondes du jour, à l'horloge de la mosquée).
  const nextSec = next ? timeToSeconds(next.time) : null;
  const progress =
    next && prev && nextSec !== null
      ? Math.min(1, Math.max(0, (nowSec - prev.sec) / (nextSec - prev.sec)))
      : 0;

  const jumuaInfo = nextJumua(prayers?.jumua, prayers?.timezone);

  // Ramadan : « jour N » si en cours, sinon compte à rebours (umalqura).
  // Appelé à chaque rendu mais MÉMOÏSÉ en interne par jour civil + fuseau
  // (ramadanInfo) : le balayage ne tourne qu'une fois par jour.
  const ramadan = ramadanInfo(now, prayers?.timezone);

  const rollDhikr = () => {
    setDhikrIndex((current) => {
      let candidate = current;
      while (candidate === current && DHIKRS.length > 1) {
        candidate = Math.floor(Math.random() * DHIKRS.length);
      }
      return candidate;
    });
  };

  const dhikr = DHIKRS[dhikrIndex];
  const isFriday = clock ? clock.weekday === 5 : now.getDay() === 5;
  const loading = status === "loading" || (status === "idle" && !prayers);

  /** Texte compact des horaires du jour (« Fajr 06:03 · Dhuhr 13:49 · … »). */
  const buildScheduleText = () => {
    if (!prayers) return "";
    const parts = PRAYERS.map(
      (p) => `${p.label} ${prayers.times?.[p.key] ?? "--:--"}`,
    );
    const jumua = prayers.jumua ? ` · Jumu'a ${prayers.jumua}` : "";
    return `Horaires ${prayers.name} — ${parts.join(" · ")}${jumua} (mawaqit.net)`;
  };

  /** Copie un texte dans le presse-papiers (Clipboard API puis execCommand).
   *  Retourne true si la copie a réussi. */
  const copyToClipboard = async (text: string): Promise<boolean> => {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      /* Clipboard API refusée → repli execCommand */
    }
    try {
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.setAttribute("readonly", "");
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      const ok = document.execCommand("copy");
      document.body.removeChild(ta);
      return ok;
    } catch {
      return false;
    }
  };

  /** Copie les horaires du jour dans le presse-papiers. */
  const copySchedule = async () => {
    if (!prayers) return;
    const ok = await copyToClipboard(buildScheduleText());
    setCopyState(ok ? "done" : "failed");
    setTimeout(() => setCopyState("idle"), 2200);
  };

  /** Partage natif des horaires (Web Share API) — l'annulation par
   *  l'utilisateur n'affiche AUCUN état (comportement attendu). */
  const shareSchedule = async () => {
    if (!prayers) return;
    try {
      await navigator.share({
        title: `Horaires — ${prayers.name}`,
        text: buildScheduleText(),
      });
      setShareState("done");
      setTimeout(() => setShareState("idle"), 2200);
    } catch (error) {
      // AbortError = panneau fermé sans partager → silencieux.
      if (error instanceof DOMException && error.name === "AbortError") return;
      setShareState("failed");
      setTimeout(() => setShareState("idle"), 2200);
    }
  };

  return (
    <ScrollArea className="h-full">
      <div className="space-y-3 p-4">
        {/* ------- Bandeau région (première ouverture) ------- */}
        {region === null && (
          <section className="rounded-xl border border-emerald-500/25 bg-gradient-to-b from-emerald-500/10 to-transparent p-3.5">
            <p className="flex items-center gap-1.5 text-[12px] font-bold text-emerald-300">
              <Globe2 className="h-3.5 w-3.5 shrink-0" aria-hidden />
              Dans quelle région cherchez-vous votre mosquée ?
            </p>
            <p className="mt-1 text-[11px] leading-relaxed text-zinc-400">
              Les mosquées de votre région passeront en premier dans la
              recherche. Modifiable à tout moment dans les paramètres.
            </p>
            <div
              role="radiogroup"
              aria-label="Choisir une région"
              className="mt-2.5 flex flex-wrap gap-1.5"
            >
              {ONBOARDING_REGION_KEYS.map((key) => {
                const item = regionByKey(key);
                if (!item) return null;
                return (
                  <button
                    key={key}
                    type="button"
                    onClick={() => setRegion(key)}
                    className="flex min-h-8 items-center gap-1.5 rounded-full border border-white/10 bg-zinc-900/70 px-2.5 text-[11px] font-semibold text-zinc-300 transition-colors hover:border-emerald-500/50 hover:bg-emerald-500/10 hover:text-emerald-300"
                  >
                    <span className="font-mono text-[9px] tracking-wide text-emerald-400/80">
                      {item.key}
                    </span>
                    {item.label}
                  </button>
                );
              })}
              <button
                type="button"
                onClick={() => setRegion("all")}
                className="min-h-8 rounded-full border border-white/10 bg-zinc-900/70 px-2.5 text-[11px] font-semibold text-zinc-400 transition-colors hover:border-white/25 hover:text-zinc-200"
              >
                Toutes les régions
              </button>
            </div>
            <button
              type="button"
              onClick={() => setRegion("all")}
              className="mt-2 text-[10.5px] font-medium text-zinc-600 underline-offset-2 transition-colors hover:text-zinc-400 hover:underline"
            >
              Choisir plus tard
            </button>
          </section>
        )}

        {/* ------- Carte mosquée ------- */}
        <section className="rounded-xl border border-white/5 bg-zinc-900/60 p-3.5">
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0 flex-1">
              {loading ? (
                <Skeleton className="h-5 w-44" />
              ) : (
                <h3 className="truncate text-sm font-bold">
                  {prayers?.name ?? mosque.name}
                </h3>
              )}
              <p className="mt-0.5 flex items-center gap-1 truncate text-[11px] text-zinc-500">
                <MapPin className="h-3 w-3 shrink-0" aria-hidden />
                {prayers?.slug ?? mosque.slug}
              </p>
            </div>
            <div className="flex shrink-0 gap-1">
              <Button
                variant="ghost"
                size="sm"
                className="h-7 px-2 text-[11px] text-zinc-400 hover:text-zinc-100"
                onClick={refreshPrayers}
                disabled={loading}
                aria-label="Actualiser les horaires"
              >
                {loading ? (
                  <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden />
                ) : (
                  <RefreshCw className="h-3.5 w-3.5" aria-hidden />
                )}
                <span className="hidden sm:inline">Actualiser</span>
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="h-7 px-2 text-[11px] text-zinc-400 hover:text-zinc-100"
                onClick={() => setSettingsOpen(true)}
              >
                Changer
              </Button>
            </div>
          </div>
          <Separator className="my-2.5 opacity-40" />
          <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-[11px]">
            <span className="text-emerald-400">{frenchToday(prayers?.timezone)}</span>
            <span className="text-zinc-600">·</span>
            <span className="text-zinc-500">{hijriToday(prayers?.timezone)}</span>
            {isFriday && prayers?.jumua && (
              <Badge className="h-5 bg-emerald-500/15 px-2 text-[10px] font-semibold text-emerald-300 hover:bg-emerald-500/15">
                Jumu&apos;a · {prayers.jumua}
              </Badge>
            )}
            {status === "sample" && (
              <Badge className="h-5 bg-amber-500/15 px-2 text-[10px] font-semibold text-amber-300 hover:bg-amber-500/15">
                <CloudOff className="mr-1 h-3 w-3" aria-hidden />
                Hors ligne — exemple
              </Badge>
            )}
            {status === "cache" && (
              <Badge
                className="h-5 bg-amber-500/15 px-2 text-[10px] font-semibold text-amber-300 hover:bg-amber-500/15"
                title={
                  prayers?.dayAfterCache
                    ? "Hors ligne depuis minuit : horaires du jour reconstitués depuis la ligne de demain mise en cache hier."
                    : "Hors ligne : derniers horaires connus de votre mosquée."
                }
              >
                <CloudOff className="mr-1 h-3 w-3" aria-hidden />
                {prayers?.dayAfterCache
                  ? "Hors ligne — horaires J+1 en cache"
                  : "Hors ligne — en cache"}
              </Badge>
            )}
            {status === "live" && (
              <Badge className="h-5 bg-emerald-500/10 px-2 text-[10px] font-medium text-emerald-400/90 hover:bg-emerald-500/10">
                <BadgeCheck className="mr-1 h-3 w-3" aria-hidden />
                Mawaqit live
              </Badge>
            )}
            {/* Fraîcheur des données (re-rendu chaque seconde via useNow) —
                rend visible la synchro de minuit et le bouton Actualiser. */}
            {(status === "live" || status === "cache") &&
              prayers?.fetchedAt &&
              !loading && (
                <span
                  className="flex items-center gap-1 text-[10px] tabular-nums text-zinc-500"
                  title={`Dernière synchronisation Mawaqit : ${new Date(
                    prayers.fetchedAt,
                  ).toLocaleString("fr-FR")}`}
                >
                  <span
                    aria-hidden
                    className={
                      status === "live"
                        ? "size-1.5 rounded-full bg-emerald-400/80 motion-safe:animate-pulse"
                        : "size-1.5 rounded-full bg-zinc-600"
                    }
                  />
                  synchro{" "}
                  {formatElapsed(
                    (now.getTime() - Date.parse(prayers.fetchedAt)) / 1000,
                  )}
                  {status === "cache" ? " (cache)" : ""}
                </span>
              )}
          </div>
          {jumuaInfo && (
            <p className="mt-1.5 flex items-center gap-1.5 text-[11px] text-zinc-400">
              <CalendarClock className="h-3 w-3 shrink-0 text-emerald-400/80" aria-hidden />
              Prochaine Jumu&apos;a&nbsp;: {" "}
              <span className="font-semibold text-zinc-300">{jumuaInfo}</span>
            </p>
          )}
          {/* Ramadan : jour N en cours, sinon compte à rebours (umalqura). */}
          {ramadan && !loading && (
            <p
              className={
                ramadan.inProgress
                  ? "mt-1.5 flex items-center gap-1.5 text-[11px] text-amber-200"
                  : "mt-1.5 flex items-center gap-1.5 text-[11px] text-zinc-400"
              }
            >
              <Moon
                className={
                  ramadan.inProgress
                    ? "h-3 w-3 shrink-0 text-amber-300"
                    : "h-3 w-3 shrink-0 text-zinc-500"
                }
                aria-hidden
              />
              {ramadan.inProgress ? (
                <>
                  Ramadan {ramadan.hijriYear}&nbsp;:{" "}
                  <span className="font-semibold">
                    jour {ramadan.dayOfRamadan}
                  </span>{" "}
                  — Ramadan moubarak&nbsp;!
                </>
              ) : (
                <>
                  Ramadan {ramadan.hijriYear}&nbsp;:{" "}
                  <span className="font-semibold text-zinc-300">
                    dans {ramadan.daysLeft} jour{ramadan.daysLeft > 1 ? "s" : ""}
                  </span>{" "}
                  (vers le{" "}
                  {ramadan.startsOn
                    ? ramadan.startsOn.toLocaleDateString("fr-FR", {
                        day: "numeric",
                        month: "long",
                      })
                    : "—"}
                  )
                </>
              )}
            </p>
          )}
        </section>

        {/* ------- Bannière prochaine prière ------- */}
        <section
          className="rounded-xl border border-emerald-500/30 bg-gradient-to-br from-emerald-950/80 to-emerald-900/40 p-3.5"
          aria-label={
            next
              ? `Prochaine prière : ${next.label} à ${next.time}${
                  next.isTomorrow ? " demain" : ""
                }`
              : "Prochaine prière"
          }
        >
          <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-emerald-300/90">
            Prochaine prière
          </p>
          {loading ? (
            <Skeleton className="mt-2 h-7 w-40" />
          ) : next ? (
            <>
              <p className="mt-1 text-xl font-extrabold tracking-tight">
                {next.label} · {next.time}
                {next.isTomorrow && (
                  <span className="ml-1.5 text-xs font-medium text-emerald-300/70">
                    (demain)
                  </span>
                )}
              </p>
              <p className="text-sm font-medium text-emerald-200/90">
                {formatRemaining(remaining ?? 0)}
              </p>

              {/* Fil de progression depuis la prière précédente */}
              <div className="mt-2.5">
                <div
                  className="h-1 overflow-hidden rounded-full bg-emerald-950/80"
                  role="progressbar"
                  aria-valuemin={0}
                  aria-valuemax={100}
                  aria-valuenow={Math.round(progress * 100)}
                  aria-label={
                    prev
                      ? `Progression depuis ${prev.label} (${prev.time}) vers ${next.label}`
                      : undefined
                  }
                >
                  <div
                    className="progress-shimmer h-full rounded-full bg-gradient-to-r from-emerald-600 via-emerald-400 to-emerald-300 transition-[width] duration-1000 ease-linear"
                    style={{ width: `${Math.max(2, progress * 100)}%` }}
                  />
                </div>
                {prev && (
                  <p className="mt-1.5 flex items-center justify-between text-[10px] text-zinc-500">
                    <span className="truncate">
                      {prev.label} {prev.time} · {formatElapsed(nowSec - prev.sec)}
                    </span>
                    <span className="shrink-0 text-emerald-400/70">{next.time}</span>
                  </p>
                )}
              </div>
            </>
          ) : (
            <p className="mt-2 text-sm text-zinc-400">Horaires indisponibles</p>
          )}
        </section>

        {/* ------- Lignes d'horaires + iqama ------- */}
        <ul className="space-y-1">
          {PRAYERS.map((prayer) => {
            const isNext = next?.key === prayer.key;
            const value = prayers?.times?.[prayer.key] ?? null;
            const iqama = prayer.real
              ? (prayers?.iqama?.[prayer.key] ?? null)
              : null;
            // Prière déjà passée (à l'horloge de la mosquée) → atténuée,
            // la « prochaine » reste pleine lumière.
            const rowSec = timeToSeconds(value);
            const isPast = !isNext && rowSec !== null && rowSec <= nowSec;
            return (
              <li
                key={prayer.key}
                aria-current={isNext ? "true" : undefined}
                className={`flex items-center justify-between rounded-lg border px-3 py-2 transition-all duration-500 ${
                  isNext
                    ? "border-emerald-500/50 bg-emerald-500/10 shadow-[inset_3px_0_0_0_#34d399]"
                    : "border-transparent border-b border-b-white/5"
                } ${isPast ? "opacity-45" : ""}`}
              >
                <span className="flex items-center gap-2">
                  <span
                    className={`text-sm font-semibold ${
                      prayer.real ? "text-zinc-100" : "text-zinc-500"
                    }`}
                  >
                    {prayer.label}
                  </span>
                  <span
                    dir="rtl"
                    lang="ar"
                    className="text-xs text-zinc-600"
                  >
                    {prayer.arabic}
                  </span>
                  {!prayer.real && (
                    <span className="text-[9px] uppercase tracking-wider text-zinc-600">
                      lever
                    </span>
                  )}
                </span>
                {loading ? (
                  <Skeleton className="h-4 w-11" />
                ) : (
                  <span className="flex flex-col items-end leading-tight">
                    <span
                      className={`font-mono text-sm font-bold tabular-nums tracking-wider ${
                        isNext
                          ? "text-emerald-300"
                          : prayer.real
                            ? "text-zinc-200"
                            : "text-zinc-500"
                      }`}
                    >
                      {value ?? "--:--"}
                    </span>
                    {iqama && (
                      <span
                        className={`font-mono text-[9px] tabular-nums ${
                          isNext ? "text-emerald-400/80" : "text-zinc-500"
                        }`}
                        title="Début de la prière en commun à la mosquée"
                      >
                        iqama {iqama}
                      </span>
                    )}
                  </span>
                )}
              </li>
            );
          })}
        </ul>

        {/* ------- Copier / partager les horaires du jour ------- */}
        {prayers && (
          <div className="flex flex-wrap items-center justify-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={copySchedule}
              className="h-7 gap-1.5 rounded-full border border-white/10 px-3 text-[11px] text-zinc-400 transition-colors hover:border-emerald-500/30 hover:bg-emerald-500/5 hover:text-emerald-300"
              aria-label="Copier les horaires du jour dans le presse-papiers"
            >
              {copyState === "done" ? (
                <>
                  <Check className="h-3.5 w-3.5 text-emerald-400" aria-hidden />
                  Copié !
                </>
              ) : copyState === "failed" ? (
                <>
                  <Copy className="h-3.5 w-3.5 text-amber-400" aria-hidden />
                  Copie impossible ici
                </>
              ) : (
                <>
                  <Copy className="h-3.5 w-3.5" aria-hidden />
                  Copier les horaires
                </>
              )}
            </Button>
            {canShare && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => void shareSchedule()}
                className="h-7 gap-1.5 rounded-full border border-white/10 px-3 text-[11px] text-zinc-400 transition-colors hover:border-emerald-500/30 hover:bg-emerald-500/5 hover:text-emerald-300"
                aria-label="Partager les horaires du jour"
              >
                {shareState === "done" ? (
                  <>
                    <Check className="h-3.5 w-3.5 text-emerald-400" aria-hidden />
                    Partagé !
                  </>
                ) : shareState === "failed" ? (
                  <>
                    <Share2 className="h-3.5 w-3.5 text-amber-400" aria-hidden />
                    Partage impossible
                  </>
                ) : (
                  <>
                    <Share2 className="h-3.5 w-3.5" aria-hidden />
                    Partager
                  </>
                )}
              </Button>
            )}
          </div>
        )}

        {/* ------- Rappels navigateur (15 min avant + à l'heure) ------- */}
        <NotificationsToggle />

        {/* ------- Comparaison de deux mosquées ------- */}
        <CompareCard />

        {/* ------- Boussole Qibla ------- */}
        <QiblaCompass
          latitude={prayers?.latitude}
          longitude={prayers?.longitude}
          mosqueName={prayers?.name ?? mosque.name}
        />

        {/* ------- Calendrier mensuel dépliable ------- */}
        <MonthCalendar />

        {/* ------- Dhikr du moment (bonus) ------- */}
        <section className="rounded-xl border border-white/5 bg-zinc-900/60 p-4">
          <div className="flex items-center justify-between">
            <p className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-[0.18em] text-emerald-400">
              <MoonStar className="h-3 w-3" aria-hidden />
              Dhikr du moment
            </p>
            <Button
              variant="ghost"
              size="sm"
              className="h-7 gap-1.5 px-2 text-[11px] text-zinc-400 hover:text-zinc-100"
              onClick={rollDhikr}
              aria-label="Autre dhikr"
            >
              <Shuffle className="h-3.5 w-3.5" aria-hidden />
              Un autre
            </Button>
          </div>
          <p
            dir="rtl"
            lang="ar"
            className="mt-3 text-center text-xl leading-relaxed text-zinc-100"
            style={{ fontFamily: "'Amiri', 'Scheherazade New', 'Traditional Arabic', serif" }}
          >
            {dhikr.arabic}
          </p>
          <p className="mt-1.5 text-center text-xs italic text-zinc-400">
            {dhikr.transliteration}
          </p>
          <p className="mt-1.5 text-center text-[13px] text-zinc-300">
            {dhikr.french}
          </p>
          <p className="mt-2.5 text-center text-[10px] leading-relaxed text-zinc-600">
            {dhikr.note} — <span className="text-zinc-500">{dhikr.source}</span>
          </p>
        </section>

        {/* ------- Compteur de Tasbih (exclusivité web) ------- */}
        <TasbihCounter />

        <p className="pb-1 text-center text-[10px] text-zinc-600">
          Horaires fournis par mawaqit.net · démo web de l&apos;application
          Sakinah
        </p>
      </div>
    </ScrollArea>
  );
}
