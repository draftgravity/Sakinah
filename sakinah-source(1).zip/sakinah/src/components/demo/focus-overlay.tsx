/**
 * Le voile du Mode Focus — replica web de app/focus/focus_overlay.py.
 *
 * Expérience immersive « crépuscule » :
 *  * plein écran véritable : le voile fixe couvre TOUT le viewport et
 *    capte les clics — impossible d'interagir avec la page derrière ;
 *    le défilement de la page est même verrouillé pendant la session ;
 *  * aurores chaudes (rose / orange / or) qui dérivent lentement derrière
 *    le minuteur, anneau de progression dégradé avec halo ;
 *  * pause / reprise (bouton ou barre Espace), arrêt par Échap ou la
 *    croix, ambiance sonore optionnelle (bruit blanc / pluie, Web Audio)
 *    qui se coupe pendant la pause ;
 *  * écran de réussite : carillon, gerbe de confettis dorés (neutralisée
 *    en prefers-reduced-motion) puis compteur de sessions incrémenté.
 */

"use client";

import { useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { CheckCircle2, Pause, Play, Volume2, VolumeX, X } from "lucide-react";
import { useDemoStore } from "@/lib/demo-store";
import type { WebAudioAPI } from "@/hooks/use-web-audio";

function formatClock(totalSec: number): string {
  const minutes = Math.floor(totalSec / 60);
  const seconds = totalSec % 60;
  return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
}

/** Une particule de confetti — trajectoire pré-calculée (pas de re-render). */
interface ConfettiParticle {
  /** déplacement final horizontal (px, depuis le centre) */
  cx: number;
  /** déplacement final vertical (px — positif = vers le bas) */
  cy: number;
  /** rotation finale (deg) */
  rotate: number;
  /** durée (ms) — variée pour un fallout naturel */
  duration: number;
  /** retard (ms) — décalage du départ */
  delay: number;
  color: string;
  /** léger rectangle ou cercle */
  round: boolean;
}

const CONFETTI_COLORS = [
  "#fb7185", /* rose 400 */
  "#f97316", /* orange 500 */
  "#fbbf24", /* ambre 400 — comme l'anneau */
  "#fde68a", /* ambre 200 */
  "#fda4af", /* rose 300 */
  "#e4e4e7", /* zinc 200 */
];

/** Génère les particules une seule fois par écran de réussite :
 *  un anneau évasé (partent vers l'extérieur) puis retombent. */
function makeConfetti(count: number): ConfettiParticle[] {
  const particles: ConfettiParticle[] = [];
  for (let i = 0; i < count; i += 1) {
    // Angle réparti sur tout le tour, distance variée : gerbe radiale.
    const angle = (i / count) * Math.PI * 2 + (Math.random() - 0.5) * 0.6;
    const distance = 90 + Math.random() * 150;
    const cx = Math.cos(angle) * distance * 1.35;
    // La seconde moitié de la trajectoire chute : cy final vers le bas.
    const cy = Math.sin(angle) * distance * 0.6 + 130 + Math.random() * 90;
    particles.push({
      cx: Math.round(cx),
      cy: Math.round(cy),
      rotate: Math.round((Math.random() - 0.5) * 720),
      duration: 1300 + Math.random() * 700,
      delay: Math.random() * 180,
      color: CONFETTI_COLORS[i % CONFETTI_COLORS.length],
      round: Math.random() > 0.6,
    });
  }
  return particles;
}

/** Gerbe de confettis au centre de l'écran de réussite. */
function ConfettiBurst() {
  const particles = useMemo(() => makeConfetti(34), []);
  return (
    <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
      {particles.map((p, index) => (
        <span
          key={index}
          className="focus-confetti"
          style={
            {
              "--cx": `${p.cx}px`,
              "--cy": `${p.cy}px`,
              "--cr": `${p.rotate}deg`,
              backgroundColor: p.color,
              borderRadius: p.round ? "50%" : "2px",
              width: p.round ? "7px" : "5px",
              height: p.round ? "7px" : "10px",
              animationDuration: `${p.duration}ms`,
              animationDelay: `${p.delay}ms`,
            } as React.CSSProperties
          }
        />
      ))}
    </div>
  );
}

const RING_RADIUS = 132;
const RING_CIRCUMFERENCE = 2 * Math.PI * RING_RADIUS;

export function FocusOverlay({ audio }: { audio: WebAudioAPI }) {
  const active = useDemoStore((state) => state.focusActive);
  const completed = useDemoStore((state) => state.focusCompleted);
  const paused = useDemoStore((state) => state.focusPaused);
  const duration = useDemoStore((state) => state.focusDurationSec);
  const remaining = useDemoStore((state) => state.focusRemainingSec);
  const sound = useDemoStore((state) => state.focusSound);
  const volume = useDemoStore((state) => state.focusVolume);
  const sessions = useDemoStore((state) => state.focusSessions.count);
  const endFocus = useDemoStore((state) => state.endFocus);
  const togglePause = useDemoStore((state) => state.togglePauseFocus);

  const [muted, setMuted] = useState(false);

  // Ambiance sonore pendant la session (fondu d'arrêt au démontage) —
  // la pause COUPE l'ambiance : silence pendant la respiration.
  useEffect(() => {
    if (!active || paused) return;
    if (sound !== "none") {
      audio.startNoise(sound, muted ? 0 : volume);
    }
    return () => audio.stopNoise();
  }, [active, paused, sound, audio, volume, muted]);

  // Plein écran « pro » : le défilement de la page est verrouillé tant
  // que le voile est ouvert — rien ne bouge derrière.
  useEffect(() => {
    if (!active) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = previous;
    };
  }, [active]);

  // Échap global → arrêt instantané (comme dans l'application) ;
  // Espace → pause / reprise.
  useEffect(() => {
    if (!active || completed) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        event.preventDefault();
        endFocus(false);
      } else if (event.key === " " || event.code === "Space") {
        event.preventDefault();
        togglePause();
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [active, completed, endFocus, togglePause]);

  // Écran de réussite → retour automatique après ~2,6 s.
  useEffect(() => {
    if (!completed) return;
    const id = setTimeout(() => endFocus(true), 2600);
    return () => clearTimeout(id);
  }, [completed, endFocus]);

  const ratio = duration > 0 ? Math.max(0, remaining / duration) : 0;
  const offset = RING_CIRCUMFERENCE * (1 - ratio);

  return (
    <AnimatePresence>
      {active && (
        <motion.div
          key="focus-overlay"
          role="alertdialog"
          aria-label="Mode Focus en cours — Échap pour arrêter, Espace pour la pause"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.25 }}
          className="fixed inset-0 z-[100] overflow-hidden bg-zinc-950/[0.96]"
        >
          {/* ------- Aurores crépuscule (définies en CSS, motion-safe) ------- */}
          <div aria-hidden className="pointer-events-none absolute inset-0">
            <div className="focus-aurora focus-aurora-rose" />
            <div className="focus-aurora focus-aurora-amber" />
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_70%_55%_at_50%_46%,transparent_30%,rgba(9,9,11,0.55)_100%)]" />
          </div>

          {!completed ? (
            <>
              {/* Croix d'arrêt */}
              <button
                type="button"
                onClick={() => endFocus(false)}
                aria-label="Arrêter la session"
                className="absolute right-5 top-5 grid h-12 w-12 place-items-center rounded-full text-zinc-400 transition-colors hover:bg-rose-500/10 hover:text-rose-300"
              >
                <X className="h-6 w-6" aria-hidden />
              </button>

              <div className="relative flex h-full flex-col items-center justify-center gap-6 px-6">
                <p className="bg-gradient-to-r from-rose-300 via-orange-300 to-amber-300 bg-clip-text text-sm font-extrabold uppercase tracking-[0.55em] text-transparent">
                  Mode Focus
                </p>

                {/* Anneau + minuteur */}
                <div className="relative grid place-items-center">
                  {/* halo derrière l'anneau */}
                  <span
                    aria-hidden="true"
                    className="focus-ring-breathe absolute size-[320px] rounded-full bg-[radial-gradient(circle,rgba(251,146,60,0.14),transparent_65%)]"
                  />
                  <svg
                    width={RING_RADIUS * 2 + 24}
                    height={RING_RADIUS * 2 + 24}
                    viewBox={`0 0 ${RING_RADIUS * 2 + 24} ${RING_RADIUS * 2 + 24}`}
                    aria-hidden
                    className="-rotate-90"
                  >
                    <circle
                      cx={RING_RADIUS + 12}
                      cy={RING_RADIUS + 12}
                      r={RING_RADIUS}
                      fill="none"
                      stroke="rgba(255,255,255,0.06)"
                      strokeWidth={9}
                    />
                    <circle
                      cx={RING_RADIUS + 12}
                      cy={RING_RADIUS + 12}
                      r={RING_RADIUS}
                      fill="none"
                      stroke="url(#focusGradient)"
                      strokeWidth={9}
                      strokeLinecap="round"
                      strokeDasharray={RING_CIRCUMFERENCE}
                      strokeDashoffset={offset}
                      style={{ transition: "stroke-dashoffset 0.9s linear" }}
                    />
                    <defs>
                      <linearGradient id="focusGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#fb7185" />
                        <stop offset="55%" stopColor="#fb923c" />
                        <stop offset="100%" stopColor="#fbbf24" />
                      </linearGradient>
                    </defs>
                  </svg>
                  <span
                    className={`absolute font-mono text-[clamp(3rem,10vw,5.5rem)] font-extrabold tabular-nums tracking-tight text-zinc-50 [text-shadow:0_0_42px_rgba(251,146,60,0.35)] transition-opacity ${
                      paused ? "opacity-50" : "opacity-100"
                    }`}
                  >
                    {formatClock(remaining)}
                  </span>
                </div>

                {/* Pause / reprise */}
                <button
                  type="button"
                  onClick={togglePause}
                  className="flex items-center gap-2.5 rounded-full border border-rose-400/25 bg-gradient-to-r from-rose-500/10 to-amber-400/10 px-6 py-2.5 text-[13px] font-semibold text-rose-200 backdrop-blur transition-all hover:border-rose-300/40 hover:from-rose-500/20 hover:to-amber-400/20"
                >
                  {paused ? (
                    <>
                      <Play className="size-4" aria-hidden />
                      Reprendre
                    </>
                  ) : (
                    <>
                      <Pause className="size-4" aria-hidden />
                      Mettre en pause
                    </>
                  )}
                </button>

                <p className="text-sm text-zinc-400">
                  {paused
                    ? "En pause — reprends ton souffle."
                    : "Reste concentré — tout le reste peut attendre."}
                </p>
                <p className="text-xs text-zinc-600">
                  <kbd className="rounded border border-white/10 px-1.5 py-0.5 font-mono text-[10px] text-zinc-400">
                    Espace
                  </kbd>{" "}
                  pause ·{" "}
                  <kbd className="rounded border border-white/10 px-1.5 py-0.5 font-mono text-[10px] text-zinc-400">
                    Échap
                  </kbd>{" "}
                  ou × pour arrêter
                  {sound !== "none" && " · ambiance en cours"}
                </p>
              </div>

              {/* Contrôle rapide du volume */}
              {sound !== "none" && (
                <button
                  type="button"
                  onClick={() => setMuted((value) => !value)}
                  className="absolute bottom-6 left-6 flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-2 text-xs font-medium text-zinc-300 backdrop-blur transition-colors hover:bg-white/10"
                >
                  {muted ? (
                    <VolumeX className="h-4 w-4" aria-hidden />
                  ) : (
                    <Volume2 className="h-4 w-4" aria-hidden />
                  )}
                  {sound === "white" ? "Bruit blanc" : "Pluie"} ·{" "}
                  {muted ? "coupé" : `${Math.round(volume * 100)}%`}
                </button>
              )}
            </>
          ) : (
            /* ------- Écran de réussite ------- */
            <motion.div
              key="focus-success"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="relative flex h-full flex-col items-center justify-center gap-4 px-6 text-center"
            >
              {/* Gerbe de confettis — la classe .focus-confetti (CSS) est
                  neutralisée par la règle globale
                  prefers-reduced-motion. */}
              <ConfettiBurst />
              {/* halo radial doré derrière la coche */}
              <div
                aria-hidden="true"
                className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_42%,rgba(251,191,36,0.16),transparent_60%)]"
              />
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", stiffness: 260, damping: 18, delay: 0.1 }}
              >
                <CheckCircle2
                  className="h-20 w-20 text-amber-300 drop-shadow-[0_0_24px_rgba(251,191,36,0.45)]"
                  aria-hidden
                />
              </motion.div>
              <h2 className="bg-gradient-to-r from-rose-200 via-amber-200 to-amber-300 bg-clip-text text-3xl font-extrabold tracking-tight text-transparent">
                Session terminée !
              </h2>
              <p className="text-sm text-zinc-400">
                <span className="tabular-nums">
                  {sessions} session{sessions > 1 ? "s" : ""} réussie
                  {sessions > 1 ? "s" : ""}
                </span>{" "}
                aujourd&apos;hui — bravo.
                <br />
                Retour à l&apos;écran normal…
              </p>
            </motion.div>
          )}
        </motion.div>
      )}
    </AnimatePresence>
  );
}
