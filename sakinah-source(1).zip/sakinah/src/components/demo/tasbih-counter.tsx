/**
 * Compteur de Tasbih — joker web de la démo (n'existe pas dans l'app Windows,
 * documenté comme tel dans le Journal des versions).
 *
 * * 4 formules : SubhânAllâh ×33, Alhamdulillâh ×33, Allâhu Akbar ×34 et
 *   un mode libre (compteur illimité, cible masquée) ;
 * * grand bouton circulaire à taper : anneau de progression SVG, impulsion
 *   à chaque tape, vibration courte si l'API est disponible ;
 * * à l'objectif atteint : état « complété » + suggestion de la formule
 *   suivante (les trois tasbihs canoniques s'enchaînent : 33 + 33 + 34) ;
 * * total du jour persisté dans localStorage (comme les stats de focus),
 *   remis à zéro au changement de jour civil (détecté aussi SANS tape grâce
 *   à useDayChange : l'affichage « aujourd'hui » suit minuit) ;
 * * STATISTIQUES : totaux du jour / cumul, suivi à vie PAR FORMULE, export
 *   CSV (séparateur « ; » + BOM UTF-8 pour Excel fr) et réinitialisation
 *   confirmée (AlertDialog destructive) ;
 * * RÉGULARITÉ : historique des 7 derniers jours (mini-graphique en
 *   barres, comme l'onglet Focus) + « série » de jours consécutifs avec
 *   au moins un dhikr — tout est effacé avec les statistiques.
 * * accessibilité : rôle bouton réel, aria-live discret, cibles ≥ 44 px,
 *   prefers-reduced-motion respecté (impulsions désactivées).
 */

"use client";

import { useCallback, useEffect, useState } from "react";
import { Check, CloudCheck, Download, Flame, HardDrive, RotateCcw, Sparkles, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { useDayChange } from "@/hooks/use-day-change";
import { useAuthStore } from "@/lib/auth-store";
import {
  ACCOUNT_SYNC_EVENT,
  resetServerDhikr,
  scheduleDhikrSync,
} from "@/lib/account-sync";
import {
  bumpDhikrHistory,
  clearDhikrHistory,
  computeDhikrStreak,
  getDhikrWeek,
  type DhikrDay,
} from "@/lib/dhikr-history";
import { cn } from "@/lib/utils";

interface TasbihPreset {
  /** clé unique */
  key: string;
  /** formule arabe (dir=rtl) */
  arabic: string;
  /** translittération latine */
  transliteration: string;
  /** cible (null = mode libre illimité) */
  target: number | null;
}

/** Les trois tasbihs canoniques après la prière (33/33/34) + mode libre. */
const PRESETS: TasbihPreset[] = [
  {
    key: "subhanallah",
    arabic: "سُبْحَانَ اللَّهِ",
    transliteration: "SubhânAllâh",
    target: 33,
  },
  {
    key: "alhamdulillah",
    arabic: "الْحَمْدُ لِلَّهِ",
    transliteration: "Alhamdulillâh",
    target: 33,
  },
  {
    key: "allahuakbar",
    arabic: "اللَّهُ أَكْبَرُ",
    transliteration: "Allâhu Akbar",
    target: 34,
  },
  {
    key: "libre",
    arabic: "ذِكْرٌ حُرٌّ",
    transliteration: "Dhikr libre",
    target: null,
  },
];

const TOTALS_KEY = "sakinah-tasbih-totals";

interface TasbihTotals {
  /** "YYYY-MM-DD" — remise à zéro au changement de jour civil */
  date: string;
  today: number;
  lifetime: number;
  /** cumul à vie par formule (clé de PRESETS) — champ optionnel : les
   *  totaux créés avant cette version n'en ont pas. */
  perFormula?: Record<string, number>;
}

const localDayKey = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(
    d.getDate(),
  ).padStart(2, "0")}`;
};

function readTotals(): TasbihTotals {
  const empty: TasbihTotals = {
    date: localDayKey(),
    today: 0,
    lifetime: 0,
  };
  try {
    const raw = window.localStorage.getItem(TOTALS_KEY);
    if (!raw) return empty;
    const parsed = JSON.parse(raw) as TasbihTotals;
    if (
      typeof parsed.today !== "number" ||
      typeof parsed.lifetime !== "number" ||
      typeof parsed.date !== "string"
    ) {
      return empty;
    }
    return parsed.date === localDayKey()
      ? parsed
      : { ...parsed, date: localDayKey(), today: 0 };
  } catch {
    return empty;
  }
}

function persistTotals(totals: TasbihTotals) {
  try {
    window.localStorage.setItem(TOTALS_KEY, JSON.stringify(totals));
  } catch {
    /* ignore */
  }
}

/**
 * Exporte les statistiques de dhikr en CSV — séparateur « ; » et BOM
 * UTF-8 pour que les accents s'affichent dans Excel français.
 * Colonnes : formule, total à vie + en-tête jour/cumul + 7 derniers jours.
 */
function exportTotalsCsv(totals: TasbihTotals, week: DhikrDay[], streak: number) {
  const lines: string[] = [
    "Sakinah — Statistiques de dhikr",
    `Généré le;${new Date().toLocaleString("fr-FR")}`,
    `Jour (${totals.date});${totals.today}`,
    `Cumul total;${totals.lifetime}`,
    `Série (jours consécutifs);${streak}`,
    "",
    "Formule;Total à vie",
    ...PRESETS.map(
      (preset) =>
        `${preset.transliteration};${totals.perFormula?.[preset.key] ?? 0}`,
    ),
    "",
    "7 derniers jours;Dhikr",
    ...week.map((day) => `${day.date};${day.count}`),
  ];
  const csv = `\uFEFF${lines.join("\r\n")}`;
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = `sakinah-dhikr-${totals.date}.csv`;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 4000);
}

/** Rayon de l'anneau de progression (SVG 128×128). */
const RADIUS = 56;
const CIRCUMFERENCE = 2 * Math.PI * RADIUS;

export function TasbihCounter() {
  const [presetIndex, setPresetIndex] = useState(0);
  const [count, setCount] = useState(0);
  const [totals, setTotals] = useState<TasbihTotals>({
    date: "",
    today: 0,
    lifetime: 0,
  });
  /** clé d'animation d'impulsion — incrémentée à chaque tape. */
  const [pulseKey, setPulseKey] = useState(0);
  const [justCompleted, setJustCompleted] = useState(false);
  /** « Exporté ! » pendant 2,4 s après un export CSV réussi. */
  const [exported, setExported] = useState(false);
  /** 7 derniers jours + série — rafraîchis à chaque tape/minuit/reset. */
  const [week, setWeek] = useState<DhikrDay[]>(() =>
    Array.from({ length: 7 }, () => ({
      date: "",
      label: "",
      count: 0,
      isToday: false,
    })),
  );
  const [streak, setStreak] = useState(0);

  // Compte connecté → les données vivent EN LIGNE (le localStorage n'est
  // plus qu'un cache) ; la ligne d'état l'indique sous les totaux.
  const authed = useAuthStore((state) => state.user !== null);
  const setLoginOpen = useAuthStore((state) => state.setLoginOpen);

  /** Relit les totaux + la régularité depuis le cache local (montage,
   *  minuit, ou réécriture par le serveur après une synchronisation). */
  const reloadFromCache = useCallback(() => {
    setTotals(readTotals());
    setWeek(getDhikrWeek());
    setStreak(computeDhikrStreak());
  }, []);

  // Hydratation des totaux (client uniquement — évite l'hydratation serveur).
  useEffect(() => {
    reloadFromCache();
  }, [reloadFromCache]);

  // Minuit : « aujourd'hui » repart de zéro SANS attendre la prochaine
  // tape (sinon le total d'hier resterait affiché jusque-là).
  useDayChange(reloadFromCache);

  // Le serveur a réécrit le cache (connexion : fusion d'appareil, ou un
  // autre appareil avait mieux) → on relit immédiatement.
  useEffect(() => {
    window.addEventListener(ACCOUNT_SYNC_EVENT, reloadFromCache);
    return () => window.removeEventListener(ACCOUNT_SYNC_EVENT, reloadFromCache);
  }, [reloadFromCache]);

  const preset = PRESETS[presetIndex];
  const isFree = preset.target === null;
  const done = !isFree && count >= (preset.target ?? 0);
  const ratio = isFree
    ? (count % 33) / 33 // l'anneau tourne en continu en mode libre
    : Math.min(1, count / (preset.target ?? 1));

  /** Tape sur le compteur : incrémente, pulse, vibre, persiste. */
  const tap = useCallback(() => {
    setCount((current) => {
      const next = isFree
        ? current + 1
        : Math.min(current + 1, preset.target ?? 0);
      if (!isFree && next === preset.target && current < next) {
        setJustCompleted(true);
      }
      return next;
    });
    setPulseKey((key) => key + 1);
    if (typeof navigator !== "undefined" && "vibrate" in navigator) {
      try {
        navigator.vibrate(done ? [30, 40, 30] : 12);
      } catch {
        /* ignore */
      }
    }
    setTotals((current) => {
      // Re-lit la date : si le jour a changé depuis la dernière tape,
      // « aujourd'hui » repart de zéro.
      const key = localDayKey();
      const today = current.date === key ? current.today : 0;
      const next: TasbihTotals = {
        date: key,
        today: today + 1,
        lifetime: current.lifetime + 1,
        perFormula: {
          ...current.perFormula,
          [preset.key]: (current.perFormula?.[preset.key] ?? 0) + 1,
        },
      };
      persistTotals(next);
      return next;
    });
    // Journal du jour (mini-graphique + série) — même fréquence que les
    // totaux : une écriture localStorage par tape reste négligeable.
    bumpDhikrHistory();
    setWeek(getDhikrWeek());
    setStreak(computeDhikrStreak());
    // Compte connecté → synchro en ligne debouncée (1,5 s après la
    // dernière tape ; fusion par maximum, donc idempotente).
    scheduleDhikrSync();
  }, [isFree, preset.target, preset.key, done]);

  /** Change de formule (remise à zéro du compteur courant). */
  const selectPreset = (index: number) => {
    setPresetIndex(index);
    setCount(0);
    setJustCompleted(false);
  };

  const resetCount = () => {
    setCount(0);
    setJustCompleted(false);
  };

  /** Exporte les statistiques (CSV) — retour visuel 2,4 s. */
  const handleExport = () => {
    try {
      exportTotalsCsv(totals, week, streak);
      setExported(true);
      window.setTimeout(() => setExported(false), 2400);
    } catch {
      /* téléchargement impossible (navigateur verrouillé…) — silencieux */
    }
  };

  /** Efface TOUT l'historique de dhikr (confirmé via AlertDialog) —
   *  cache local ET base en ligne si un compte est connecté. */
  const resetStats = () => {
    const empty: TasbihTotals = {
      date: localDayKey(),
      today: 0,
      lifetime: 0,
    };
    persistTotals(empty);
    clearDhikrHistory();
    setTotals(empty);
    setWeek(getDhikrWeek());
    setStreak(0);
    void resetServerDhikr();
  };

  /** Prochaine formule suggérée après un tasbih complété. */
  const nextSuggestion = (() => {
    if (!done || isFree) return null;
    const nextIndex = (presetIndex + 1) % (PRESETS.length - 1);
    const next = PRESETS[nextIndex];
    return next.target === null ? null : { nextIndex, next };
  })();

  return (
    <section
      className="rounded-xl border border-white/5 bg-zinc-900/60 p-4"
      aria-label="Compteur de Tasbih"
    >
      <div className="flex items-center justify-between">
        <p className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-[0.18em] text-emerald-400">
          <Sparkles className="h-3 w-3" aria-hidden />
          Compteur de Tasbih
        </p>
        <span className="text-[10px] text-zinc-600">exclusivité web</span>
      </div>

      {/* ------- Bouton circulaire + anneau ------- */}
      <div className="mt-3 flex justify-center">
        <button
          type="button"
          onClick={tap}
          aria-label={
            done
              ? `Tasbih terminé — ${count} fois`
              : `Compter ${preset.transliteration} — ${count}${
                  isFree ? "" : ` sur ${preset.target}`
                }`
          }
          className="group relative grid size-32 place-items-center rounded-full outline-none focus-visible:ring-2 focus-visible:ring-emerald-400/70"
        >
          {/* anneau de progression */}
          <svg
            width={128}
            height={128}
            viewBox="0 0 128 128"
            aria-hidden
            className="absolute inset-0 -rotate-90"
          >
            <circle
              cx={64}
              cy={64}
              r={RADIUS}
              fill="none"
              stroke="rgba(255,255,255,0.06)"
              strokeWidth={6}
            />
            <circle
              cx={64}
              cy={64}
              r={RADIUS}
              fill="none"
              stroke={done ? "#f59e0b" : "url(#tasbihGradient)"}
              strokeWidth={6}
              strokeLinecap="round"
              strokeDasharray={CIRCUMFERENCE}
              strokeDashoffset={CIRCUMFERENCE * (1 - ratio)}
              style={{
                transition: "stroke-dashoffset 220ms cubic-bezier(0.22,1,0.36,1)",
              }}
            />
            <defs>
              <linearGradient
                id="tasbihGradient"
                x1="0%"
                y1="0%"
                x2="100%"
                y2="100%"
              >
                <stop offset="0%" stopColor="#34d399" />
                <stop offset="100%" stopColor="#10b981" />
              </linearGradient>
            </defs>
          </svg>

          {/* fond du bouton + impulsion à chaque tape (key>0 → la clé
              change à chaque tape, React remonte l'élément et relance
              l'animation définie en CSS) */}
          <span
            key={pulseKey}
            aria-hidden
            className={cn(
              "absolute inset-[10px] rounded-full border bg-[#0d0d10] transition-colors",
              done
                ? "border-amber-400/40 bg-amber-500/10"
                : "border-white/10 group-hover:border-emerald-400/30 group-active:border-emerald-400/50",
              pulseKey > 0 && "tasbih-pulse",
            )}
          />

          <span className="relative z-10 flex flex-col items-center leading-none">
            <span
              className={cn(
                "font-mono text-3xl font-extrabold tabular-nums tracking-tight",
                done ? "text-amber-300" : "text-zinc-100",
              )}
            >
              {count}
            </span>
            <span className="mt-1 text-[10px] font-semibold uppercase tracking-widest text-zinc-500">
              {done ? "complété" : isFree ? "taper ici" : `/ ${preset.target}`}
            </span>
          </span>
        </button>
      </div>

      {/* formule courante */}
      <div className="mt-3 text-center" aria-live="polite">
        <p
          dir="rtl"
          lang="ar"
          className={cn(
            "text-xl leading-relaxed transition-colors",
            done ? "text-amber-200" : "text-zinc-100",
          )}
          style={{
            fontFamily: "'Amiri', 'Scheherazade New', 'Traditional Arabic', serif",
          }}
        >
          {preset.arabic}
        </p>
        <p className="mt-1 text-xs italic text-zinc-400">
          {preset.transliteration}
        </p>
      </div>

      {/* ------- Sélecteur de formule ------- */}
      <div
        className="mt-3 grid grid-cols-4 gap-1.5"
        role="group"
        aria-label="Formule de tasbih"
      >
        {PRESETS.map((item, index) => {
          const selected = index === presetIndex;
          return (
            <button
              key={item.key}
              type="button"
              onClick={() => selectPreset(index)}
              aria-pressed={selected}
              className={cn(
                "flex min-h-11 flex-col items-center justify-center rounded-lg border px-1 py-1.5 text-center transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400/60",
                selected
                  ? "border-emerald-500/50 bg-emerald-500/10"
                  : "border-white/5 bg-zinc-900/40 hover:border-white/15 hover:bg-zinc-800/40",
              )}
            >
              <span
                className={cn(
                  "text-[11px] font-semibold leading-tight",
                  selected ? "text-emerald-300" : "text-zinc-300",
                )}
              >
                {item.transliteration}
              </span>
              <span className="text-[9px] tabular-nums text-zinc-500">
                {item.target === null ? "libre" : `×${item.target}`}
              </span>
            </button>
          );
        })}
      </div>

      {/* ------- Complété : suggestion + réinitialisation ------- */}
      <div className="mt-3 flex items-center justify-between gap-2">
        {done && nextSuggestion ? (
          <button
            type="button"
            onClick={() => selectPreset(nextSuggestion.nextIndex)}
            className="flex min-h-9 flex-1 items-center justify-center gap-1.5 rounded-full border border-amber-400/30 bg-amber-500/10 px-3 text-[11px] font-semibold text-amber-300 transition-colors hover:bg-amber-500/20 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400/60"
          >
            <Check className="h-3.5 w-3.5" aria-hidden />
            Enchaîner : {nextSuggestion.next.transliteration} ×
            {nextSuggestion.next.target}
          </button>
        ) : (
          <p className="flex-1 text-center text-[10px] leading-relaxed text-zinc-600">
            {isFree
              ? "Mode libre — comptez sans limite, l'anneau tourne."
              : "Tapez le cercle pour compter — l'écran vibre à chaque tape."}
          </p>
        )}
        <Button
          variant="ghost"
          size="sm"
          onClick={resetCount}
          disabled={count === 0}
          aria-label="Remettre le compteur à zéro"
          className="h-9 shrink-0 gap-1.5 rounded-full border border-white/10 px-3 text-[11px] text-zinc-400 transition-colors hover:border-emerald-500/30 hover:bg-emerald-500/5 hover:text-emerald-300 disabled:opacity-40"
        >
          <RotateCcw className="h-3.5 w-3.5" aria-hidden />
          {justCompleted && count > 0 ? "Recommencer" : "Zéro"}
        </Button>
      </div>

      {/* ------- Statistiques : jour / cumul + export + reset ------- */}
      <div className="mt-3 rounded-lg border border-white/5 bg-zinc-950/40 p-2.5">
        <div
          className="grid grid-cols-2 divide-x divide-white/5"
          aria-label="Statistiques de dhikr"
        >
          <div className="pr-2 text-center">
            <p className="text-[9px] font-semibold uppercase tracking-[0.14em] text-zinc-600">
              Aujourd&apos;hui
            </p>
            <p className="mt-0.5 font-mono text-lg font-extrabold tabular-nums leading-none text-emerald-300">
              {totals.today}
            </p>
          </div>
          <div className="pl-2 text-center">
            <p className="text-[9px] font-semibold uppercase tracking-[0.14em] text-zinc-600">
              Cumul
            </p>
            <p className="mt-0.5 font-mono text-lg font-extrabold tabular-nums leading-none text-zinc-100">
              {totals.lifetime}
            </p>
          </div>
        </div>
        {/* État de stockage : en ligne (compte) ou local (démo). */}
        <div className="mt-2 flex items-center justify-center">
          {authed ? (
            <p
              className="flex items-center gap-1 text-[9px] font-semibold text-emerald-400/90"
              title="Vos statistiques suivent votre compte — elles se retrouvent sur tous vos appareils."
            >
              <CloudCheck className="size-3" aria-hidden />
              Synchronisé en ligne
            </p>
          ) : (
            <button
              type="button"
              onClick={() => setLoginOpen(true)}
              className="flex min-h-6 items-center gap-1 text-[9px] text-zinc-600 transition-colors hover:text-emerald-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400/60"
              title="Créer un compte ou vous connecter pour conserver vos statistiques en ligne"
            >
              <HardDrive className="size-3" aria-hidden />
              Local — <span className="underline underline-offset-2">se connecter pour synchroniser</span>
            </button>
          )}
        </div>
        <div className="mt-2 flex items-center justify-between gap-1.5">
          {/* répartition par formule (à vie) — masquée si vierge */}
          {totals.lifetime > 0 && totals.perFormula ? (
            <p
              className="min-w-0 flex-1 truncate text-[9.5px] leading-tight text-zinc-600"
              title={PRESETS.filter((p) => (totals.perFormula?.[p.key] ?? 0) > 0)
                .map(
                  (p) => `${p.transliteration} : ${totals.perFormula?.[p.key]}`,
                )
                .join("\n")}
            >
              {PRESETS.filter((p) => (totals.perFormula?.[p.key] ?? 0) > 0)
                .map(
                  (p) =>
                    `${p.transliteration} ${totals.perFormula?.[p.key]}`,
                )
                .join(" · ")}
            </p>
          ) : (
            <p className="flex-1 text-[9.5px] text-zinc-600">
              {authed
                ? "Vos tapes suivent votre compte, pas cet appareil."
                : "Vos tapes restent sur cet appareil."}
            </p>
          )}
          <div className="flex shrink-0 gap-1">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleExport}
              disabled={totals.lifetime === 0}
              aria-label="Exporter les statistiques de dhikr en CSV"
              title="Télécharger les statistiques (CSV — Excel/LibreOffice)"
              className="h-8 gap-1.5 rounded-full border border-white/10 px-2.5 text-[10px] text-zinc-400 transition-colors hover:border-emerald-500/30 hover:bg-emerald-500/5 hover:text-emerald-300 disabled:opacity-40"
            >
              {exported ? (
                <>
                  <Check className="h-3.5 w-3.5 text-emerald-400" aria-hidden />
                  Exporté
                </>
              ) : (
                <>
                  <Download className="h-3.5 w-3.5" aria-hidden />
                  CSV
                </>
              )}
            </Button>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  disabled={totals.today === 0 && totals.lifetime === 0}
                  aria-label="Réinitialiser les statistiques de dhikr"
                  title="Remettre les totaux à zéro"
                  className="h-8 gap-1.5 rounded-full border border-white/10 px-2.5 text-[10px] text-zinc-400 transition-colors hover:border-red-500/30 hover:bg-red-500/5 hover:text-red-300 disabled:opacity-40"
                >
                  <Trash2 className="h-3.5 w-3.5" aria-hidden />
                  Effacer
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent className="max-w-[calc(100vw-2rem)] rounded-xl border-white/10 bg-zinc-950 sm:max-w-md">
                <AlertDialogHeader className="text-left">
                  <AlertDialogTitle className="text-base font-bold text-zinc-100">
                    Effacer les statistiques de dhikr ?
                  </AlertDialogTitle>
                  <AlertDialogDescription className="text-[13px] leading-relaxed text-zinc-400">
                    Le total du jour ({totals.today}) et le cumul ({" "}
                    {totals.lifetime}) seront remis à zéro sur cet appareil.
                    Cette action est immédiate et irréversible — pensez à
                    exporter vos statistiques avant si elles comptent pour
                    vous.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter className="gap-2">
                  <AlertDialogCancel className="h-9 rounded-full border-white/10 bg-transparent px-4 text-zinc-300 hover:bg-white/5 hover:text-zinc-100">
                    Annuler
                  </AlertDialogCancel>
                  <AlertDialogAction
                    onClick={resetStats}
                    className="h-9 rounded-full border border-red-500/40 bg-red-500/20 px-4 text-[13px] font-semibold text-red-200 transition-colors hover:bg-red-500/30 focus-visible:ring-2 focus-visible:ring-red-400/60"
                  >
                    Effacer
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>
      </div>

      {/* ------- Régularité : série + 7 derniers jours ------- */}
      <div className="mt-3 rounded-lg border border-white/5 bg-zinc-950/40 p-2.5">
        <div className="flex items-center justify-between gap-2">
          <p className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-[0.18em] text-amber-400">
            <Flame className="h-3 w-3" aria-hidden />
            Régularité
          </p>
          <p className="min-w-0 truncate text-[10px] text-zinc-600">
            {streak > 0 ? (
              <>
                série de{" "}
                <span className="font-semibold text-amber-300">
                  {streak} jour{streak > 1 ? "s" : ""}
                </span>
              </>
            ) : (
              "une tape par jour suffit"
            )}
            {" · "}
            {week.reduce((sum, day) => sum + day.count, 0)} cette semaine
          </p>
        </div>
        <div
          className="mt-2 flex items-end gap-1.5"
          role="img"
          aria-label={`Dhikr des 7 derniers jours : ${week
            .map((d) => `${d.label} ${d.count}`)
            .join(", ")}`}
        >
          {week.map((day, index) => {
            const max = Math.max(1, ...week.map((d) => d.count));
            const height =
              day.count === 0 ? 3 : Math.max(8, (day.count / max) * 44);
            return (
              <div
                key={day.date || `slot-${index}`}
                className="flex flex-1 flex-col items-center gap-1"
                title={`${day.label} — ${day.count} dhikr${
                  day.count > 1 ? "s" : ""
                }`}
              >
                <div
                  aria-hidden="true"
                  style={{ height: `${height}px` }}
                  className={cn(
                    "w-full max-w-[18px] rounded-sm transition-all duration-500",
                    day.count === 0
                      ? "bg-white/10"
                      : day.isToday
                        ? "bg-gradient-to-t from-amber-600 to-amber-400 shadow-[0_0_12px_-2px_rgba(245,158,11,0.5)]"
                        : "bg-gradient-to-t from-emerald-700/70 to-emerald-500/70",
                  )}
                />
                <span
                  className={cn(
                    "text-[9px] font-medium capitalize",
                    day.isToday ? "text-amber-400" : "text-zinc-600",
                  )}
                >
                  {day.label}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
