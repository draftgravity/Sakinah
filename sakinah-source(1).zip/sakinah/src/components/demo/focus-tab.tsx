/**
 * Onglet « Mode Focus » de la démo — replica web de app/ui/focus_tab.py.
 *
 * Habillage « crépuscule » (rose → orange → or) : le Mode Focus possède
 * sa propre identité chromatique, distincte de l'accent émeraude des
 * prières. Gros bouton circulaire avec anneau de progression et halo
 * animé, durée (25 min par défaut + mode démo 25 s), ambiance sonore
 * bruit blanc / pluie avec volume, compteur de sessions réussies
 * aujourd'hui + historique 7 jours.
 */

"use client";

import { useState } from "react";
import {
  Check,
  CloudRain,
  Copy,
  Flame,
  Pause,
  Play,
  Square,
  Sunrise,
  Volume2,
  Wind,
} from "lucide-react";
import { useDemoStore, getFocusHistory, type FocusSound } from "@/lib/demo-store";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { cn } from "@/lib/utils";

function formatClock(totalSec: number): string {
  const minutes = Math.floor(totalSec / 60);
  const seconds = totalSec % 60;
  return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
}

const DURATIONS: { label: string; value: number; hint?: string }[] = [
  { label: "15 min", value: 15 * 60 },
  { label: "25 min", value: 25 * 60 },
  { label: "50 min", value: 50 * 60 },
  { label: "25 s", value: 25, hint: "démo rapide" },
];

const SOUNDS: { key: FocusSound; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { key: "none", label: "Aucune", icon: Square },
  { key: "white", label: "Bruit blanc", icon: Wind },
  { key: "rain", label: "Pluie", icon: CloudRain },
];

export function FocusTabDemo() {
  const focusActive = useDemoStore((state) => state.focusActive);
  const focusPaused = useDemoStore((state) => state.focusPaused);
  const remaining = useDemoStore((state) => state.focusRemainingSec);
  const duration = useDemoStore((state) => state.focusDurationSec);
  const sound = useDemoStore((state) => state.focusSound);
  const volume = useDemoStore((state) => state.focusVolume);
  const sessions = useDemoStore((state) => state.focusSessions.count);
  const startFocus = useDemoStore((state) => state.startFocus);
  const togglePauseFocus = useDemoStore((state) => state.togglePauseFocus);
  const setFocusSound = useDemoStore((state) => state.setFocusSound);
  const setFocusVolume = useDemoStore((state) => state.setFocusVolume);

  const [durationSec, setDurationSec] = useState(25 * 60);

  // Progression du bouton circulaire quand une session tourne.
  const ratio =
    focusActive && duration > 0 ? Math.max(0, remaining / duration) : 1;
  const CIRC = 2 * Math.PI * 86;

  return (
    <ScrollArea className="h-full">
      <div className="flex flex-col items-center gap-4 p-4">
        {/* ------- En-tête crépuscule ------- */}
        <div className="w-full rounded-xl border border-rose-500/15 bg-gradient-to-br from-rose-500/[0.08] via-orange-500/[0.05] to-amber-400/[0.06] p-3 text-center">
          <h3 className="bg-gradient-to-r from-rose-300 via-orange-300 to-amber-300 bg-clip-text text-sm font-extrabold tracking-tight text-transparent">
            Mode Focus — Pomodoro
          </h3>
          <p className="mt-1 text-[11px] leading-relaxed text-zinc-500">
            L&apos;écran s&apos;assombrit entièrement, un grand minuteur
            prend le dessus. Une session = une bulle de concentration
            profonde, à l&apos;abri des clics.
          </p>
        </div>

        {/* ------- Bouton principal circulaire ------- */}
        <div className="relative mt-1 grid place-items-center">
          {/* halo qui respire (neutralisé si l'utilisateur réduit le mouvement) */}
          {focusActive && !focusPaused && (
            <span
              aria-hidden="true"
              className="absolute inset-0 rounded-full bg-[radial-gradient(circle,rgba(251,113,133,0.16),transparent_65%)] motion-safe:animate-ping [animation-duration:3s] [animation-iteration-count:1]"
            />
          )}
          <Button
            size="lg"
            disabled={focusActive}
            onClick={() => startFocus(durationSec, sound, volume)}
            className="relative grid h-40 w-40 place-items-center overflow-hidden rounded-full border-0 bg-gradient-to-br from-rose-500 via-orange-500 to-amber-400 text-zinc-950 shadow-[0_0_50px_-12px_rgba(251,113,133,0.6)] transition-all duration-300 hover:scale-[1.03] hover:shadow-[0_0_60px_-10px_rgba(251,146,60,0.75)] disabled:cursor-not-allowed disabled:opacity-95"
            aria-label={
              focusActive
                ? focusPaused
                  ? "Session Focus en pause"
                  : "Session Focus en cours"
                : "Lancer le mode Focus"
            }
          >
            {/* anneau de progression (uniquement en session) */}
            {focusActive && (
              <svg
                aria-hidden
                className="absolute inset-0 -rotate-90"
                viewBox="0 0 176 176"
              >
                <circle
                  cx="88"
                  cy="88"
                  r="86"
                  fill="none"
                  stroke="rgba(9,9,11,0.35)"
                  strokeWidth="5"
                />
                <circle
                  cx="88"
                  cy="88"
                  r="86"
                  fill="none"
                  stroke="rgba(9,9,11,0.75)"
                  strokeWidth="5"
                  strokeLinecap="round"
                  strokeDasharray={CIRC}
                  strokeDashoffset={CIRC * (1 - ratio)}
                  style={{ transition: "stroke-dashoffset 0.9s linear" }}
                />
              </svg>
            )}
            <span className="relative flex flex-col items-center gap-1">
              {focusActive ? (
                <>
                  <span
                    className={cn(
                      "font-mono text-2xl font-extrabold tabular-nums",
                      focusPaused && "opacity-60",
                    )}
                  >
                    {formatClock(remaining)}
                  </span>
                  <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-widest opacity-70">
                    {focusPaused ? (
                      <>
                        <Pause className="size-2.5" aria-hidden />
                        en pause
                      </>
                    ) : (
                      "en cours"
                    )}
                  </span>
                </>
              ) : (
                <>
                  <Play className="size-5 opacity-80" aria-hidden />
                  <span className="text-lg font-extrabold">C&apos;est parti !</span>
                  <span className="text-[10px] font-semibold uppercase tracking-widest opacity-60">
                    {durationSec === 25 * 60
                      ? "25 minutes"
                      : formatClock(durationSec)}
                  </span>
                </>
              )}
            </span>
          </Button>
        </div>

        {/* ------- Pause / Reprise (en session uniquement) ------- */}
        {focusActive && (
          <button
            type="button"
            onClick={togglePauseFocus}
            className="flex items-center gap-2 rounded-full border border-white/10 bg-zinc-900/70 px-4 py-2 text-[11px] font-semibold text-zinc-300 transition-colors hover:border-rose-400/30 hover:bg-rose-500/10 hover:text-rose-200"
          >
            {focusPaused ? (
              <>
                <Play className="size-3.5" aria-hidden />
                Reprendre
              </>
            ) : (
              <>
                <Pause className="size-3.5" aria-hidden />
                Mettre en pause
              </>
            )}
          </button>
        )}

        {/* ------- Durée ------- */}
        <div className="w-full rounded-xl border border-white/5 bg-zinc-900/60 p-3">
          <p className="mb-2 flex items-center gap-1.5 text-[11px] font-semibold text-zinc-400">
            <Sunrise className="size-3 text-amber-400/80" aria-hidden />
            Durée de la session
          </p>
          <div className="flex flex-wrap gap-1.5" role="radiogroup" aria-label="Durée">
            {DURATIONS.map((item) => {
              const active = durationSec === item.value;
              return (
                <button
                  key={item.value}
                  type="button"
                  role="radio"
                  aria-checked={active}
                  disabled={focusActive}
                  onClick={() => setDurationSec(item.value)}
                  className={`rounded-lg border px-2.5 py-1.5 text-[11px] font-semibold transition-colors disabled:opacity-40 ${
                    active
                      ? "border-rose-400/50 bg-gradient-to-r from-rose-500/20 to-amber-400/15 text-rose-200"
                      : "border-white/10 bg-zinc-900 text-zinc-400 hover:border-white/20 hover:text-zinc-200"
                  }`}
                >
                  {item.label}
                  {item.hint && (
                    <span className="ml-1 text-[9px] font-medium opacity-60">
                      ({item.hint})
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          <Separator className="my-3 opacity-40" />

          {/* ------- Ambiance sonore ------- */}
          <p className="mb-2 text-[11px] font-semibold text-zinc-400">
            Ambiance sonore
          </p>
          <div className="flex flex-wrap gap-1.5" role="radiogroup" aria-label="Ambiance sonore">
            {SOUNDS.map(({ key, label, icon: Icon }) => {
              const active = sound === key;
              return (
                <button
                  key={key}
                  type="button"
                  role="radio"
                  aria-checked={active}
                  disabled={focusActive}
                  onClick={() => setFocusSound(key)}
                  className={`flex items-center gap-1.5 rounded-lg border px-2.5 py-1.5 text-[11px] font-semibold transition-colors disabled:opacity-40 ${
                    active
                      ? "border-rose-400/50 bg-gradient-to-r from-rose-500/20 to-amber-400/15 text-rose-200"
                      : "border-white/10 bg-zinc-900 text-zinc-400 hover:border-white/20 hover:text-zinc-200"
                  }`}
                >
                  <Icon className="h-3 w-3" aria-hidden />
                  {label}
                </button>
              );
            })}
          </div>

          {sound !== "none" && (
            <div className="mt-3 flex items-center gap-3">
              <Volume2 className="h-3.5 w-3.5 shrink-0 text-zinc-500" aria-hidden />
              <Slider
                value={[Math.round(volume * 100)]}
                min={0}
                max={100}
                step={5}
                disabled={focusActive}
                onValueChange={([value]) => setFocusVolume(value / 100)}
                aria-label="Volume de l'ambiance"
              />
              <span className="w-8 shrink-0 text-right font-mono text-[11px] tabular-nums text-zinc-500">
                {Math.round(volume * 100)}%
              </span>
            </div>
          )}
        </div>

        {/* ------- Compteur du jour ------- */}
        <div className="flex w-full items-center justify-between rounded-xl border border-white/5 bg-zinc-900/60 px-3.5 py-2.5">
          <span className="text-[11px] font-semibold text-zinc-400">
            Sessions réussies aujourd&apos;hui
          </span>
          <span className="flex items-center gap-2">
            <span className="text-sm tracking-[3px] text-rose-400">
              {"●".repeat(Math.min(sessions, 8))}
              {sessions > 8 ? "…" : ""}
            </span>
            <span className="bg-gradient-to-r from-rose-300 to-amber-300 bg-clip-text text-lg font-extrabold tabular-nums text-transparent">
              {sessions}
            </span>
          </span>
        </div>

        {/* ------- Historique 7 jours ------- */}
        <WeekHistory sessions={sessions} />

        <p className="text-center text-[10px] leading-relaxed text-zinc-600">
          <kbd className="rounded border border-white/10 bg-zinc-900 px-1.5 py-0.5 font-mono text-[9px] text-zinc-400">
            Échap
          </kbd>{" "}
          ou la croix arrête la session à tout moment · à la fin : carillon
          doré et retour à la normale
        </p>
      </div>
    </ScrollArea>
  );
}

/** Numéro de semaine ISO 8601 (lundi = premier jour). */
function isoWeekNumber(date: Date): number {
  const utc = new Date(
    Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()),
  );
  const dayNum = utc.getUTCDay() || 7;
  utc.setUTCDate(utc.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(utc.getUTCFullYear(), 0, 1));
  return Math.ceil(((utc.getTime() - yearStart.getTime()) / 86_400_000 + 1) / 7);
}

/** « 15 sept. » à partir d'une clé ISO « YYYY-MM-DD ». */
function shortFrenchDate(isoDate: string): string {
  const date = new Date(`${isoDate}T12:00:00`);
  if (Number.isNaN(date.getTime())) return isoDate;
  try {
    return new Intl.DateTimeFormat("fr-FR", {
      day: "numeric",
      month: "short",
    }).format(date);
  } catch {
    return isoDate;
  }
}

/**
 * Graphique en barres des sessions réussies sur les 7 derniers jours
 * (persisté dans localStorage via le store — voir getFocusHistory).
 * Re-render à chaque changement du compteur du jour (prop sessions).
 * Bouton « Copier les stats » : résumé texte (semaine ISO) vers le
 * presse-papiers — Clipboard API puis repli execCommand.
 */
function WeekHistory({ sessions }: { sessions: number }) {
  const days = getFocusHistory();
  const max = Math.max(1, ...days.map((d) => d.count));
  const total = days.reduce((sum, day) => sum + day.count, 0);
  const best = days.reduce((best, day) => (day.count > best.count ? day : best), days[0]);
  const hasData = total > 0;
  const [copyState, setCopyState] = useState<"idle" | "done" | "failed">("idle");

  const copyStats = async () => {
    const now = new Date();
    const week = isoWeekNumber(now);
    const first = days[0];
    const last = days[days.length - 1];
    const lines = days.map(
      (day) =>
        `  ${day.label} ${shortFrenchDate(day.date)} — ${
          day.count === 0 ? "—" : `${day.count} session${day.count > 1 ? "s" : ""}`
        }`,
    );
    const record =
      hasData && best.count > 0
        ? ` · record ${best.count} (${best.label} ${shortFrenchDate(best.date)})`
        : "";
    const text = [
      `Sakinah Focus — 7 derniers jours (semaine ISO ${week} · ${shortFrenchDate(
        first.date,
      )} → ${shortFrenchDate(last.date)})`,
      ...lines,
      `Total : ${total} session${total > 1 ? "s" : ""}${record} · aujourd'hui : ${sessions}`,
    ].join("\n");

    let ok = false;
    try {
      await navigator.clipboard.writeText(text);
      ok = true;
    } catch {
      /* Clipboard API refusée → repli execCommand */
    }
    if (!ok) {
      try {
        const ta = document.createElement("textarea");
        ta.value = text;
        ta.setAttribute("readonly", "");
        ta.style.position = "fixed";
        ta.style.opacity = "0";
        document.body.appendChild(ta);
        ta.select();
        ok = document.execCommand("copy");
        document.body.removeChild(ta);
      } catch {
        /* les deux méthodes indisponibles */
      }
    }

    setCopyState(ok ? "done" : "failed");
    setTimeout(() => setCopyState("idle"), 2200);
  };


  return (
    <div className="w-full rounded-xl border border-white/5 bg-zinc-900/60 p-3">
      <div className="flex items-center justify-between gap-2">
        <p className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-[0.18em] text-amber-400">
          <Flame className="h-3 w-3" aria-hidden />
          Cette semaine
        </p>
        <div className="flex min-w-0 items-center gap-2">
          <p className="truncate text-[10px] text-zinc-600">
            {total} session{total > 1 ? "s" : ""}
            {hasData && best.count > 0 && (
              <> · record {best.count} le {best.label}</>
            )}
          </p>
          {hasData && (
            <button
              type="button"
              onClick={copyStats}
              aria-label="Copier les statistiques de la semaine dans le presse-papiers"
              className={cn(
                "flex shrink-0 items-center gap-1 rounded-full border px-2 py-0.5 text-[9px] font-semibold transition-colors",
                copyState === "done"
                  ? "border-rose-400/60 bg-rose-500/15 text-rose-300"
                  : copyState === "failed"
                    ? "border-amber-500/50 bg-amber-500/10 text-amber-300"
                    : "border-white/10 bg-zinc-900 text-zinc-400 hover:border-white/25 hover:text-zinc-200",
              )}
            >
              {copyState === "done" ? (
                <>
                  <Check className="h-2.5 w-2.5" aria-hidden />
                  Copié !
                </>
              ) : copyState === "failed" ? (
                "Copie impossible ici"
              ) : (
                <>
                  <Copy className="h-2.5 w-2.5" aria-hidden />
                  Copier les stats
                </>
              )}
            </button>
          )}
        </div>
      </div>

      <div
        className="mt-2.5 flex items-end gap-1.5"
        role="img"
        aria-label={`Sessions de focus des 7 derniers jours : ${days
          .map((d) => `${d.label} ${d.count}`)
          .join(", ")}`}
      >
        {days.map((day) => {
          const height = day.count === 0 ? 3 : Math.max(8, (day.count / max) * 44);
          return (
            <div
              key={day.date}
              className="flex flex-1 flex-col items-center gap-1"
              title={`${day.label} — ${day.count} session${day.count > 1 ? "s" : ""}`}
            >
              <div
                aria-hidden="true"
                style={{ height: `${height}px` }}
                className={cn(
                  "w-full max-w-[18px] rounded-sm transition-all duration-500",
                  day.count === 0
                    ? "bg-white/10"
                    : day.isToday
                      ? "bg-gradient-to-t from-rose-600 to-amber-400 shadow-[0_0_12px_-2px_rgba(251,146,60,0.55)]"
                      : "bg-gradient-to-t from-rose-700/60 to-amber-500/50",
                )}
              />
              <span
                className={cn(
                  "text-[9px] font-medium capitalize",
                  day.isToday ? "text-rose-300" : "text-zinc-600",
                )}
              >
                {day.label}
              </span>
            </div>
          );
        })}
      </div>

      <p className="mt-2 text-center text-[9px] leading-relaxed text-zinc-600">
        {hasData
          ? `Compteur du jour synchronisé (${sessions}) — historique conservé 7 jours dans ce navigateur.`
          : "Chaque session terminée remplit le graphique du jour."}
      </p>
    </div>
  );
}
