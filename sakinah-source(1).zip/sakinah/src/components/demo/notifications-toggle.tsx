/**
 * Bouton « Rappels navigateur » de l'onglet Prières — replique web des
 * notifications Windows de l'application : 15 minutes avant chaque prière
 * et à l'heure exacte (voir use-prayer-notifications.ts).
 *
 * États gérés : non supporté (caché), permission refusée (message),
 * activé / désactivé (interrupteur) — plus un bouton « Tester » qui montre
 * à quoi ressemblera le vrai rappel (même libellé que le T-15 min).
 */

"use client";

import { useState } from "react";
import { Bell, BellOff, BellRing, Send } from "lucide-react";
import { usePrayerNotifications } from "@/hooks/use-prayer-notifications";
import { useDemoStore } from "@/lib/demo-store";
import { computeNextPrayer } from "@/lib/prayer-utils";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";

export function NotificationsToggle() {
  const { enabled, supported, permission, enable, disable } =
    usePrayerNotifications();
  const prayers = useDemoStore((state) => state.prayers);
  /** « envoyé » 2,4 s après un test réussi, « impossible » en cas d'échec. */
  const [testState, setTestState] = useState<"idle" | "sent" | "failed">(
    "idle",
  );

  // Notification API absente (navigateur exotique) → on n'affiche rien.
  if (!supported) return null;

  const denied = permission === "denied";

  /** Envoie une notification d'exemple calquée sur le vrai rappel T-15 min
   *  (demande la permission au passage si elle n'est pas encore donnée). */
  const sendTest = async () => {
    if (!("Notification" in window)) return;
    let perm = Notification.permission;
    if (perm === "default") {
      perm = await Notification.requestPermission();
    }
    if (perm !== "granted") {
      setTestState("failed");
      setTimeout(() => setTestState("idle"), 2400);
      return;
    }
    const next = prayers
      ? computeNextPrayer(
          prayers.times,
          prayers.tomorrowFajr,
          prayers.timezone,
        )
      : null;
    try {
      if (next) {
        new Notification(`${next.label} à ${next.time}`, {
          body: `Aperçu du rappel : la prière de ${next.label} commence dans 15 minutes — prépare-toi.`,
          icon: "/icon.svg",
          tag: "sakinah-test",
        });
      } else {
        new Notification("Aperçu d'un rappel Sakinah", {
          body: "Vous serez averti 15 minutes avant chaque prière et à l'heure exacte.",
          icon: "/icon.svg",
          tag: "sakinah-test",
        });
      }
      setTestState("sent");
    } catch {
      setTestState("failed");
    }
    setTimeout(() => setTestState("idle"), 2400);
  };

  return (
    <section
      aria-label="Rappels dans le navigateur"
      className="flex items-center justify-between gap-3 rounded-xl border border-white/5 bg-zinc-900/60 px-3.5 py-2.5"
    >
      <div className="flex min-w-0 items-center gap-2.5">
        <span
          className={`grid h-7 w-7 shrink-0 place-items-center rounded-lg ${
            enabled
              ? "bg-emerald-500/15 text-emerald-400"
              : "bg-zinc-800/80 text-zinc-500"
          }`}
          aria-hidden
        >
          {enabled ? (
            <BellRing className="h-3.5 w-3.5" />
          ) : denied ? (
            <BellOff className="h-3.5 w-3.5" />
          ) : (
            <Bell className="h-3.5 w-3.5" />
          )}
        </span>
        <div className="min-w-0">
          <p className="text-xs font-semibold text-zinc-200">
            Rappels navigateur
          </p>
          <p className="truncate text-[10px] leading-snug text-zinc-500">
            {denied
              ? "Bloqués dans les réglages du navigateur"
              : enabled
                ? "15 min avant + à l'heure · tant que l'onglet est ouvert"
                : "Soyez averti avant chaque prière"}
          </p>
        </div>
      </div>
      <div className="flex shrink-0 items-center gap-2">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => void sendTest()}
          disabled={denied}
          className="h-7 gap-1.5 rounded-full border border-white/10 px-2.5 text-[10px] font-medium text-zinc-400 transition-colors hover:border-emerald-500/30 hover:bg-emerald-500/5 hover:text-emerald-300"
          aria-label="Envoyer un rappel de test dans le navigateur"
        >
          <Send className="h-3 w-3" aria-hidden />
          {testState === "sent"
            ? "Envoyé !"
            : testState === "failed"
              ? "Impossible"
              : "Tester"}
        </Button>
        <Switch
          checked={enabled}
          onCheckedChange={(checked) => (checked ? void enable() : disable())}
          disabled={denied}
          aria-label="Activer les rappels de prières dans le navigateur"
          className="data-[state=checked]:bg-emerald-600"
        />
      </div>
    </section>
  );
}
