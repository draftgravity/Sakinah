/**
 * SakinahDemo — orchestrateur de la démo interactive (monté UNE fois
 * dans la page, il vit pendant toute la visite).
 *
 * Responsabilités (équivalent web de app/controller.py) :
 *  * réhydratation du store persisté (mosquée, préférences, position) ;
 *  * chargement des horaires Mawaqit (via /api/prayers) avec repli sur
 *    les données d'exemple si le serveur est hors-ligne ;
 *  * MINUIT AUTOMATIQUE : au changement de jour civil (ou au retour d'un
 *    onglet resté ouvert la nuit), recharge silencieuse des horaires et
 *    remise à zéro des compteurs du jour (sessions Focus, totaux Tasbih) ;
 *  * raccourcis clavier : « H » ou « Ctrl+Alt+H » → masquer/afficher le
 *    carré (comme le raccourci global de l'application Windows) ;
 *  * horloge de la session Focus (1 s) → carillon + écran de réussite ;
 *  * montage du carré, de la pop-up, du voile Focus et des paramètres.
 */

"use client";

import { useEffect, useState } from "react";
import { useDemoStore, hydrateFocusSessions } from "@/lib/demo-store";
import { useAuthStore } from "@/lib/auth-store";
import {
  ACCOUNT_SYNC_EVENT,
  flushDhikrSync,
  mergeOnLogin,
  syncFocusSession,
} from "@/lib/account-sync";
import { SAMPLE_MOSQUE } from "@/lib/sample-data";
import { readCachedPrayers, writeCachedPrayers } from "@/lib/prayers-cache";
import { useDayChange } from "@/hooks/use-day-change";
import { useWebAudio } from "@/hooks/use-web-audio";
import { WidgetSquare } from "@/components/demo/widget-square";
import { WidgetPopup } from "@/components/demo/widget-popup";
import { FocusOverlay } from "@/components/demo/focus-overlay";
import { SettingsDialog } from "@/components/demo/settings-dialog";

export default function SakinahDemo() {
  const audio = useWebAudio();

  // --- Réhydratation du store persisté + compteur du jour --------------
  // Le premier fetch attend la fin de la réhydratation pour éviter un
  // double chargement (mosquée par défaut → mosquée persistée).
  // ⚠️ Toujours `false` au départ : lors du rendu d'hydratation React,
  // `useSyncExternalStore` sert encore l'instantané SERVEUR du store
  // (mosquée par défaut) alors que zustand a déjà réhydraté de façon
  // synchrone — un `hasHydrated()` initial `true` déclencherait donc un
  // fetch avec la mauvaise mosquée avant le rattrapage du rendu suivant.
  // L'effet de montage passe `hydrated` à `true` APRÈS le premier commit,
  // quand le sélecteur a basculé sur l'état client réel.
  // ⚠️ En SSR, `localStorage` n'existe pas : le middleware persist de
  // zustand n'attache alors PAS `api.persist` — d'où l'optional chaining.
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    let unsub: (() => void) | undefined;
    const persist = useDemoStore.persist;
    if (persist) {
      if (persist.hasHydrated()) {
        // Hydratation synchrone déjà terminée (auto-réhydratation zustand).
        setHydrated(true);
      } else {
        unsub = persist.onFinishHydration(() => setHydrated(true));
        void persist.rehydrate();
      }
    } else {
      // Stockage indisponible (SSR strict, mode privé…) : direct.
      setHydrated(true);
    }
    hydrateFocusSessions();
    return unsub;
  }, []);

  // --- Chargement des horaires (mosquée choisie + bouton Actualiser) ----
  const slug = useDemoStore((state) => state.mosque.slug);
  const refreshNonce = useDemoStore((state) => state.refreshNonce);

  useEffect(() => {
    if (!hydrated) return;
    let cancelled = false;

    const load = async () => {
      // Écran de chargement UNIQUEMENT si rien n'est affiché : le
      // rechargement de minuit (« silencieux ») garde les anciens horaires
      // à l'écran jusqu'à l'arrivée des nouveaux — pas de flash à 00h00.
      if (useDemoStore.getState().prayers === null) {
        useDemoStore.getState().setPrayers(null, "loading");
      }
      try {
        const response = await fetch(
          `/api/prayers?slug=${encodeURIComponent(slug)}`,
          { signal: AbortSignal.timeout(13000) },
        );
        if (!response.ok) throw new Error(`status ${response.status}`);
        const data = await response.json();
        if (!cancelled) {
          useDemoStore.getState().setPrayers(data, "live");
          // Mémorise les horaires de « sa » mosquée pour la reprise hors ligne.
          writeCachedPrayers(data);
        }
      } catch {
        if (!cancelled) {
          // Repli hors ligne : derniers horaires connus de cette mosquée,
          // sinon jeu d'exemple (Paris) + badge « hors ligne ».
          const cached = readCachedPrayers(slug);
          if (cached) {
            useDemoStore.getState().setPrayers(cached, "cache");
          } else {
            useDemoStore.getState().setPrayers(SAMPLE_MOSQUE, "sample");
          }
        }
      }
    };

    void load();
    return () => {
      cancelled = true;
    };
  }, [hydrated, slug, refreshNonce]);

  // --- Compte connecté : données « en ligne d'abord » ------------------
  // À la connexion (ou au retour de session), les données LOCALES sont
  // poussées au serveur (fusion par maximum), puis l'état fusionné du
  // serveur remplace le cache local — le compte devient la source de
  // vérité, l'appareil n'est plus qu'un cache.
  const userId = useAuthStore((state) => state.user?.id ?? null);
  useEffect(() => {
    if (!userId) return;
    void mergeOnLogin();
  }, [userId]);

  // Le serveur a réécrit le cache local (connexion / meilleur appareil) →
  // ré-hydrate le compteur Focus du jour.
  useEffect(() => {
    const onAccountSync = () => hydrateFocusSessions();
    window.addEventListener(ACCOUNT_SYNC_EVENT, onAccountSync);
    return () => window.removeEventListener(ACCOUNT_SYNC_EVENT, onAccountSync);
  }, []);

  // Fermeture de l'onglet : envoie le dhikr tapé depuis le dernier flush
  // (le debounce de 1,5 s n'aura pas le temps de partir autrement).
  useEffect(() => {
    const onPageHide = () => {
      void flushDhikrSync();
    };
    window.addEventListener("pagehide", onPageHide);
    return () => window.removeEventListener("pagehide", onPageHide);
  }, []);

  // --- Minuit automatique -------------------------------------------------
  // Changement de jour civil (ou retour d'un onglet resté ouvert la nuit) :
  //  * recharge SILENCIEUSE des horaires (sans écran de chargement) — les
  //    horaires d'hier deviendraient faux dès 00h00 ;
  //  * re-hydrate les compteurs du jour (sessions Focus) pour appliquer
  //    leur remise à zéro au changement de date.
  useDayChange(() => {
    useDemoStore.getState().silentRefreshPrayers();
    hydrateFocusSessions();
  });

  // --- Raccourcis clavier : H / Ctrl+Alt+H ------------------------------
  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      const typing =
        target &&
        (target.tagName === "INPUT" ||
          target.tagName === "TEXTAREA" ||
          target.tagName === "SELECT" ||
          target.isContentEditable);
      if (typing) return;

      const key = event.key.toLowerCase();
      const isCombo = event.ctrlKey && event.altKey && key === "h";
      const isPlainH =
        key === "h" && !event.ctrlKey && !event.altKey && !event.metaKey;
      if (isCombo || isPlainH) {
        event.preventDefault();
        useDemoStore.getState().toggleWidget();
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, []);

  // --- Horloge de la session Focus ---------------------------------------
  const focusActive = useDemoStore((state) => state.focusActive);
  const focusCompleted = useDemoStore((state) => state.focusCompleted);

  useEffect(() => {
    if (!focusActive || focusCompleted) return;
    const id = setInterval(() => {
      const state = useDemoStore.getState();
      if (!state.focusActive || state.focusCompleted) return;
      if (state.focusRemainingSec <= 1) {
        // Fin de session : carillon + compte immédiat + écran de réussite.
        audio.playChime(state.focusVolume);
        state.completeFocus();
        // Compte connecté → la session part immédiatement vers la base
        // en ligne (sinon elle reste dans le cache local de la démo).
        void syncFocusSession(state.focusDurationSec);
      } else {
        state.tickFocus();
      }
    }, 1000);
    return () => clearInterval(id);
  }, [focusActive, focusCompleted, audio]);

  return (
    <>
      <WidgetSquare />
      <WidgetPopup />
      <FocusOverlay audio={audio} />
      <SettingsDialog />
    </>
  );
}
