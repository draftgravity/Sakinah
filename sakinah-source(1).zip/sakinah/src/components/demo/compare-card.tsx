/**
 * Carte « Comparer avec une autre mosquée » de l'onglet Prières :
 *  * recherche Mawaqit (via /api/mosques/search) d'une seconde mosquée ;
 *  * tableau côte à côte des adhans du jour + écarts signés en minutes ;
 *  * ligne Jumu'a + actions « Changer » / « Fermer » ;
 *  * la mosquée comparée est PERSISTÉE (store zustand) : la comparaison
 *    survit au changement d'onglet et au rechargement de la page.
 *
 * Les données viennent des mêmes routes que le reste de la démo
 * (/api/prayers?slug=…), l'heure de chaque mosquée suit son propre fuseau.
 */

"use client";

import { useEffect, useRef, useState } from "react";
import {
  GitCompareArrows,
  Loader2,
  MapPin,
  Search,
  X,
} from "lucide-react";
import { useDemoStore } from "@/lib/demo-store";
import {
  PRAYERS,
  timeToSeconds,
  type PrayersPayload,
} from "@/lib/prayer-utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";

interface MosqueSearchItem {
  slug: string;
  name: string;
  localisation: string;
}

/** « +3 min » / « −12 min » / « ±0 » — séparateur typographique français. */
function formatDelta(seconds: number): string {
  if (seconds === 0) return "±0";
  const minutes = Math.round(seconds / 60);
  if (minutes === 0) return seconds > 0 ? "+<1 min" : "−<1 min";
  return `${minutes > 0 ? "+" : "−"}${Math.abs(minutes)} min`;
}

export function CompareCard() {
  const current = useDemoStore((state) => state.prayers);
  const currentName = useDemoStore((state) => state.mosque.name);
  const compareMosque = useDemoStore((state) => state.compareMosque);
  const setCompareMosque = useDemoStore((state) => state.setCompareMosque);
  const region = useDemoStore((state) => state.region);

  // La carte s'ouvre d'elle-même si une comparaison est déjà mémorisée.
  const [open, setOpen] = useState(() => useDemoStore.getState().compareMosque !== null);
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<MosqueSearchItem[] | null>(null);
  const [searching, setSearching] = useState(false);
  const [offline, setOffline] = useState(false);
  const [other, setOther] = useState<PrayersPayload | null>(null);
  const [loadingOther, setLoadingOther] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  /** slug dont la restauration est déjà en cours (anti-double-fetch). */
  const restoringRef = useRef<string | null>(null);

  // Restauration : une mosquée comparée mémorisée mais pas encore chargée
  // (changement d'onglet, rechargement) → fetch automatique de ses horaires.
  // ⚠️ Pas de `loadingOther` dans les dépendances : l'effet s'annulerait
  // lui-même (le setLoadingOther(true) déclenche le cleanup qui annule le
  // fetch). Le garde `restoringRef` évite le double appel (StrictMode).
  useEffect(() => {
    if (!open || !compareMosque || other || error) return;
    if (restoringRef.current === compareMosque.slug) return;
    restoringRef.current = compareMosque.slug;
    setLoadingOther(true);
    const load = async () => {
      try {
        const response = await fetch(
          `/api/prayers?slug=${encodeURIComponent(compareMosque.slug)}`,
          { signal: AbortSignal.timeout(13000) },
        );
        if (!response.ok) throw new Error(`status ${response.status}`);
        const data = (await response.json()) as PrayersPayload;
        setOther(data);
      } catch {
        setError("Horaires indisponibles pour cette mosquée — réessayez.");
        restoringRef.current = null;
      } finally {
        setLoadingOther(false);
      }
    };
    void load();
  }, [open, compareMosque, other, error]);

  // Recherche debouncée (400 ms) dès 2 caractères — mêmes règles que les
  // paramètres, résultats limités aux 6 premiers pour rester compact.
  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    const trimmed = query.trim();
    if (trimmed.length < 2) {
      setResults(null);
      setSearching(false);
      setOffline(false);
      return;
    }
    setSearching(true);
    debounceRef.current = setTimeout(async () => {
      try {
        const regionParam =
          region && region !== "all" ? `&region=${region}` : "";
        const response = await fetch(
          `/api/mosques/search?q=${encodeURIComponent(trimmed)}${regionParam}`,
          { signal: AbortSignal.timeout(10000) },
        );
        const data = await response.json();
        setResults(
          Array.isArray(data.mosques) ? data.mosques.slice(0, 6) : [],
        );
        setOffline(data.source === "offline");
      } catch {
        setResults([]);
        setOffline(true);
      } finally {
        setSearching(false);
      }
    }, 400);
    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
    };
  }, [query, region]);

  /** Charge les horaires de la mosquée comparée (et les mémorise). */
  const pickMosque = async (item: MosqueSearchItem) => {
    setQuery("");
    setResults(null);
    setLoadingOther(true);
    setError(null);
    try {
      const response = await fetch(
        `/api/prayers?slug=${encodeURIComponent(item.slug)}`,
        { signal: AbortSignal.timeout(13000) },
      );
      if (!response.ok) throw new Error(`status ${response.status}`);
      const data = (await response.json()) as PrayersPayload;
      setOther(data);
      setCompareMosque({ slug: item.slug, name: item.name });
    } catch {
      setError("Horaires indisponibles pour cette mosquée — réessayez.");
      setOther(null);
      setCompareMosque(null);
    } finally {
      setLoadingOther(false);
    }
  };

  const close = () => {
    setOpen(false);
    setQuery("");
    setResults(null);
    setOther(null);
    setError(null);
    setCompareMosque(null);
  };

  /* ------- État replié ------- */
  if (!open) {
    return (
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="flex w-full items-center justify-between rounded-xl border border-white/5 bg-zinc-900/60 px-3.5 py-2.5 text-left transition-colors hover:border-white/10 hover:bg-zinc-900"
      >
        <span className="flex items-center gap-2">
          <GitCompareArrows className="h-4 w-4 text-emerald-400" aria-hidden />
          <span className="text-xs font-semibold text-zinc-200">
            Comparer avec une autre mosquée
          </span>
        </span>
        <span className="text-[10px] font-normal text-zinc-500">
          côte à côte
        </span>
      </button>
    );
  }

  /* ------- État étendu ------- */
  return (
    <section
      aria-label="Comparaison de mosquées"
      className="rounded-xl border border-white/5 bg-zinc-900/60 p-3.5"
    >
      <div className="flex items-center justify-between gap-2">
        <p className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-[0.18em] text-emerald-400">
          <GitCompareArrows className="h-3 w-3" aria-hidden />
          Comparer deux mosquées
        </p>
        <Button
          variant="ghost"
          size="sm"
          className="h-7 w-7 p-0 text-zinc-500 hover:text-zinc-100"
          onClick={close}
          aria-label="Fermer la comparaison"
        >
          <X className="h-4 w-4" aria-hidden />
        </Button>
      </div>

      {/* --- Choix de la seconde mosquée --- */}
      {!other && !loadingOther && (
        <div className="mt-2.5">
          <div className="relative">
            <Search
              className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-zinc-500"
              aria-hidden
            />
            <Input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Nom, ville, code postal…"
              className="h-9 min-w-0 border-white/10 bg-zinc-950/60 pl-8 text-xs placeholder:text-zinc-600 focus-visible:ring-emerald-500/40"
              aria-label="Rechercher la mosquée à comparer"
              autoComplete="off"
            />
            {searching && (
              <Loader2
                className="absolute right-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 animate-spin text-zinc-500"
                aria-hidden
              />
            )}
          </div>

          {error && (
            <p className="mt-2 text-[11px] text-amber-400" role="alert">
              {error}
            </p>
          )}

          {results && results.length === 0 && !searching && (
            <p className="mt-2 text-[11px] text-zinc-500">
              {offline
                ? "Recherche indisponible (hors ligne)."
                : "Aucune mosquée trouvée pour cette recherche."}
            </p>
          )}

          {results && results.length > 0 && (
            <ScrollArea className="mt-2 max-h-44">
              <ul className="space-y-1 pr-1.5">
                {results.map((item) => (
                  <li key={item.slug} className="min-w-0">
                    <button
                      type="button"
                      onClick={() => void pickMosque(item)}
                      className="w-full rounded-lg border border-white/5 bg-zinc-950/40 px-2.5 py-2 text-left transition-colors hover:border-emerald-500/30 hover:bg-emerald-500/5"
                    >
                      <span className="block truncate text-xs font-semibold text-zinc-200">
                        {item.name}
                      </span>
                      <span className="mt-0.5 flex items-center gap-1 truncate text-[10px] text-zinc-500">
                        <MapPin className="h-2.5 w-2.5 shrink-0" aria-hidden />
                        <span className="truncate">{item.localisation}</span>
                      </span>
                    </button>
                  </li>
                ))}
              </ul>
            </ScrollArea>
          )}

          {results === null && !searching && (
            <p className="mt-2 text-[10px] leading-relaxed text-zinc-600">
              Comparez les adhans du jour entre deux mosquées Mawaqit — utile
              avant de voyager ou pour choisir où prier.
            </p>
          )}
        </div>
      )}

      {/* --- Chargement de la seconde mosquée --- */}
      {loadingOther && (
        <div className="mt-3 space-y-2" aria-live="polite">
          <Skeleton className="h-4 w-3/4" />
          <Skeleton className="h-6 w-full" />
          <Skeleton className="h-6 w-full" />
          <Skeleton className="h-6 w-5/6" />
        </div>
      )}

      {/* --- Tableau de comparaison --- */}
      {other && !loadingOther && current && (
        <div className="mt-2.5">
          <table className="w-full border-collapse">
            <caption className="sr-only">
              Comparaison des horaires d&apos;adhan du jour entre {currentName}{" "}
              et {other.name}
            </caption>
            <thead>
              <tr className="border-b border-white/10">
                <th scope="col" className="pb-1.5 text-left text-[9px] font-semibold uppercase tracking-wider text-zinc-600">
                  Prière
                </th>
                <th scope="col" className="pb-1.5 text-center text-[11px] font-bold text-zinc-200" title={currentName}>
                  <span className="line-clamp-1">{currentName}</span>
                </th>
                <th scope="col" className="pb-1.5 text-right text-[11px] font-bold text-emerald-300" title={other.name}>
                  <span className="line-clamp-1">{other.name}</span>
                </th>
                <th scope="col" className="pb-1.5 pl-1.5 text-right text-[9px] font-semibold uppercase tracking-wider text-zinc-600">
                  Écart
                </th>
              </tr>
            </thead>
            <tbody>
              {PRAYERS.map((prayer) => {
                const a = timeToSeconds(current.times?.[prayer.key]);
                const b = timeToSeconds(other.times?.[prayer.key]);
                const delta = a !== null && b !== null ? b - a : null;
                return (
                  <tr
                    key={prayer.key}
                    className="border-b border-white/[0.04] transition-colors last:border-0 odd:bg-white/[0.015] hover:bg-white/[0.04]"
                  >
                    <th
                      scope="row"
                      className="py-1.5 pr-1 text-left text-[11px] font-medium text-zinc-400"
                    >
                      {prayer.label}
                    </th>
                    <td className="py-1.5 text-center font-mono text-xs font-bold tabular-nums text-zinc-200">
                      {current.times?.[prayer.key] ?? "--:--"}
                    </td>
                    <td className="py-1.5 text-right font-mono text-xs font-bold tabular-nums text-emerald-300">
                      {other.times?.[prayer.key] ?? "--:--"}
                    </td>
                    <td
                      className={cn(
                        "py-1.5 pl-1.5 text-right font-mono text-[10px] font-semibold tabular-nums",
                        delta === null
                          ? "text-zinc-600"
                          : delta > 0
                            ? "text-amber-400/90"
                          : delta < 0
                              ? "text-emerald-400/90"
                              : "text-zinc-500",
                      )}
                      aria-label={
                        delta === null
                          ? "Écart inconnu"
                          : `Écart de ${formatDelta(delta)}`
                      }
                    >
                      {delta === null ? "—" : formatDelta(delta)}
                    </td>
                  </tr>
                );
              })}
              {(current.jumua || other.jumua) && (
                <tr className="border-t border-white/10 bg-white/[0.02]">
                  <th
                    scope="row"
                    className="py-1.5 pr-1 text-left text-[11px] font-semibold text-zinc-300"
                  >
                    Jumu&apos;a
                  </th>
                  <td className="py-1.5 text-center font-mono text-xs font-bold tabular-nums text-zinc-300">
                    {current.jumua ?? "—"}
                  </td>
                  <td className="py-1.5 text-right font-mono text-xs font-bold tabular-nums text-emerald-300">
                    {other.jumua ?? "—"}
                  </td>
                  <td className="py-1.5 pl-1.5 text-right font-mono text-[10px] text-zinc-600">
                    —
                  </td>
                </tr>
              )}
            </tbody>
          </table>

          <div className="mt-2.5 flex items-center justify-between gap-2">
            <p className="text-[9px] leading-relaxed text-zinc-600">
              Adhans du jour ·{" "}
              {current.timezone === other.timezone
                ? "même fuseau"
                : "fuseaux différents"}
            </p>
            <Button
              variant="ghost"
              size="sm"
              className="h-7 gap-1.5 rounded-full border border-white/10 px-3 text-[11px] text-zinc-400 transition-colors hover:border-emerald-500/30 hover:bg-emerald-500/5 hover:text-emerald-300"
              onClick={() => {
                setOther(null);
                setError(null);
                setCompareMosque(null);
              }}
            >
              <Search className="h-3 w-3" aria-hidden />
              Changer
            </Button>
          </div>
        </div>
      )}

      {/* --- Cas dégradé : horaires principaux pas encore chargés --- */}
      {other && !current && (
        <p className="mt-2 text-[11px] text-zinc-500" role="alert">
          Les horaires de votre mosquée ne sont pas encore chargés — réessayez
          dans un instant.
        </p>
      )}
    </section>
  );
}
