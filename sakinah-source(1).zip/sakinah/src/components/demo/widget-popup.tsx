/**
 * La pop-up principale de la démo — replica web de app/main_window.py :
 * apparaît sous le carré noir, se referme au clic extérieur ou via Échap,
 * et contient les deux onglets « Prières » et « Mode Focus ».
 */

"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { MoonStar, Settings2, ShieldCheck, Timer, X } from "lucide-react";
import { useDemoStore, type PopupTab } from "@/lib/demo-store";
import { useAuthStore } from "@/lib/auth-store";
import { computeNextPrayer, formatRemaining, useNow } from "@/lib/prayer-utils";
import { PrayersTabDemo } from "@/components/demo/prayers-tab";
import { FocusTabDemo } from "@/components/demo/focus-tab";

const WIDTH = 400;

const TABS: { key: PopupTab; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { key: "prayers", label: "Prières", icon: MoonStar },
  { key: "focus", label: "Mode Focus", icon: Timer },
];

export function WidgetPopup() {
  const open = useDemoStore((state) => state.popupOpen);
  const tab = useDemoStore((state) => state.popupTab);
  const setTab = useDemoStore((state) => state.setPopupTab);
  const closePopup = useDemoStore((state) => state.closePopup);
  const setSettingsOpen = useDemoStore((state) => state.setSettingsOpen);
  const widgetPos = useDemoStore((state) => state.widgetPos);
  const mosque = useDemoStore((state) => state.mosque);
  const prayers = useDemoStore((state) => state.prayers);

  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  // Version « normale » vs « gérant » : l'onglet Mode Focus n'est proposé
  // qu'aux comptes GÉRANT qui ont choisi la version complète (préférence
  // « focusEnabled » conservée en ligne, modifiable depuis l'espace gérant).
  const isManager = useAuthStore(
    (state) => state.user?.role === "MANAGER" && state.user.focusEnabled,
  );
  const visibleTabs = isManager
    ? TABS
    : TABS.filter((item) => item.key !== "focus");
  const activeTab: PopupTab = isManager ? tab : "prayers";

  // Échap referme la pop-up.
  useEffect(() => {
    if (!open) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") closePopup();
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [open, closePopup]);

  // Verrou « vraie fenêtre » : tant que la pop-up est ouverte, la molette
  // ne fait PLUS défiler la page derrière — le défilement reste DANS la
  // pop-up (comportement d'une application, pas d'une page web). La
  // largeur de la barre de défilement est compensée pour éviter tout
  // saut de mise en page.
  useEffect(() => {
    if (!open) return;
    const body = document.body;
    const previousOverflow = body.style.overflow;
    const previousPaddingRight = body.style.paddingRight;
    const scrollbar =
      window.innerWidth - document.documentElement.clientWidth;
    body.style.overflow = "hidden";
    if (scrollbar > 0) body.style.paddingRight = `${scrollbar}px`;
    return () => {
      body.style.overflow = previousOverflow;
      body.style.paddingRight = previousPaddingRight;
    };
  }, [open]);

  const now = useNow(1000);
  const next = prayers
    ? computeNextPrayer(prayers.times, prayers.tomorrowFajr, prayers.timezone)
    : null;
  const remaining = next
    ? Math.max(0, (next.datetime.getTime() - now.getTime()) / 1000)
    : null;

  if (!mounted || !open || !widgetPos) return null;

  // Positionnement : aligné à droite sous le carré, calé dans l'écran.
  const vw = window.innerWidth;
  const vh = window.innerHeight;
  const isCompact = vw < 480;
  const width = isCompact ? vw - 24 : WIDTH;
  let left = isCompact ? 12 : widgetPos.x + 20 - WIDTH;
  left = Math.min(Math.max(8, left), vw - width - 8);
  let top = widgetPos.y + 52;
  const maxPanelHeight = Math.max(320, vh - top - 16);
  if (top + 420 > vh) top = Math.max(72, vh - 470);

  return (
    <>
      {/* Clic extérieur → fermeture (comportement flyout de l'app) */}
      <button
        type="button"
        aria-label="Fermer"
        className="fixed inset-0 z-[74] cursor-default"
        onClick={closePopup}
      />

      <AnimatePresence>
        <motion.aside
          key="sakinah-popup"
          role="dialog"
          aria-label="Sakinah — fenêtre principale"
          initial={{ opacity: 0, y: -10, scale: 0.97 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -8, scale: 0.97 }}
          transition={{ type: "spring", stiffness: 380, damping: 30 }}
          style={{ left, top, width, height: maxPanelHeight, maxHeight: maxPanelHeight }}
          className="fixed z-[80] flex flex-col overflow-hidden rounded-2xl border border-white/10 bg-zinc-950/95 shadow-2xl shadow-black/60 backdrop-blur-xl"
        >
          {/* ------- En-tête ------- */}
          <header className="relative flex items-center gap-2.5 border-b border-white/5 px-4 py-3">
            {/* liseré dégradé émeraude sous l'en-tête */}
            <span
              aria-hidden="true"
              className="absolute inset-x-0 bottom-0 h-px bg-gradient-to-r from-transparent via-emerald-500/40 to-transparent"
            />
            <span className="grid h-7 w-7 place-items-center rounded-lg bg-[#0a0a0b] text-emerald-400">
              <MoonStar className="h-4 w-4" aria-hidden />
            </span>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-bold tracking-wide">Sakinah</p>
              <p className="truncate text-[11px] text-zinc-500">{mosque.name}</p>
            </div>
            <button
              type="button"
              onClick={() => setSettingsOpen(true)}
              className="grid h-8 w-8 place-items-center rounded-lg text-zinc-400 transition-colors hover:bg-white/5 hover:text-zinc-100"
              aria-label="Paramètres"
              title="Paramètres"
            >
              <Settings2 className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={closePopup}
              className="grid h-8 w-8 place-items-center rounded-lg text-zinc-400 transition-colors hover:bg-red-500/10 hover:text-red-400"
              aria-label="Fermer"
              title="Fermer"
            >
              <X className="h-4 w-4" />
            </button>
          </header>

          {/* ------- Onglets ------- */}
          <nav className="flex gap-1 px-3 pt-2" role="tablist">
            {visibleTabs.map(({ key, label, icon: Icon }) => {
              const active = tab === key;
              return (
                <button
                  key={key}
                  type="button"
                  role="tab"
                  aria-selected={active}
                  onClick={() => setTab(key)}
                  title={key === "focus" ? "Réservé au gérant" : undefined}
                  className={`relative flex flex-1 items-center justify-center gap-2 rounded-lg px-3 py-2 text-xs font-semibold transition-colors ${
                    active
                      ? "bg-emerald-500/10 text-emerald-300"
                      : "text-zinc-400 hover:bg-white/5 hover:text-zinc-200"
                  }`}
                >
                  <Icon className="h-3.5 w-3.5" aria-hidden />
                  {label}
                  {key === "focus" && (
                    <ShieldCheck
                      className="h-3 w-3 text-amber-400/80"
                      aria-label="Onglet réservé au gérant"
                    />
                  )}
                </button>
              );
            })}
          </nav>

          {/* ------- Contenu ------- */}
          {/* Le wrapper « absolute inset-0 » donne une hauteur DÉFINIE à
              la zone défilable (Radix force position:relative en inline
              sur la racine ScrollArea : un simple h-full ne peut pas se
              résoudre). Sans elle, la molette remontait à la page au lieu
              de faire défiler la pop-up. */}
          <div className="relative min-h-0 flex-1 overflow-hidden">
            <div className="absolute inset-0">
              {activeTab === "prayers" ? <PrayersTabDemo /> : <FocusTabDemo />}
            </div>
          </div>

          {/* ------- Pied ------- */}
          <footer className="flex items-center justify-between border-t border-white/5 px-4 py-2.5 text-[11px]">
            <span className="text-emerald-400">
              {next
                ? `Prochaine prière : ${next.label} ${next.time} — ${formatRemaining(remaining ?? 0)}`
                : "Prochaine prière : —"}
            </span>
            <span className="text-zinc-600">v1.0.0 · PyQt6</span>
          </footer>
        </motion.aside>
      </AnimatePresence>
    </>
  );
}
