/**
 * Calendrier mensuel des prières d'une mosquée (proxy Mawaqit).
 *
 * Renvoie le calendrier ANNUEL extrait de `confData` — le même que
 * mawaqit.net affiche mois par mois : pour chaque jour, 6 horaires
 * [Fajr, Chourouk, Dhuhr, Asr, Maghrib, Isha].
 *
 * GET /api/prayers/calendar?slug=grande-mosquee-de-paris
 * → { slug, name, timezone, calendar: (Record<jour, string[]> | null)[12],
 *     iqamaCalendar?: (Record<jour, (string|null)[]> | null)[12], fetchedAt }
 *
 * `iqamaCalendar` contient, quand la mosquée les publie, les heures
 * FINALES d'iqama (délais relatifs déjà appliqués aux adhans du jour) :
 * [Fajr, Dhuhr, Asr, Maghrib, Isha] — pas de Chourouk.
 *
 * Les mois sont indexés 0 = janvier … 11 = décembre, et les clés de chaque
 * mois sont les numéros de jour ("1" … "31") — identique à confData.
 */

import { NextRequest, NextResponse } from "next/server";
import {
  fetchMosqueData,
  mawaqitErrorResponse,
  sanitizeSlug,
} from "../shared";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  const slug = sanitizeSlug(request.nextUrl.searchParams.get("slug"));
  if (!slug) {
    return NextResponse.json({ error: "Slug manquant" }, { status: 400 });
  }

  try {
    const data = await fetchMosqueData(slug);
    return NextResponse.json({
      slug: data.slug,
      name: data.name,
      timezone: data.timezone,
      calendar: data.calendar,
      // Optionnel : certaines mosquées ne publient pas d'iqama calendrier.
      ...(data.iqamaCalendar.length > 0
        ? { iqamaCalendar: data.iqamaCalendar }
        : {}),
      fetchedAt: data.fetchedAt,
    });
  } catch (error) {
    return mawaqitErrorResponse(error);
  }
}
