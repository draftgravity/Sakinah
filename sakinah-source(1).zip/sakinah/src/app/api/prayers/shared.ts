/**
 * Client Mawaqit partagé entre les routes /api/prayers et /api/prayers/calendar.
 *
 * Stratégie identique à l'application Python (app/services/mawaqit.py) :
 *  1. récupère la page publique https://mawaqit.net/fr/<slug> ;
 *  2. extrait le JSON `var confData = {...};` embarqué dans le HTML ;
 *  3. normalise : times (5 valeurs sans Chourouk + shuruq séparé),
 *     calendrier annuel (12 mois × jours × 6 horaires), Fajr de demain,
 *     jumua, nom de la mosquée, coordonnées et fuseau.
 *
 * Cache mémoire de 10 minutes partagé par toutes les routes.
 */

import { NextResponse } from "next/server";

export interface MosqueData {
  slug: string;
  name: string;
  jumua: string | null;
  /** horaires "HH:MM" du jour (clés : fajr, shourouk, dhuhr, asr, maghrib, isha) */
  times: Record<string, string | null>;
  /** horaires d'iqama (début de la prière en commun à la mosquée) du jour */
  iqama: Record<string, string | null>;
  /** premier horaire de demain (Fajr) */
  tomorrowFajr: string | null;
  /** ligne COMPLETE de demain (times + iqama) — survie hors ligne à minuit */
  tomorrow: {
    times: Record<string, string | null>;
    iqama: Record<string, string | null>;
  } | null;
  latitude: number | null;
  longitude: number | null;
  timezone: string | null;
  /** calendar[mois 0-11][jour "1".."31"] = [Fajr, Chourouk, Dhuhr, Asr, Maghrib, Isha] */
  calendar: (Record<string, string[]> | null)[];
  /** iqamaCalendar[mois 0-11][jour "1".."31"] = [Fajr, Dhuhr, Asr, Maghrib, Isha] — heures FINALES "HH:MM" (délais relatifs déjà appliqués), null si inconnu */
  iqamaCalendar: (Record<string, (string | null)[]> | null)[];
  fetchedAt: string;
}

/** Erreur transportant un statut HTTP (404 introuvable, 502 réseau…). */
export class MawaqitError extends Error {
  status: number;

  constructor(message: string, status = 502) {
    super(message);
    this.status = status;
  }
}

const CACHE_TTL_MS = 10 * 60 * 1000;
const cache = new Map<string, { data: MosqueData; timestamp: number }>();

const CONF_DATA_RE = /(?:var|let)\s+confData\s*=\s*([\s\S]*?);\s*\n/;

/** Particules françaises à garder en minuscules au milieu d'un nom. */
const FRENCH_PARTICLES = new Set([
  "de", "du", "des", "le", "la", "les", "l'", "d'",
  "en", "au", "aux", "et", "sur", "sous", "à",
]);

/** Blanchit le slug Mawaqit (identifiant URL simple). */
export function sanitizeSlug(raw: string | null | undefined): string {
  return (raw ?? "").trim().replace(/[^a-zA-Z0-9-]/g, "").slice(0, 120);
}

type TimesMap = Record<string, string | null>;

function timesFromList(values: unknown, shuruq: unknown): TimesMap {
  const result: TimesMap = {
    fajr: null,
    shourouk: null,
    dhuhr: null,
    asr: null,
    maghrib: null,
    isha: null,
  };
  if (Array.isArray(values)) {
    const items = values.map((v) => (typeof v === "string" ? v : null));
    if (items.length >= 6) {
      // Format « recherche » : [Fajr, Chourouk, Dhuhr, Asr, Maghrib, Isha]
      result.fajr = items[0];
      result.shourouk = items[1];
      result.dhuhr = items[2];
      result.asr = items[3];
      result.maghrib = items[4];
      result.isha = items[5];
    } else if (items.length === 5) {
      // Format « confData » : [Fajr, Dhuhr, Asr, Maghrib, Isha] (+ shuruq à part)
      result.fajr = items[0];
      result.dhuhr = items[1];
      result.asr = items[2];
      result.maghrib = items[3];
      result.isha = items[4];
    }
  }
  if (typeof shuruq === "string" && shuruq) {
    result.shourouk = shuruq;
  }
  return result;
}

/** calendar[month][day] → horaire à l'index donné (0 = Fajr…). */
export function calendarTime(
  calendar: unknown,
  day: Date,
  index: number,
): string | null {
  return calendarTimeAt(calendar, day.getMonth() + 1, day.getDate(), index);
}

/** calendar[mois 1-12][jour] → horaire à l'index donné (0 = Fajr…). */
function calendarTimeAt(
  calendar: unknown,
  month: number,
  day: number,
  index: number,
): string | null {
  if (!Array.isArray(calendar)) return null;
  const monthRecord = calendar[month - 1];
  if (typeof monthRecord !== "object" || monthRecord === null) return null;
  const dayValues = (monthRecord as Record<string, unknown>)[String(day)];
  if (Array.isArray(dayValues) && typeof dayValues[index] === "string") {
    return dayValues[index];
  }
  return null;
}

/** Date (année/mois/jour) dans un fuseau — null si fuseau inconnu/invalide. */
function zoneDateParts(
  tz: string | null | undefined,
  at: Date = new Date(),
): { year: number; month: number; day: number } | null {
  if (!tz) return null;
  try {
    const parts = new Intl.DateTimeFormat("en-US", {
      timeZone: tz,
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
    }).formatToParts(at);
    const get = (type: string) =>
      Number(parts.find((p) => p.type === type)?.value);
    const year = get("year");
    const month = get("month");
    const day = get("day");
    if (!year || !month || !day) return null;
    return { year, month, day };
  } catch {
    return null;
  }
}

/**
 * Même date murale + N jours, TOUJOURS dans le fuseau (arithmétique de
 * calendrier pure — insensible aux changements d'heure).
 */
function zoneDateShifted(
  tz: string | null | undefined,
  offsetDays: number,
): { year: number; month: number; day: number } | null {
  const base = zoneDateParts(tz);
  if (!base || offsetDays === 0) return base;
  const shifted = new Date(
    Date.UTC(base.year, base.month - 1, base.day) + offsetDays * 86_400_000,
  );
  return {
    year: shifted.getUTCFullYear(),
    month: shifted.getUTCMonth() + 1,
    day: shifted.getUTCDate(),
  };
}

/** Horaires 6 valeurs du calendrier → TimesMap (repli partiel si absent). */
function timesFromCalendar(
  calendar: unknown,
  date: { month: number; day: number } | null,
  fallback: TimesMap,
): TimesMap {
  if (!date) return fallback;
  const get = (index: number, key: string) =>
    calendarTimeAt(calendar, date.month, date.day, index) ?? fallback[key];
  return {
    fajr: get(0, "fajr"),
    shourouk: get(1, "shourouk"),
    dhuhr: get(2, "dhuhr"),
    asr: get(3, "asr"),
    maghrib: get(4, "maghrib"),
    isha: get(5, "isha"),
  };
}

/** Capitalisation douce si l'API renvoie un nom tout en majuscules. */
export function prettyName(raw: unknown): string {
  const text = String(raw ?? "").trim();
  if (!text) return "";
  const isUpper = /[A-ZÀ-Ý]/.test(text) && text === text.toUpperCase();
  let result = text;
  if (isUpper) {
    result = text
      .split(/\s+/)
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
      .join(" ");
  }
  // Typographie française : particules en minuscules au milieu du nom
  // (« Mosquée De Paris » → « Mosquée de Paris »).
  const words = result.split(/\s+/);
  const fixed = words.map((word, index) => {
    const lower = word.toLowerCase();
    if (index > 0 && index < words.length - 1 && FRENCH_PARTICLES.has(lower)) {
      return lower;
    }
    return word;
  });
  return fixed.join(" ");
}

/** Ajoute des minutes à "HH:MM" → "HH:MM" (retourne null si invalide). */
function addMinutes(time: string | null | undefined, minutes: number): string | null {
  if (!time) return null;
  const match = /^(\d{1,2}):(\d{2})/.exec(time.trim());
  if (!match) return null;
  const total = Number(match[1]) * 60 + Number(match[2]) + minutes;
  const hours = Math.floor(((total % 1440) + 1440) % 1440 / 60);
  const mins = ((total % 60) + 60) % 60;
  return `${String(hours).padStart(2, "0")}:${String(mins).padStart(2, "0")}`;
}

/**
 * Valeur d'iqama Mawaqit → heure finale "HH:MM". Deux formats coexistent
 * selon les mosquées :
 *  * délai relatif : "+8", "8", "+0" → ajouté à l'heure d'adhan ;
 *  * heure absolue : "06:17" → utilisée telle quelle.
 */
function iqamaTime(
  prayerTime: string | null | undefined,
  value: unknown,
): string | null {
  const text = String(value ?? "").trim();
  if (!text) return null;

  // Délai relatif : "+8", "8", "+0"
  const delayMatch = /^\+?(\d{1,3})$/.exec(text);
  if (delayMatch) return addMinutes(prayerTime, Number(delayMatch[1]));

  // Heure absolue : "06:17" / "6:17"
  const timeMatch = /^(\d{1,2}):(\d{2})$/.exec(text);
  if (timeMatch) {
    const hours = Number(timeMatch[1]);
    const minutes = Number(timeMatch[2]);
    if (hours > 23 || minutes > 59) return null;
    return `${timeMatch[1].padStart(2, "0")}:${timeMatch[2]}`;
  }
  return null;
}

/**
 * Horaires d'iqama du jour — iqamaCalendar[mois][jour] contient 5 valeurs
 * [Fajr, Dhuhr, Asr, Maghrib, Isha] (pas de Chourouk) dans DEUX formats
 * selon les mosquées :
 *  * délai relatif : "+8", "+0", "8" → minutes après l'adhan ;
 *  * heure absolue : "06:17" → iqama directement.
 * Repli : délai unique `confData.iqama` (ex. "+10").
 */
function computeIqama(
  times: TimesMap,
  iqamaCalendar: unknown,
  fallbackIqama: unknown,
  zoneToday: { month: number; day: number } | null = null,
): Record<string, string | null> {
  const result: Record<string, string | null> = {
    fajr: null,
    dhuhr: null,
    asr: null,
    maghrib: null,
    isha: null,
  };

  // Ordre des 5 prières dans iqamaCalendar (pas de Chourouk).
  const keys = ["fajr", "dhuhr", "asr", "maghrib", "isha"] as const;

  // Jour « aujourd'hui » : horloge de la mosquée si connue, sinon serveur.
  const now = new Date();
  const month = zoneToday ? zoneToday.month - 1 : now.getMonth();
  const day = zoneToday ? zoneToday.day : now.getDate();

  let dayValues: unknown[] | null = null;
  if (Array.isArray(iqamaCalendar)) {
    const monthRecord = iqamaCalendar[month];
    if (typeof monthRecord === "object" && monthRecord !== null) {
      const raw = (monthRecord as Record<string, unknown>)[String(day)];
      if (Array.isArray(raw)) dayValues = raw;
    }
  }

  for (let index = 0; index < keys.length; index += 1) {
    const key = keys[index];
    const value = dayValues?.[index] ?? fallbackIqama;
    const iqama = iqamaTime(times[key], value);
    if (iqama) result[key] = iqama;
  }
  return result;
}

/**
 * Calendrier annuel des iqamas — heures finales "HH:MM" par jour.
 *
 * `confData.iqamaCalendar[mois][jour]` contient 5 valeurs
 * [Fajr, Dhuhr, Asr, Maghrib, Isha] (pas de Chourouk) au même format que
 * l'iqama du jour : délai relatif (« +8 ») à ajouter à l'adhan DU JOUR
 * (tiré de confData.calendar, index décalé : [Fajr, Chourouk, Dhuhr, Asr,
 * Maghrib, Isha]) ou heure absolue (« 06:17 »).
 * Repli : délai unique `confData.iqama`.
 */
function computeIqamaCalendar(
  calendar: unknown,
  iqamaCalendar: unknown,
  fallbackIqama: unknown,
): (Record<string, (string | null)[]> | null)[] {
  if (!Array.isArray(iqamaCalendar)) return [];

  /** Index des adhans dans confData.calendar pour les 5 prières d'iqama. */
  const PRAYER_INDEXES = [0, 2, 3, 4, 5]; // [Fajr, Dhuhr, Asr, Maghrib, Isha]

  return iqamaCalendar.slice(0, 12).map((month, monthIndex) => {
    if (typeof month !== "object" || month === null) return null;
    const timesMonth =
      Array.isArray(calendar) &&
      typeof calendar[monthIndex] === "object" &&
      calendar[monthIndex] !== null
        ? (calendar[monthIndex] as Record<string, unknown>)
        : null;

    const days: Record<string, (string | null)[]> = {};
    for (const [day, values] of Object.entries(month as Record<string, unknown>)) {
      if (!Array.isArray(values)) continue;
      const dayTimes = timesMonth
        ? (timesMonth[day] as unknown)
        : null;
      const adhans = Array.isArray(dayTimes) ? dayTimes : null;

      const iqamas: (string | null)[] = PRAYER_INDEXES.map((prayerIndex, i) =>
        iqamaTime(
          typeof adhans?.[prayerIndex] === "string" ? adhans[prayerIndex] : null,
          values[i] ?? fallbackIqama,
        ),
      );
      // Ne garde le jour que si au moins une iqama est connue.
      if (iqamas.some((value) => value !== null)) days[day] = iqamas;
    }
    return Object.keys(days).length > 0 ? days : null;
  });
}

/** Normalise le calendrier annuel : 12 mois, chaque jour = 6 horaires max. */
function normalizeCalendar(calendar: unknown): (Record<string, string[]> | null)[] {
  if (!Array.isArray(calendar)) return [];
  return calendar.slice(0, 12).map((month) => {
    if (typeof month !== "object" || month === null) return null;
    const days: Record<string, string[]> = {};
    for (const [day, values] of Object.entries(month as Record<string, unknown>)) {
      if (Array.isArray(values)) {
        const times = values
          .filter((v): v is string => typeof v === "string")
          .slice(0, 6);
        if (times.length > 0) days[day] = times;
      }
    }
    return Object.keys(days).length > 0 ? days : null;
  });
}

function toNumber(value: unknown): number | null {
  const parsed = typeof value === "number" ? value : Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

/**
 * Récupère (ou relit depuis le cache) les données complètes d'une mosquée.
 * @throws {MawaqitError} 400 slug manquant · 404 introuvable · 502 réseau.
 */
export async function fetchMosqueData(slug: string): Promise<MosqueData> {
  const cached = cache.get(slug);
  if (cached && Date.now() - cached.timestamp < CACHE_TTL_MS) {
    return cached.data;
  }

  let page: Response;
  try {
    page = await fetch(`https://mawaqit.net/fr/${slug}`, {
      headers: {
        Accept: "text/html",
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36",
      },
      cache: "no-store",
      signal: AbortSignal.timeout(12000),
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "erreur réseau.";
    throw new MawaqitError(`Impossible de joindre mawaqit.net — ${message}`, 502);
  }

  if (page.status === 404) {
    throw new MawaqitError(
      "Mosquée introuvable sur mawaqit.net — vérifiez le slug.",
      404,
    );
  }
  if (!page.ok) {
    throw new MawaqitError(`Mawaqit a répondu ${page.status}`, 502);
  }

  const html = await page.text();
  const match = CONF_DATA_RE.exec(html);
  if (!match) {
    throw new MawaqitError("Horaires introuvables dans la page de la mosquée.", 502);
  }

  let conf: Record<string, unknown>;
  try {
    conf = JSON.parse(match[1]) as Record<string, unknown>;
  } catch {
    throw new MawaqitError("Données de la mosquée illisibles (confData).", 502);
  }

  // « Aujourd'hui » et « demain » à l'horloge de la MOSQUÉE — Mawaqit peut
  // servir la veille dans confData pendant ~2 h après minuit UTC, et le
  // serveur Next tourne en UTC : on se cale sur le calendrier annuel.
  const zoneToday = zoneDateParts(conf.timezone);
  const rawTimes = timesFromList(conf.times, conf.shuruq);
  const times = timesFromCalendar(conf.calendar, zoneToday, rawTimes);
  const calendar = normalizeCalendar(conf.calendar);
  const iqama = computeIqama(times, conf.iqamaCalendar, conf.iqama, zoneToday);
  const iqamaCalendar = computeIqamaCalendar(conf.calendar, conf.iqamaCalendar, conf.iqama);
  const zoneTomorrow = zoneDateShifted(conf.timezone, 1);
  const tomorrowFajr =
    (zoneTomorrow
      ? calendarTimeAt(conf.calendar, zoneTomorrow.month, zoneTomorrow.day, 0)
      : null) ??
    calendarTime(conf.calendar, new Date(Date.now() + 86_400_000), 0) ??
    times.fajr;

  // Ligne complète de demain (adhans + iqamas) depuis le calendrier annuel —
  // le client la met en cache pour rester exact APRÈS minuit sans réseau.
  const NULL_TIMES: Record<string, string | null> = {
    fajr: null, shourouk: null, dhuhr: null, asr: null, maghrib: null, isha: null,
  };
  const tomorrowTimes = zoneTomorrow
    ? timesFromCalendar(conf.calendar, zoneTomorrow, NULL_TIMES)
    : null;
  const hasTomorrow =
    tomorrowTimes !== null &&
    Object.values(tomorrowTimes).some((value) => value !== null);
  const tomorrow = hasTomorrow
    ? {
        times: tomorrowTimes!,
        iqama: computeIqama(
          tomorrowTimes!,
          conf.iqamaCalendar,
          conf.iqama,
          zoneTomorrow,
        ),
      }
    : null;

  const data: MosqueData = {
    slug,
    name: prettyName(conf.name ?? conf.label ?? slug),
    jumua: typeof conf.jumua === "string" ? conf.jumua : null,
    times,
    iqama,
    tomorrowFajr,
    tomorrow,
    latitude: toNumber(conf.latitude),
    longitude: toNumber(conf.longitude),
    timezone: typeof conf.timezone === "string" ? conf.timezone : null,
    calendar,
    iqamaCalendar,
    fetchedAt: new Date().toISOString(),
  };

  cache.set(slug, { data, timestamp: Date.now() });
  return data;
}

/** Réponse d'erreur standardisée à partir d'une MawaqitError. */
export function mawaqitErrorResponse(error: unknown): NextResponse {
  if (error instanceof MawaqitError) {
    return NextResponse.json({ error: error.message }, { status: error.status });
  }
  const message = error instanceof Error ? error.message : "Erreur inattendue.";
  return NextResponse.json(
    { error: `Erreur inattendue — ${message}` },
    { status: 500 },
  );
}
