/**
 * Proxy des horaires de prière Mawaqit (côté serveur).
 *
 * Délègue le fetching/parsing à ./shared (cache mémoire de 10 minutes,
 * partagé avec la route /api/prayers/calendar) — la logique détaillée
 * (extraction de `confData`, normalisation, Fajr de demain) y est commentée.
 */

import { NextRequest, NextResponse } from "next/server";
import {
  fetchMosqueData,
  mawaqitErrorResponse,
  sanitizeSlug,
} from "./shared";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  const slug = sanitizeSlug(request.nextUrl.searchParams.get("slug"));
  if (!slug) {
    return NextResponse.json({ error: "Slug manquant" }, { status: 400 });
  }

  try {
    const data = await fetchMosqueData(slug);
    return NextResponse.json({
      slug: data.slug,
      name: data.name,
      localisation: null,
      jumua: data.jumua,
      times: data.times,
      iqama: data.iqama,
      tomorrowFajr: data.tomorrowFajr,
      tomorrow: data.tomorrow,
      latitude: data.latitude,
      longitude: data.longitude,
      timezone: data.timezone,
      fetchedAt: data.fetchedAt,
    });
  } catch (error) {
    return mawaqitErrorResponse(error);
  }
}
