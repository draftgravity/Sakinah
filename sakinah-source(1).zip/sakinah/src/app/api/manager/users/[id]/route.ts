/**
 * PATCH  /api/manager/users/[id] — change le rôle (USER ⇄ MANAGER).
 * DELETE /api/manager/users/[id] — supprime le compte ET ses données
 * (sessions de connexion, dhikr, focus, activités — cascade Prisma).
 *
 * Le gérant ne peut pas modifier ni supprimer SON PROPRE compte
 * (sinon il pourrait s'enfermer dehors).
 */

import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireManager, logActivity } from "@/lib/auth";

type RouteContext = { params: Promise<{ id: string }> };

export async function PATCH(request: Request, context: RouteContext) {
  const guard = await requireManager();
  if ("response" in guard) return guard.response;

  const { id } = await context.params;
  if (id === guard.user.id) {
    return NextResponse.json(
      { error: "Vous ne pouvez pas modifier votre propre rôle." },
      { status: 400 },
    );
  }

  const body = (await request.json().catch(() => null)) as {
    role?: unknown;
  } | null;
  const role = body?.role;
  if (role !== "USER" && role !== "MANAGER") {
    return NextResponse.json(
      { error: "Rôle invalide (attendu : USER ou MANAGER)." },
      { status: 400 },
    );
  }

  const target = await db.user.findUnique({ where: { id } });
  if (!target) {
    return NextResponse.json(
      { error: "Utilisateur introuvable." },
      { status: 404 },
    );
  }
  if (target.role === role) {
    return NextResponse.json({ ok: true, role });
  }

  await db.user.update({ where: { id }, data: { role } });
  await logActivity(
    guard.user.id,
    "ROLE",
    role === "MANAGER"
      ? `${target.username} promu gérant par ${guard.user.username}`
      : `${target.username} rétrogradé en membre par ${guard.user.username}`,
  );

  return NextResponse.json({ ok: true, role });
}

export async function DELETE(_request: Request, context: RouteContext) {
  const guard = await requireManager();
  if ("response" in guard) return guard.response;

  const { id } = await context.params;
  if (id === guard.user.id) {
    return NextResponse.json(
      { error: "Vous ne pouvez pas supprimer votre propre compte." },
      { status: 400 },
    );
  }

  const target = await db.user.findUnique({ where: { id } });
  if (!target) {
    return NextResponse.json(
      { error: "Utilisateur introuvable." },
      { status: 404 },
    );
  }

  await db.user.delete({ where: { id } });
  await logActivity(
    guard.user.id,
    "DELETE",
    `Compte ${target.username} supprimé par ${guard.user.username}`,
  );

  return NextResponse.json({ ok: true });
}
