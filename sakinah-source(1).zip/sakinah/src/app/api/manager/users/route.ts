/**
 * GET /api/manager/users — annuaire des comptes avec leurs statistiques
 * (dhikr du jour / cumul, sessions & minutes de focus), pour l'espace
 * gérant. Gérant uniquement (403 sinon).
 */

import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireManager } from "@/lib/auth";

export async function GET() {
  const guard = await requireManager();
  if ("response" in guard) return guard.response;

  const now = new Date();
  const today = new Intl.DateTimeFormat("fr-CA", {
    timeZone: "Europe/Paris",
  }).format(now);

  const [users, focusByUser, dhikrTodayByUser] = await Promise.all([
    db.user.findMany({
      orderBy: [{ role: "desc" }, { createdAt: "desc" }],
      include: {
        dhikrTotals: {
          select: { todayCount: true, todayDate: true, lifetimeCount: true },
        },
      },
    }),
    db.focusSession.groupBy({
      by: ["userId"],
      _count: { _all: true },
      _sum: { durationSec: true },
    }),
    db.dhikrDaily.groupBy({
      by: ["userId"],
      where: { date: today },
      _sum: { count: true },
    }),
  ]);

  const focusMap = new Map(focusByUser.map((row) => [row.userId, row]));
  const dhikrMap = new Map(dhikrTodayByUser.map((row) => [row.userId, row]));

  return NextResponse.json({
    users: users.map((user) => {
      const focus = focusMap.get(user.id);
      const dhikrToday = dhikrMap.get(user.id)?._sum.count ?? 0;
      const totals = user.dhikrTotals;
      return {
        id: user.id,
        username: user.username,
        name: user.name,
        email: user.email,
        role: user.role === "MANAGER" ? "MANAGER" : "USER",
        createdAt: user.createdAt.toISOString(),
        lastLoginAt: user.lastLoginAt ? user.lastLoginAt.toISOString() : null,
        dhikrToday,
        dhikrLifetime: totals?.lifetimeCount ?? 0,
        focusSessions: focus?._count._all ?? 0,
        focusMinutes: Math.floor((focus?._sum.durationSec ?? 0) / 60),
      };
    }),
  });
}
