/**
 * GET /api/manager/source — archive ZIP du code source « prêt pour GitHub ».
 *
 * Réservée au gérant (403 sinon). Génère à la volée un paquet contenant
 * EXACTEMENT ce qui doit être publié sur GitHub :
 *
 *  * dossiers complets : src/, public/, prisma/, sakina-widget/, scripts/ ;
 *  * fichiers racine : package.json, configs, README, GUIDE-DEPLOIEMENT,
 *    LICENSE, .env.example, .gitignore, bun.lock.
 *
 * Ne contient JAMAIS : .env (secrets), bases de données, journaux internes,
 * captures de QA, node_modules. Le .env.example et le guide de déploiement
 * sont inclus pour que quiconque ouvre le dépôt sache comment installer.
 *
 * NB : sur Vercel, seuls les fichiers listés dans `outputFileTracingIncludes`
 * (next.config.ts) existent dans la fonction — la whitelist ci-dessous est
 * volontairement alignée dessus.
 */

import { promises as fs } from "fs";
import path from "path";
import JSZip from "jszip";
import { requireManager } from "@/lib/auth";

export const dynamic = "force-dynamic";

const ROOT = process.cwd();

/** Dossier racine de l'archive (extraction propre). */
const ZIP_ROOT = "sakinah";

/** Dossiers embarqués intégralement (parcours récursif). */
const INCLUDE_DIRS = ["src", "public", "prisma", "sakina-widget", "scripts"];

/** Fichiers racine embarqués tels quels. */
const INCLUDE_FILES = [
  "package.json",
  "bun.lock",
  "tsconfig.json",
  "next.config.ts",
  "tailwind.config.ts",
  "postcss.config.mjs",
  "components.json",
  "eslint.config.mjs",
  "README.md",
  "GUIDE-DEPLOIEMENT.md",
  ".env.example",
  ".gitignore",
  "LICENSE",
];

/** Entrées ignorées pendant le parcours des dossiers. */
const EXCLUDED_NAMES = new Set([
  "__pycache__",
  ".git",
  ".turbo",
  ".next",
  "node_modules",
]);

/** Taille maximale d'un fichier individuel (2 Mo — garde-fou). */
const MAX_FILE_SIZE = 2 * 1024 * 1024;

/** Liste récursive des fichiers d'un dossier (chemins relatifs POSIX). */
async function walkDir(
  dir: string,
  base = "",
): Promise<string[]> {
  const out: string[] = [];
  let entries: Awaited<ReturnType<typeof fs.readdir>>;
  try {
    entries = await fs.readdir(dir, { withFileTypes: true });
  } catch {
    return out; // dossier absent (ex. Vercel sans tracing) → ignoré
  }
  for (const entry of entries) {
    if (EXCLUDED_NAMES.has(entry.name)) continue;
    if (entry.name.endsWith(".pyc")) continue;
    const abs = path.join(dir, entry.name);
    const rel = base ? `${base}/${entry.name}` : entry.name;
    if (entry.isDirectory()) {
      out.push(...(await walkDir(abs, rel)));
    } else if (entry.isFile()) {
      out.push(rel);
    }
  }
  return out;
}

export async function GET() {
  const guard = await requireManager();
  if ("response" in guard) return guard.response;

  try {
    const zip = new JSZip();
    let count = 0;

    // --- dossiers (parcours récursif) -------------------------------------
    for (const dir of INCLUDE_DIRS) {
      const rels = await walkDir(path.join(ROOT, dir), dir);
      for (const rel of rels) {
        const abs = path.join(ROOT, rel);
        const stat = await fs.stat(abs);
        if (stat.size > MAX_FILE_SIZE) continue;
        zip.file(`${ZIP_ROOT}/${rel}`, await fs.readFile(abs));
        count += 1;
      }
    }

    // --- fichiers racine ---------------------------------------------------
    for (const file of INCLUDE_FILES) {
      const abs = path.join(ROOT, file);
      try {
        const stat = await fs.stat(abs);
        if (!stat.isFile() || stat.size > MAX_FILE_SIZE) continue;
        zip.file(`${ZIP_ROOT}/${file}`, await fs.readFile(abs));
        count += 1;
      } catch {
        // fichier absent (ex. LICENSE pas encore créé) → ignoré
      }
    }

    const buffer = await zip.generateAsync({
      type: "nodebuffer",
      compression: "DEFLATE",
      compressionOptions: { level: 9 },
    });

    if (count === 0) {
      return Response.json(
        { error: "Aucun fichier source trouvé — déploiement inhabituel." },
        { status: 500 },
      );
    }

    return new Response(new Uint8Array(buffer), {
      headers: {
        "Content-Type": "application/zip",
        "Content-Disposition": 'attachment; filename="sakinah-source.zip"',
        "Cache-Control": "no-store",
      },
    });
  } catch (error) {
    console.error("[api/manager/source] échec de la génération :", error);
    return Response.json(
      { error: "Génération du paquet source impossible." },
      { status: 500 },
    );
  }
}
