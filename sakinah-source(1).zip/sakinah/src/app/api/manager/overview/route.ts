/**
 * GET /api/manager/overview — tableau de bord du gérant (403 sinon) :
 * KPIs (utilisateurs, actifs, dhikr, focus), séries des 7 derniers jours
 * et dernières activités. Les clés de jour suivent Europe/Paris (fuseau
 * du public visé) via Intl — aucun calcul d'heure manuel.
 */

import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireManager } from "@/lib/auth";

/** Clé du jour « YYYY-MM-DD » en Europe/Paris. */
function parisDayKey(date: Date): string {
  return new Intl.DateTimeFormat("fr-CA", {
    timeZone: "Europe/Paris",
  }).format(date);
}

export async function GET() {
  const guard = await requireManager();
  if ("response" in guard) return guard.response;

  const now = new Date();
  const today = parisDayKey(now);
  const weekDates: string[] = [];
  for (let i = 6; i >= 0; i -= 1) {
    weekDates.push(parisDayKey(new Date(now.getTime() - i * 86_400_000)));
  }

  const [
    usersCount,
    newUsers,
    dhikrTodayRows,
    dhikrWeekRows,
    totalsAgg,
    activeDhikr,
    focusAgg,
    focusWeekRows,
    activeFocus,
    activity,
  ] = await Promise.all([
    db.user.count(),
    db.user.count({ where: { createdAt: { gte: new Date(now.getTime() - 7 * 86_400_000) } } }),
    db.dhikrDaily.groupBy({
      by: ["date"],
      where: { date: today },
      _sum: { count: true },
    }),
    db.dhikrDaily.groupBy({
      by: ["date"],
      where: { date: { in: weekDates } },
      _sum: { count: true },
    }),
    db.dhikrTotals.aggregate({ _sum: { lifetimeCount: true } }),
    db.dhikrDaily.findMany({
      where: { date: today, count: { gt: 0 } },
      select: { userId: true },
    }),
    db.focusSession.aggregate({
      _count: { _all: true },
      _sum: { durationSec: true },
    }),
    db.focusSession.groupBy({
      by: ["dateKey"],
      where: { dateKey: { in: weekDates } },
      _count: { _all: true },
      _sum: { durationSec: true },
    }),
    db.focusSession.findMany({
      where: { dateKey: today },
      select: { userId: true },
    }),
    db.activity.findMany({
      orderBy: { createdAt: "desc" },
      take: 15,
      include: { user: { select: { username: true } } },
    }),
  ]);

  const activeUsers = new Set([
    ...activeDhikr.map((row) => row.userId),
    ...activeFocus.map((row) => row.userId),
  ]);

  const dhikr7d = weekDates.map((date) => ({
    date,
    count:
      dhikrWeekRows.find((row) => row.date === date)?._sum.count ?? 0,
  }));
  const focus7d = weekDates.map((date) => {
    const row = focusWeekRows.find((r) => r.dateKey === date);
    return {
      date,
      sessions: row?._count._all ?? 0,
      minutes: Math.floor((row?._sum.durationSec ?? 0) / 60),
    };
  });

  return NextResponse.json({
    kpis: {
      users: usersCount,
      newUsers7d: newUsers,
      activeToday: activeUsers.size,
      dhikrToday: dhikrTodayRows[0]?._sum.count ?? 0,
      dhikrLifetime: totalsAgg._sum.lifetimeCount ?? 0,
      focusSessions: focusAgg._count._all,
      focusMinutes: Math.floor((focusAgg._sum.durationSec ?? 0) / 60),
    },
    dhikr7d,
    focus7d,
    activity: activity.map((row) => ({
      id: row.id,
      type: row.type,
      detail: row.detail,
      username: row.user?.username ?? null,
      createdAt: row.createdAt.toISOString(),
    })),
    generatedAt: now.toISOString(),
  });
}
