/**
 * GET /api/files/content?path=app/controller.py[&download=1]
 *
 * Renvoie le contenu d'un fichier source du dossier sakina-widget, avec une
 * défense en profondeur :
 *  * rejet de tout « .. » dans le chemin demandé ;
 *  * `path.resolve` + vérification que le résultat reste bien DANS
 *    sakina-widget/ (protection contre la traversée de répertoires) ;
 *  * whitelist d'extensions (.py .txt .json .md .gitignore) ;
 *  * taille maximale 200 Ko.
 *
 * `download=1` sert le fichier en pièce jointe (Content-Disposition) au lieu
 * du JSON.
 */

import { promises as fs } from "fs";
import path from "path";
import { NextResponse } from "next/server";
import { WIDGET_ROOT, MAX_FILE_SIZE, isAllowedFileName, languageForFile } from "../shared";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const relPath = (searchParams.get("path") ?? "").trim();
  const asDownload = searchParams.get("download") === "1";

  // --- validations basiques ---------------------------------------------
  if (!relPath || relPath.includes("..") || relPath.includes("\0")) {
    return NextResponse.json({ error: "Chemin de fichier invalide." }, { status: 400 });
  }

  const absPath = path.resolve(WIDGET_ROOT, relPath);
  const rootWithSep = WIDGET_ROOT + path.sep;
  if (absPath !== WIDGET_ROOT && !absPath.startsWith(rootWithSep)) {
    return NextResponse.json(
      { error: "Accès refusé : chemin hors du dossier sakina-widget." },
      { status: 403 },
    );
  }
  if (!isAllowedFileName(absPath)) {
    return NextResponse.json(
      { error: "Type de fichier non autorisé (.py, .txt, .json, .md uniquement)." },
      { status: 400 },
    );
  }

  // --- lecture -----------------------------------------------------------
  let stat: Awaited<ReturnType<typeof fs.stat>>;
  try {
    stat = await fs.stat(absPath);
  } catch {
    return NextResponse.json({ error: "Fichier introuvable." }, { status: 404 });
  }
  if (!stat.isFile()) {
    return NextResponse.json({ error: "Ce chemin n'est pas un fichier." }, { status: 400 });
  }
  if (stat.size > MAX_FILE_SIZE) {
    return NextResponse.json(
      { error: "Fichier trop volumineux (maximum 200 Ko)." },
      { status: 413 },
    );
  }

  let content: string;
  try {
    content = await fs.readFile(absPath, "utf8");
  } catch {
    return NextResponse.json({ error: "Lecture impossible." }, { status: 500 });
  }

  const fileName = path.basename(absPath);
  const language = languageForFile(fileName);
  const lines = content.length === 0 ? 0 : content.split("\n").length;

  if (asDownload) {
    return new Response(content, {
      headers: {
        "Content-Type": "text/plain; charset=utf-8",
        "Content-Disposition": `attachment; filename="${fileName}"`,
        "Cache-Control": "no-store",
      },
    });
  }

  return NextResponse.json(
    { path: relPath, content, language, lines },
    { headers: { "Cache-Control": "no-store" } },
  );
}
