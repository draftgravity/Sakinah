/**
 * GET /api/files — manifeste JSON du dossier sakina-widget/.
 * Utilisé par l'explorateur de code de la page vitrine.
 */

import { NextResponse } from "next/server";
import { listWidgetFiles, sortManifest } from "./shared";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const files = sortManifest(await listWidgetFiles());
    const totalLines = files.reduce((sum, file) => sum + file.lines, 0);
    return NextResponse.json(
      { files, totalLines, totalFiles: files.length },
      { headers: { "Cache-Control": "no-store" } },
    );
  } catch (error) {
    console.error("[api/files] échec du parcours :", error);
    return NextResponse.json(
      { error: "Impossible de lire le dossier sakina-widget." },
      { status: 500 },
    );
  }
}
