/**
 * Utilitaires partagés par les routes /api/files, /api/files/content et
 * /api/download : parcours du dossier sakina-widget et tri du manifeste.
 */

import { promises as fs } from "fs";
import path from "path";

/** Racine absolue du code Python — jamais exposée telle quelle au client. */
export const WIDGET_ROOT = path.join(process.cwd(), "sakina-widget");

/** Dossiers exclus du parcours récursif. */
const EXCLUDED_DIRS = new Set(["__pycache__", ".git"]);

/** Taille maximale d'un fichier servi par /api/files/content (200 Ko). */
export const MAX_FILE_SIZE = 200 * 1024;

/** Extensions autorisées en lecture (whitelist stricte). */
const ALLOWED_EXTENSIONS = new Set([".py", ".txt", ".json", ".md", ".gitignore"]);

export type WidgetLanguage = "python" | "json" | "markdown" | "text";

export interface WidgetFileMeta {
  /** chemin relatif POSIX, ex. « app/controller.py » */
  path: string;
  size: number;
  lines: number;
  language: WidgetLanguage;
}

/** Déduit le langage de coloration syntaxique depuis l'extension. */
export function languageForFile(fileName: string): WidgetLanguage {
  if (fileName.endsWith(".py")) return "python";
  if (fileName.endsWith(".json")) return "json";
  if (fileName.endsWith(".md")) return "markdown";
  return "text";
}

/** Vérifie qu'un nom de fichier est lisible (whitelist d'extensions). */
export function isAllowedFileName(absPath: string): boolean {
  const ext = path.extname(absPath).toLowerCase();
  if (ALLOWED_EXTENSIONS.has(ext)) return true;
  return path.basename(absPath) === ".gitignore";
}

/** Un fichier/dossier caché est ignoré, sauf .gitignore. */
function isHiddenExcluded(name: string, isDirectory: boolean): boolean {
  if (isDirectory) return EXCLUDED_DIRS.has(name);
  if (name.endsWith(".pyc")) return true;
  return name.startsWith(".") && name !== ".gitignore";
}

/**
 * Parcours récursif du dossier sakina-widget (exclut __pycache__, .git, *.pyc).
 * Retourne les métadonnées de chaque fichier (taille, nombre de lignes, langage).
 */
export async function listWidgetFiles(
  dir = WIDGET_ROOT,
  base = "",
): Promise<WidgetFileMeta[]> {
  const entries = await fs.readdir(dir, { withFileTypes: true });
  const files: WidgetFileMeta[] = [];

  for (const entry of entries) {
    if (isHiddenExcluded(entry.name, entry.isDirectory())) continue;

    if (entry.isDirectory()) {
      const nested = await listWidgetFiles(
        path.join(dir, entry.name),
        path.posix.join(base, entry.name),
      );
      files.push(...nested);
    } else if (entry.isFile()) {
      const abs = path.join(dir, entry.name);
      const rel = path.posix.join(base, entry.name);
      const content = await fs.readFile(abs, "utf8");
      files.push({
        path: rel,
        size: Buffer.byteLength(content, "utf8"),
        lines: content.length === 0 ? 0 : content.split("\n").length,
        language: languageForFile(entry.name),
      });
    }
  }

  return files;
}

/**
 * Tri du manifeste : fichiers racine d'abord, puis par dossier, chaque groupe
 * en ordre alphabétique.
 */
export function sortManifest(files: WidgetFileMeta[]): WidgetFileMeta[] {
  const dirOf = (p: string) => (p.includes("/") ? p.slice(0, p.lastIndexOf("/")) : "");
  return [...files].sort((a, b) => {
    const dirA = dirOf(a.path);
    const dirB = dirOf(b.path);
    if (dirA === "" && dirB !== "") return -1;
    if (dirA !== "" && dirB === "") return 1;
    if (dirA !== dirB) return dirA.localeCompare(dirB, "en");
    return a.path.localeCompare(b.path, "en");
  });
}

/**
 * Collecte les chemins (relatif + absolu) de tous les fichiers zippables.
 * Contrairement à listWidgetFiles, aucune lecture n'est faite ici : la route
 * /api/download lit les octets bruts elle-même (y compris binaires éventuels).
 */
export async function collectWidgetFilePaths(
  dir = WIDGET_ROOT,
  base = "",
): Promise<Array<{ rel: string; abs: string }>> {
  const entries = await fs.readdir(dir, { withFileTypes: true });
  const out: Array<{ rel: string; abs: string }> = [];

  for (const entry of entries) {
    if (isHiddenExcluded(entry.name, entry.isDirectory())) continue;

    if (entry.isDirectory()) {
      const nested = await collectWidgetFilePaths(
        path.join(dir, entry.name),
        path.posix.join(base, entry.name),
      );
      out.push(...nested);
    } else if (entry.isFile()) {
      out.push({ rel: path.posix.join(base, entry.name), abs: path.join(dir, entry.name) });
    }
  }

  return out;
}
