/**
 * /api/focus — sessions de concentration DU COMPTE connecté.
 *
 * GET  : { history, today, totalSessions, totalMinutes }
 *        history = { "YYYY-MM-DD": nb de sessions } (40 derniers jours)
 *
 * POST : deux usages (combinables) :
 *   a) { sessions: [{ durationSec, dateKey }] }
 *      → une session VIENT d'être terminée (durée réelle connue) ;
 *   b) { history: { "YYYY-MM-DD": count } }
 *      → fusion d'appareil à la connexion : pour chaque jour où le compte
 *        a MOINS de sessions que l'historique local, on comble avec des
 *        sessions « importées » (durationSec = 0 — comptées, sans durée).
 *
 * La réponse renvoie l'état frais (comme GET) : le client remplace son
 * cache local par la vérité serveur.
 */

import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireUser, logActivity } from "@/lib/auth";

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
const HISTORY_LIMIT = 40;
/** durée plafonnée : 4 h — au-delà, donnée manifestement erronée */
const MAX_DURATION = 4 * 3600;

interface SessionInput {
  durationSec: number;
  dateKey: string;
}

export async function GET() {
  const guard = await requireUser();
  if ("response" in guard) return guard.response;
  return NextResponse.json(await serverState(guard.user.id));
}

export async function POST(request: Request) {
  const guard = await requireUser();
  if ("response" in guard) return guard.response;
  const userId = guard.user.id;

  const body = (await request.json().catch(() => null)) as {
    sessions?: unknown;
    history?: unknown;
  } | null;

  // ---- a) nouvelles sessions complétées ----------------------------
  const validSessions: SessionInput[] = [];
  if (Array.isArray(body?.sessions) && body!.sessions.length <= 30) {
    for (const raw of body!.sessions) {
      if (typeof raw !== "object" || raw === null) continue;
      const { durationSec, dateKey } = raw as Record<string, unknown>;
      if (
        typeof durationSec !== "number" ||
        !Number.isInteger(durationSec) ||
        durationSec < 0 ||
        durationSec > MAX_DURATION
      ) {
        continue;
      }
      if (typeof dateKey !== "string" || !DATE_RE.test(dateKey)) continue;
      validSessions.push({ durationSec, dateKey });
    }
  }

  if (validSessions.length > 0) {
    await db.focusSession.createMany({
      data: validSessions.map((session) => ({ userId, ...session })),
    });
    // Journal : une entrée par session réelle (durée connue), max 3.
    for (const session of validSessions.slice(0, 3)) {
      if (session.durationSec === 0) continue;
      const minutes = Math.round(session.durationSec / 60);
      await logActivity(
        userId,
        "FOCUS",
        `Session de focus de ${minutes} min (${guard.user.username})`,
      );
    }
  }

  // ---- b) fusion de l'historique local (connexion) ------------------
  let imported = 0;
  if (
    typeof body?.history === "object" &&
    body!.history !== null &&
    !Array.isArray(body!.history)
  ) {
    const entries = Object.entries(body!.history as Record<string, unknown>)
      .filter(
        ([date, count]) =>
          DATE_RE.test(date) &&
          typeof count === "number" &&
          Number.isInteger(count) &&
          count > 0 &&
          count <= 100,
      )
      .slice(0, HISTORY_LIMIT);

    if (entries.length > 0) {
      const dates = entries.map(([date]) => date);
      const counts = await db.focusSession.groupBy({
        by: ["dateKey"],
        where: { userId, dateKey: { in: dates } },
        _count: { _all: true },
      });
      const serverCounts = new Map(
        counts.map((row) => [row.dateKey, row._count._all]),
      );
      const toCreate: { userId: string; durationSec: number; dateKey: string; completedAt: Date }[] =
        [];
      for (const [date, count] of entries) {
        const missing = count - (serverCounts.get(date) ?? 0);
        for (let i = 0; i < missing; i += 1) {
          toCreate.push({
            userId,
            durationSec: 0,
            dateKey: date,
            completedAt: new Date(`${date}T12:00:00`), // ordre d'affichage
          });
        }
      }
      if (toCreate.length > 0) {
        await db.focusSession.createMany({ data: toCreate });
        imported = toCreate.length;
        await logActivity(
          userId,
          "FOCUS_IMPORT",
          `Historique focus synchronisé (${imported} session${imported > 1 ? "s" : ""}, ${guard.user.username})`,
        );
      }
    }
  }

  const state = await serverState(userId);
  return NextResponse.json({ ...state, imported });
}

/* ------------------------------------------------------------------ */

/** État focus d'un compte : historique 40 j + agrégats. */
async function serverState(userId: string) {
  const [sessions, grouped] = await Promise.all([
    db.focusSession.findMany({
      where: { userId },
      orderBy: { completedAt: "desc" },
      take: 500,
      select: { dateKey: true, durationSec: true },
    }),
    db.focusSession.aggregate({
      where: { userId },
      _count: { _all: true },
      _sum: { durationSec: true },
    }),
  ]);

  const history: Record<string, number> = {};
  for (const session of sessions) {
    history[session.dateKey] = (history[session.dateKey] ?? 0) + 1;
  }
  // Garde les 40 derniers jours (les dateKey sont triés par défaut).
  const dates = Object.keys(history).sort().slice(-HISTORY_LIMIT);
  const trimmed: Record<string, number> = {};
  for (const date of dates) trimmed[date] = history[date];

  return {
    history: trimmed,
    totalSessions: grouped._count._all,
    totalMinutes: Math.floor((grouped._sum.durationSec ?? 0) / 60),
  };
}
