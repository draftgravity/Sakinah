/**
 * GET /api/download — archive ZIP complète du dossier sakina-widget/.
 * Générée à la volée avec jszip (aucun fichier temporaire sur le disque).
 */

import { promises as fs } from "fs";
import JSZip from "jszip";
import { collectWidgetFilePaths } from "../files/shared";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const files = await collectWidgetFilePaths();
    const zip = new JSZip();

    for (const file of files) {
      // Dossier racine « sakinah-widget/ » dans l'archive pour une extraction propre.
      const data = await fs.readFile(file.abs);
      zip.file(`sakinah-widget/${file.rel}`, data);
    }

    const buffer = await zip.generateAsync({
      type: "nodebuffer",
      compression: "DEFLATE",
      compressionOptions: { level: 9 },
    });

    return new Response(new Uint8Array(buffer), {
      headers: {
        "Content-Type": "application/zip",
        "Content-Disposition": 'attachment; filename="sakinah-widget.zip"',
        "Cache-Control": "no-store",
      },
    });
  } catch (error) {
    console.error("[api/download] échec de la génération du ZIP :", error);
    return new Response(JSON.stringify({ error: "Génération du ZIP impossible." }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
}
