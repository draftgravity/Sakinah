/**
 * /api/dhikr — totaux et historique de dhikr DU COMPTE connecté.
 *
 * GET  : { date, today, lifetime, perFormula, history }
 *        history = { "YYYY-MM-DD": count } (40 derniers jours)
 *
 * PUT  : synchronisation depuis le client (debouncée après chaque tape) :
 *        { date, today, lifetime, perFormula, history, reset? }
 *        Fusion IDEMPOTENTE par maximum — deux appareils ne se comptent
 *        jamais deux fois : un re-chargement de page renvoie les mêmes
 *        valeurs, le serveur les prend en MAX avec les siennes.
 *        `reset: true` (bouton « Effacer ») remet TOUT à zéro.
 */

import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
const FORMULA_KEYS = new Set(["subhanallah", "alhamdulillah", "allahuakbar", "libre"]);

/** Nombre maximum de jours d'historique acceptés/renvoyés. */
const HISTORY_LIMIT = 40;

type Numbers = Record<string, number>;

function sanitizeCountMap(input: unknown, maxKeys: number): Numbers | null {
  if (typeof input !== "object" || input === null || Array.isArray(input)) {
    return null;
  }
  const out: Numbers = {};
  let keys = 0;
  for (const [key, value] of Object.entries(input as Numbers)) {
    if (keys >= maxKeys) break;
    if (!DATE_RE.test(key) && !FORMULA_KEYS.has(key)) continue;
    if (typeof value !== "number" || !Number.isInteger(value) || value < 0) {
      continue;
    }
    out[key] = Math.min(value, 1_000_000_000);
    keys += 1;
  }
  return out;
}

function readInt(value: unknown): number | null {
  if (typeof value !== "number" || !Number.isInteger(value) || value < 0) {
    return null;
  }
  return Math.min(value, 1_000_000_000);
}

/** Fusion par maximum des deux maps (clés union). */
function mergeMax(a: Numbers | null, b: Numbers | null): Numbers {
  const out: Numbers = { ...(a ?? {}) };
  for (const [key, value] of Object.entries(b ?? {})) {
    out[key] = Math.max(out[key] ?? 0, value);
  }
  return out;
}

export async function GET() {
  const guard = await requireUser();
  if ("response" in guard) return guard.response;

  const [totals, dailies] = await Promise.all([
    db.dhikrTotals.findUnique({ where: { userId: guard.user.id } }),
    db.dhikrDaily.findMany({
      where: { userId: guard.user.id },
      orderBy: { date: "desc" },
      take: HISTORY_LIMIT,
    }),
  ]);

  const history: Numbers = {};
  for (const day of dailies) history[day.date] = day.count;

  return NextResponse.json({
    date: totals?.todayDate ?? "",
    today: totals?.todayCount ?? 0,
    lifetime: totals?.lifetimeCount ?? 0,
    perFormula: (totals?.perFormula as Numbers | null) ?? {},
    history,
  });
}

export async function PUT(request: Request) {
  const guard = await requireUser();
  if ("response" in guard) return guard.response;
  const userId = guard.user.id;

  const body = (await request.json().catch(() => null)) as {
    date?: unknown;
    today?: unknown;
    lifetime?: unknown;
    perFormula?: unknown;
    history?: unknown;
    reset?: unknown;
  } | null;

  // ---- « Effacer » : remise à zéro complète du compte -------------
  if (body?.reset === true) {
    await db.$transaction([
      db.dhikrTotals.deleteMany({ where: { userId } }),
      db.dhikrDaily.deleteMany({ where: { userId } }),
    ]);
    return NextResponse.json({
      date: "",
      today: 0,
      lifetime: 0,
      perFormula: {},
      history: {},
    });
  }

  // ---- Validation des entrées -------------------------------------
  const incomingDate =
    typeof body?.date === "string" && DATE_RE.test(body.date) ? body.date : null;
  if (!incomingDate) {
    return NextResponse.json(
      { error: "Date du jour invalide (attendu : AAAA-MM-JJ)." },
      { status: 400 },
    );
  }
  const incomingToday = readInt(body?.today) ?? 0;
  const incomingLifetime = readInt(body?.lifetime) ?? 0;
  const incomingPerFormula = sanitizeCountMap(body?.perFormula, 16) ?? {};
  const incomingHistory = sanitizeCountMap(body?.history, HISTORY_LIMIT) ?? {};

  const existing = await db.dhikrTotals.findUnique({ where: { userId } });

  // ---- Totaux : fusion par maximum, le jour le plus récent gagne ---
  let todayDate = incomingDate;
  let todayCount = incomingToday;
  if (existing) {
    if (existing.todayDate > incomingDate) {
      // un autre appareil a déjà basculé sur un jour plus récent
      todayDate = existing.todayDate;
      todayCount = existing.todayCount;
    } else if (existing.todayDate === incomingDate) {
      todayCount = Math.max(existing.todayCount, incomingToday);
    } // sinon : incoming plus récent → nouveau jour, on repart de l'entrant
  }
  const lifetime = Math.max(existing?.lifetimeCount ?? 0, incomingLifetime);
  const perFormula = mergeMax(
    (existing?.perFormula as Numbers | null) ?? null,
    incomingPerFormula,
  );

  await db.dhikrTotals.upsert({
    where: { userId },
    create: {
      userId,
      todayDate,
      todayCount,
      lifetimeCount: lifetime,
      perFormula,
    },
    update: { todayDate, todayCount, lifetimeCount: lifetime, perFormula },
  });

  // ---- Historique par jour : maximum par date ----------------------
  // Le jour courant est couvert par l'historique ET par les totaux.
  const merged: Numbers = { ...incomingHistory };
  merged[incomingDate] = Math.max(
    merged[incomingDate] ?? 0,
    incomingToday,
  );
  const dates = Object.keys(merged);
  const existingDailies = await db.dhikrDaily.findMany({
    where: { userId, date: { in: dates } },
    select: { date: true, count: true },
  });
  const existingByDate = new Map(existingDailies.map((d) => [d.date, d.count]));
  await db.$transaction(
    dates.map((date) => {
      const finalCount = Math.max(existingByDate.get(date) ?? 0, merged[date]);
      return db.dhikrDaily.upsert({
        where: { userId_date: { userId, date } },
        create: { userId, date, count: finalCount },
        update: { count: finalCount },
      });
    }),
  );

  // Réponse : état serveur complet (les 40 derniers jours réels) pour
  // que le client s'hydrate depuis n'importe quelle réponse.
  const freshDailies = await db.dhikrDaily.findMany({
    where: { userId },
    orderBy: { date: "desc" },
    take: HISTORY_LIMIT,
    select: { date: true, count: true },
  });
  const freshHistory: Numbers = {};
  for (const day of freshDailies) freshHistory[day.date] = day.count;

  return NextResponse.json({
    date: todayDate,
    today: todayCount,
    lifetime,
    perFormula,
    history: freshHistory,
  });
}
