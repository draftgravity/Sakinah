/**
 * POST /api/auth/login — connexion par identifiant OU e-mail + mot de passe.
 *
 * * identifiant insensible à la casse (usernameLower / email en minuscules) ;
 * * messages d'erreur volontairement génériques (ne révèle pas si
 *   l'identifiant existe) + temps de réponse égalisé (hash factice) ;
 * * limite de débit : 10 tentatives / 5 min / IP (anti force-brute) ;
 * * succès : session créée + cookie httpOnly + dernière connexion
 *   enregistrée + entrée dans le journal d'activité.
 */

import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import {
  createSession,
  setSessionCookie,
  toPublicUser,
  verifyDummyPassword,
  verifyPassword,
  logActivity,
} from "@/lib/auth";
import { clientIp, rateLimit, rateLimitReset } from "@/lib/rate-limit";

export async function POST(request: Request) {
  const ip = clientIp(request);
  const limitKey = `login:${ip}`;
  const limit = rateLimit(limitKey, { max: 10, windowMs: 5 * 60_000 });
  if (!limit.allowed) {
    return NextResponse.json(
      {
        error: `Trop de tentatives. Réessayez dans ${Math.max(
          1,
          Math.ceil(limit.retryAfterSec / 60),
        )} min.`,
      },
      { status: 429 },
    );
  }

  const body = (await request.json().catch(() => null)) as {
    identifier?: unknown;
    password?: unknown;
  } | null;

  const identifier =
    typeof body?.identifier === "string" ? body.identifier.trim() : "";
  const password = typeof body?.password === "string" ? body.password : "";

  if (!identifier || !password) {
    return NextResponse.json(
      { error: "Veuillez renseigner votre identifiant et votre mot de passe." },
      { status: 400 },
    );
  }

  const id = identifier.toLowerCase();
  const user = await db.user.findFirst({
    where: { OR: [{ usernameLower: id }, { email: id }] },
  });

  if (!user) {
    verifyDummyPassword(password); // égalise le temps de réponse
    return NextResponse.json(
      { error: "Identifiant ou mot de passe incorrect." },
      { status: 401 },
    );
  }
  if (!verifyPassword(password, user.passwordHash)) {
    return NextResponse.json(
      { error: "Identifiant ou mot de passe incorrect." },
      { status: 401 },
    );
  }

  const lastLoginAt = new Date();
  await db.user.update({
    where: { id: user.id },
    data: { lastLoginAt },
  });
  const { token, expiresAt } = await createSession(user.id);
  await logActivity(user.id, "LOGIN", `Connexion de ${user.username}`);

  rateLimitReset(limitKey);

  const response = NextResponse.json({
    user: toPublicUser({ ...user, lastLoginAt }),
  });
  return setSessionCookie(response, token, expiresAt, request);
}
