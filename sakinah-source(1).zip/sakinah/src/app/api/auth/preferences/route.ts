/**
 * PATCH /api/auth/preferences — préférences du compte.
 *
 * Seule préférence aujourd'hui : « version de la démo » du gérant
 * (focusEnabled). Réservée au rôle MANAGER — elle ne change rien pour
 * un membre, qui ne voit de toute façon que la version prières.
 * La préférence est stockée EN LIGNE : elle suit le compte sur tous
 * ses appareils (et dans la web-app installée).
 */

import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser, jsonError, toPublicUser, logActivity } from "@/lib/auth";

export async function PATCH(request: Request) {
  const user = await getSessionUser();
  if (!user) {
    return jsonError("Connexion requise.", 401);
  }
  if (user.role !== "MANAGER") {
    return jsonError("Réservé au gérant.", 403);
  }

  const body = (await request.json().catch(() => null)) as {
    focusEnabled?: unknown;
  } | null;
  if (typeof body?.focusEnabled !== "boolean") {
    return jsonError("Valeur de préférence invalide.", 400);
  }

  const updated = await db.user.update({
    where: { id: user.id },
    data: { focusEnabled: body.focusEnabled },
  });

  await logActivity(
    user.id,
    "ROLE",
    body.focusEnabled
      ? `${user.username} passe en version complète (avec Mode Focus)`
      : `${user.username} passe en version prières (sans Mode Focus)`,
  );

  return NextResponse.json({ user: toPublicUser(updated) });
}
