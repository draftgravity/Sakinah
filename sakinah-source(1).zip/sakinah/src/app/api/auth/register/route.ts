/**
 * POST /api/auth/register — création de compte.
 *
 * * Rôle « USER » par défaut (version prières uniquement ; le gérant promeut
 *   depuis son espace).
 * * Bootstrap d'une base vide : si AUCUN gérant n'existe encore, le PREMIER
 *   compte créé devient automatiquement MANAGER — ainsi, un déploiement
 *   tout neuf (Vercel + Neon, sans seed) est immédiatement administrable
 *   par la personne qui vient de l'installer.
 *
 * Validations : nom d'utilisateur 3–24 caractères (lettres, chiffres, _ . -),
 * e-mail syntaxiquement valide et unique, mot de passe ≥ 8 caractères.
 * Le compte est immédiatement connecté (session + cookie).
 */

import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import {
  createSession,
  hashPassword,
  setSessionCookie,
  toPublicUser,
  logActivity,
} from "@/lib/auth";
import { clientIp, rateLimit } from "@/lib/rate-limit";

const USERNAME_RE = /^[a-zA-Z0-9_.-]{3,24}$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export async function POST(request: Request) {
  const limit = rateLimit(`register:${clientIp(request)}`, {
    max: 6,
    windowMs: 10 * 60_000,
  });
  if (!limit.allowed) {
    return NextResponse.json(
      { error: "Trop de créations de compte. Réessayez dans quelques minutes." },
      { status: 429 },
    );
  }

  const body = (await request.json().catch(() => null)) as {
    username?: unknown;
    email?: unknown;
    password?: unknown;
    name?: unknown;
  } | null;

  const username =
    typeof body?.username === "string" ? body.username.trim() : "";
  const email =
    typeof body?.email === "string" ? body.email.trim().toLowerCase() : "";
  const password = typeof body?.password === "string" ? body.password : "";
  const name =
    typeof body?.name === "string" && body.name.trim()
      ? body.name.trim().slice(0, 60)
      : null;

  if (!USERNAME_RE.test(username)) {
    return NextResponse.json(
      {
        error:
          "Nom d'utilisateur : 3 à 24 caractères (lettres, chiffres, _ . -).",
      },
      { status: 400 },
    );
  }
  if (!EMAIL_RE.test(email) || email.length > 190) {
    return NextResponse.json(
      { error: "Adresse e-mail invalide." },
      { status: 400 },
    );
  }
  if (password.length < 8 || password.length > 200) {
    return NextResponse.json(
      { error: "Le mot de passe doit contenir au moins 8 caractères." },
      { status: 400 },
    );
  }

  const usernameLower = username.toLowerCase();
  const [byEmail, byUsername] = await Promise.all([
    db.user.findUnique({ where: { email } }),
    db.user.findUnique({ where: { usernameLower } }),
  ]);
  if (byEmail) {
    return NextResponse.json(
      { error: "Un compte existe déjà avec cette adresse e-mail." },
      { status: 409 },
    );
  }
  if (byUsername) {
    return NextResponse.json(
      { error: "Ce nom d'utilisateur est déjà pris." },
      { status: 409 },
    );
  }

  // Bootstrap : sur une base vierge, le premier compte devient gérant.
  const managerCount = await db.user.count({ where: { role: "MANAGER" } });
  const role = managerCount === 0 ? "MANAGER" : "USER";

  let user;
  try {
    user = await db.user.create({
      data: {
        username,
        usernameLower,
        email,
        name,
        passwordHash: hashPassword(password),
        role,
        lastLoginAt: new Date(),
      },
    });
  } catch {
    // concurrence : l'unique a été pris entre la vérification et l'insertion
    return NextResponse.json(
      { error: "Ce nom d'utilisateur ou e-mail est déjà pris." },
      { status: 409 },
    );
  }

  await logActivity(
    user.id,
    "REGISTER",
    role === "MANAGER"
      ? `Inscription de ${user.username} — premier compte, devenu gérant`
      : `Inscription de ${user.username}`,
  );
  const { token, expiresAt } = await createSession(user.id);

  const response = NextResponse.json({ user: toPublicUser(user) });
  return setSessionCookie(response, token, expiresAt, request);
}
