/**
 * POST /api/auth/logout — déconnexion : la session est supprimée en base
 * et le cookie effacé.
 */

import { cookies } from "next/headers";
import { NextResponse } from "next/server";
import { SESSION_COOKIE, clearSessionCookie, deleteSession } from "@/lib/auth";

export async function POST(request: Request) {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (token) {
    await deleteSession(token);
  }
  return clearSessionCookie(NextResponse.json({ ok: true }), request);
}
