/**
 * Index de l'API Sakinah — documente les points d'entrée disponibles.
 * GET /api
 */

import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export function GET() {
  return NextResponse.json({
    name: "Sakinah — API de la page vitrine",
    endpoints: [
      {
        path: "/api/prayers?slug={slug}",
        description:
          "Horaires du jour d'une mosquée (proxy mawaqit.net) : 6 horaires, Fajr de demain, Jumu'a, coordonnées.",
      },
      {
        path: "/api/prayers/calendar?slug={slug}",
        description:
          "Calendrier annuel des prières (12 mois × jours × 6 horaires) extrait de mawaqit.net.",
      },
      {
        path: "/api/mosques/search?q={mot}",
        description:
          "Recherche de mosquée par nom, ville ou code postal (max ~10 résultats).",
      },
      {
        path: "/api/files",
        description: "Manifeste des fichiers sources du projet Python.",
      },
      {
        path: "/api/files/content?path={chemin}",
        description: "Contenu d'un fichier source (téléchargement : &download=1).",
      },
      {
        path: "/api/download",
        description: "Archive ZIP complète du projet Python (sakina-widget/).",
      },
    ],
    source: "https://mawaqit.net",
  });
}
