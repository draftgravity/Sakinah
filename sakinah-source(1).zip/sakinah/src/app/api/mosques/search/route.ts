/**
 * Proxy de recherche de mosquées Mawaqit (côté serveur pour éviter tout
 * souci CORS et masquer l'API au client).
 *
 * Endpoint amont : https://mawaqit.net/api/2.0/mosque/search?word=<q>
 * Réponse : liste de mosquées (name, slug, localisation, times du jour…).
 *
 * Paramètre « region » (clé du catalogue src/lib/regions.ts, ex. FR) :
 * les mosquées de la région du visiteur passent EN PREMIER (tri stable —
 * les autres résultats restent disponibles, après).
 */

import { NextRequest, NextResponse } from "next/server";
import { mosqueInRegion, regionByKey } from "@/lib/regions";

export const dynamic = "force-dynamic";

export interface MosqueSearchItem {
  slug: string;
  name: string;
  localisation: string;
  jumua: string | null;
  /** coordonnées publiées par Mawaqit (null si absentes) — distance « autour de moi » */
  latitude: number | null;
  longitude: number | null;
}

/** Extrait une coordonnée numérique tolérante (nombre ou chaîne). */
function toCoord(value: unknown): number | null {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string") {
    const parsed = Number(value.replace(",", "."));
    if (Number.isFinite(parsed)) return parsed;
  }
  return null;
}

export async function GET(request: NextRequest) {
  const query = request.nextUrl.searchParams.get("q")?.trim() ?? "";
  if (query.length < 2) {
    return NextResponse.json({ mosques: [], source: "live" });
  }

  try {
    const upstream = await fetch(
      `https://mawaqit.net/api/2.0/mosque/search?word=${encodeURIComponent(query)}`,
      {
        headers: {
          Accept: "application/json",
          "User-Agent": "SakinahWidget/1.0 (+web-demo; mawaqit.net)",
        },
        cache: "no-store",
        signal: AbortSignal.timeout(9000),
      },
    );
    if (!upstream.ok) {
      throw new Error(`Mawaqit a répondu ${upstream.status}`);
    }
    const data: unknown = await upstream.json();
    if (!Array.isArray(data)) {
      return NextResponse.json({ mosques: [], source: "live" });
    }

    const mosques: MosqueSearchItem[] = data
      .filter((item): item is Record<string, unknown> => typeof item === "object" && item !== null)
      .map((item) => {
        const latitude = toCoord(item.latitude);
        const longitude = toCoord(item.longitude);
        return {
          slug: String(item.slug ?? ""),
          name: String(item.name ?? item.label ?? item.slug ?? ""),
          localisation: String(item.localisation ?? ""),
          jumua: item.jumua ? String(item.jumua) : null,
          latitude:
            latitude !== null && Math.abs(latitude) <= 90 ? latitude : null,
          longitude:
            longitude !== null && Math.abs(longitude) <= 180 ? longitude : null,
        };
      })
      .filter((mosque) => mosque.slug.length > 0)
      .slice(0, 10);

    // Région du visiteur : ses mosquées passent en tête (tri stable).
    const region = regionByKey(request.nextUrl.searchParams.get("region"));
    if (region) {
      mosques.sort(
        (a, b) =>
          Number(mosqueInRegion(b.localisation, b.slug, region)) -
          Number(mosqueInRegion(a.localisation, a.slug, region)),
      );
    }

    return NextResponse.json({ mosques, source: "live" });
  } catch {
    // Hors-ligne ou API indisponible → le client basculera sur les
    // données d'exemple avec un badge explicite.
    return NextResponse.json({ mosques: [], source: "offline" });
  }
}
