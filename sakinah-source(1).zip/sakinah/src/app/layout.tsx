import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { RegisterSw } from "@/components/pwa/register-sw";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

/**
 * URL publique du site — utilisée par les balises canonical / Open Graph
 * et par le sitemap. En production, définir NEXT_PUBLIC_SITE_URL
 * (ex. https://sakinah.app) ; en développement, repli sur localhost.
 */
const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";

/** Code de vérification Google Search Console (facultatif) — voir
 *  GUIDE-DEPLOIEMENT.md : collez le code fourni par Google dans la variable
 *  NEXT_PUBLIC_GOOGLE_SITE_VERIFICATION (Vercel) et la balise est générée. */
const GOOGLE_VERIFICATION = process.env.NEXT_PUBLIC_GOOGLE_SITE_VERIFICATION ?? "";

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  ...(GOOGLE_VERIFICATION
    ? { verification: { google: GOOGLE_VERIFICATION } }
    : {}),
  title: "Sakinah — Widget de prières pour Windows",
  description:
    "Un petit carré noir, discret, en haut à droite de votre écran : horaires de prière de votre mosquée (Mawaqit) avec compte à rebours en direct, calendrier mensuel, Qibla et rappels à l'heure. Open source, 100 % local.",
  keywords: [
    "Sakinah",
    "widget prière",
    "horaires de prière",
    "Mawaqit",
    "qibla",
    "ramadan",
    "calendrier musulman",
    "Windows",
    "PyQt6",
    "adhan",
    "application desktop",
  ],
  authors: [{ name: "Sakinah" }],
  manifest: "/manifest.webmanifest",
  applicationName: "Sakinah",
  icons: {
    icon: [
      { url: "/icons/icon-48.png", sizes: "48x48", type: "image/png" },
      { url: "/icons/icon-192.png", sizes: "192x192", type: "image/png" },
      { url: "/icons/icon-512.png", sizes: "512x512", type: "image/png" },
    ],
    apple: "/icons/apple-touch-icon.png",
  },
  appleWebApp: {
    capable: true,
    title: "Sakinah",
    statusBarStyle: "black-translucent",
  },
  openGraph: {
    title: "Sakinah — Le carré noir qui veille sur vos prières",
    description:
      "Horaires de prière de votre mosquée (Mawaqit), calendrier mensuel et Qibla, dans un petit carré noir toujours au premier plan. Application Windows open source en Python/PyQt6.",
    siteName: "Sakinah",
    type: "website",
    locale: "fr_FR",
  },
  twitter: {
    card: "summary_large_image",
    title: "Sakinah — Widget de prières pour Windows",
    description:
      "Horaires Mawaqit en direct, calendrier mensuel et Qibla, dans un petit carré noir toujours au premier plan.",
  },
};

export const viewport: Viewport = {
  themeColor: "#09090b",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fr" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <RegisterSw />
        <Toaster />
      </body>
    </html>
  );
}
