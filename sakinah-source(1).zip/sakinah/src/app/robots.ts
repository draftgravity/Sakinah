/**
 * robots.ts — politique d'exploration pour les robots (lu à /robots.txt).
 * Tout le site est indexable ; le sitemap est déclaré pour aider Google
 * à le découvrir (Search Console).
 */

import type { MetadataRoute } from "next";

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";

export default function robots(): MetadataRoute.Robots {
  return {
    rules: {
      userAgent: "*",
      allow: "/",
      // Les routes API ne présentent aucun intérêt pour l'index.
      disallow: ["/api/"],
    },
    sitemap: `${SITE_URL}/sitemap.xml`,
  };
}
