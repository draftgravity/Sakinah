/**
 * sitemap.ts — plan du site pour les moteurs de recherche (Google Search
 * Console le lit à /sitemap.xml). Une seule page aujourd'hui ; en
 * production, définir NEXT_PUBLIC_SITE_URL (ex. https://sakinah.app).
 */

import type { MetadataRoute } from "next";

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";

export default function sitemap(): MetadataRoute.Sitemap {
  return [
    {
      url: SITE_URL,
      lastModified: new Date(),
      changeFrequency: "weekly",
      priority: 1,
    },
  ];
}
