/**
 * Page vitrine de Sakinah — widget de prières & de focus pour Windows.
 *
 * Thème sombre intégral (zinc-950) + accent émeraude (prières) et ambre
 * (focus). La démo interactive est montée UNE fois en fin de page : elle fait
 * vivre le carré noir (fixed, z-70), sa pop-up (z-80) et le voile Focus
 * (z-100) pendant toute la visite.
 */

import SakinahDemo from "@/components/demo/sakinah-demo";
import { SiteHeader } from "@/components/site/site-header";
import { HeroSection } from "@/components/site/hero-section";
import { StatsBand } from "@/components/site/stats-band";
import { FeaturesSection } from "@/components/site/features-section";
import { DemoSection } from "@/components/site/demo-section";
import { CodeSection } from "@/components/site/code-section";
import { InstallationSection } from "@/components/site/installation-section";
import { ChangelogSection } from "@/components/site/changelog-section";
import { FaqSection } from "@/components/site/faq-section";
import { FinalCta } from "@/components/site/final-cta";
import { SiteFooter } from "@/components/site/site-footer";
import { BackToTop } from "@/components/site/back-to-top";

export default function Home() {
  return (
    <div className="relative flex min-h-screen flex-col overflow-x-clip bg-zinc-950 text-zinc-100">
      {/* décor de fond : halo émeraude en haut + voile latéral discret */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-x-0 top-0 h-[560px] bg-[radial-gradient(ellipse_60%_50%_at_50%_-10%,rgba(16,185,129,0.14),transparent_70%)]"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-x-0 top-0 h-[360px] dot-grid opacity-60 [mask-image:radial-gradient(ellipse_70%_60%_at_50%_0%,black,transparent)]"
      />

      <SiteHeader />

      <main className="relative flex-1">
        <HeroSection />
        <StatsBand />
        <FeaturesSection />
        <DemoSection />
        <CodeSection />
        <InstallationSection />
        <ChangelogSection />
        <FaqSection />
        <FinalCta />
      </main>

      <SiteFooter />

      {/* Démo interactive réelle : carré noir (z-70), pop-up (z-80),
          voile Focus (z-100) et paramètres. Ne monter qu'UNE fois. */}
      <SakinahDemo />

      {/* Retour en haut (flottant, z-40) */}
      <BackToTop />
    </div>
  );
}
