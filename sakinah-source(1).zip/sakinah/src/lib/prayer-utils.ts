/**
 * Logique « prières » partagée par la démo web — le pendant TypeScript
 * de app/services/prayer_service.py (mêmes règles : Chourouk affiché mais
 * jamais « prière suivante », repli sur le Fajr de demain après Isha).
 */

export interface PrayerDef {
  key: string;
  label: string;
  arabic: string;
  /** true = vraie prière (rappel, adhan) ; false = info (Chourouk) */
  real: boolean;
}

export const PRAYERS: PrayerDef[] = [
  { key: "fajr", label: "Fajr", arabic: "الفجر", real: true },
  { key: "shourouk", label: "Chourouk", arabic: "الشروق", real: false },
  { key: "dhuhr", label: "Dhuhr", arabic: "الظهر", real: true },
  { key: "asr", label: "Asr", arabic: "العصر", real: true },
  { key: "maghrib", label: "Maghrib", arabic: "المغرب", real: true },
  { key: "isha", label: "Isha", arabic: "العشاء", real: true },
];

export const PRAYER_LABELS: Record<string, string> = Object.fromEntries(
  PRAYERS.map((p) => [p.key, p.label]),
);

export type TimesMap = Record<string, string | null>;

export interface PrayersPayload {
  slug: string;
  name: string;
  localisation?: string | null;
  jumua?: string | null;
  /** horaires "HH:MM" du jour */
  times: TimesMap;
  /** horaires d'iqama (prière en commun à la mosquée) du jour */
  iqama?: Record<string, string | null>;
  /** premier horaire de demain (Fajr) — compte à rebours après Isha */
  tomorrowFajr?: string | null;
  /** ligne complète de demain (adhans + iqamas) — mise en cache pour
   *  présenter les bons horaires après minuit même sans réseau */
  tomorrow?: {
    times: TimesMap;
    iqama?: Record<string, string | null>;
  } | null;
  /** true = payload synthétisé depuis la ligne J+1 du cache (repli minuit) */
  dayAfterCache?: boolean;
  /** coordonnées de la mosquée (boussole Qibla) — optionnelles */
  latitude?: number | null;
  longitude?: number | null;
  /** fuseau horaire de la mosquée (ex. "Europe/Paris") */
  timezone?: string | null;
  /** true = données d'exemple (API Mawaqit injoignable) */
  sample?: boolean;
  fetchedAt: string;
}

export interface NextPrayerInfo {
  key: string;
  label: string;
  time: string;
  datetime: Date;
  remainingSec: number;
  isTomorrow: boolean;
}

/* ------------------ Fuseau horaire de la mosquée ------------------ */

/** Horloge murale dans un fuseau (date + secondes écoulées depuis minuit). */
export interface ZoneClock {
  year: number;
  month: number; // 1-12
  day: number;
  sec: number; // secondes depuis minuit locale du fuseau
  weekday: number; // 0 = dimanche … 5 = vendredi
}

const zoneDtfCache = new Map<string, Intl.DateTimeFormat>();

function getZoneDtf(tz: string): Intl.DateTimeFormat | null {
  try {
    let dtf = zoneDtfCache.get(tz);
    if (!dtf) {
      dtf = new Intl.DateTimeFormat("en-US", {
        timeZone: tz,
        hour12: false,
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        weekday: "short",
      });
      zoneDtfCache.set(tz, dtf);
    }
    return dtf;
  } catch {
    return null;
  }
}

const WEEKDAYS: Record<string, number> = {
  Sun: 0,
  Mon: 1,
  Tue: 2,
  Wed: 3,
  Thu: 4,
  Fri: 5,
  Sat: 6,
};

/**
 * Heure murale actuelle dans le fuseau de la mosquée (null → repli navigateur).
 * Ex. un visiteur à Tokyo consultant la Grande Mosquée de Paris voit le
 * compte à rebours de Paris, pas celui de Tokyo.
 */
export function zoneClock(
  tz: string | null | undefined,
  at: Date = new Date(),
): ZoneClock | null {
  if (!tz) return null;
  const dtf = getZoneDtf(tz);
  if (!dtf) return null;
  const parts = dtf.formatToParts(at);
  const get = (type: string) =>
    parts.find((p) => p.type === type)?.value ?? "";
  const hour = Number(get("hour")) % 24; // certains moteurs renvoient « 24 »
  const weekday = WEEKDAYS[get("weekday")];
  return {
    year: Number(get("year")),
    month: Number(get("month")),
    day: Number(get("day")),
    sec: hour * 3600 + Number(get("minute")) * 60 + Number(get("second")),
    weekday: weekday === undefined ? -1 : weekday,
  };
}

/** Secondes du jour d'une heure « HH:MM » (null si invalide). */
export function timeToSeconds(
  value: string | null | undefined,
): number | null {
  if (!value) return null;
  const match = /^(\d{1,2}):(\d{2})/.exec(value.trim());
  if (!match) return null;
  const hours = Number(match[1]);
  const minutes = Number(match[2]);
  if (hours > 23 || minutes > 59) return null;
  return hours * 3600 + minutes * 60;
}

/** « 6:03 » → « 06:03 » (affichage stable des horaires). */
export function normalizeTime(value: string): string {
  const sec = timeToSeconds(value);
  if (sec === null) return value;
  return `${String(Math.floor(sec / 3600)).padStart(2, "0")}:${String(
    Math.floor(sec / 60) % 60,
  ).padStart(2, "0")}`;
}

/**
 * Instant ABSOLU correspondant à une heure murale du fuseau (DST géré par
 * double passe : on mesure l'écart réel fuseau/UTC à l'instant deviné).
 */
function zoneWallTimeToAbs(
  clock: ZoneClock,
  sec: number,
  tz: string,
  dayOffset = 0,
): Date {
  const guess = Date.UTC(clock.year, clock.month - 1, clock.day, 0, 0, 0) +
    (dayOffset * 86_400 + sec) * 1000;
  const probe = zoneClock(tz, new Date(guess));
  if (!probe) return new Date(guess);
  const asUTC =
    Date.UTC(
      probe.year,
      probe.month - 1,
      probe.day,
      0,
      0,
      0,
    ) + probe.sec * 1000;
  return new Date(guess - (asUTC - guess));
}

/** Convertit "HH:MM" en Date du jour (null si invalide). */
export function timeToDate(value: string | null | undefined, dayOffset = 0): Date | null {
  if (!value) return null;
  const match = /^(\d{1,2}):(\d{2})/.exec(value.trim());
  if (!match) return null;
  const hours = Number(match[1]);
  const minutes = Number(match[2]);
  if (hours > 23 || minutes > 59) return null;
  const date = new Date();
  date.setDate(date.getDate() + dayOffset);
  date.setHours(hours, minutes, 0, 0);
  return date;
}

/**
 * Calcule la prochaine prière + secondes restantes (null si données vides).
 *
 * Le calcul est fait à L'HORLOGE DE LA MOSQUÉE (paramètre `timezone`, ex.
 * "Europe/Paris") : le compte à rebours est correct quel que soit le fuseau
 * du visiteur. Sans fuseau connu → repli sur l'heure locale du navigateur
 * (ancien comportement).
 */
export function computeNextPrayer(
  times: TimesMap,
  tomorrowFajr?: string | null,
  timezone?: string | null,
): NextPrayerInfo | null {
  const now = new Date();
  const clock = zoneClock(timezone, now);

  // ---- Chemin « fuseau de la mosquée » (cas normal, API Mawaqit) ----
  if (clock) {
    let best: { key: string; label: string; time: string; sec: number } | null =
      null;
    for (const prayer of PRAYERS) {
      if (!prayer.real) continue;
      const value = times[prayer.key];
      const sec = timeToSeconds(value);
      if (sec === null || sec <= clock.sec) continue;
      if (!best || sec < best.sec) {
        best = { key: prayer.key, label: prayer.label, time: normalizeTime(value!), sec };
      }
    }

    if (best) {
      const datetime = zoneWallTimeToAbs(clock, best.sec, timezone!);
      return {
        key: best.key,
        label: best.label,
        time: best.time,
        datetime,
        remainingSec: Math.max(
          0,
          Math.round((datetime.getTime() - now.getTime()) / 1000),
        ),
        isTomorrow: false,
      };
    }

    // Toutes les prières du jour sont passées → Fajr de demain (heure murale
    // de demain dans le fuseau, robuste même le jour d'un changement d'heure).
    const fajrValue = tomorrowFajr ?? times.fajr;
    const fajrSec = timeToSeconds(fajrValue);
    if (fajrSec === null) return null;
    const datetime = zoneWallTimeToAbs(clock, fajrSec, timezone!, 1);
    return {
      key: "fajr",
      label: "Fajr",
      time: normalizeTime(fajrValue!),
      datetime,
      remainingSec: Math.max(
        0,
        Math.round((datetime.getTime() - now.getTime()) / 1000),
      ),
      isTomorrow: true,
    };
  }

  // ---- Repli : heure locale du navigateur (comportement historique) ----
  let best: { key: string; label: string; date: Date } | null = null;

  for (const prayer of PRAYERS) {
    if (!prayer.real) continue;
    const date = timeToDate(times[prayer.key]);
    if (!date || date.getTime() <= now.getTime()) continue;
    if (!best || date < best.date) {
      best = { key: prayer.key, label: prayer.label, date };
    }
  }

  let isTomorrow = false;
  if (!best) {
    // Toutes les prières du jour sont passées → Fajr de demain.
    const fajr = timeToDate(tomorrowFajr ?? times.fajr, 1);
    if (!fajr) return null;
    best = { key: "fajr", label: "Fajr", date: fajr };
    isTomorrow = true;
  }

  return {
    key: best.key,
    label: best.label,
    time: `${String(best.date.getHours()).padStart(2, "0")}:${String(
      best.date.getMinutes(),
    ).padStart(2, "0")}`,
    datetime: best.date,
    remainingSec: Math.max(0, Math.round((best.date.getTime() - now.getTime()) / 1000)),
    isTomorrow,
  };
}

/** Formate des secondes en durée lisible : « dans 2 h 14 min », « dans 42 min 10 s ». */
export function formatRemaining(seconds: number): string {
  const total = Math.max(0, Math.floor(seconds));
  const hours = Math.floor(total / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  const secs = total % 60;
  if (hours > 0) return `dans ${hours} h ${String(minutes).padStart(2, "0")} min`;
  if (minutes > 0) return `dans ${minutes} min ${String(secs).padStart(2, "0")} s`;
  return `dans ${secs} s`;
}

/** Horloge réactive (re-render chaque `intervalMs`). */
import { useEffect, useState } from "react";

export function useNow(intervalMs = 1000): Date {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), intervalMs);
    return () => clearInterval(id);
  }, [intervalMs]);
  return now;
}

/** Date hégirienne approximative via l'Intl du navigateur (fuseau de la mosquée si fourni). */
export function hijriToday(timezone?: string | null): string {
  try {
    return new Intl.DateTimeFormat("fr-FR-u-ca-islamic-umalqura", {
      day: "numeric",
      month: "long",
      year: "numeric",
      ...(timezone ? { timeZone: timezone } : {}),
    }).format(new Date());
  } catch {
    return "";
  }
}

/* ---------- Ramadan : compte à rebours via le calendrier hégirien ---------- */

export interface RamadanInfo {
  /** année hégirienne du Ramadan en cours/visé (ex. 1447) */
  hijriYear: number;
  /** 1ᵉʳ jour de Ramadan (minuit local) — null si introuvable */
  startsOn: Date | null;
  /** jours restants avant le 1ᵉʳ Ramadan (0 = il commence aujourd'hui) */
  daysLeft: number;
  /** true : on est DANS le mois de Ramadan */
  inProgress: boolean;
  /** jour courant de Ramadan (1-30) si inProgress */
  dayOfRamadan: number;
}

/** Parts numériques du calendrier islamic-umalqura (mois 9 = Ramadan). */
function islamicParts(date: Date, timezone?: string | null) {
  try {
    const fmt = new Intl.DateTimeFormat("en-u-ca-islamic-umalqura", {
      day: "numeric",
      month: "numeric",
      year: "numeric",
      ...(timezone ? { timeZone: timezone } : {}),
    });
    const parts = fmt.formatToParts(date);
    const get = (type: string) =>
      Number(parts.find((p) => p.type === type)?.value ?? NaN);
    return { day: get("day"), month: get("month"), year: get("year") };
  } catch {
    return null;
  }
}

/** Mémoïsation par jour civil + fuseau (le balayage ne tourne qu'une fois par jour). */
let ramadanMemo: { key: string; info: RamadanInfo | null } | null = null;

/**
 * Position dans le calendrier de Ramadan : soit « jour N de Ramadan »,
 * soit « dans X jours ». Balaye jour par jour (≤ 355 itérations, une seule
 * fois par jour grâce au mémo) — approximation umalqura, cohérente avec
 * l'affichage de la date hégirienne de la page.
 */
export function ramadanInfo(
  now: Date = new Date(),
  timezone?: string | null,
): RamadanInfo | null {
  const key = `${now.getFullYear()}-${now.getMonth()}-${now.getDate()}|${timezone ?? ""}`;
  if (ramadanMemo?.key === key) return ramadanMemo.info;

  let info: RamadanInfo | null = null;
  const today = islamicParts(now, timezone);
  if (today && Number.isFinite(today.day)) {
    if (today.month === 9) {
      // Déjà dans Ramadan : prochain 1ᵉʳ = fin du mois (pour l'affichage
      // « jour N », pas besoin de le chercher).
      info = {
        hijriYear: today.year,
        startsOn: null,
        daysLeft: 0,
        inProgress: true,
        dayOfRamadan: today.day,
      };
    } else {
      // Cherche le prochain 1ᵉʳ Ramadan en avançant jour par jour.
      for (let offset = 1; offset <= 355; offset += 1) {
        const probe = new Date(now.getTime() + offset * 86_400_000);
        const parts = islamicParts(probe, timezone);
        if (parts && parts.month === 9 && parts.day === 1) {
          info = {
            hijriYear: parts.year,
            startsOn: probe,
            daysLeft: offset,
            inProgress: false,
            dayOfRamadan: 0,
          };
          break;
        }
      }
    }
  }
  ramadanMemo = { key, info };
  return info;
}
