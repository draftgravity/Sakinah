/**
 * Limiteur de débit en mémoire (anti force-brute sur la connexion).
 *
 * Compteur glissant par clé (IP + route) : au-delà de `max` tentatives
 * dans `windowMs`, la requête est refusée (429) jusqu'à expiration de la
 * fenêtre. Les tentatives réussies réinitialisent le compteur.
 *
 * Memoire volatile assumée : suffisant pour une instance unique et
 * protège surtout contre le bourrage de formulaire automatisé.
 */

type Bucket = { hits: number[]; };

const buckets = new Map<string, Bucket>();

export function clientIp(request: Request): string {
  const forwarded = request.headers.get("x-forwarded-for");
  if (forwarded) return forwarded.split(",")[0].trim();
  return request.headers.get("x-real-ip") ?? "local";
}

export function rateLimit(
  key: string,
  { max, windowMs }: { max: number; windowMs: number },
): { allowed: boolean; retryAfterSec: number } {
  const now = Date.now();
  const bucket = buckets.get(key) ?? { hits: [] };
  bucket.hits = bucket.hits.filter((time) => now - time < windowMs);

  if (bucket.hits.length >= max) {
    const oldest = bucket.hits[0] ?? now;
    buckets.set(key, bucket);
    return {
      allowed: false,
      retryAfterSec: Math.ceil((windowMs - (now - oldest)) / 1000),
    };
  }
  bucket.hits.push(now);
  buckets.set(key, bucket);

  // Nettoyage périodique (toutes les ~500 insertions, sans compteur global :
  // on profite du passage pour purger les seaux morts si la map dérive).
  if (buckets.size > 500) {
    for (const [k, b] of buckets) {
      if (b.hits.every((t) => now - t >= windowMs)) buckets.delete(k);
    }
  }
  return { allowed: true, retryAfterSec: 0 };
}

/** Réinitialise le compteur d'une clé (après une connexion réussie). */
export function rateLimitReset(key: string) {
  buckets.delete(key);
}
