/**
 * Authentification Sakinah — sessions serveur + mots de passe scrypt.
 *
 * * Mots de passe : JAMAIS stockés en clair — dérivation scrypt (node:crypto)
 *   au format « s1$salt$clé » (s1 = version du format), comparaison à temps
 *   constant via timingSafeEqual ;
 * * Sessions : jeton opaque de 32 octets (crypto.randomBytes) stocké en base
 *   avec expiration (30 jours), transmis en cookie httpOnly SameSite=Lax —
 *   inaccessible au JavaScript côté client ;
 * * `getSessionUser()` lit le cookie et renvoie l'utilisateur courant (ou
 *   null), `requireUser`/`requireManager` gardent les routes API.
 */

import { randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import { cookies } from "next/headers";
import { db } from "@/lib/db";

export const SESSION_COOKIE = "sakina_session";
export const SESSION_DAYS = 30;

export type UserRole = "USER" | "MANAGER";

export interface PublicUser {
  id: string;
  username: string;
  name: string | null;
  email: string;
  role: UserRole;
  /** Version de la démo du gérant : true = complète (Mode Focus),
   *  false = prières. Sans effet pour les membres. */
  focusEnabled: boolean;
  createdAt: string;
  lastLoginAt: string | null;
}

/* ------------------------------------------------------------------ */
/* Mots de passe (scrypt)                                              */
/* ------------------------------------------------------------------ */

const SCRYPT_KEYLEN = 64;

/** Hache un mot de passe : « s1$saltHex$cléHex ». */
export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const key = scryptSync(password, salt, SCRYPT_KEYLEN).toString("hex");
  return `s1$${salt}$${key}`;
}

/** Vérifie un mot de passe contre son hash stocké (temps constant). */
export function verifyPassword(password: string, stored: string): boolean {
  const parts = stored.split("$");
  if (parts.length !== 3 || parts[0] !== "s1") return false;
  const [, saltHex, keyHex] = parts;
  try {
    const derived = scryptSync(password, saltHex, SCRYPT_KEYLEN);
    const expected = Buffer.from(keyHex, "hex");
    if (derived.length !== expected.length) return false;
    return timingSafeEqual(derived, expected);
  } catch {
    return false;
  }
}

/** Hash factice pour égaliser le temps de réponse quand l'utilisateur
 *  n'existe pas (évite de révéler qu'un identifiant est inconnu). */
const DUMMY_HASH = hashPassword("egalisation-du-temps-de-reponse");

export function verifyDummyPassword(password: string): boolean {
  return verifyPassword(password, DUMMY_HASH);
}

/* ------------------------------------------------------------------ */
/* Sessions                                                            */
/* ------------------------------------------------------------------ */

/** Crée une session (jeton + expiration) pour un utilisateur. */
export async function createSession(userId: string) {
  const token = randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 86_400_000);
  await db.authSession.create({ data: { token, userId, expiresAt } });
  // Nettoyage opportuniste des sessions expirées (toutes les 1ʳᵉʳˢ connexions).
  await db.authSession
    .deleteMany({ where: { expiresAt: { lt: new Date() } } })
    .catch(() => undefined);
  return { token, expiresAt };
}

export async function deleteSession(token: string) {
  await db.authSession.deleteMany({ where: { token } }).catch(() => undefined);
}

/** L'utilisateur connecté (via cookie) — null si anonyme ou expiré. */
export async function getSessionUser(): Promise<PublicUser | null> {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  const session = await db.authSession.findUnique({
    where: { token },
    include: { user: true },
  });
  if (!session) return null;
  if (session.expiresAt.getTime() < Date.now()) {
    await db.authSession
      .delete({ where: { id: session.id } })
      .catch(() => undefined);
    return null;
  }
  return toPublicUser(session.user);
}

/* ------------------------------------------------------------------ */
/* Garde des routes API                                                */
/* ------------------------------------------------------------------ */

/** Réponse JSON d'erreur (format commun aux routes). */
export function jsonError(message: string, status: number) {
  return Response.json({ error: message }, { status });
}

/** Exige un utilisateur connecté → sinon 401. */
export async function requireUser(): Promise<
  { user: PublicUser } | { response: Response }
> {
  const user = await getSessionUser();
  if (!user) {
    return { response: jsonError("Connexion requise.", 401) };
  }
  return { user };
}

/** Exige un GÉRANT → sinon 401/403. */
export async function requireManager(): Promise<
  { user: PublicUser } | { response: Response }
> {
  const user = await getSessionUser();
  if (!user) {
    return { response: jsonError("Connexion requise.", 401) };
  }
  if (user.role !== "MANAGER") {
    return { response: jsonError("Accès réservé au gérant.", 403) };
  }
  return { user };
}

/* ------------------------------------------------------------------ */
/* Utilitaires                                                          */
/* ------------------------------------------------------------------ */

/** Représentation publique d'un utilisateur (sans le hash). */
export function toPublicUser(user: {
  id: string;
  username: string;
  name: string | null;
  email: string;
  role: string;
  focusEnabled?: boolean;
  createdAt: Date;
  lastLoginAt: Date | null;
}): PublicUser {
  return {
    id: user.id,
    username: user.username,
    name: user.name,
    email: user.email,
    role: user.role === "MANAGER" ? "MANAGER" : "USER",
    focusEnabled: user.focusEnabled !== false,
    createdAt: user.createdAt.toISOString(),
    lastLoginAt: user.lastLoginAt ? user.lastLoginAt.toISOString() : null,
  };
}

/* ------------------------------------------------------------------ */
/* Cookie de session                                                    */
/* ------------------------------------------------------------------ */

/** Attributs SameSite adaptés au contexte de la requête.
 *
 * La vitrine est souvent consultée DANS un cadre intégré sur un autre
 * site (panneau d'aperçu) : un cookie SameSite=Lax y est silencieusement
 * refusé par le navigateur — le login « réussit » puis toutes les routes
 * suivantes renvoient 401. En contexte intégré, il faut SameSite=None
 * (qui exige Secure). En direct sur localhost, Lax suffit et fonctionne
 * partout : on garde ce profil pour ne rien casser en développement.
 */
export function sessionCookieSameSite(request: Request): string {
  const host = (request.headers.get("host") ?? "")
    .split(":")[0]
    .trim()
    .toLowerCase();
  const isLocal =
    host === "localhost" || host === "127.0.0.1" || host === "[::1]";
  return isLocal ? "SameSite=Lax" : "SameSite=None; Secure";
}

/** Attribue le cookie de session sur une réponse (httpOnly). */
export function setSessionCookie(
  response: Response,
  token: string,
  expiresAt: Date,
  request: Request,
) {
  response.headers.append(
    "set-cookie",
    [
      `${SESSION_COOKIE}=${token}`,
      "Path=/",
      "HttpOnly",
      sessionCookieSameSite(request),
      `Expires=${expiresAt.toUTCString()}`,
      "Max-Age=" + SESSION_DAYS * 86_400,
    ].join("; "),
  );
  return response;
}

/** Efface le cookie de session. */
export function clearSessionCookie(response: Response, request: Request) {
  response.headers.append(
    "set-cookie",
    [
      `${SESSION_COOKIE}=`,
      "Path=/",
      "HttpOnly",
      sessionCookieSameSite(request),
      "Max-Age=0",
    ].join("; "),
  );
  return response;
}

/** Journalise une activité (best effort — n'échoue jamais la requête). */
export async function logActivity(
  userId: string | null,
  type: string,
  detail: string,
) {
  await db.activity
    .create({ data: { userId, type, detail } })
    .catch(() => undefined);
}
