/**
 * Synchronisation des données du compte (dhikr + focus) ↔ serveur.
 *
 * PRINCIPE — « en ligne d'abord » : quand un compte est connecté, la
 * base du serveur est la source de vérité ; le localStorage ne sert que
 * de cache pour la démo hors connexion.
 *
 *  * `mergeOnLogin()`   : à la connexion, pousse les valeurs LOCALES vers
 *    le serveur (fusion par maximum — deux appareils ne comptent jamais
 *    deux fois), puis rapatrie l'état fusionné et notifie les composants ;
 *  * `scheduleDhikrSync()` : après chaque tape (debounce 1,5 s), envoie
 *    les totaux + l'historique — idempotent grâce à la fusion max ;
 *  * `syncFocusSession()`  : une session de concentration vient d'être
 *    terminée → envoyée immédiatement ;
 *  * `resetServerDhikr()`  : bouton « Effacer » → remise à zéro serveur.
 *
 * Les composants sont prévenus par l'événement window `ACCOUNT_SYNC_EVENT`
 * (le compteur relit ses totaux, l'orchestrateur ré-hydrate le focus).
 */

"use client";

import { useAuthStore } from "@/lib/auth-store";

export const ACCOUNT_SYNC_EVENT = "sakinah:account-sync";

/* ------------------------------------------------------------------ */
/* Lecture / écriture du cache local (formats existants de la démo)    */
/* ------------------------------------------------------------------ */

const TOTALS_KEY = "sakinah-tasbih-totals";
const DHIKR_HISTORY_KEY = "sakinah-dhikr-history";
const FOCUS_HISTORY_KEY = "sakinah-focus-history";
const FOCUS_STATS_KEY = "sakinah-focus-stats";

interface TasbihTotals {
  date: string;
  today: number;
  lifetime: number;
  perFormula?: Record<string, number>;
}

type DayCounts = Record<string, number>;

/** Réponse de /api/dhikr (GET ou PUT). */
interface DhikrState {
  date: string;
  today: number;
  lifetime: number;
  perFormula: Record<string, number>;
  history: DayCounts;
}

/** Réponse de /api/focus (GET ou POST). */
interface FocusState {
  history: DayCounts;
  totalSessions: number;
  totalMinutes: number;
}

export const localDayKey = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(
    d.getDate(),
  ).padStart(2, "0")}`;
};

function readJson<T>(key: string, fallback: T): T {
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function writeJson(key: string, value: unknown) {
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* quota — best effort */
  }
}

function isAuthed() {
  return useAuthStore.getState().user !== null;
}

/** Notifie les composants que le cache local vient d'être réécrit. */
function notifySync() {
  window.dispatchEvent(new CustomEvent(ACCOUNT_SYNC_EVENT));
}

/* ------------------------------------------------------------------ */
/* Fusion à la connexion                                               */
/* ------------------------------------------------------------------ */

/**
 * À la connexion :
 *  1. lit l'état SERVEUR du compte ;
 *  2. MIGRATION UNIQUEMENT SI LE COMPTE EST VIERGE : un visiteur qui a
 *     tapé en anonyme puis crée son compte emporte ses données — mais un
 *     cache local laissé par un AUTRE utilisateur sur un ordinateur
 *     partagé ne pollue jamais un compte existant (le serveur prime) ;
 *  3. l'état final (serveur) remplace le cache local et les composants
 *     en sont notifiés.
 */
export async function mergeOnLogin(): Promise<void> {
  if (!isAuthed()) return;
  const today = localDayKey();

  const [dhikrResponse, focusResponse] = await Promise.all([
    fetch("/api/dhikr", { cache: "no-store" }).catch(() => null),
    fetch("/api/focus", { cache: "no-store" }).catch(() => null),
  ]);

  const serverDhikr = dhikrResponse?.ok
    ? ((await dhikrResponse.json()) as DhikrState)
    : null;
  const serverFocus = focusResponse?.ok
    ? ((await focusResponse.json()) as FocusState)
    : null;

  const totals = readJson<TasbihTotals | null>(TOTALS_KEY, null);
  const dhikrHistory = readJson<DayCounts>(DHIKR_HISTORY_KEY, {});
  const focusHistory = readJson<DayCounts>(FOCUS_HISTORY_KEY, {});

  const localDhikrWorth =
    (totals && (totals.today > 0 || totals.lifetime > 0)) ||
    Object.values(dhikrHistory).some((count) => count > 0);
  const localFocusWorth = Object.values(focusHistory).some((count) => count > 0);

  const serverDhikrEmpty =
    !serverDhikr ||
    (serverDhikr.today === 0 &&
      serverDhikr.lifetime === 0 &&
      Object.keys(serverDhikr.history).length === 0);
  const serverFocusEmpty = !serverFocus || serverFocus.totalSessions === 0;

  // Migration du local (une seule fois : compte vierge côté serveur).
  let finalDhikr = serverDhikr;
  if (serverDhikrEmpty && localDhikrWorth) {
    const put = await fetch("/api/dhikr", {
      method: "PUT",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        date: totals?.date && /^\d{4}-\d{2}-\d{2}$/.test(totals.date) ? totals.date : today,
        today: totals?.today ?? 0,
        lifetime: totals?.lifetime ?? 0,
        perFormula: totals?.perFormula ?? {},
        history: dhikrHistory,
      }),
    }).catch(() => null);
    if (put?.ok) {
      finalDhikr = (await put.json()) as DhikrState;
    }
  }
  let finalFocus = serverFocus;
  if (serverFocusEmpty && localFocusWorth) {
    const post = await fetch("/api/focus", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ history: focusHistory }),
    }).catch(() => null);
    if (post?.ok) {
      finalFocus = (await post.json()) as FocusState;
    }
  }

  // Le serveur devient la vérité : réécrit le cache local.
  if (finalDhikr) {
    writeJson(TOTALS_KEY, {
      date: finalDhikr.date || today,
      today: finalDhikr.today,
      lifetime: finalDhikr.lifetime,
      perFormula: finalDhikr.perFormula,
    });
    writeJson(DHIKR_HISTORY_KEY, finalDhikr.history);
  }
  if (finalFocus) {
    writeJson(FOCUS_HISTORY_KEY, finalFocus.history);
    writeJson(FOCUS_STATS_KEY, {
      date: today,
      count: finalFocus.history[today] ?? 0,
    });
  }

  notifySync();
}

/* ------------------------------------------------------------------ */
/* Synchronisation debouncée du dhikr (une tape)                       */
/* ------------------------------------------------------------------ */

let dhikrTimer: ReturnType<typeof setTimeout> | undefined;

/** Envoie les totaux + historique locaux (1,5 s après la dernière tape). */
export function scheduleDhikrSync() {
  if (!isAuthed()) return;
  if (dhikrTimer) clearTimeout(dhikrTimer);
  dhikrTimer = setTimeout(() => {
    dhikrTimer = undefined;
    void flushDhikrSync();
  }, 1500);
}

/** Flush immédiat (utilisé aussi par pagehide). */
export async function flushDhikrSync(): Promise<void> {
  if (!isAuthed()) return;
  const totals = readJson<TasbihTotals | null>(TOTALS_KEY, null);
  if (!totals) return;
  const history = readJson<DayCounts>(DHIKR_HISTORY_KEY, {});
  try {
    const response = await fetch("/api/dhikr", {
      method: "PUT",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        date: totals.date,
        today: totals.today,
        lifetime: totals.lifetime,
        perFormula: totals.perFormula ?? {},
        history,
      }),
    });
    if (!response.ok) return;
    // Le serveur peut avoir MIEUX que nous (autre appareil) → on aligne le
    // cache local sur sa réponse (fusion max déjà appliquée côté serveur).
    const data = (await response.json()) as {
      date: string;
      today: number;
      lifetime: number;
      perFormula: Record<string, number>;
      history: DayCounts;
    };
    if (
      data.today > totals.today ||
      data.lifetime > totals.lifetime ||
      data.date > totals.date
    ) {
      writeJson(TOTALS_KEY, {
        date: data.date,
        today: data.today,
        lifetime: data.lifetime,
        perFormula: data.perFormula,
      });
      writeJson(DHIKR_HISTORY_KEY, data.history);
      notifySync();
    }
  } catch {
    /* hors ligne : la prochaine tape relancera la synchro */
  }
}

/* ------------------------------------------------------------------ */
/* Session de focus terminée                                           */
/* ------------------------------------------------------------------ */

export async function syncFocusSession(durationSec: number): Promise<void> {
  if (!isAuthed()) return;
  const today = localDayKey();
  try {
    const response = await fetch("/api/focus", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ sessions: [{ durationSec, dateKey: today }] }),
    });
    if (!response.ok) return;
    const data = (await response.json()) as { history: DayCounts };
    writeJson(FOCUS_HISTORY_KEY, data.history);
    writeJson(FOCUS_STATS_KEY, {
      date: today,
      count: data.history[today] ?? 0,
    });
    notifySync();
  } catch {
    /* hors ligne : la session restera dans le cache local */
  }
}

/* ------------------------------------------------------------------ */
/* Réinitialisation serveur (bouton « Effacer »)                       */
/* ------------------------------------------------------------------ */

export async function resetServerDhikr(): Promise<void> {
  if (!isAuthed()) return;
  try {
    await fetch("/api/dhikr", {
      method: "PUT",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ reset: true }),
    });
  } catch {
    /* la remise à zéro locale est déjà faite ; le serveur rattrapera
       à la prochaine synchro (fusion max → valeurs basses → inchangé).
       ⚠ Cas limite accepté : sans connexion, le serveur garde ses
       totaux jusqu'au retour du réseau. */
  }
}
