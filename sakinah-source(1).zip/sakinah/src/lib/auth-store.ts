/**
 * Store d'authentification (zustand) — session Sakinah.
 *
 * * `init()` est appelé UNE fois au chargement de la page : /api/auth/me
 *   rétablit la session depuis le cookie httpOnly ;
 * * `login` accepte identifiant OU e-mail (le champ est unique côté API) ;
 * * `register` crée un compte membre (USER) — seul le gérant promeut ;
 * * `loginOpen` pilote le dialogue de connexion (ouvert depuis l'en-tête,
 *   le compteur de Tasbih « non synchronisé », etc.).
 */

"use client";

import { create } from "zustand";

export type Role = "USER" | "MANAGER";

export interface AuthUser {
  id: string;
  username: string;
  name: string | null;
  email: string;
  role: Role;
  /** Version du gérant : true = complète (Mode Focus), false = prières. */
  focusEnabled: boolean;
  createdAt: string;
  lastLoginAt: string | null;
}

export interface AuthResult {
  ok: boolean;
  error?: string;
}

interface AuthState {
  user: AuthUser | null;
  /** true dès que la session a été vérifiée une fois (évite le flash). */
  ready: boolean;
  /** dialogue « Connexion / Inscription » ouvert ? */
  loginOpen: boolean;
  init: () => Promise<void>;
  setLoginOpen: (open: boolean) => void;
  setUser: (user: AuthUser | null) => void;
  login: (identifier: string, password: string) => Promise<AuthResult>;
  register: (payload: {
    username: string;
    email: string;
    password: string;
    name?: string;
  }) => Promise<AuthResult>;
  /** Version de la démo du gérant (en ligne) — true = complète. */
  setFocusEnabled: (enabled: boolean) => Promise<AuthResult>;
  logout: () => Promise<void>;
}

let initialized = false;

export const useAuthStore = create<AuthState>()((set, get) => ({
  user: null,
  ready: false,
  loginOpen: false,

  init: async () => {
    if (initialized) return;
    initialized = true;
    try {
      const response = await fetch("/api/auth/me", {
        cache: "no-store",
      });
      if (response.ok) {
        const data = (await response.json()) as { user: AuthUser };
        set({ user: data.user, ready: true });
        return;
      }
    } catch {
      /* hors ligne : session inconnue, on reste anonyme */
    }
    set({ ready: true });
  },

  setLoginOpen: (open) => set({ loginOpen: open }),
  setUser: (user) => set({ user }),

  login: async (identifier, password) => {
    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ identifier, password }),
      });
      const data = (await response.json().catch(() => ({}))) as {
        user?: AuthUser;
        error?: string;
      };
      if (!response.ok || !data.user) {
        return { ok: false, error: data.error ?? "Connexion impossible." };
      }
      set({ user: data.user, loginOpen: false });
      return { ok: true };
    } catch {
      return { ok: false, error: "Réseau indisponible — réessayez." };
    }
  },

  register: async (payload) => {
    try {
      const response = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = (await response.json().catch(() => ({}))) as {
        user?: AuthUser;
        error?: string;
      };
      if (!response.ok || !data.user) {
        return { ok: false, error: data.error ?? "Création impossible." };
      }
      set({ user: data.user, loginOpen: false });
      return { ok: true };
    } catch {
      return { ok: false, error: "Réseau indisponible — réessayez." };
    }
  },

  setFocusEnabled: async (enabled) => {
    try {
      const response = await fetch("/api/auth/preferences", {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ focusEnabled: enabled }),
      });
      const data = (await response.json().catch(() => ({}))) as {
        user?: AuthUser;
        error?: string;
      };
      if (!response.ok || !data.user) {
        return { ok: false, error: data.error ?? "Modification impossible." };
      }
      set({ user: data.user });
      return { ok: true };
    } catch {
      return { ok: false, error: "Réseau indisponible — réessayez." };
    }
  },

  logout: async () => {
    try {
      await fetch("/api/auth/logout", { method: "POST" });
    } catch {
      /* même hors ligne : on efface l'état local */
    }
    set({ user: null });
  },
}));

/** Sélecteur pratique : l'utilisateur courant est-il gérant ? */
export const useIsManager = () =>
  useAuthStore((state) => state.user?.role === "MANAGER");

/** Sélecteur : le gérant voit-il la version complète (Mode Focus) ?
 *  (Toujours false pour un membre ou un anonyme.) */
export const useSeesFocusTab = () =>
  useAuthStore(
    (state) => state.user?.role === "MANAGER" && state.user.focusEnabled,
  );
