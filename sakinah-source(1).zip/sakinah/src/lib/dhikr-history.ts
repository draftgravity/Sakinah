/**
 * Historique de dhikr — le pendant web des « statistiques de focus » :
 * chaque tape du compteur de Tasbih incrémente le total du JOUR dans
 * localStorage, ce qui permet de dessiner :
 *  * un mini-graphique des 7 derniers jours (comme l'onglet Focus) ;
 *  * une « série » (streak) : jours consécutifs avec au moins un dhikr.
 *
 * Conventions : clé de jour locale « YYYY-MM-DD » (identique au store et
 * au hook use-day-change), rétention 30 jours, échec localStorage silencieux.
 */

const DHIKR_HISTORY_KEY = "sakinah-dhikr-history";
const HISTORY_DAYS = 30;

export type DhikrHistory = Record<string, number>;

export interface DhikrDay {
  date: string;
  label: string;
  count: number;
  isToday: boolean;
}

/** Clé du jour local « YYYY-MM-DD ». */
export function dayKeyOf(date: Date = new Date()): string {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(
    date.getDate(),
  ).padStart(2, "0")}`;
}

function readAll(): DhikrHistory {
  if (typeof window === "undefined") return {};
  try {
    const raw = window.localStorage.getItem(DHIKR_HISTORY_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw) as DhikrHistory;
    if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) {
      return {};
    }
    const kept: DhikrHistory = {};
    for (const [key, value] of Object.entries(parsed)) {
      if (Number.isInteger(value) && value >= 0) kept[key] = value;
    }
    return kept;
  } catch {
    return {};
  }
}

function writeAll(history: DhikrHistory) {
  try {
    window.localStorage.setItem(DHIKR_HISTORY_KEY, JSON.stringify(history));
  } catch {
    /* quota — best effort */
  }
}

/** +1 tape aujourd'hui (retourne le nouvel historique complet). */
export function bumpDhikrHistory(): DhikrHistory {
  const history = readAll();
  const key = dayKeyOf();
  history[key] = (history[key] ?? 0) + 1;
  // Rétention : ne garde que les 30 derniers jours (clés ISO triées).
  const cutoff = Date.now() - HISTORY_DAYS * 86_400_000;
  for (const day of Object.keys(history)) {
    const time = Date.parse(`${day}T00:00:00`);
    if (Number.isNaN(time) || time < cutoff) delete history[day];
  }
  writeAll(history);
  return history;
}

/** Efface tout l'historique (bouton « Effacer » confirmé). */
export function clearDhikrHistory() {
  try {
    window.localStorage.removeItem(DHIKR_HISTORY_KEY);
  } catch {
    /* ignore */
  }
}

/** Les 7 derniers jours, triés du plus ancien aujourd'hui. */
export function getDhikrWeek(): DhikrDay[] {
  const history = readAll();
  const days: DhikrDay[] = [];
  const formatter = new Intl.DateTimeFormat("fr-FR", { weekday: "short" });
  for (let offset = 6; offset >= 0; offset -= 1) {
    const date = new Date();
    date.setDate(date.getDate() - offset);
    const key = dayKeyOf(date);
    days.push({
      date: key,
      label: formatter.format(date).replace(".", ""),
      count: history[key] ?? 0,
      isToday: offset === 0,
    });
  }
  return days;
}

/**
 * Série de jours consécutifs avec au moins un dhikr, en partant
 * d'aujourd'hui — ou, si rien aujourd'hui, d'hier (une série n'est cassée
 * que si le jour s'est terminé sans tape ; convention usuelle).
 * Retourne 0 si aucun des deux n'a de tape.
 */
export function computeDhikrStreak(): number {
  const history = readAll();
  let streak = 0;
  const cursor = new Date();
  if (!(history[dayKeyOf(cursor)] > 0)) {
    cursor.setDate(cursor.getDate() - 1); // aujourd'hui encore vierge → hier
  }
  while (history[dayKeyOf(cursor)] > 0) {
    streak += 1;
    cursor.setDate(cursor.getDate() - 1);
    if (streak > HISTORY_DAYS) break; // garde-fou (rétention 30 jours)
  }
  return streak;
}

/** Total des 7 derniers jours (pour le résumé et l'export CSV). */
export function dhikrWeekTotal(): number {
  return getDhikrWeek().reduce((sum, day) => sum + day.count, 0);
}
