/**
 * Catalogue des régions de recherche de mosquées.
 *
 * À l'ouverture, la démo demande la région du visiteur (France, Belgique,
 * États-Unis…) : les résultats Mawaqit placés EN PREMIER sont ceux de sa
 * région — les autres ne disparaissent pas, ils passent simplement après.
 *
 * La correspondance se fait sur le champ « localisation » (adresse complète
 * publiée par Mawaqit, qui se termine par le pays — dans plusieurs langues :
 * "France", "Belgium", "Belgique"…) et sur le slug (qui se termine souvent
 * par le pays : "…-93500-france").
 */

export interface Region {
  /** clé courte (code pays) — "all" = aucune préférence */
  key: string;
  /** libellé français */
  label: string;
  /** motifs pays (minuscules) recherchés dans localisation + slug */
  patterns: string[];
}

/** Régions proposées — les plus demandées sur Mawaqit (Europe de l'Ouest,
 *  Maghreb, Amérique du Nord, Moyen-Orient). */
export const REGIONS: Region[] = [
  { key: "FR", label: "France", patterns: ["france"] },
  { key: "BE", label: "Belgique", patterns: ["belgium", "belgique"] },
  { key: "CH", label: "Suisse", patterns: ["switzerland", "suisse", "schweiz"] },
  { key: "GB", label: "Royaume-Uni", patterns: ["united kingdom", "royaume-uni", "england", "scotland", "wales"] },
  { key: "DE", label: "Allemagne", patterns: ["germany", "deutschland", "allemagne"] },
  { key: "NL", label: "Pays-Bas", patterns: ["netherlands", "pays-bas", "holland"] },
  { key: "ES", label: "Espagne", patterns: ["spain", "españa", "espagne"] },
  { key: "IT", label: "Italie", patterns: ["italy", "italia", "italie"] },
  { key: "US", label: "États-Unis", patterns: ["united states", "usa", "états-unis", "etats-unis"] },
  { key: "CA", label: "Canada", patterns: ["canada"] },
  { key: "MA", label: "Maroc", patterns: ["morocco", "maroc"] },
  { key: "DZ", label: "Algérie", patterns: ["algeria", "algérie", "algerie"] },
  { key: "TN", label: "Tunisie", patterns: ["tunisia", "tunisie"] },
  { key: "TR", label: "Turquie", patterns: ["turkey", "türkiye", "turquie"] },
  { key: "SA", label: "Arabie saoudite", patterns: ["saudi", "arabie saoudite"] },
  { key: "EG", label: "Égypte", patterns: ["egypt", "égypte", "egypte"] },
  { key: "SN", label: "Sénégal", patterns: ["senegal", "sénégal"] },
];

/** Raccourci proposé dans le bandeau de première ouverture. */
export const ONBOARDING_REGION_KEYS = [
  "FR", "BE", "CH", "GB", "DE", "MA", "DZ", "TN", "US", "CA",
];

/** Retrouve une région par sa clé (null si inconnue ou "all"). */
export function regionByKey(key: string | null | undefined): Region | null {
  if (!key || key === "all") return null;
  return REGIONS.find((region) => region.key === key) ?? null;
}

/** Une mosquée (localisation + slug Mawaqit) appartient-elle à la région ? */
export function mosqueInRegion(
  localisation: string,
  slug: string,
  region: Region,
): boolean {
  const haystack = `${localisation} ${slug}`.toLowerCase();
  return region.patterns.some((pattern) => haystack.includes(pattern));
}
