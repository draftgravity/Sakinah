/**
 * Store central de la démo interactive (zustand + persistance locale).
 *
 * Il fait vivre : le carré noir (position/visibilité), la pop-up et ses
 * onglets, la session Focus (décompte, ambiance), le compteur du jour et
 * les horaires de prières de la mosquée choisie — exactement comme le
 * contrôleur de l'application Python (app/controller.py).
 */

"use client";

import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import type { PrayersPayload } from "@/lib/prayer-utils";
import { SAMPLE_MOSQUE } from "@/lib/sample-data";

export type FocusSound = "none" | "white" | "rain";
export type PopupTab = "prayers" | "focus";

export interface MosqueSelection {
  slug: string;
  name: string;
}

interface FocusStats {
  date: string;      // "YYYY-MM-DD"
  count: number;
}

interface DemoState {
  // --- widget carré noir ---
  widgetVisible: boolean;
  widgetPos: { x: number; y: number } | null;
  /** true = le carré se masque quand la page passe en plein écran
   *  (équivalent web de « Masquer en plein écran » de l'app Windows). */
  fullscreenHide: boolean;
  // --- pop-up ---
  popupOpen: boolean;
  popupTab: PopupTab;
  settingsOpen: boolean;
  // --- session focus ---
  focusActive: boolean;
  focusDurationSec: number;
  focusRemainingSec: number;
  focusSound: FocusSound;
  focusVolume: number;
  focusCompleted: boolean;   // écran de succès affiché
  focusPaused: boolean;      // session en pause (reprise au même endroit)
  focusSessions: FocusStats;
  // --- prières ---
  mosque: MosqueSelection;
  /** région du visiteur (clé REGIONS : "FR", "BE"… ; "all" = toutes ;
   *  null = pas encore demandé → bandeau de première ouverture). */
  region: string | null;
  prayers: PrayersPayload | null;
  /** horaires Mawaqit du jour — "cache" = repli hors ligne local */
  prayersStatus: "idle" | "loading" | "live" | "sample" | "cache";
  /** incrémenté par le bouton « Actualiser » pour re-déclencher le fetch */
  refreshNonce: number;
  // --- comparaison de mosquées (persistée : survit au changement d'onglet) ---
  compareMosque: MosqueSelection | null;
}

interface DemoActions {
  toggleWidget: (visible?: boolean) => void;
  setWidgetPos: (pos: { x: number; y: number }) => void;
  /** « Masquer le carré en plein écran » — préférence widget. */
  setFullscreenHide: (hide: boolean) => void;
  openPopup: (tab?: PopupTab) => void;
  closePopup: () => void;
  setPopupTab: (tab: PopupTab) => void;
  setSettingsOpen: (open: boolean) => void;
  startFocus: (durationSec: number, sound: FocusSound, volume: number) => void;
  tickFocus: () => void;
  /** Session menée à son terme : compte la session + écran de réussite. */
  completeFocus: () => void;
  endFocus: (completed: boolean) => void;
  /** Met en pause / reprend la session en cours. */
  togglePauseFocus: () => void;
  setFocusSound: (sound: FocusSound) => void;
  setFocusVolume: (volume: number) => void;
  setMosque: (mosque: MosqueSelection) => void;
  /** Fixe la région de recherche (clé REGIONS ou "all"). */
  setRegion: (key: string) => void;
  setPrayers: (payload: PrayersPayload | null, status: DemoState["prayersStatus"]) => void;
  refreshPrayers: () => void;
  /** Rechargement SILENCIEUX (minuit auto) : sans écran de chargement —
   *  les horaires courants restent affichés jusqu'à l'arrivée des nouveaux. */
  silentRefreshPrayers: () => void;
  /** Mémorise (ou efface) la mosquée comparée — persistée entre les onglets. */
  setCompareMosque: (mosque: MosqueSelection | null) => void;
}

/** Clé du jour à la DATE LOCALE du visiteur (le compteur « aujourd'hui »
 *  suit le jour civil du visiteur, pas le jour UTC). */
const todayKey = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(
    d.getDate(),
  ).padStart(2, "0")}`;
};

/** Historique des sessions réussies par jour (7 derniers jours). */
const HISTORY_KEY = "sakinah-focus-history";
const HISTORY_DAYS = 7;

type FocusHistory = Record<string, number>;

function readHistory(): FocusHistory {
  try {
    const raw = window.localStorage.getItem(HISTORY_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw) as FocusHistory;
    if (typeof parsed !== "object" || parsed === null) return {};
    // Ne garde que les 7 derniers jours (clés ISO triées).
    const cutoff = Date.now() - HISTORY_DAYS * 86_400_000;
    const kept: FocusHistory = {};
    for (const [key, value] of Object.entries(parsed)) {
      const time = Date.parse(`${key}T00:00:00`);
      if (!Number.isNaN(time) && time >= cutoff && Number.isInteger(value)) {
        kept[key] = Math.max(0, value);
      }
    }
    return kept;
  } catch {
    return {};
  }
}

function persistHistory(history: FocusHistory) {
  try {
    window.localStorage.setItem(HISTORY_KEY, JSON.stringify(history));
  } catch {
    /* ignore */
  }
}

export interface FocusHistoryDay {
  /** "YYYY-MM-DD" */
  date: string;
  /** libellé court du jour (« lun. », « mar. »…) */
  label: string;
  count: number;
  isToday: boolean;
}

/** Historique des 7 derniers jours (ancien → récent), pour le graphique. */
export function getFocusHistory(): FocusHistoryDay[] {
  const history = readHistory();
  const days: FocusHistoryDay[] = [];
  const formatter = new Intl.DateTimeFormat("fr-FR", { weekday: "short" });
  const localKey = (date: Date) =>
    `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(
      date.getDate(),
    ).padStart(2, "0")}`;
  for (let offset = HISTORY_DAYS - 1; offset >= 0; offset -= 1) {
    const date = new Date();
    date.setDate(date.getDate() - offset);
    const key = localKey(date);
    days.push({
      date: key,
      label: formatter.format(date).replace(".", ""),
      count: history[key] ?? 0,
      isToday: offset === 0,
    });
  }
  return days;
}

const defaultFocusStats = (): FocusStats => {
  if (typeof window === "undefined") return { date: todayKey(), count: 0 };
  try {
    const raw = window.localStorage.getItem("sakinah-focus-stats");
    if (raw) {
      const parsed = JSON.parse(raw) as FocusStats;
      if (parsed.date === todayKey()) return parsed;
    }
  } catch {
    /* ignore */
  }
  return { date: todayKey(), count: 0 };
};

const persistFocusStats = (stats: FocusStats) => {
  try {
    window.localStorage.setItem("sakinah-focus-stats", JSON.stringify(stats));
  } catch {
    /* ignore */
  }
};

export const useDemoStore = create<DemoState & DemoActions>()(
  persist(
    (set, get) => ({
      // ---------------------------------------------------------------- état
      widgetVisible: true,
      widgetPos: null,
      fullscreenHide: false,
      popupOpen: false,
      popupTab: "prayers",
      settingsOpen: false,
      focusActive: false,
      focusDurationSec: 25 * 60,
      focusRemainingSec: 25 * 60,
      focusSound: "none",
      focusVolume: 0.6,
      focusCompleted: false,
      focusPaused: false,
      focusSessions: { date: todayKey(), count: 0 },
      mosque: { slug: SAMPLE_MOSQUE.slug, name: SAMPLE_MOSQUE.name },
      region: null,
      prayers: null,
      prayersStatus: "idle",
      refreshNonce: 0,
      compareMosque: null,

      // ------------------------------------------------------------- actions
      toggleWidget: (visible) =>
        set((state) => ({
          widgetVisible: visible ?? !state.widgetVisible,
          popupOpen: false,
        })),

      setWidgetPos: (pos) => set({ widgetPos: pos }),

      setFullscreenHide: (hide) => set({ fullscreenHide: hide }),

      openPopup: (tab) =>
        set((state) => ({ popupOpen: true, popupTab: tab ?? state.popupTab })),

      closePopup: () => set({ popupOpen: false }),

      setPopupTab: (tab) => set({ popupTab: tab }),

      setSettingsOpen: (open) => set({ settingsOpen: open }),

      startFocus: (durationSec, sound, volume) => {
        if (get().focusActive) return;
        set({
          focusActive: true,
          focusCompleted: false,
          focusPaused: false,
          focusDurationSec: durationSec,
          focusRemainingSec: durationSec,
          focusSound: sound,
          focusVolume: volume,
          popupOpen: false,
        });
      },

      tickFocus: () =>
        set((state) => {
          if (!state.focusActive || state.focusCompleted || state.focusPaused)
            return state;
          const remaining = state.focusRemainingSec - 1;
          return { ...state, focusRemainingSec: remaining };
        }),

      togglePauseFocus: () =>
        set((state) => {
          if (!state.focusActive || state.focusCompleted) return state;
          return { ...state, focusPaused: !state.focusPaused };
        }),

      /**
       * Session réussie : incrémente immédiatement le compteur du jour ET
       * l'historique 7 jours, puis affiche l'écran de réussite (focusActive
       * reste true pour maintenir le voile jusqu'au retour automatique).
       */
      completeFocus: () =>
        set((state) => {
          if (!state.focusActive || state.focusCompleted) return state;
          const key = todayKey();
          const base =
            state.focusSessions.date === key ? state.focusSessions.count : 0;
          const sessions = { date: key, count: base + 1 };
          persistFocusStats(sessions);
          if (typeof window !== "undefined") {
            const history = readHistory();
            history[key] = (history[key] ?? 0) + 1;
            persistHistory(history);
          }
          return {
            ...state,
            focusCompleted: true,
            focusRemainingSec: 0,
            focusSessions: sessions,
          };
        }),

      endFocus: (completed) =>
        set((state) => {
          // La session a déjà été comptée par completeFocus() (écran de
          // réussite) — on ne compte qu'une annulation explicite.
          const alreadyCounted = state.focusCompleted;
          let sessions = state.focusSessions;
          if (completed && !alreadyCounted) {
            const key = todayKey();
            const base =
              sessions.date === key ? sessions.count : 0; // reset au changement de jour
            sessions = { date: key, count: base + 1 };
            persistFocusStats(sessions);
            // Historique 7 jours (pour le graphique de l'onglet Focus).
            if (typeof window !== "undefined") {
              const history = readHistory();
              history[key] = (history[key] ?? 0) + 1;
              persistHistory(history);
            }
          }
          return {
            focusActive: false,
            focusCompleted: false,
            focusPaused: false,
            focusRemainingSec: state.focusDurationSec,
            focusSessions: sessions,
          };
        }),

      setFocusSound: (sound) => set({ focusSound: sound }),
      setFocusVolume: (volume) => set({ focusVolume: volume }),

      setMosque: (mosque) => set({ mosque, prayers: null, prayersStatus: "loading" }),

      setRegion: (key) => set({ region: key }),

      setPrayers: (payload, status) => set({ prayers: payload, prayersStatus: status }),

      refreshPrayers: () =>
        set((state) => ({ refreshNonce: state.refreshNonce + 1, prayers: null, prayersStatus: "loading" })),

      /** Minuit (ou retour d'onglet après minuit) : recharge sans faire
       *  clignoter la pop-up — l'écran « loading » serait brutal à 00h00. */
      silentRefreshPrayers: () =>
        set((state) => ({ refreshNonce: state.refreshNonce + 1 })),

      setCompareMosque: (mosque) => set({ compareMosque: mosque }),
    }),
    {
      name: "sakinah-demo",
      storage: createJSONStorage(() => localStorage),
      // On ne persiste que les préférences (pas l'état volatile de session).
      partialize: (state) => ({
        mosque: state.mosque,
        region: state.region,
        fullscreenHide: state.fullscreenHide,
        focusSound: state.focusSound,
        focusVolume: state.focusVolume,
        widgetPos: state.widgetPos,
        compareMosque: state.compareMosque,
      }),
    },
  ),
);

/** Réinitialise proprement le compteur du jour au chargement. */
export function hydrateFocusSessions() {
  const { focusSessions } = useDemoStore.getState();
  const key = todayKey();
  if (focusSessions.date !== key) {
    useDemoStore.setState({ focusSessions: { date: key, count: 0 } });
  } else {
    // resynchronise depuis localStorage (persisté hors zustand-persist)
    try {
      const raw = window.localStorage.getItem("sakinah-focus-stats");
      if (raw) {
        const parsed = JSON.parse(raw) as FocusStats;
        if (parsed.date === key && parsed.count !== focusSessions.count) {
          useDemoStore.setState({ focusSessions: parsed });
        }
      }
    } catch {
      /* ignore */
    }
  }
}
