/**
 * Cache local des horaires (repli hors ligne) — avec « cache de demain ».
 *
 * Quand /api/prayers est injoignable, la démo retombe sur les DERNIERS
 * horaires connus de LA mosquée du visiteur (localStorage, 48 h max) avant
 * d'utiliser le jeu d'exemple de Paris — un visiteur qui revient garde ainsi
 * « sa » mosquée même sans réseau.
 *
 * SURVIE À MINUIT HORS LIGNE : chaque écriture mémorise AUSSI la ligne J+1
 * (adhans + iqamas) servie par l'API. Si le cache « du jour » est périmé
 * parce que la date de la mosquée a changé entre-temps, et que nous sommes
 * précisément le lendemain du fetch, les horaires de J+1 sont promus en
 * horaires « du jour » — le visiteur garde des horaires EXACTS au lieu de
 * retomber sur le jeu d'exemple.
 */

import type { PrayersPayload, TimesMap } from "@/lib/prayer-utils";

const PRAYERS_CACHE_PREFIX = "sakinah-prayers-cache:";
const MAX_AGE_MS = 2 * 86_400_000; // 48 heures

interface PrayersCacheEntry {
  at: number;
  data: PrayersPayload;
  /** ligne J+1 capturée au moment du fetch (null si l'API n'en avait pas) */
  tomorrow?: {
    times: TimesMap;
    iqama?: Record<string, string | null>;
  } | null;
}

/** Date « YYYY-MM-DD » dans le fuseau de la mosquée (UTC en repli). */
function mosqueDay(timezone: string | null | undefined, at: Date): string {
  try {
    return new Intl.DateTimeFormat("en-CA", {
      timeZone: timezone ?? "UTC",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
    }).format(at);
  } catch {
    return "invalid";
  }
}

export function readCachedPrayers(slug: string): PrayersPayload | null {
  try {
    const raw = window.localStorage.getItem(PRAYERS_CACHE_PREFIX + slug);
    if (!raw) return null;
    const entry = JSON.parse(raw) as PrayersCacheEntry;
    if (
      !entry ||
      typeof entry.at !== "number" ||
      Date.now() - entry.at > MAX_AGE_MS ||
      !entry.data ||
      !entry.data.times
    ) {
      return null;
    }

    // Les horaires ne valent que pour LEUR journée : un cache d'hier
    // présenterait de faux horaires « du jour ». Comparaison à l'horloge
    // de la mosquée (UTC en repli si le fuseau est absent).
    const now = new Date();
    const tz = entry.data.timezone ?? null;
    if (mosqueDay(tz, now) === mosqueDay(tz, new Date(entry.data.fetchedAt ?? 0))) {
      return entry.data;
    }

    // ---- « Cache de demain » : nous sommes le lendemain du fetch et la
    // ligne J+1 a été mémorisée → horaires EXACTS du nouveau jour.
    const nextDay = new Date(
      new Date(entry.data.fetchedAt ?? entry.at).getTime() + 86_400_000,
    );
    if (
      entry.tomorrow &&
      mosqueDay(tz, now) === mosqueDay(tz, nextDay) &&
      Object.values(entry.tomorrow.times).some((value) => value !== null)
    ) {
      return {
        ...entry.data,
        times: entry.tomorrow.times,
        iqama: entry.tomorrow.iqama ?? {},
        // Le Fajr de « demain » (J+2) est inconnu hors ligne : le Fajr du
        // jour promu sert d'approximation honnête (dérive ~1 min/jour).
        tomorrowFajr: entry.tomorrow.times.fajr ?? entry.data.tomorrowFajr ?? null,
        dayAfterCache: true,
      };
    }

    return null;
  } catch {
    return null;
  }
}

export function writeCachedPrayers(data: PrayersPayload): void {
  try {
    const entry: PrayersCacheEntry = {
      at: Date.now(),
      data,
      tomorrow: data.tomorrow ?? null,
    };
    window.localStorage.setItem(
      PRAYERS_CACHE_PREFIX + data.slug,
      JSON.stringify(entry),
    );
  } catch {
    /* quota localStorage — cache best effort */
  }
}
