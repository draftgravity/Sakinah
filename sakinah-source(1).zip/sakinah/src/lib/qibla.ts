/**
 * Calculs de Qibla — cap et distance vers la Kaaba depuis un point donné.
 *
 * Utilisé par la boussole de la démo (coordonnées de la mosquée choisie,
 * renvoyées par /api/prayers). Formule du cap initial sur un grand cercle :
 *
 *   θ = atan2( sin Δλ · cos φ₂ ,
 *              cos φ₁ · sin φ₂ − sin φ₁ · cos φ₂ · cos Δλ )
 */

/** Coordonnées de la Kaaba (Masjid al-Haram, La Mecque). */
export const KAABA = { latitude: 21.4225, longitude: 39.8262 };

const toRad = (deg: number) => (deg * Math.PI) / 180;
const toDeg = (rad: number) => (rad * 180) / Math.PI;

/** Cap (bearing) en degrés 0-360 depuis un point vers la Kaaba. */
export function qiblaBearing(latitude: number, longitude: number): number {
  const phi1 = toRad(latitude);
  const phi2 = toRad(KAABA.latitude);
  const deltaLambda = toRad(KAABA.longitude - longitude);

  const y = Math.sin(deltaLambda) * Math.cos(phi2);
  const x =
    Math.cos(phi1) * Math.sin(phi2) -
    Math.sin(phi1) * Math.cos(phi2) * Math.cos(deltaLambda);

  const bearing = toDeg(Math.atan2(y, x));
  return (bearing + 360) % 360;
}

/** Distance orthodromique (haversine) en kilomètres vers la Kaaba. */
export function kaabaDistanceKm(latitude: number, longitude: number): number {
  return haversineKm(latitude, longitude, KAABA.latitude, KAABA.longitude);
}

/** Distance orthodromique (haversine) générique en kilomètres entre deux points. */
export function haversineKm(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number,
): number {
  const R = 6371; // rayon terrestre moyen (km)
  const dPhi = toRad(lat2 - lat1);
  const dLambda = toRad(lon2 - lon1);
  const a =
    Math.sin(dPhi / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLambda / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}

/** Points cardinaux français (16 directions). */
const CARDINALS = [
  "N", "NNE", "NE", "ENE",
  "E", "ESE", "SE", "SSE",
  "S", "SSO", "SO", "OSO",
  "O", "ONO", "NO", "NNO",
] as const;

/** Libellé cardinal français d'un cap en degrés (« ESE », « SO »…). */
export function cardinalLabel(bearing: number): string {
  const index = Math.round((((bearing % 360) + 360) % 360) / 22.5) % 16;
  return CARDINALS[index];
}

/** Formate une distance : « 4 531 km » (séparateur d'espace fine française). */
export function formatDistance(km: number): string {
  return new Intl.NumberFormat("fr-FR", {
    style: "unit",
    unit: "kilometer",
    unitDisplay: "narrow",
    maximumFractionDigits: 0,
  }).format(km);
}
