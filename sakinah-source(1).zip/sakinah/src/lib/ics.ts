/**
 * Export iCalendar (.ics) du calendrier mensuel des prières.
 *
 * Génère un fichier RFC 5545 valide importable dans Google Agenda, Outlook
 * ou Apple Calendrier :
 *  * un VEVENT par prière et par jour du mois (adhans), durée 15 min ;
 *  * événement « Jumu'a » les vendredis si l'heure est connue ;
 *  * horaires convertis en INSTANTS UTC via l'horloge du fuseau de la
 *    mosquée (double passe Intl, changements d'heure exacts) — le fichier
 *    est donc correct pour un import depuis n'importe quel fuseau ;
 *  * échappement du texte + repli de ligne à 75 octets (RFC 5545 §3.1).
 */

import { zoneClock } from "@/lib/prayer-utils";

const PRAYER_ORDER = [
  { key: "fajr", label: "Fajr", arabic: "الفجر" },
  { key: "shourouk", label: "Chourouk", arabic: "الشروق" },
  { key: "dhuhr", label: "Dhuhr", arabic: "الظهر" },
  { key: "asr", label: "Asr", arabic: "العصر" },
  { key: "maghrib", label: "Maghrib", arabic: "المغرب" },
  { key: "isha", label: "Isha", arabic: "العشاء" },
];

/** Index d'iqama (iqamaCalendar = [Fajr, Dhuhr, Asr, Maghrib, Isha]). */
const IQAMA_INDEX: Record<string, number | null> = {
  fajr: 0,
  shourouk: null,
  dhuhr: 1,
  asr: 2,
  maghrib: 3,
  isha: 4,
};

export interface IcsMonthInput {
  mosqueName: string;
  slug: string;
  timezone: string | null;
  year: number;
  /** mois 0-11 */
  month: number;
  /** calendar[month]["jour"] = [Fajr, Chourouk, Dhuhr, Asr, Maghrib, Isha] */
  monthData: Record<string, string[]> | null;
  /** iqamaCalendar[month]["jour"] = [Fajr, Dhuhr, Asr, Maghrib, Isha] */
  iqamaData?: Record<string, (string | null)[]> | null;
  /** heure de la Jumu'a ("HH:MM") si connue — événement du vendredi */
  jumua?: string | null;
}

/* ----------------------------- utilitaires ----------------------------- */

/** « 6:5 » → { h: 6, m: 5 } (null si invalide). */
function parseTime(value: string | null | undefined): {
  h: number;
  m: number;
} | null {
  if (!value) return null;
  const match = /^(\d{1,2}):(\d{2})$/.exec(value.trim());
  if (!match) return null;
  const h = Number(match[1]);
  const m = Number(match[2]);
  if (h > 23 || m > 59) return null;
  return { h, m };
}

/**
 * Heure murale (fuseau de la mosquée) → instant UTC exact (double passe :
 * l'écart réel fuseau/UTC est mesuré à l'instant deviné → DST correct).
 */
function wallTimeToUtc(
  year: number,
  month: number, // 1-12
  day: number,
  h: number,
  m: number,
  tz: string | null,
): Date {
  const sec = h * 3600 + m * 60;
  const guess = Date.UTC(year, month - 1, day, 0, 0, 0) + sec * 1000;
  const probe = tz ? zoneClock(tz, new Date(guess)) : null;
  if (!probe) return new Date(guess);
  const asUtc =
    Date.UTC(probe.year, probe.month - 1, probe.day, 0, 0, 0) +
    probe.sec * 1000;
  return new Date(guess - (asUtc - guess));
}

const pad = (n: number, width = 2) => String(n).padStart(width, "0");

/** Date → « YYYYMMDDTHHMMSSZ » (format UTC de la RFC 5545). */
function icsUtcStamp(date: Date): string {
  return (
    `${date.getUTCFullYear()}${pad(date.getUTCMonth() + 1)}${pad(
      date.getUTCDate(),
    )}` +
    `T${pad(date.getUTCHours())}${pad(date.getUTCMinutes())}${pad(
      date.getUTCSeconds(),
    )}Z`
  );
}

/** Échappe un texte selon RFC 5545 §3.3.11. */
function escapeText(value: string): string {
  return value
    .replace(/\\/g, "\\\\")
    .replace(/;/g, "\\;")
    .replace(/,/g, "\\,")
    .replace(/\r?\n/g, "\\n");
}

/** Longueur en OCTETS UTF-8 (la RFC 5545 limite les lignes à 75 octets). */
function byteLength(value: string): number {
  return new TextEncoder().encode(value).length;
}

/** Repli de ligne à 75 octets max (continuation « CRLF + espace »). */
function foldLine(line: string): string {
  if (byteLength(line) <= 74) return line;
  const parts: string[] = [];
  let rest = line;
  let budget = 74; // 1er segment
  while (byteLength(rest) > budget) {
    // Coupe au plus grand préfixe qui tient dans le budget d'octets SANS
    // couper au milieu d'un caractère multi-octets.
    let cut = rest.length;
    while (cut > 0 && byteLength(rest.slice(0, cut)) > budget) cut -= 1;
    parts.push(rest.slice(0, cut));
    rest = rest.slice(cut);
    budget = 73; // segments suivants : 73 + l'espace de continuation = 74
  }
  parts.push(rest);
  return parts.join("\r\n ");
}

/* ------------------------------ génération ------------------------------ */

const MONTH_NAMES = [
  "janvier", "février", "mars", "avril", "mai", "juin",
  "juillet", "août", "septembre", "octobre", "novembre", "décembre",
];

/** Construit le contenu .ics complet du mois. */
export function buildMonthIcs(input: IcsMonthInput): string {
  const now = icsUtcStamp(new Date());
  const monthLabel = `${MONTH_NAMES[input.month]} ${input.year}`;
  const lines: string[] = [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//Sakinah//Horaires de priere Mawaqit//FR",
    "CALSCALE:GREGORIAN",
    "METHOD:PUBLISH",
    `X-WR-CALNAME:${escapeText(`Sakinah — ${input.mosqueName} · ${monthLabel}`)}`,
    `X-WR-CALDESC:${escapeText(
      `Adhans du mois de ${monthLabel} — ${input.mosqueName}. Horaires mawaqit.net exportés par la démo Sakinah.`,
    )}`,
    `X-WR-TIMEZONE:${input.timezone ?? "UTC"}`,
  ];

  const days = Object.keys(input.monthData ?? {})
    .map(Number)
    .filter((n) => Number.isInteger(n) && n >= 1 && n <= 31)
    .sort((a, b) => a - b);

  const dayDate = (day: number) =>
    new Date(Date.UTC(input.year, input.month, day));

  const addEvent = (options: {
    day: number;
    prayerKey: string;
    title: string;
    time: { h: number; m: number } | null;
    durationMin: number;
    description: string;
  }) => {
    if (!options.time) return;
    const start = wallTimeToUtc(
      input.year,
      input.month + 1,
      options.day,
      options.time.h,
      options.time.m,
      input.timezone,
    );
    const end = new Date(start.getTime() + options.durationMin * 60_000);
    const dateKey = `${input.year}${pad(input.month + 1)}${pad(options.day)}`;
    lines.push(
      "BEGIN:VEVENT",
      `UID:${input.slug}-${dateKey}-${options.prayerKey}@sakinah.app`,
      `DTSTAMP:${now}`,
      `DTSTART:${icsUtcStamp(start)}`,
      `DTEND:${icsUtcStamp(end)}`,
      `SUMMARY:${escapeText(options.title)}`,
      `DESCRIPTION:${escapeText(options.description)}`,
      "CATEGORIES:PRIERE",
      "END:VEVENT",
    );
  };

  for (const day of days) {
    const values = input.monthData?.[String(day)] ?? [];
    const iqamas = input.iqamaData?.[String(day)] ?? null;
    const weekday = dayDate(day).getUTCDay();

    for (let index = 0; index < PRAYER_ORDER.length; index += 1) {
      const prayer = PRAYER_ORDER[index];
      const time = parseTime(values[index]);
      if (!time) continue;
      const iqamaIdx = IQAMA_INDEX[prayer.key];
      const iqama =
        iqamaIdx !== null && iqamas ? (iqamas[iqamaIdx] ?? null) : null;

      const isFridayDhuhr = weekday === 5 && prayer.key === "dhuhr";
      // Le vendredi, la Jumu'a remplace la prière du Dhuhr : on exporte
      // l'événement « Jumu'a » plutôt que le Dhuhr si l'heure est connue.
      if (isFridayDhuhr && input.jumua) {
        addEvent({
          day,
          prayerKey: "jumua",
          title: `Jumu'a — ${input.mosqueName}`,
          time: parseTime(input.jumua),
          durationMin: 45,
          description:
            "Prière du vendredi (Jumu'a) à la mosquée. Source : mawaqit.net — export Sakinah.",
        });
        continue;
      }

      addEvent({
        day,
        prayerKey: prayer.key,
        title: `${prayer.label} — ${input.mosqueName}`,
        time,
        durationMin: prayer.key === "shourouk" ? 10 : 15,
        description:
          prayer.key === "shourouk"
            ? `Lever du soleil (${prayer.arabic}). Source : mawaqit.net — export Sakinah.`
            : `Adhan du ${prayer.label} (${prayer.arabic}) à ${pad(time.h)}:${pad(time.m)}${
                iqama ? ` · iqama (prière en commun) à ${iqama}` : ""
              }. Source : mawaqit.net — export Sakinah.`,
      });
    }
  }

  lines.push("END:VCALENDAR");
  return lines.map(foldLine).join("\r\n") + "\r\n";
}

/** Déclenche le téléchargement du fichier .ics généré. */
export function downloadMonthIcs(input: IcsMonthInput): boolean {
  if (!input.monthData) return false;
  try {
    const content = buildMonthIcs(input);
    const blob = new Blob([content], {
      type: "text/calendar;charset=utf-8",
    });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `sakinah-${input.slug}-${MONTH_NAMES[input.month]}-${input.year}.ics`;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
    return true;
  } catch {
    return false;
  }
}
