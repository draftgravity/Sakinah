/**
 * Données d'exemple pour la démo quand l'API Mawaqit est injoignable,
 * + la liste des dhikrs (identique à data/dhikrs.json de l'app Python).
 */

import type { PrayersPayload } from "@/lib/prayer-utils";

export const SAMPLE_MOSQUE: PrayersPayload = {
  slug: "grande-mosquee-de-paris",
  name: "Grande Mosquée de Paris",
  localisation: "Place du Puits de l'Ermite, 75005 Paris",
  jumua: "13:30",
  times: {
    fajr: "06:05",
    shourouk: "07:33",
    dhuhr: "13:45",
    asr: "17:03",
    maghrib: "19:57",
    isha: "21:18",
  },
  tomorrowFajr: "06:07",
  latitude: 48.8424,
  longitude: 2.3548,
  timezone: "Europe/Paris",
  sample: true,
  fetchedAt: new Date().toISOString(),
};

export interface Dhikr {
  arabic: string;
  transliteration: string;
  french: string;
  note: string;
  source: string;
}

export const DHIKRS: Dhikr[] = [
  {
    arabic: "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ",
    transliteration: "Subhânallâhi wa bi-hamdih",
    french: "Gloire et pureté à Allah, et c'est par Sa louange.",
    note: "Celui qui la dit 100 fois par jour verra ses fautes pardonnées, fussent-elles aussi nombreuses que l'écume de la mer.",
    source: "Bukhari & Muslim",
  },
  {
    arabic: "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ، سُبْحَانَ اللَّهِ الْعَظِيمِ",
    transliteration: "Subhânallâhi wa bi-hamdih, subhânallâhil-`Azîm",
    french: "Gloire et pureté à Allah et par Sa louange, gloire à Allah le Très-Grand.",
    note: "Deux paroles légères sur la langue, lourdes dans la balance et aimées du Tout-Miséricordieux.",
    source: "Bukhari",
  },
  {
    arabic: "لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ",
    transliteration: "Lâ hawla wa lâ quwwata illâ billâh",
    french: "Il n'y a de puissance ni de force que par Allah.",
    note: "Fait partie des trésors du Paradis.",
    source: "Bukhari & Muslim",
  },
  {
    arabic: "أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ",
    transliteration: "Astaghfirullâha wa atûbu ilayh",
    french: "Je demande pardon à Allah et je reviens vers Lui.",
    note: "Le Prophète ﷺ demandait pardon plus de 70 fois par jour.",
    source: "Bukhari",
  },
  {
    arabic: "الْحَمْدُ لِلَّهِ عَلَى كُلِّ حَالٍ",
    transliteration: "Al-hamdu lillâhi `alâ kulli hâl",
    french: "Louange à Allah en toute circonstance.",
    note: "Le croyant loue Allah dans l'aisance comme dans l'épreuve.",
    source: "Ibn Mâjah",
  },
  {
    arabic: "لَا إِلَٰهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ",
    transliteration: "Lâ ilâha illallâhu wahdahu lâ sharîka lah",
    french: "Nulle divinité excepté Allah, Lui seul, sans associé.",
    note: "La meilleure mention (dhikr) est « Lâ ilâha illallâh ».",
    source: "Tirmidhî",
  },
  {
    arabic: "اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ",
    transliteration: "Allâhumma salli wa sallim `alâ nabiyyinâ Muhammad",
    french: "Ô Allah, accorde Tes grâces et Ta paix à notre Prophète Muhammad.",
    note: "Une seule prière sur le Prophète ﷺ vaut dix miséricordes en retour.",
    source: "Muslim",
  },
  {
    arabic: "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ",
    transliteration: "Rabbanâ âtinâ fid-dunyâ hasanah, wa fil-âkhirati hasanah, wa qinâ `adhâban-nâr",
    french: "Seigneur ! Accorde-nous une belle part ici-bas, une belle part dans l'au-delà, et protège-nous du châtiment du Feu.",
    note: "Invocation complète et équilibrée enseignée par le Coran.",
    source: "Coran — Al-Baqarah 2:201",
  },
  {
    arabic: "حَسْبِيَ اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ عَلَيْهِ تَوَكَّلْتُ",
    transliteration: "Hasbiyallâhu lâ ilâha illâ Huwa, `alayhi tawakkaltu",
    french: "Allah me suffit : nulle divinité excepté Lui. C'est en Lui que je place ma confiance.",
    note: "Dite sept fois matin et soir, Allah suffit à celui qui la prononce.",
    source: "Coran — At-Tawbah 9:129",
  },
  {
    arabic: "اللَّهُمَّ إِنِّي أَسْأَلُكَ الْعَفْوَ وَالْعَافِيَةَ",
    transliteration: "Allâhumma innî as'alukal-`afwa wal-`âfiyah",
    french: "Ô Allah, je Te demande le pardon et le bien-être.",
    note: "Le Prophète ﷺ demandait le pardon et la santé avec insistance.",
    source: "Abû Dâwûd",
  },
  {
    arabic: "اللَّهُمَّ أَعِنِّي عَلَى ذِكْرِكَ وَشُكْرِكَ وَحُسْنِ عِبَادَتِكَ",
    transliteration: "Allâhumma a`innî `alâ dhikrika wa shukrika wa husni `ibâdatik",
    french: "Ô Allah, aide-moi à T'évoquer, à Te remercier et à T'adorer de la meilleure façon.",
    note: "Conseillée par le Prophète ﷺ à Mu`âdh chaque jour après la prière.",
    source: "Abû Dâwûd",
  },
  {
    arabic: "سُبْحَانَ اللَّهِ، وَالْحَمْدُ لِلَّهِ، وَلَا إِلَٰهَ إِلَّا اللَّهُ، وَاللَّهُ أَكْبَرُ",
    transliteration: "Subhânallâh, wal-hamdu lillâh, wa lâ ilâha illallâh, wallâhu akbar",
    french: "Gloire à Allah, louange à Allah, nulle divinité excepté Allah, Allah est le Plus Grand.",
    note: "Les paroles les plus aimées d'Allah ; elles plantent un arbre au Paradis.",
    source: "Muslim & Tirmidhî",
  },
];
