import type { NextConfig } from "next";

/**
 * Configuration Next.js Sakinah.
 *
 * ⚠️ `outputFileTracingIncludes` est INDISPENSABLE au bon fonctionnement du
 * site sur Vercel : plusieurs routes lisent des fichiers du dépôt au moment
 * de la requête (ZIP du widget, explorateur de code, paquet source gérant).
 * Sur un hébergement classique ces fichiers existent ; dans une fonction
 * serverless Vercel, seuls les fichiers « tracés » sont embarqués — sans
 * cette liste, /api/download renverrait une erreur 500 en production.
 */
const WIDGET_FILES = "./sakina-widget/**/*";

const nextConfig: NextConfig = {
  output: "standalone",
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  outputFileTracingIncludes: {
    // ZIP du widget Windows (bouton « Télécharger (.zip) »)
    "/api/download": [WIDGET_FILES],
    // Explorateur de code de la vitrine (manifeste)
    "/api/files": [WIDGET_FILES],
    // Explorateur de code (contenu d'un fichier)
    "/api/files/content": [WIDGET_FILES],
    // Paquet source « prêt pour GitHub » (gérant uniquement)
    "/api/manager/source": [
      "./src/**/*",
      "./public/**/*",
      "./prisma/**/*",
      WIDGET_FILES,
      "./scripts/**/*",
      "./package.json",
      "./bun.lock",
      "./tsconfig.json",
      "./next.config.ts",
      "./tailwind.config.ts",
      "./postcss.config.mjs",
      "./components.json",
      "./eslint.config.mjs",
      "./README.md",
      "./GUIDE-DEPLOIEMENT.md",
      "./.env.example",
      "./.gitignore",
      "./LICENSE",
    ],
  },
};

export default nextConfig;
