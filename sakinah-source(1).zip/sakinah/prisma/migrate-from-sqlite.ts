/**
 * migrate-from-sqlite.ts — migration UNIQUE de l'ancienne base SQLite
 * (db/custom.db,_provider « sqlite » d'origine) vers PostgreSQL.
 *
 * Copie TOUTES les données (comptes, sessions, dhikr, focus, journal
 * d'activité) en conservant les identifiants (cuid) : les sessions de
 * connexion ouvertes restent donc valides après la migration.
 *
 * Usage (le serveur PostgreSQL doit être démarré, DATABASE_URL pointé) :
 *   bun prisma/migrate-from-sqlite.ts [chemin/vers/custom.db]
 */

import { PrismaClient } from "@prisma/client";
import { Database } from "bun:sqlite";

const db = new PrismaClient();
const sqlitePath = process.argv[2] ?? "db/custom.db";

// Date de SQLite : nombre (ms epoch) ou chaîne ISO selon la version.
function toDate(value: unknown): Date {
  if (value instanceof Date) return value;
  if (typeof value === "number") return new Date(value);
  return new Date(String(value));
}

// Champ Json de SQLite : chaîne JSON brute → objet.
function toJson(value: unknown): unknown {
  if (value == null) return null;
  if (typeof value === "string") {
    try {
      return JSON.parse(value);
    } catch {
      return null;
    }
  }
  return value;
}

type Row = Record<string, unknown>;

async function main() {
  const sqlite = new Database(sqlitePath, { readonly: true });

  const users = sqlite.query("SELECT * FROM User").all() as Row[];
  const sessions = sqlite.query("SELECT * FROM AuthSession").all() as Row[];
  const dhikrTotals = sqlite.query("SELECT * FROM DhikrTotals").all() as Row[];
  const dhikrDays = sqlite.query("SELECT * FROM DhikrDaily").all() as Row[];
  const focusSessions = sqlite.query("SELECT * FROM FocusSession").all() as Row[];
  const activities = sqlite.query("SELECT * FROM Activity").all() as Row[];
  sqlite.close();

  console.log(
    `Source ${sqlitePath} : ${users.length} utilisateurs, ${sessions.length} sessions, ` +
      `${dhikrTotals.length} totaux, ${dhikrDays.length} jours, ` +
      `${focusSessions.length} focus, ${activities.length} activités.`,
  );

  // Déjà migré ? (aucun utilisateur en base ET source non vide → on y va)
  const existing = await db.user.count();
  if (existing > 0) {
    console.log(`Cible déjà peuplée (${existing} utilisateurs) — rien à faire.`);
    return;
  }

  await db.user.createMany({
    data: users.map((row) => ({
      id: row.id,
      username: row.username,
      usernameLower: row.usernameLower,
      email: row.email,
      name: row.name ?? null,
      passwordHash: row.passwordHash,
      role: row.role,
      focusEnabled: row.focusEnabled === undefined ? true : Boolean(row.focusEnabled),
      createdAt: toDate(row.createdAt),
      updatedAt: toDate(row.updatedAt),
      lastLoginAt: row.lastLoginAt ? toDate(row.lastLoginAt) : null,
    })),
  });
  console.log(`✓ ${users.length} utilisateurs`);

  if (sessions.length > 0) {
    await db.authSession.createMany({
      data: sessions.map((row) => ({
        id: row.id,
        token: row.token,
        userId: row.userId,
        expiresAt: toDate(row.expiresAt),
        createdAt: toDate(row.createdAt),
      })),
    });
    console.log(`✓ ${sessions.length} sessions de connexion (conservées)`);
  }

  if (dhikrTotals.length > 0) {
    await db.dhikrTotals.createMany({
      data: dhikrTotals.map((row) => ({
        id: row.id,
        userId: row.userId,
        todayDate: row.todayDate,
        todayCount: row.todayCount,
        lifetimeCount: row.lifetimeCount,
        perFormula: toJson(row.perFormula),
        updatedAt: toDate(row.updatedAt),
      })),
    });
    console.log(`✓ ${dhikrTotals.length} totaux de dhikr`);
  }

  if (dhikrDays.length > 0) {
    await db.dhikrDaily.createMany({
      data: dhikrDays.map((row) => ({
        id: row.id,
        userId: row.userId,
        date: row.date,
        count: row.count,
      })),
    });
    console.log(`✓ ${dhikrDays.length} jours de dhikr`);
  }

  if (focusSessions.length > 0) {
    await db.focusSession.createMany({
      data: focusSessions.map((row) => ({
        id: row.id,
        userId: row.userId,
        durationSec: row.durationSec,
        dateKey: row.dateKey,
        completedAt: toDate(row.completedAt),
      })),
    });
    console.log(`✓ ${focusSessions.length} sessions focus`);
  }

  if (activities.length > 0) {
    await db.activity.createMany({
      data: activities.map((row) => ({
        id: row.id,
        userId: row.userId ?? null,
        type: row.type,
        detail: row.detail,
        createdAt: toDate(row.createdAt),
      })),
    });
    console.log(`✓ ${activities.length} entrées de journal`);
  }

  // Vérification : les compteurs source/cible doivent coïncider.
  const [u, s, t, d, f, a] = await Promise.all([
    db.user.count(),
    db.authSession.count(),
    db.dhikrTotals.count(),
    db.dhikrDaily.count(),
    db.focusSession.count(),
    db.activity.count(),
  ]);
  console.log(
    `Vérification : ${u}/${users.length} users, ${s}/${sessions.length} sessions, ` +
      `${t}/${dhikrTotals.length} totaux, ${d}/${dhikrDays.length} jours, ` +
      `${f}/${focusSessions.length} focus, ${a}/${activities.length} activités.`,
  );
  if (
    u !== users.length ||
    t !== dhikrTotals.length ||
    d !== dhikrDays.length ||
    f !== focusSessions.length ||
    a !== activities.length
  ) {
    throw new Error("Compteurs incohérents après migration — vérifier la base.");
  }
  console.log("🎉 Migration SQLite → PostgreSQL terminée sans perte.");
}

main()
  .catch((error) => {
    console.error(error);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
