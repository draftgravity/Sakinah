/**
 * Seed Sakinah — prépare la base « en ligne » (PostgreSQL).
 *
 * Crée UNIQUEMENT le compte GÉRANT initial, dont les identifiants viennent
 * de .env (SEED_MANAGER_USERNAME / _EMAIL / _PASSWORD) — jamais écrits en
 * dur ici : ce fichier est public (open source).
 *
 * ⚠️ Aucun compte de démonstration n'est créé : la base ne contient que
 * des comptes réels. Si SEED_MANAGER_PASSWORD n'est pas défini, un mot de
 * passe aléatoire est généré et affiché UNE SEULE FOIS en console — notez-
 * le immédiatement (il est haché immédiatement, impossible de le relire).
 *
 * En production (Vercel + Neon), ce seed n'est pas nécessaire : le PREMIER
 * compte créé via « Créer un compte » devient automatiquement gérant
 * (cf. src/app/api/auth/register/route.ts).
 *
 * Idempotent : ré-exécuter le script ne duplique rien (upsert sur le nom
 * d'utilisateur ; les données existantes ne sont jamais touchées).
 *
 * Usage : bun run db:seed
 */

import { PrismaClient } from "@prisma/client";
import { randomBytes, scryptSync } from "node:crypto";

const db = new PrismaClient();

const MANAGER_USERNAME = process.env.SEED_MANAGER_USERNAME ?? "";
const MANAGER_EMAIL = process.env.SEED_MANAGER_EMAIL ?? "";
const MANAGER_PASSWORD = process.env.SEED_MANAGER_PASSWORD ?? "";

function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const key = scryptSync(password, salt, 64).toString("hex");
  return `s1$${salt}$${key}`;
}

/** Mot de passe aléatoire lisible (sans caractères ambigus). */
function randomPassword(): string {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789";
  const bytes = randomBytes(16);
  return Array.from(bytes, (b) => alphabet[b % alphabet.length]).join("");
}

async function main() {
  if (!MANAGER_USERNAME || !MANAGER_EMAIL) {
    console.log(
      "Seed ignoré : SEED_MANAGER_USERNAME et SEED_MANAGER_EMAIL ne sont pas définis.\n" +
        "En production, inutile de seeder — le PREMIER compte créé sur le site\n" +
        "devient automatiquement le gérant.",
    );
    return;
  }

  const password = MANAGER_PASSWORD || randomPassword();
  const usernameLower = MANAGER_USERNAME.toLowerCase();
  const existing = await db.user.findUnique({ where: { usernameLower } });

  if (existing) {
    // Le gérant existe déjà : on ne touche à rien (ni rôle, ni mot de passe,
    // ni données) — c'est un compte réel.
    console.log(`• ${existing.username} existe déjà — rien à faire.`);
    if (existing.role !== "MANAGER") {
      await db.user.update({
        where: { id: existing.id },
        data: { role: "MANAGER" },
      });
      console.log("  → rôle MANAGER réaffirmé.");
    }
    return;
  }

  await db.user.create({
    data: {
      username: MANAGER_USERNAME,
      usernameLower,
      email: MANAGER_EMAIL.toLowerCase(),
      name: MANAGER_USERNAME,
      passwordHash: hashPassword(password),
      role: "MANAGER",
      lastLoginAt: null,
    },
  });
  await db.activity.create({
    data: {
      type: "REGISTER",
      detail: `Compte gérant « ${MANAGER_USERNAME} » créé par le seed`,
    },
  });

  console.log(`✓ Gérant « ${MANAGER_USERNAME} » créé.`);
  if (!MANAGER_PASSWORD) {
    console.log(
      "\n  ⚠️  SEED_MANAGER_PASSWORD absent — mot de passe généré :\n" +
        `      ${password}\n` +
        "  Notez-le MAINTENANT (il est haché en base, on ne peut plus le relire).\n",
    );
  }
  console.log("Seed terminé.");
}

main()
  .catch((error) => {
    console.error(error);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
