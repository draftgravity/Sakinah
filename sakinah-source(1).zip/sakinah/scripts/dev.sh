#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# dev.sh — démarre le serveur de développement Next.js (port 3000).
#
# Neutralise une éventuelle DATABASE_URL obsolète « file:… » (SQLite)
# héritée de l'environnement du poste : le .env du projet fournit l'URL
# PostgreSQL. Les URLs PostgreSQL légitimes restent prioritaires.
#
# Usage : bun run dev
# ---------------------------------------------------------------------------
cd "$(dirname "$0")/.."
if [[ "${DATABASE_URL:-}" == file:* ]]; then
  unset DATABASE_URL
fi
exec bunx next dev -p 3000 2>&1 | tee dev.log
