#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# start-postgres.sh — démarre le serveur PostgreSQL local de Sakinah.
#
# Le sandbox n'a pas PostgreSQL installé système : nous utilisons une
# distribution PORTABLE (binaires zonky) dans /home/z/pg16-dist, démarrée
# sans droits root sur le port 5432. Ce script est idempotent :
#   * serveur déjà démarré → ne fait rien ;
#   * données présentes   → simple redémarrage ;
#   * premier lancement   → initdb + création de la base « sakinah ».
#
# Usage : bash scripts/start-postgres.sh   (ou : bun run pg:start)
# ---------------------------------------------------------------------------
set -euo pipefail

PGDIR="${PGDIR:-/home/z/pg16-dist}"
DB_URL_HOST="127.0.0.1"
DB_URL_PORT="5432"
DB_USER="sakinah"
DB_PASSWORD="SakinahLocal2025"
DB_NAME="sakinah"

if [ ! -x "$PGDIR/bin/postgres" ]; then
  echo "❌ PostgreSQL portable introuvable dans $PGDIR (voir GUIDE-DEPLOIEMENT.md)." >&2
  exit 1
fi

# Déjà en écoute ? (pg_ctl status suffit)
if "$PGDIR/bin/pg_ctl" -D "$PGDIR/data" status >/dev/null 2>&1; then
  echo "✓ PostgreSQL déjà démarré (port $DB_URL_PORT)."
  exit 0
fi

# Premier lancement : initialiser le cluster.
if [ ! -f "$PGDIR/data/PG_VERSION" ]; then
  echo "• Initialisation du cluster PostgreSQL…"
  echo "$DB_PASSWORD" > /tmp/sakinah-pgpw
  "$PGDIR/bin/initdb" -D "$PGDIR/data" -U "$DB_USER" \
    --pwfile=/tmp/sakinah-pgpw -E UTF8 --locale=C -A scram-sha-256
  rm -f /tmp/sakinah-pgpw
fi

echo "• Démarrage de PostgreSQL…"
"$PGDIR/bin/pg_ctl" -D "$PGDIR/data" -l "$PGDIR/pg.log" \
  -o "-p $DB_URL_PORT -c listen_addresses=$DB_URL_HOST" start

# Attendre que le serveur accepte les connexions (max ~10 s).
for _ in $(seq 1 20); do
  if (exec 3<>/dev/tcp/$DB_URL_HOST/$DB_URL_PORT) 2>/dev/null; then
    exec 3<&- 3>&-
    break
  fi
  sleep 0.5
done

# Créer la base « sakinah » si absente (psql n'est pas livré par la
# distribution portable : on passe par prisma db execute).
cd "$(dirname "$0")/.."
echo "SELECT 'CREATE DATABASE $DB_NAME' WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = '$DB_NAME');" \
  | bunx prisma db execute --stdin \
    --url "postgresql://$DB_USER:$DB_PASSWORD@$DB_URL_HOST:$DB_URL_PORT/postgres" >/dev/null || true

echo "✓ PostgreSQL prêt : postgresql://$DB_USER:••••@$DB_URL_HOST:$DB_URL_PORT/$DB_NAME"
