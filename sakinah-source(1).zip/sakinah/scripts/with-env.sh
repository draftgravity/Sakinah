#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# with-env.sh — exécute une commande en neutralisant une éventuelle
# DATABASE_URL obsolète de type SQLite (« file:… ») héritée de
# l'environnement, qui écraserait sinon le .env du projet.
#
# Une URL PostgreSQL/Postgres légitime est TOUJOURS conservée (déploiement
# Vercel/Railway : la variable d'environnement reste prioritaire, comme
# attendu). Ce garde-fou ne concerne que les vieilles valeurs « file: ».
#
# Usage : bash scripts/with-env.sh <commande> [args…]
#   ex.  : bash scripts/with-env.sh prisma db push
# ---------------------------------------------------------------------------
if [[ "${DATABASE_URL:-}" == file:* ]]; then
  unset DATABASE_URL
fi
exec bun "$@"
